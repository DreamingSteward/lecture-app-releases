# 강의록앱 실행기 (Windows 바로가기·작업 스케줄러용). 작업 폴더와 상관없이 앱을 찾아서 실행.
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
# pythonw 로 실행하면 sys.stdout/stderr 가 None 이라 오류 메시지를 쓰다 앱이 멈춤 → 기록 파일로 보냄
if sys.stdout is None or sys.stderr is None:
    try:
        _d = os.path.join(os.path.dirname(os.path.abspath(__file__)), "logs")
        os.makedirs(_d, exist_ok=True)
        _f = open(os.path.join(_d, "화면오류.log"), "a", encoding="utf-8", buffering=1)
    except Exception:
        _f = open(os.devnull, "w")
    if sys.stdout is None:
        sys.stdout = _f
    if sys.stderr is None:
        sys.stderr = _f
from lecture_app.main import main  # noqa: E402

sys.exit(main(sys.argv[1:]))
