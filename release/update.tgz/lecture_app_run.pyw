# 강의록앱 실행기 (Windows 바로가기·작업 스케줄러용). 작업 폴더와 상관없이 앱을 찾아서 실행.
import os
import sys

_APP = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _APP)
# pythonw 로 실행하면 sys.stdout/stderr 가 None 이라 오류 메시지를 쓰다 앱이 멈춤 → 기록 파일로 보냄
if sys.stdout is None or sys.stderr is None:
    try:
        _d = os.path.join(_APP, "logs")
        os.makedirs(_d, exist_ok=True)
        _f = open(os.path.join(_d, "화면오류.log"), "a", encoding="utf-8", buffering=1)
    except Exception:
        _f = open(os.devnull, "w")
    if sys.stdout is None:
        sys.stdout = _f
    if sys.stderr is None:
        sys.stderr = _f


def _log(msg):
    try:
        import time
        os.makedirs(os.path.join(_APP, "logs"), exist_ok=True)
        with open(os.path.join(_APP, "logs", "업데이트.log"), "a", encoding="utf-8") as f:
            f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} [실행기] {msg}\n")
    except Exception:
        pass


def _aside(code):
    """망가진 앱 폴더는 지우지 않고 옆으로 (나중에 원인 확인용)"""
    import time
    if os.path.exists(code):
        os.replace(code, os.path.join(_APP, f"lecture_app_실패_{int(time.time())}"))


def _recover():
    """업데이트 도중 전원이 꺼져 lecture_app 폴더가 없거나 비었으면 직전 버전으로 되살림 (개발 폴더는 건드리지 않음)"""
    import glob
    import shutil
    code = os.path.join(_APP, "lecture_app")
    if os.path.isfile(os.path.join(code, "__main__.py")) or os.path.exists(os.path.join(_APP, ".git")):
        return
    try:
        olds = [d for d in sorted(glob.glob(os.path.join(_APP, "lecture_app_이전_*")), reverse=True)
                if os.path.isfile(os.path.join(d, "__main__.py"))]
        bak = os.path.join(_APP, "logs", "업데이트_이전", "lecture_app")
        if olds:
            _aside(code)
            os.replace(olds[0], code)
            _log(f"앱 폴더가 없어서 {os.path.basename(olds[0])} 를 제자리로 되살림")
        elif os.path.isfile(os.path.join(bak, "__main__.py")):
            _aside(code)
            shutil.copytree(bak, code)
            _log("앱 폴더가 없어서 logs/업데이트_이전 백업으로 되살림")
    except Exception as e:
        _log(f"앱 폴더 되살리기 실패: {e}")


def _rollback_after_update(e) -> bool:
    """방금(7일 안) 업데이트한 새 코드가 켜자마자(불러오기에서) 죽으면 직전 버전으로 한 번 되돌림 · 그 버전은 다시 자동으로 깔지 않음"""
    import json
    import shutil
    import time
    if os.path.exists(os.path.join(_APP, ".git")):
        return False
    st_f = os.path.join(_APP, "logs", "업데이트.json")
    bdir = os.path.join(_APP, "logs", "업데이트_이전")
    try:
        with open(st_f, encoding="utf-8") as f:
            st = json.load(f)
        with open(os.path.join(_APP, "VERSION"), encoding="utf-8") as f:
            cur = f.read().strip()
        with open(os.path.join(bdir, "VERSION"), encoding="utf-8") as f:
            bver = f.read().strip()
        last = st.get("last") or {}
        mt = os.path.getmtime(os.path.join(_APP, "VERSION"))
        if not (last.get("to") == cur and last.get("from") == bver and bver != cur
                and os.path.isfile(os.path.join(bdir, "lecture_app", "__main__.py")) and time.time() - mt < 7 * 86400):
            return False
        code = os.path.join(_APP, "lecture_app")
        tmp = os.path.join(_APP, f"lecture_app_되돌림_{os.getpid()}")
        shutil.rmtree(tmp, ignore_errors=True)
        shutil.copytree(os.path.join(bdir, "lecture_app"), tmp)
        _aside(code)
        os.replace(tmp, code)
        for n in ("requirements.txt", "VERSION"):          # 실행기(이 파일)는 지금 쓰는 중이라 그대로
            if os.path.isfile(os.path.join(bdir, n)):
                shutil.copy2(os.path.join(bdir, n), os.path.join(_APP, n))
        st["later"] = {"version": cur, "until": time.time() + 60 * 86400, "why": "rollback"}
        st.pop("schedule", None)
        st.pop("last", None)
        with open(st_f + ".tmp", "w", encoding="utf-8") as f:
            json.dump(st, f, ensure_ascii=False)
        os.replace(st_f + ".tmp", st_f)
        _log(f"새 버전 {cur} 가 켜지지 않아 {bver} 로 되돌림: {type(e).__name__}: {str(e)[:200]}")
        return True
    except Exception as e2:
        _log(f"켜지지 않는 새 버전을 되돌리지 못함: {e2}")
        return False


_recover()
try:
    from lecture_app.main import main  # noqa: E402
except Exception as _e:
    if not _rollback_after_update(_e):
        raise
    for _m in [m for m in sys.modules if m == "lecture_app" or m.startswith("lecture_app.")]:
        del sys.modules[_m]
    import importlib
    importlib.invalidate_caches()
    from lecture_app.main import main  # noqa: E402

sys.exit(main(sys.argv[1:]))
