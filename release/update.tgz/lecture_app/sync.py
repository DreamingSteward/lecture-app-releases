"""내 구글 드라이브 「강의록앱/_상태」 동기화 (권한: 앱이 만든 파일만 · drive.file)

· 담는 것: 시간표 · 옮긴 강의 · 시험 제외(✕) · 현황 · 화면 설정 · 일부 설정 · 학교 인증 상태 · 터널 주소
· 안 담는 것 (기기마다): 학년 드라이브 링크 · LMS 비밀번호 · 저장 폴더 경로 · 노션 연결
· 합치기: 항목마다 고친 시각(t)을 같이 저장 → 항목별로 마지막에 고친 쪽이 이김
  처음 동기화하는 기기(그 항목 기록이 없음)는 드라이브에 있는 값을 먼저 받음
· 기기 목록(devices): 같은 구글 계정으로 로그인한 기기 {id: {name, kind, app, seen, out}} — 기기마다 따로 합침
  「연결 끊기」 = out 표시 → 그 기기가 다음 동기화 때 스스로 로그아웃
· 언제: 앱을 켤 때 · 30초마다 바뀐 게 있는지 보고 바뀌었으면 · 10분마다 (드라이브에서 받아오기)
"""
from __future__ import annotations

import hashlib
import json
import threading
import time
from pathlib import Path
from typing import Dict, Optional

API = "https://www.googleapis.com/drive/v3"
UP = "https://www.googleapis.com/upload/drive/v3"
FOLDER = "강의록앱"
NAME = "_상태"
TAG = "la_state"                       # appProperties 로 우리 파일 찾기

# 기기와 상관없는 설정 + 학년 드라이브 연결 (첫 설정 「다른 기기에서 쓰던 게 있어요」에서 가져옴 · 내 드라이브의 내 파일에만)
# 저장 폴더 · LMS · 노션 · 원격 · 받아 두기/인터넷으로만(drive_mode)은 기기마다
CFG_KEYS = ("schedule", "cover", "cover_template", "paper", "split_name", "keep_orig", "extras", "extras_label",
            "board_include", "name_fmt", "tt_label", "menubar",
            "drive_root", "drive_semester", "drive_sem_id", "drive_sem_label", "drive_course_map", "drive_course_map_root",
            "drive_manual_map", "drive_extras_map", "drive_extras", "extras_old", "extras_order")
DATA_FILES = ("시간표.json", "옮긴강의.json", "시험제외.json", "현황.json")
PUSH_ONLY = {"tunnel", "pair", "cloud"}   # 이 컴퓨터 것 — 받아서 덮어쓰지 않음 (pair = 웹앱이 터널에 코드 없이 붙는 계정 열쇠 · cloud = 구글 드라이브 복사 켜짐)
ASK_KEYS = {"ask:cloud"}               # 웹앱이 컴퓨터에 부탁하는 것 (캔버스 P14 「컴퓨터가 꺼져 있어도 보기」) — 받기만 · 컴퓨터 화면에서 사용자에게 물어봄

SEEN_EVERY = 3600                      # 「마지막 사용」은 1시간에 한 번만 고침 (그것 때문에 매번 올리지 않게)

_LOCK = threading.Lock()
_ST: Dict[str, object] = {"busy": False, "last": 0.0, "err": "", "pushed": 0, "pulled": 0}


def _h(v) -> str:
    return hashlib.sha256(json.dumps(v, ensure_ascii=False, sort_keys=True).encode()).hexdigest()[:16]


class StateSync:
    def __init__(self, M, acct):
        self.M, self.acct = M, acct
        self.path = M.APP / ".sync.json"
        self._seen: Optional[Dict[str, str]] = None     # 마지막으로 본 로컬 해시 (30초 확인용)

    # ------------------------------------------------------------ 기록
    def _rec(self) -> dict:
        try:
            d = json.loads(self.path.read_text("utf-8"))
            return d if isinstance(d, dict) else {}
        except Exception:
            return {}

    def _rec_save(self, d: dict):
        tmp = self.path.with_name(".sync.tmp")
        tmp.write_text(json.dumps(d, ensure_ascii=False, indent=1), "utf-8")
        self.M.safe_replace(tmp, self.path)

    # ------------------------------------------------------------ 로컬 항목
    def _data_rel(self, name: str) -> str:
        try:
            return str((self.M.DATA / name).relative_to(self.M.APP))
        except ValueError:
            return name

    def collect(self) -> Dict[str, object]:
        M, out = self.M, {}
        for n in DATA_FILES:
            out["file:" + self._data_rel(n)] = self._read(M.DATA / n)
        out["file:화면설정.json"] = self._read(M.APP / "화면설정.json")
        cfg = M.read_cfg()
        for k in CFG_KEYS:
            out["cfg:" + k] = cfg.get(k)
        out["tunnel"] = (cfg.get("remote") or {}).get("tunnel_url") or None
        try:
            from . import remote as R
            out["pair"] = (R.acct_key() or None) if out["tunnel"] else None
        except Exception:
            out["pair"] = None
        try:
            from . import cloud as _cl
            g = _cl._cfg(cfg).get("gdrive") or {}
            out["cloud"] = {"on": bool(isinstance(g, dict) and g.get("on") and g.get("dir"))}
        except Exception:
            out["cloud"] = None
        a = self.acct._st()
        out["acct"] = {k: a.get(k) for k in ("verified", "method", "consent") if a.get(k) not in (None, "")} or None
        return out

    @staticmethod
    def _read(p: Path):
        try:
            return json.loads(p.read_text("utf-8"))
        except Exception:
            return None

    def apply(self, key: str, v):
        M = self.M
        if key in PUSH_ONLY:
            return
        if key.startswith("file:"):
            rel = key[5:]
            p = (M.APP / rel).resolve()
            app = M.APP.resolve()
            parts = Path(rel).parts
            ok_name = p.name in DATA_FILES or rel == "화면설정.json"
            ok_place = len(parts) == 1 or (len(parts) == 3 and parts[0] == "학년" and ".." not in parts)
            if not ok_name or not ok_place or not (p.parent == app or p.parent.parent.parent == app):
                return                                   # 정해진 기록 파일만 (앱 폴더 밖 · account.json 같은 다른 파일은 쓰지 않음)
            if v is None:
                try:
                    p.unlink()
                except FileNotFoundError:
                    pass
                return
            p.parent.mkdir(parents=True, exist_ok=True)
            tmp = p.with_name(p.stem + ".sync.tmp")
            tmp.write_text(json.dumps(v, ensure_ascii=False, indent=1), "utf-8")
            M.safe_replace(tmp, p)
        elif key.startswith("cfg:"):
            k = key[4:]
            if k not in CFG_KEYS:
                return
            with M.CFG_LOCK:
                cfg = M.read_cfg()
                if v is None:
                    cfg.pop(k, None)
                else:
                    cfg[k] = v
                M.write_cfg(cfg)
        elif key == "acct" and isinstance(v, dict):
            self.acct._save(**{k: v.get(k) for k in ("verified", "method", "consent")})
        elif key == "ask:cloud" and isinstance(v, dict):
            # 웹앱(폰)에서 「컴퓨터가 꺼져 있어도 보기」 → 조용히 켜지 않고 컴퓨터 화면 · 알림으로 물어봄 (gui.py cloud_ask)
            with M.CFG_LOCK:
                cfg = M.read_cfg()
                g = ((cfg.get("cloud_copy") or {}).get("gdrive") or {})
                if not (isinstance(g, dict) and g.get("on")):
                    cfg["cloud_ask"] = {"at": float(v.get("at") or time.time()), "from": str(v.get("from") or "폰")[:40]}
                    M.write_cfg(cfg)
                    try:
                        from . import notifier
                        notifier.notify("강의록앱 · 내 구글 드라이브에 복사할까요?",
                                        f"{cfg['cloud_ask']['from']}에서 「컴퓨터가 꺼져 있어도 보기」를 눌렀어요. 강의록앱을 열어 켜 주세요.")
                    except Exception:
                        pass

    # ------------------------------------------------------------ 기기 목록
    def device_id(self) -> str:
        p = self.M.APP / ".device_id"
        try:
            d = p.read_text("utf-8").strip()
            if d:
                return d
        except Exception:
            pass
        import uuid
        d = uuid.uuid4().hex[:12]
        try:
            p.write_text(d, "utf-8")
        except Exception:
            pass
        return d

    @staticmethod
    def device_me() -> dict:
        import platform
        import socket
        kind = {"Darwin": "mac", "Windows": "win"}.get(platform.system(), "pc")
        name = ""
        if kind == "mac":
            try:
                import subprocess
                name = subprocess.run(["scutil", "--get", "ComputerName"], capture_output=True, text=True, timeout=3).stdout.strip()
            except Exception:
                name = ""
        if not name:
            name = socket.gethostname().split(".")[0]
        return {"name": name[:40] or ("맥" if kind == "mac" else "PC"), "kind": kind, "app": "강의록앱"}

    def _merge_devices(self, remote: dict, mine: dict, now: float, me: str) -> tuple:
        """기기마다 seen 이 큰 쪽 · out 은 한쪽이라도 있으면 남음. (합친 목록, 바뀌었나, 나를 끊었나)"""
        out = {}
        for k in set(remote) | set(mine):
            a, b = remote.get(k) if isinstance(remote.get(k), dict) else None, mine.get(k) if isinstance(mine.get(k), dict) else None
            if not a and not b:
                continue
            xs = sorted([x for x in (a, b) if x], key=lambda x: float(x.get("seen") or 0))
            e = {**xs[0], **xs[-1]}                      # 모르는 칸(웹앱이 더한 것)도 남기고 · 겹치면 seen 이 큰 쪽
            if (a or {}).get("out") or (b or {}).get("out"):
                e["out"] = max(float((a or {}).get("out") or 0), float((b or {}).get("out") or 0)) or now
            out[k] = e
        kicked = bool((out.get(me) or {}).get("out"))
        if not kicked:
            cur = out.get(me) or {}
            if now - float(cur.get("seen") or 0) > SEEN_EVERY or {k: cur.get(k) for k in ("name", "kind", "app")} != self.device_me():
                out[me] = {**self.device_me(), "seen": now}
        changed = _h(out) != _h(remote)
        return out, changed, kicked

    def devices(self) -> dict:
        rec, me = self._rec(), self.device_id()
        ds = rec.get("devices") if isinstance(rec.get("devices"), dict) else {}
        rows = [{"id": k, **{x: v.get(x) for x in ("name", "kind", "app", "seen")}, "me": k == me}
                for k, v in ds.items() if isinstance(v, dict) and not v.get("out")]
        if not any(r["me"] for r in rows):
            rows.append({"id": me, **self.device_me(), "seen": time.time(), "me": True})
        rows.sort(key=lambda r: (not r["me"], -float(r.get("seen") or 0)))
        return {"ok": True, "devices": rows, "last": rec.get("last") or 0}

    def kick(self, b: dict) -> dict:
        """다른 기기 연결 끊기 (b = {"id"} 하나 · {"all": true} 이 기기 빼고 모두)"""
        rec, me, now = self._rec(), self.device_id(), time.time()
        ds = rec.get("devices") if isinstance(rec.get("devices"), dict) else {}
        ids = [k for k in ds if k != me] if b.get("all") else [str(b.get("id") or "")]
        n = 0
        for k in ids:
            if k and k != me and isinstance(ds.get(k), dict):
                ds[k]["out"] = now
                n += 1
        rec["devices"] = ds
        self._rec_save(rec)
        r = self.sync_once()
        return {**self.devices(), "kicked": n, "synced": bool(r.get("ok")), "msg": r.get("msg", "")}

    def leave(self):
        """이 기기에서 로그아웃: 목록에서 나를 빼고 올린 뒤 기록 지우기"""
        try:
            rec, me = self._rec(), self.device_id()
            ds = rec.get("devices") if isinstance(rec.get("devices"), dict) else {}
            if me in ds:
                ds[me]["out"] = time.time()
                rec["devices"] = ds
                self._rec_save(rec)
                self.sync_once()
        except Exception:
            pass
        for f in (self.path, self.M.APP / ".device_id"):
            try:
                f.unlink()
            except Exception:
                pass
        self._seen = None

    # ------------------------------------------------------------ 드라이브
    def _req(self, method: str, url: str, at: str, **kw):
        import requests
        r = requests.request(method, url, headers={"Authorization": "Bearer " + at, **kw.pop("headers", {})}, timeout=30, **kw)
        if r.status_code == 401:
            raise PermissionError("구글 로그인이 만료됐어요")
        if r.status_code == 403:
            raise PermissionError("드라이브 권한이 없어요 (다시 로그인해 주세요)")
        r.raise_for_status()
        return r

    def _find(self, at: str, q: str) -> Optional[str]:
        r = self._req("GET", API + "/files", at, params={"q": q + " and trashed=false", "fields": "files(id,modifiedTime)",
                                                          "orderBy": "modifiedTime desc", "pageSize": 5, "spaces": "drive"})
        f = r.json().get("files") or []
        return f[0]["id"] if f else None

    def _ids(self, at: str, rec: dict):
        fid, did = rec.get("folder"), rec.get("file")
        if not did:
            did = self._find(at, f"appProperties has {{ key='{TAG}' and value='file' }}")
        if not did and not fid:
            fid = self._find(at, f"appProperties has {{ key='{TAG}' and value='folder' }}")
        if not did and not fid:
            r = self._req("POST", API + "/files", at, json={"name": FOLDER, "mimeType": "application/vnd.google-apps.folder",
                                                             "appProperties": {TAG: "folder"}}, params={"fields": "id"})
            fid = r.json()["id"]
        return fid, did

    def _download(self, at: str, did: str) -> dict:
        r = self._req("GET", f"{API}/files/{did}", at, params={"alt": "media"})
        try:
            d = r.json()
            return d if isinstance(d, dict) else {}
        except Exception:
            return {}

    def _upload(self, at: str, did: Optional[str], fid: Optional[str], body: dict) -> str:
        data = json.dumps(body, ensure_ascii=False).encode()
        if did:
            r = self._req("PATCH", f"{UP}/files/{did}", at, params={"uploadType": "media", "fields": "id"},
                          data=data, headers={"Content-Type": "application/json"})
            return r.json()["id"]
        meta = {"name": NAME, "mimeType": "application/json", "appProperties": {TAG: "file"}, **({"parents": [fid]} if fid else {})}
        bd = "la" + hashlib.md5(data).hexdigest()
        payload = (f"--{bd}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n{json.dumps(meta, ensure_ascii=False)}\r\n"
                   f"--{bd}\r\nContent-Type: application/json\r\n\r\n").encode() + data + f"\r\n--{bd}--".encode()
        r = self._req("POST", f"{UP}/files", at, params={"uploadType": "multipart", "fields": "id"},
                      data=payload, headers={"Content-Type": f"multipart/related; boundary={bd}"})
        return r.json()["id"]

    # ------------------------------------------------------------ 한 번 맞추기
    @staticmethod
    def _item(key: str, r: Optional[dict], t: float, v) -> dict:
        """올릴 항목: 드라이브 항목의 모르는 칸은 그대로 두고 t · v 만 바꿈
        · web / x = 웹앱이 올린 시간표 표시 · 시험 일정 묶음 → 컴퓨터 시간표로 바뀌면 뺌
        · kt = 화면 설정 키마다 고친 시각 (웹앱이 키별로 합침) → 바뀐 키만 지금 시각"""
        r = r if isinstance(r, dict) else {}
        e = {k: x for k, x in r.items() if k not in ("t", "v", "web", "x", "kt")}
        e.update(t=t, v=v)
        if key == "file:화면설정.json" and isinstance(v, dict):
            rv = r.get("v") if isinstance(r.get("v"), dict) else {}
            kt = r.get("kt") if isinstance(r.get("kt"), dict) else {}
            rt = float(r.get("t") or 0)
            e["kt"] = {x: (float(kt.get(x) or rt) if x in rv and rv.get(x) == v.get(x) else t) for x in v}
        return e

    def sync_once(self) -> dict:
        if not _LOCK.acquire(blocking=False):
            return {"ok": True, "busy": True}
        _ST["busy"] = True
        try:
            at = self.acct.access_token()
            if not at:
                _ST["err"] = "구글 로그인(드라이브 권한)이 필요해요"
                return {"ok": False, "msg": _ST["err"]}
            rec = self._rec()
            fid, did = self._ids(at, rec)
            remote = self._download(at, did) if did else {}
            ritems = remote.get("items") if isinstance(remote.get("items"), dict) else {}
            if not rec.get("chosen") and not rec.get("last"):
                try:
                    shared = self.M.read_cfg().get("shared_pc") is True
                except Exception:
                    shared = False
                if ritems or shared:                     # 공용 PC 는 드라이브가 비어 있어도 묻기 (앞사람 기록이 올라가지 않게)                               # 이 기기 첫 동기화인데 드라이브에 다른 기기 기록이 있음 → 덮어쓰지 않고 고르게 함 (adopt)
                    _ST["err"] = ""
                    _ST["need_choice"] = True
                    _ST["remote_empty"] = not ritems
                    return {"ok": True, "need_choice": True, "remote_empty": not ritems}
                rec["chosen"] = True                     # 드라이브가 비어 있음 = 첫 기기 → 그냥 올림
            local = self.collect()
            mine = rec.get("items") if isinstance(rec.get("items"), dict) else {}
            now = time.time()
            push = pulled = 0
            me = self.device_id()
            ldev = rec.get("devices") if isinstance(rec.get("devices"), dict) else {}
            rs = remote.get("reset") if isinstance(remote.get("reset"), dict) else {}
            rst = float(rs.get("t") or 0)
            fresh = bool(rec.get("fresh"))
            took = False
            if fresh:                                    # 이 컴퓨터에서 「새로 시작」 (adopt fresh): 드라이브를 이 컴퓨터 것으로 새로 · 웹앱 WEBSYNC 와 같은 뜻
                ritems.clear()                           # 예전 기록은 adopt 가 「_상태 (이전 날짜)」로 남겨 둠
                remote["devices"] = {k: d for k, d in (remote.get("devices") or {}).items() if isinstance(d, dict) and d.get("out")}
                ldev = {}
                remote["reset"] = {"t": now, "id": me}
                rec["epoch"] = now
            elif rst and rec.get("last") and rs.get("id") != me and rst != float(rec.get("epoch") or 0) and rst > float(rec.get("last") or 0):
                # 다른 기기가 「새로 시작」함 (내 마지막 맞춤 뒤) → 웹앱 take 처럼 받기만: 드라이브 값을 받고 · 안 올린 변경은 버림
                # · 드라이브에 없는 이 컴퓨터 값은 그대로 두고 올리지 않음(고치면 그때 올림) · 예전 기기 목록은 다시 섞지 않음
                took = True
                rec["epoch"] = rst
                mine = {k: x for k, x in mine.items() if k in ASK_KEYS}
                ldev = {}
            for key in sorted(set(local) | set(ritems)):
                r = ritems.get(key) if isinstance(ritems.get(key), dict) else None
                if key in PUSH_ONLY and local.get(key) is None:
                    continue                                                    # 이 기기엔 없음 (다른 컴퓨터 주소는 그대로)
                if key in local:
                    lv, lh = local[key], _h(local[key])
                    m = mine.get(key)
                    if r is None and key not in PUSH_ONLY and key != "acct":
                        if took:                                                # 새로 시작한 기기 드라이브에 없음 → 그대로 둠
                            mine[key] = {"h": lh, "t": 0, "hold": 1}
                            continue
                        if m and m.get("hold") and m.get("h") == lh:            # 그 뒤로 안 고침 → 계속 안 올림
                            continue
                    lt = float(m["t"]) if m and m.get("h") == lh and not m.get("hold") else now      # 지난번 이후 여기서 고쳤으면 지금 시각
                    if r and _h(r.get("v")) == lh:
                        mine[key] = {"h": lh, "t": max(lt, float(r.get("t") or 0))}
                        continue
                    if r and key not in PUSH_ONLY and (m is None or float(r.get("t") or 0) > lt):
                        self.apply(key, r.get("v"))                              # 드라이브 쪽이 더 나중 (또는 이 기기 첫 동기화)
                        mine[key] = {"h": _h(r.get("v")), "t": float(r.get("t") or now)}
                        pulled += 1
                    else:
                        ritems[key] = self._item(key, r, lt, lv)                # 모르는 칸(kt 등)은 남김
                        mine[key] = {"h": lh, "t": lt}
                        push += 1
                elif r and key in ASK_KEYS:                                    # 웹앱의 부탁: 새것만 한 번
                    m = mine.get(key) or {}
                    if float(r.get("t") or 0) > float(m.get("t") or 0):
                        if m:                                                  # 이 기기 첫 동기화 때 예전 부탁은 묻지 않음
                            self.apply(key, r.get("v"))
                        elif now - float(r.get("t") or 0) < 3 * 86400:
                            self.apply(key, r.get("v"))
                        mine[key] = {"t": float(r.get("t") or 0)}
                        pulled += 1
                elif r and key.startswith("file:") and key not in PUSH_ONLY:   # 다른 학년 파일 등 이 기기에 없는 항목
                    continue
            rdev = remote.get("devices") if isinstance(remote.get("devices"), dict) else {}
            if took or fresh:                            # 새로 시작 뒤: 드라이브 목록 + 끊은 표시만 (예전 기기를 다시 넣지 않음)
                ldev = {k: d for k, d in (rec.get("devices") or {}).items() if isinstance(d, dict) and d.get("out")}
            devs, dchg, kicked = self._merge_devices(rdev, ldev, now, me)
            devs = {k: v for k, v in devs.items() if not v.get("out") or now - float(v["out"]) < 90 * 86400}   # 끊은 지 90일 지난 기록은 정리
            rec["devices"] = devs
            if kicked:                                   # 다른 기기에서 이 기기 연결을 끊었음 → 로그아웃
                self._rec_save(rec)
                self.acct.logout()
                for f in (self.path, self.M.APP / ".device_id"):
                    try:
                        f.unlink()
                    except Exception:
                        pass
                _ST.update(err="다른 기기에서 이 기기의 연결을 끊었어요. 다시 로그인해 주세요.")
                return {"ok": False, "kicked": True, "msg": _ST["err"]}
            if push or dchg or not did or fresh:
                # 맨 위의 모르는 칸(웹앱 reset 등)은 그대로 둠
                body = {**{k: x for k, x in remote.items() if k not in ("items", "devices")},
                        "v": 1, "app": "강의록앱", "updated": now, "items": ritems, "devices": devs}
                did = self._upload(at, did, fid, body)
            rec.pop("fresh", None)
            rec.update(folder=fid, file=did, items=mine, last=now)
            _ST["note"] = "다른 기기에서 「새로 시작」해서 그 기기 기록을 받았어요" if took else ""
            self._rec_save(rec)
            self._seen = {k: _h(v) for k, v in self.collect().items()}
            _ST.update(last=now, err="", pushed=push, pulled=pulled)
            return {"ok": True, "pushed": push, "pulled": pulled}
        except Exception as e:
            _ST["err"] = str(e) if isinstance(e, PermissionError) else f"동기화 실패 ({type(e).__name__})"
            return {"ok": False, "msg": _ST["err"]}
        finally:
            _ST["busy"] = False
            _LOCK.release()

    # ------------------------------------------------------------ 첫 설정: 다른 기기 기록 미리 보기 · 이어받기 · 새로 시작
    def peek(self) -> dict:
        """드라이브의 _상태를 받기만 하고(이 기기에 적용 안 함) 요약을 돌려줌"""
        at = self.acct.access_token()
        if not at:
            return {"ok": False, "found": False, "msg": "구글 로그인(드라이브 권한)이 필요해요"}
        try:
            rec = self._rec()
            fid, did = self._ids(at, rec)
            if not did:
                return {"ok": True, "found": False}
            b = self._download(at, did)
        except Exception as e:
            return {"ok": False, "found": False, "msg": str(e) if isinstance(e, PermissionError) else f"기록을 확인하지 못했어요 ({type(e).__name__})"}
        it = b.get("items") if isinstance(b.get("items"), dict) else {}
        v = lambda k: (it.get(k) or {}).get("v") if isinstance(it.get(k), dict) else None
        tt = next((x.get("v") for k, x in it.items() if k.startswith("file:") and k.endswith("시간표.json") and isinstance(x, dict) and x.get("v")), None) or []
        tt = tt.get("courses") if isinstance(tt, dict) else tt
        tt = tt if isinstance(tt, list) else []
        courses = sorted({str(c.get("name") or c.get("course") or "") for c in tt if isinstance(c, dict)} - {""})
        n_lec = sum(len(c.get("lectures") or c.get("rows") or []) for c in tt if isinstance(c, dict))
        me = self.device_id()
        devs = [d for k, d in (b.get("devices") or {}).items() if isinstance(d, dict) and not d.get("out") and k != me]
        last = max(devs, key=lambda d: float(d.get("seen") or 0)) if devs else None
        a = v("acct") or {}
        xs = next((x.get("v") for k, x in it.items() if k.endswith("시험제외.json") and isinstance(x, dict)), None) or []
        mv = next((x.get("v") for k, x in it.items() if k.endswith("옮긴강의.json") and isinstance(x, dict)), None) or {}
        olds = v("cfg:extras_old") or []
        return {"ok": True, "found": bool(it), "updated": b.get("updated") or 0,
                "last": {k: last.get(k) for k in ("name", "kind", "app", "seen")} if last else None,
                "courses": len(courses), "course_names": courses[:3], "lectures": n_lec,
                "xskip": len(xs) if isinstance(xs, list) else 0, "moved": len(mv) if isinstance(mv, dict) else 0,
                "verified": bool(a.get("verified")), "method": a.get("method") or "",
                "drive": bool(v("cfg:drive_root")), "drive_sem": v("cfg:drive_sem_label") or "",
                "extras_label": v("cfg:extras_label") or "",
                "olds": [str(o.get("label")) for o in olds if isinstance(o, dict)][:5],
                "schedule": bool(v("cfg:schedule")),
                # 다른 기기에서 켠 내 드라이브 복사 (다른 컴퓨터 cloud · 웹앱 P09 webbk) → 첫 설정 C16 「이어서 해요」 (묻지 않음)
                "copy_on": bool((v("cloud") or {}).get("on")) or bool((v("webbk") or {}).get("on"))}

    def adopt(self, b: dict) -> dict:
        """take = 드라이브 기록을 이 기기로 가져옴 / fresh = 드라이브 기록은 「_상태 (이전 …)」로 남기고 이 기기 것으로 새로 시작"""
        if b.get("mode") == "fresh":
            at = self.acct.access_token()
            if not at:
                return {"ok": False, "msg": "구글 로그인(드라이브 권한)이 필요해요"}
            rec = self._rec()
            try:
                fid, did = self._ids(at, rec)
                if did:                                   # 예전 기록은 지우지 않고 사본으로 남김
                    import datetime
                    self._req("POST", f"{API}/files/{did}/copy", at, params={"fields": "id"},
                              json={"name": f"{NAME} (이전 {datetime.date.today():%Y-%m-%d})", "appProperties": {TAG: "old"}})
            except Exception as e:
                return {"ok": False, "msg": f"예전 기록을 남기지 못해서 멈췄어요 ({type(e).__name__})"}
            now = time.time()
            rec["items"] = {k: {"h": _h(v), "t": now + 1} for k, v in self.collect().items()}   # 이 기기 값이 이김
            rec["chosen"] = True
            rec["fresh"] = now                            # 다음 맞춤: 드라이브를 이 기기 것으로 새로 + reset 표시 (다른 기기는 받기만)
            self._rec_save(rec)
        else:
            rec = self._rec()
            rec["items"] = {}                             # 기록 없음 = 처음 맞추는 기기 → 드라이브 값을 받음
            rec["chosen"] = True
            self._rec_save(rec)
        return self.sync_once()

    def changed(self) -> bool:
        cur = {k: _h(v) for k, v in self.collect().items()}
        if self._seen is None:
            self._seen = cur
            return True
        return cur != self._seen

    def state(self) -> dict:
        rec = self._rec()
        return {"ok": True, "on": bool(self.acct._st().get("drive")), "last": rec.get("last") or _ST["last"],
                "busy": _ST["busy"], "err": _ST["err"], "pushed": _ST["pushed"], "pulled": _ST["pulled"],
                "need_choice": bool(_ST.get("need_choice")) and not rec.get("chosen") and not rec.get("last"),
                "remote_empty": bool(_ST.get("remote_empty")), "note": _ST.get("note") or ""}

    # ------------------------------------------------------------ 계속 돌기
    def loop(self, stop: Optional[threading.Event] = None):
        stop = stop or threading.Event()
        last_full = 0.0
        time.sleep(5)
        while not stop.is_set():
            try:
                if self.acct._st().get("drive"):
                    if time.time() - last_full > 600 or self.changed():
                        time.sleep(0 if not last_full else 30)          # 고친 뒤 30초 모아서
                        self.sync_once()
                        last_full = time.time()
            except Exception:
                pass
            stop.wait(30)
