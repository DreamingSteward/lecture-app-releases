from . import _lazy as _lz  # 필요한 프로그램을 받기 전에도 앱 화면이 켜지게 (자리표시)
_lz.install()
