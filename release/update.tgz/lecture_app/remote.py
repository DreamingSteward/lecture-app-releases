"""휴대폰·아이패드에서 열기: 같은 와이파이(또는 핫스팟)의 다른 기기에서 강의록앱 화면을 보고 받기를 시작.

- 기본은 꺼져 있음. 설정에서 켜면 RPORT(8766)로 따로 문을 엶 (원래 화면 8765 는 이 컴퓨터만 그대로).
- 처음 접속한 기기는 이 컴퓨터 화면에 뜬 6자리 코드를 입력해야 함 → 기기마다 열쇠(쿠키)를 줌.
- 다른 기기에서 되는 것: 현황·받기 진행·기록 보기, 받기 시작·중지, PDF 보기. 설정·계정·파일 바꾸기는 안 됨.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import secrets
import socket
import subprocess
import sys
import threading
import time
from http.server import ThreadingHTTPServer
from pathlib import Path
from typing import List, Optional
from urllib.parse import parse_qs, quote, urlparse

from . import main as M

RPORT = 8766
COOKIE = "la_rt"
_SRV: List[Optional[ThreadingHTTPServer]] = [None]
# 연결 코드·QR 열쇠는 방법마다 따로 (같은 와이파이 / 밖에서)
_CODES = {"lan": {"code": "", "at": 0.0, "key": ""}, "tunnel": {"code": "", "at": 0.0, "key": ""}}
_FAILS: dict = {}
_GFAILS: list = []           # 모든 기기 합친 틀린 시각 (코드를 바꿔도 안 지움 → 밖에서 계속 맞혀 보기 막기)
G_WIN = 600
_TFAILS: list = []           # 터널(밖)에서 온 코드 실패 (1시간)
TUNNEL_FAIL_MAX = 10
_NEXT: dict = {}             # 홈 화면 앱용 한 번 쓰는 열쇠 → (만료 시각, 방법)
_LOCK = threading.Lock()

# 다른 기기용 서비스 워커: 컴퓨터가 꺼져도(터널이 끊겨도) 마지막으로 본 현황·열어 본 PDF를 보여 줌
# (https 주소 = 밖에서 열기 터널에서만 동작. 같은 와이파이 http 주소에선 브라우저가 서비스 워커를 안 씀)
REMOTE_SW = r"""
const C='la-r2', P='la-r1-pdf', MAXPDF=40;
const API=/^\/api\/(state|job|runs|run|remote\/me|remote|pending|decided|profs|settings|covers|tt|sched_runs|update|cloud)$/, LIVE=/^\/api\/(events|log|progress)$/;
const LIB=/^https:\/\/cdn\.jsdelivr\.net\/npm\/pdfjs-dist@3\.11\.174\//;
self.addEventListener('install',e=>{ self.skipWaiting(); e.waitUntil(caches.open(C).then(c=>c.addAll(['/manifest.webmanifest','/icon-192.png'])).catch(()=>{})); });
self.addEventListener('activate',e=>e.waitUntil((async()=>{ for(const k of await caches.keys()) if(k!==C&&k!==P) await caches.delete(k); await self.clients.claim(); })()));
// 강의록앱이 보낸 응답에는 x-la-app 이 붙음 → 없으면(Cloudflare 오류 페이지 등) 번호와 상관없이 컴퓨터 꺼짐으로 봄
const down=r=>!r||r.type==='opaqueredirect'||!r.headers.get('x-la-app')||[502,503,504,520,521,522,523,524,530].includes(r.status);
function within(p,ms){ return new Promise((ok,no)=>{ const t=setTimeout(()=>no(new Error('timeout')),ms); p.then(v=>{clearTimeout(t);ok(v);},e=>{clearTimeout(t);no(e);}); }); }
async function stamp(r){ const h=new Headers(r.headers); h.set('x-la-at',String(Date.now())); h.delete('set-cookie'); const b=await r.clone().blob();
  const n=+(r.headers.get('content-length')||0); if(n&&b.size!==n) throw new Error('short');      // 중간에 끊긴 파일은 저장 안 함
  return new Response(b,{status:200,headers:h}); }
async function fromCache(cache,key){ const hit=await cache.match(key); if(!hit) return null; const h=new Headers(hit.headers); h.set('x-la-offline',hit.headers.get('x-la-at')||'1'); return new Response(await hit.blob(),{status:200,headers:h}); }
function offlineJson(){ return new Response(JSON.stringify({ok:false,offline:true,msg:'컴퓨터에 연결할 수 없어요'}),{status:503,headers:{'content-type':'application/json; charset=utf-8','x-la-offline':'0'}}); }
async function netFirst(req,key,ms,cacheName,keep){
  const cache=await caches.open(cacheName);
  try{
    const r=await within(fetch(req,{cache:'no-store'}),ms);
    if(down(r)) throw new Error('down');
    if(r.ok && (!keep||await keep(r.clone()))){ try{ await cache.put(key,await stamp(r)); if(cacheName===P) trim(cache); }catch(e){} }
    return r;
  }catch(e){
    return (await fromCache(cache,key)) || null;
  }
}
async function trim(cache){ const ks=await cache.keys(); for(let i=0;i<ks.length-MAXPDF;i++) await cache.delete(ks[i]); }
self.addEventListener('fetch',e=>{
  const req=e.request; if(req.method!=='GET') return;
  const u=new URL(req.url);
  if(LIB.test(req.url)){ e.respondWith(caches.open(C).then(async c=>{ const hit=await c.match(req.url); if(hit) return hit; const r=await fetch(req); if(r.ok) c.put(req.url,r.clone()); return r; })); return; }
  if(u.origin!==location.origin) return;
  if(u.pathname==='/remote/file'||u.pathname.startsWith('/remote/file/')){
    const rel=u.searchParams.get('rel')||''; const key='/remote/file?rel='+encodeURIComponent(rel);
    e.respondWith(netFirst(req,key,15000,P,async r=>/pdf/.test(r.headers.get('content-type')||'')).then(r=>r||offlineJson())); return; }
  if(u.pathname==='/remote/pfile'||u.pathname.startsWith('/remote/pfile/')){
    e.respondWith(netFirst(req,'/remote/pfile'+u.search,15000,P,async r=>/pdf/.test(r.headers.get('content-type')||'')).then(r=>r||offlineJson())); return; }
  if(u.pathname==='/'){
    e.respondWith(netFirst(req,'/',8000,C,async r=>/text\/html/.test(r.headers.get('content-type')||'')).then(r=>r||new Response('<meta charset=utf-8><meta name=viewport content="width=device-width"><body style="font-family:-apple-system,sans-serif;padding:24px;line-height:1.6"><h3>컴퓨터에 연결할 수 없어요</h3>컴퓨터가 켜져 있고 강의록앱이 실행 중인지 확인해 주세요.',{status:503,headers:{'content-type':'text/html; charset=utf-8'}}))); return; }
  if(LIVE.test(u.pathname)){              // 받기 중 실시간 기록: 저장 안 함 (꺼져 있으면 빈 내용)
    e.respondWith(within(fetch(req,{cache:'no-store'}),7000).then(r=>{ if(down(r)) throw 0; return r; }).catch(()=>new Response(JSON.stringify({text:'',offset:+(u.searchParams.get('offset')||0),offline:true}),{status:200,headers:{'content-type':'application/json; charset=utf-8','x-la-offline':'-1'}}))); return; }
  if(API.test(u.pathname)){
    const key=u.pathname+u.search;
    const keep=u.pathname==='/api/remote/me'?(async r=>{ let a=false; try{ a=!!(await r.json()).auth; }catch(x){}
      if(!a){ await caches.delete(C); await caches.delete(P); }      // 연결이 끊긴 기기: 저장해 둔 현황·PDF도 지움
      return a; }):null;
    e.respondWith(netFirst(req,key,7000,C,keep).then(r=>r||offlineJson())); return; }
  if(/^\/(icon-\d+\.png|manifest\.webmanifest|help-img\/)/.test(u.pathname)){
    e.respondWith(netFirst(req,u.pathname,6000,C).then(r=>r||fetch(req))); return; }
});
"""

GET_OK = {"/api/state", "/api/verq", "/api/merge", "/api/name", "/api/progress", "/api/job", "/api/log", "/api/events", "/api/runs", "/api/run",
          # 휴대폰에서 보기: 애매한 자료·강좌별 교수 (고르기·고치기도 됨) / 설정·예약·시간표·표지 (보기만)
          "/api/pending", "/api/decided", "/api/profs", "/api/settings", "/api/covers", "/api/cover/preview",
          "/api/font/file", "/api/tt", "/api/sched_runs", "/api/update", "/api/cloud"}
POST_OK = {"/api/start", "/api/stop"}          # 휴대폰에서 바꿀 수 있는 건 받기 시작·중지뿐 (나머지는 보기만)


# ---------------------------------------------------------------- 설정
def _cfg() -> dict:
    try:
        return dict(M.read_cfg().get("remote") or {})
    except Exception:
        return {}


def enabled() -> bool:
    """같은 와이파이에서 열기 (와이파이의 다른 기기에 문을 엶)"""
    return bool(_cfg().get("enabled"))


def tunnel_on() -> bool:
    return bool(_cfg().get("tunnel"))


def serving() -> bool:
    """다른 기기용 문(RPORT)이 필요한지: 와이파이 또는 밖에서 열기 중 하나라도 켜져 있으면"""
    r = _cfg()
    return bool(r.get("enabled")) or bool(r.get("tunnel"))


def mb_view() -> str:
    """메뉴 막대에 보일 QR: 둘 다 켜져 있으면 고른 쪽, 하나만 켜져 있으면 그쪽"""
    r = _cfg()
    lan, tn = bool(r.get("enabled")), bool(r.get("tunnel"))
    if lan and tn:
        return "tunnel" if r.get("mb_view") == "tunnel" else "lan"
    return "tunnel" if tn else ("lan" if lan else "")


def _hash(tok: str) -> str:
    return hashlib.sha256(tok.encode("utf-8")).hexdigest()


def _m(via: str) -> str:
    return "tunnel" if via == "tunnel" else "lan"


def new_code(via: str = "lan") -> str:
    with _LOCK:
        C = _CODES[_m(via)]
        C["code"] = f"{secrets.randbelow(1000000):06d}"
        C["key"] = secrets.token_urlsafe(18)          # QR 안에 들어가는 열쇠 (찍으면 코드 없이 연결)
        C["at"] = time.time()
        return C["code"]


CODE_TTL = 30 * 60          # 연결 코드는 30분이 지나면 새로 (화면에는 늘 지금 코드가 보여요)
FAIL_MAX = 20               # 모든 기기 합쳐서 이만큼 틀리면 코드를 새로 (주소를 바꿔 가며 맞혀 보는 것 막기)


def code(via: str = "lan") -> str:
    with _LOCK:
        C = _CODES[_m(via)]
        c = C["code"]
        old = c and time.time() - C["at"] > CODE_TTL
    return new_code(via) if (not c or old) else c


def qr_url(base: str, via: str = "lan") -> str:
    """QR 에 넣는 주소: 찍으면 코드 입력 없이 바로 연결 (# 뒤라 서버 기록에도 안 남음)"""
    code(via)
    return f"{base}/#k={_CODES[_m(via)]['key']}"


def _fail_key(ip: str) -> str:
    """틀린 횟수를 세는 단위: IPv4는 주소, IPv6는 앞 64비트(한 기기가 주소를 바꿔 가며 시도해도 같이 셈)"""
    try:
        import ipaddress
        a = ipaddress.ip_address(ip.split("%")[0])
        if a.version == 6 and not a.ipv4_mapped:
            return str(ipaddress.ip_network(f"{a}/64", strict=False))
    except Exception:
        pass
    return ip


def devices() -> list:
    """via: lan(같은 와이파이로 연결) / tunnel(밖에서 연결) / old(예전에 연결해 방법 기록이 없음)"""
    return [{"id": d.get("id"), "name": d.get("name", ""), "added": d.get("added", ""), "seen": d.get("seen", ""),
             "via": d.get("via") or "old"} for d in _cfg().get("devices") or []]


def _device_of(tok: str) -> Optional[dict]:
    if not tok:
        return None
    h = _hash(tok)
    for d in _cfg().get("devices") or []:
        if secrets.compare_digest(str(d.get("hash", "")), h):
            return d
    return None


def _add_device(name: str, via: str = "lan") -> str:
    tok = secrets.token_urlsafe(32)
    with M.CFG_LOCK:
        cfg = M.read_cfg()
        r = dict(cfg.get("remote") or {})
        devs = list(r.get("devices") or [])
        devs.append({"id": secrets.token_hex(4), "name": name[:40], "hash": _hash(tok), "via": _m(via),
                     "added": time.strftime("%Y-%m-%d %H:%M")})
        same = [d for d in devs if (d.get("via") or "old") == _m(via)]
        if len(same) > 10:                            # 방법마다 기기는 10개까지 (오래된 것부터 빼기)
            drop = {id(d) for d in same[:-10]}
            devs = [d for d in devs if id(d) not in drop]
        r["devices"] = devs[-30:]
        cfg["remote"] = r
        M.write_cfg(cfg)
    return tok


def forget(dev_id) -> int:
    """기기 연결 끊기 · dev_id: 하나 또는 여러 개(list) · 끊은 수"""
    ids = {str(x) for x in (dev_id if isinstance(dev_id, (list, tuple, set)) else [dev_id]) if x}
    with M.CFG_LOCK:
        cfg = M.read_cfg()
        r = dict(cfg.get("remote") or {})
        old = r.get("devices") or []
        devs = [d for d in old if d.get("id") not in ids]
        if len(devs) == len(old):
            return 0
        r["devices"] = devs
        cfg["remote"] = r
        M.write_cfg(cfg)
    return len(old) - len(devs)


def _dev_name(ua: str) -> str:
    ua = ua or ""
    for k, v in (("iPad", "아이패드"), ("iPhone", "아이폰"), ("Android", "안드로이드"), ("Macintosh", "맥"), ("Windows", "윈도우")):
        if k in ua:
            return v
    return "기기"


# ---------------------------------------------------------------- 주소·QR
def addresses() -> List[str]:
    """다른 기기에서 쳐 넣을 주소 (이름 주소 먼저, 그다음 숫자 주소)"""
    out = []
    name = ""
    try:
        if sys.platform == "darwin":
            name = subprocess.run(["scutil", "--get", "LocalHostName"], capture_output=True, text=True, timeout=3).stdout.strip()
        else:
            name = socket.gethostname().split(".")[0]
    except Exception:
        pass
    if name and re.fullmatch(r"[A-Za-z0-9-]+", name):
        out.append(f"http://{name}.local:{RPORT}")
    ips = []
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))           # 실제로 보내지는 않음 (밖으로 나가는 주소 확인용)
        ips.append(s.getsockname()[0])
        s.close()
    except Exception:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ips.append(info[4][0])
    except Exception:
        pass
    import ipaddress
    clat = ipaddress.ip_network("192.0.0.0/29")     # 아이폰 핫스팟(IPv6 통신사)에서 맥이 받는 가짜 IPv4 → 폰에서 못 들어옴
    good = []
    for ip in dict.fromkeys(ips):
        try:
            a = ipaddress.ip_address(ip)
        except ValueError:
            continue
        if a.is_loopback or a.is_link_local or a in clat:
            continue
        good.append((0 if a.is_private else 1, ip))
    if any(k == 0 for k, _ in good):            # 집·핫스팟 같은 내부 주소만 (밖에서 보이는 주소는 같은 와이파이에선 안 쓰임)
        good = [g for g in good if g[0] == 0]
    v4 = [f"http://{ip}:{RPORT}" for _, ip in good]
    v6 = [f"http://[{ip}]:{RPORT}" for ip in _ipv6_addrs()]
    # 이름(.local) 주소를 먼저 (QR에 씀): 와이파이·핫스팟이 바뀌어도 그대로라 홈 화면 바로가기도 계속 쓸 수 있음
    # 안 열릴 때 쓰는 숫자 주소(IPv4 → IPv6)는 그 아래에
    return out + v4 + v6


def _ipv6_addrs() -> List[str]:
    """이 컴퓨터의 IPv6 주소 (link-local 빼고, 영구 주소 먼저)"""
    import ipaddress
    found = []
    try:
        s = socket.socket(socket.AF_INET6, socket.SOCK_DGRAM)
        s.connect(("2001:4860:4860::8888", 1))       # 실제로 보내지는 않음
        found.append(s.getsockname()[0].split("%")[0])
        s.close()
    except Exception:
        pass
    if sys.platform == "darwin":
        try:
            out = subprocess.run(["ifconfig"], capture_output=True, text=True, timeout=3).stdout
            for m in re.finditer(r"inet6 ([0-9a-f:]+)[^\n]*?(temporary)?\n", out):
                if not m.group(2):
                    found.insert(0, m.group(1))
                else:
                    found.append(m.group(1))
        except Exception:
            pass
    good = []
    for ip in dict.fromkeys(found):
        try:
            a = ipaddress.ip_address(ip)
        except ValueError:
            continue
        if a.version == 6 and not (a.is_loopback or a.is_link_local or a.is_multicast or a.is_unspecified):
            good.append(ip)
    return good[:2]


def qr_svg(text: str) -> str:
    try:
        import qrcode
        import qrcode.image.svg
    except ImportError:
        threading.Thread(target=_install_qr, daemon=True).start()
        return ""
    try:
        img = qrcode.make(text, image_factory=qrcode.image.svg.SvgPathImage, box_size=8, border=2)
        s = img.to_string()
        return s.decode("utf-8") if isinstance(s, bytes) else str(s)
    except Exception:
        return ""


_QR_TRY = [0.0]


def _install_qr():
    if time.time() - _QR_TRY[0] < 3600:
        return
    _QR_TRY[0] = time.time()
    kw = {"creationflags": 0x08000000} if os.name == "nt" else {}
    try:
        subprocess.run([sys.executable, "-m", "pip", "install", "-q", "--disable-pip-version-check", "qrcode"],
                       capture_output=True, timeout=300, **kw)
    except Exception:
        pass


_ADDR = {"t": 0.0, "v": []}


def state(lite: bool = False, public: bool = False) -> dict:
    """설정 화면·메뉴 막대용. lite: QR 그림 없이 / public: 휴대폰에서 보는 설정 화면용 (코드·QR 빼고)"""
    lan, on = enabled(), serving()
    if lan and (not lite or time.time() - _ADDR["t"] > 30):
        _ADDR["v"], _ADDR["t"] = addresses(), time.time()
    adds = _ADDR["v"] if lan else []
    from . import tunnel
    tn = tunnel.state()
    ready = tn["status"] == "ready" and bool(tn["url"])
    tnon = tunnel_on()
    if tnon and ready and not lite and not public:
        tn["qr"] = qr_svg(qr_url(tn["url"], "tunnel"))
    cl = code("lan") if lan else ""
    ct = code("tunnel") if tnon else ""
    cfg = _cfg()
    view = mb_view()
    ck = hashlib.sha256((cl + ct + _CODES["lan"]["key"] + _CODES["tunnel"]["key"]).encode()).hexdigest()[:8] if on else ""
    out = {"enabled": lan, "serving": on, "running": _SRV[0] is not None,
           "codes": {"lan": cl, "tunnel": ct}, "code": ct if view == "tunnel" else cl,     # code: 메뉴 막대에 보일 쪽
           "ck": ck, "urls": adds, "qr": "" if (lite or public) else (qr_svg(qr_url(adds[0], "lan")) if adds else ""),
           "devices": devices(), "port": RPORT, "tunnel": tn,
           "mb_view": view, "mb_show": cfg.get("mb_show", True) is not False,
           # 메뉴 막대가 QR을 직접 그릴 때 쓰는 주소 (# 뒤 열쇠 포함)
           "lan_qr": qr_url(adds[0], "lan") if adds else "", "tunnel_qr": qr_url(tn["url"], "tunnel") if (tnon and ready) else ""}
    if public:
        for k in ("code", "ck", "lan_qr", "tunnel_qr"):
            out[k] = ""
        out["codes"] = {"lan": "", "tunnel": ""}
    return out

def set_enabled(on: bool) -> dict:
    """같은 와이파이에서 열기 켜기·끄기 (밖에서 열기와는 따로)"""
    with M.CFG_LOCK:
        cfg = M.read_cfg()
        r = dict(cfg.get("remote") or {})
        r["enabled"] = bool(on)
        cfg["remote"] = r
        M.write_cfg(cfg)
    err = ensure()
    if err:
        return {"ok": False, "msg": err}
    if on:
        return {"ok": True, "msg": "켰어요. 같은 와이파이의 휴대폰·아이패드에서 QR을 찍어 주세요."}
    return {"ok": True, "msg": "같은 와이파이에서 열기를 껐어요." + (" 밖에서 열기는 그대로 켜져 있어요." if tunnel_on() else "")}


def set_menubar(body: dict) -> dict:
    with M.CFG_LOCK:
        cfg = M.read_cfg()
        r = dict(cfg.get("remote") or {})
        if body.get("view") in ("lan", "tunnel"):
            r["mb_view"] = body["view"]
        if "show" in body:
            r["mb_show"] = bool(body["show"])
        cfg["remote"] = r
        M.write_cfg(cfg)
    return {"ok": True}


_SVLOCK = threading.RLock()          # 문 열기·닫기를 동시에 하지 않게 (메뉴 막대와 설정 화면이 같이 눌러도)


def ensure() -> Optional[str]:
    """설정에 맞게 문 열기·닫기: 와이파이 켬 → 모든 주소 / 밖에서만 → 이 컴퓨터 안(127.0.0.1)만 / 둘 다 끔 → 닫음"""
    from . import tunnel
    with _SVLOCK:
        lan, tn = enabled(), tunnel_on()
        with _LOCK:                       # 끈 쪽의 연결 코드·QR 열쇠는 바로 못 쓰게
            for via, on in (("lan", lan), ("tunnel", tn)):
                if not on:
                    _CODES[via].update(code="", key="", at=0.0)
                    for k in [k for k, v in _NEXT.items() if v[1] == via]:
                        _NEXT.pop(k, None)
        if not (lan or tn):
            stop()
            tunnel.stop()
            return None
        want = "all" if lan else "local"
        if _SRV[0] is not None and _BIND[0] != want:
            stop()
        err = start()
        if tn:
            tunnel.start()
        else:
            tunnel.stop()
        return err

# ---------------------------------------------------------------- 서버
class _Srv(ThreadingHTTPServer):
    allow_reuse_address = os.name != "nt"      # 윈도우는 같은 문을 두 번 열 수 있게 되어 버려서 끔


class _DualServer(_Srv):
    address_family = socket.AF_INET6

    def server_bind(self):
        try:
            self.socket.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 0)
        except (OSError, AttributeError):
            pass
        super().server_bind()


_BIND = [""]


def start() -> Optional[str]:
    with _SVLOCK:
        return _start()


def _start() -> Optional[str]:
    if _SRV[0] is not None or not serving():
        return None
    from . import gui
    want = "all" if enabled() else "local"
    last = None
    for _ in range(20):                    # 다시 켜는 중이면 앞 서버가 문을 닫을 때까지 잠깐 기다림
        try:
            if want == "local":            # 밖에서 열기만: 터널(cloudflared)만 들어오게 이 컴퓨터 안으로만
                srv = _Srv(("127.0.0.1", RPORT), _handler(gui))
                break
            try:
                srv = _DualServer(("::", RPORT), _handler(gui))      # IPv4·IPv6 둘 다 (아이폰 핫스팟은 IPv6로 들어옴)
            except OSError:
                srv = _Srv(("0.0.0.0", RPORT), _handler(gui))
            break
        except OSError as e:
            last = e
            time.sleep(0.5)
    else:
        return f"다른 기기용 문({RPORT})을 열지 못했어요: {last}"
    srv.daemon_threads = True
    _SRV[0] = srv
    _BIND[0] = want
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    if tunnel_on():
        try:
            from . import tunnel
            tunnel.start()
        except Exception as e:
            sys.stderr.write(f"터널 켜기 실패: {e}\n")
    return None


def stop():
    with _SVLOCK:
        srv = _SRV[0]
        _SRV[0] = None
        if srv:
            try:
                srv.shutdown()
                srv.server_close()
            except Exception:
                pass


def _handler(gui):
    H = gui.H

    class RH(H):
        """다른 기기용: 열쇠(쿠키)가 있어야 하고, 보기·받기 시작만"""

        def end_headers(self):
            # 모든 응답에 「강의록앱이 보냄」 표시: 이게 없으면 휴대폰은 컴퓨터가 꺼진 걸로 봄
            # (컴퓨터를 끄면 터널 주소가 사라져 Cloudflare가 404 같은 자기 오류 페이지를 보냄)
            self.send_header("X-LA-App", "1")
            super().end_headers()

        def _host_ok(self) -> bool:
            """다른 사이트가 이름을 바꿔치기해(DNS 리바인딩) 이 문으로 들어오는 것 막기: 숫자 주소·이 컴퓨터 이름·터널 주소만"""
            h = (self.headers.get("Host") or "").strip().lower()
            if not h:
                return True
            host = h[1:h.index("]")] if h.startswith("[") and "]" in h else h.rsplit(":", 1)[0] if h.count(":") == 1 else h
            import ipaddress
            try:
                ipaddress.ip_address(host)
                return True
            except ValueError:
                pass
            if host in ("localhost",):
                return True
            from . import tunnel
            tu = (tunnel.state().get("url") or "").lower()
            if tu and host == re.sub(r"^https?://", "", tu).split("/")[0]:
                return True
            th = ((tunnel._rcfg() or {}).get("tunnel_host") or "").lower()
            if th and host == th:
                return True
            for a in (_ADDR["v"] or []):
                if host == re.sub(r"^https?://", "", a).rsplit(":", 1)[0].lower():
                    return True
            return host.endswith(".local") and enabled()

        def _ip(self) -> str:
            """터널(cloudflared)로 들어오면 이 컴퓨터 안에서 온 것처럼 보이니 Cloudflare가 붙여 준 실제 주소로"""
            ip = self.client_address[0]
            if ip in ("127.0.0.1", "::1", "::ffff:127.0.0.1"):
                ip = (self.headers.get("CF-Connecting-IP") or ip).strip()
            return ip

        def _https(self) -> bool:
            return (self.headers.get("X-Forwarded-Proto") or "").lower() == "https"

        def _token(self) -> str:
            m = re.search(rf"(?:^|;\s*){COOKIE}=([A-Za-z0-9_\-]+)", self.headers.get("Cookie") or "")
            return m.group(1) if m else ""

        def _local(self) -> bool:
            return self.client_address[0] in ("127.0.0.1", "::1", "::ffff:127.0.0.1")

        def _open(self) -> bool:
            """문이 열려 있는지: 와이파이 켬 → 누구나(코드 필요) / 밖에서만 → 터널(이 컴퓨터 안)로 온 것만"""
            return enabled() or (tunnel_on() and self._local())

        def _authed(self) -> bool:
            if not self._open():
                return False
            d = _device_of(self._token())
            return d is not None

        def _deny(self, code=401):
            return self._send(code, {"ok": False, "auth": False, "msg": "연결 코드를 입력해 주세요."})

        def do_GET(self):
            if not self._host_ok():
                return self._send(403, {"ok": False, "msg": "forbidden"})
            if not self._open():
                return self._send(403, {"ok": False, "msg": "다른 기기에서 열기가 꺼져 있어요."})
            u = urlparse(self.path)
            q = parse_qs(u.query)
            if u.path == "/":
                html = gui.HTML.read_text("utf-8")
                html = html.replace("<script>", "<script>window.REMOTE=true;</script><script>", 1)
                return self._send(200, html.encode("utf-8"), "text/html; charset=utf-8")
            if u.path == "/sw.js":
                return self._send(200, REMOTE_SW.encode("utf-8"), "text/javascript; charset=utf-8")
            if u.path == "/manifest.webmanifest":      # 시작 주소를 비워 둠 → 홈 화면에 추가할 때 지금 주소(#k= 한 번 쓰는 열쇠 포함)로
                man = {k: v for k, v in gui.MANIFEST.items() if k not in ("start_url", "id")}
                return self._send(200, json.dumps(man, ensure_ascii=False).encode("utf-8"), "application/manifest+json")
            if u.path in ("/api/ping",) or re.fullmatch(r"/icon-(32|64|192|512)\.png", u.path) \
                    or re.fullmatch(r"/help-img/[a-z0-9_]+\.webp", u.path):
                return H.do_GET(self)
            if u.path == "/api/remote/me":
                try:
                    M.read_cfg()
                except Exception:              # 설정 파일을 잠깐 못 읽음 → 「연결 끊김」으로 (폰이 저장해 둔 걸 지우지 않게)
                    return self._send(503, {"ok": False, "msg": "잠시 뒤 다시 해 주세요."})
                return self._send(200, {"ok": True, "auth": self._authed()})
            if not self._authed():
                return self._deny()
            if u.path == "/remote/file" or u.path.startswith("/remote/file/"):     # 뒤에 파일 이름을 붙여도 됨 (아이폰이 그 이름으로 저장)
                return self._file((q.get("rel") or [""])[0], bool(q.get("dl")))
            if u.path == "/remote/pfile" or u.path.startswith("/remote/pfile/"):              # 애매한 자료 미리보기 (받아 둔 PDF)
                got = gui.preview_file({k: (v or [""])[0] for k, v in q.items()})
                if not got:
                    return self._send(404, {"ok": False, "msg": "미리 받아 둔 파일이 없어요."})
                f, name = got
                if f.suffix.lower() != ".pdf" and not str(name).lower().endswith(".pdf"):
                    return self._send(415, {"ok": False, "msg": f"PDF가 아닌 파일({Path(name).suffix or f.suffix})이라 휴대폰에서는 미리 볼 수 없어요. 컴퓨터에서 열어 주세요."})
                return self._pdf(f, name, False)
            if u.path == "/api/remote":                 # 휴대폰의 설정 화면 (보기만 · 코드·QR 빼고)
                return self._send(200, state(True, public=True))
            if u.path in GET_OK:
                return H.do_GET(self)
            return self._send(403, {"ok": False, "msg": "다른 기기에서는 쓸 수 없는 기능이에요."})

        def _file(self, rel: str, dl: bool = False):
            from pathlib import PureWindowsPath, PurePosixPath
            if not rel or "\x00" in rel or PureWindowsPath(rel).anchor or PurePosixPath(rel).is_absolute() \
                    or rel.startswith(("\\", "//")):          # 절대 경로·드라이브·네트워크 경로(\\서버)는 아예 안 받음
                return self._send(404, {"ok": False, "msg": "파일이 없어요."})
            try:
                p = (M.SAVE_ROOT / rel).resolve()
            except (OSError, ValueError):
                return self._send(404, {"ok": False, "msg": "파일이 없어요."})
            root = M.SAVE_ROOT.resolve()
            if (root not in p.parents) or p.suffix.lower() != ".pdf" or not p.is_file():
                return self._send(404, {"ok": False, "msg": "파일이 없어요."})
            return self._pdf(p, p.name, dl)

        def _pdf(self, p: Path, name: str, dl: bool):
            try:
                data = p.read_bytes()
            except OSError:
                return self._send(403, {"ok": False, "msg": "이 컴퓨터에서 파일을 읽을 수 없어요 (폴더 권한)."})
            self.send_response(200)
            self.send_header("Content-Type", "application/pdf")
            self.send_header("Content-Length", str(len(data)))
            ascii_name = re.sub(r"[^A-Za-z0-9._-]+", "_", name).strip("_") or "lecture.pdf"
            self.send_header("Content-Disposition", ("attachment" if dl else "inline")
                             + f'; filename="{ascii_name}"; filename*=UTF-8\'\'' + quote(name))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(data)

        def do_POST(self):
            if not self._host_ok():
                return self._send(403, {"ok": False, "msg": "forbidden"})
            if not self._open():
                return self._send(403, {"ok": False, "msg": "다른 기기에서 열기가 꺼져 있어요."})
            if self.headers.get("X-Lecture-App") != "1":
                return self._send(403, {"ok": False})
            u = urlparse(self.path)
            try:
                n = max(0, min(int(self.headers.get("Content-Length") or 0), 65536))
            except ValueError:
                n = 0
            try:
                body = json.loads(self.rfile.read(n) or b"{}")
            except Exception:
                body = {}
            if u.path == "/api/remote/pair":
                return self._pair(body)
            if not self._authed():
                return self._deny()
            if u.path == "/api/remote/forget_me":      # 휴대폰 설정: 이 기기 연결 끊기
                d = _device_of(self._token())
                ok = bool(d) and forget(d.get("id"))
                data = json.dumps({"ok": ok, "msg": "이 기기 연결을 끊었어요." if ok else "이미 끊긴 기기예요."}).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Content-Length", str(len(data)))
                self.send_header("Set-Cookie", f"{COOKIE}=; Max-Age=0; Path=/; HttpOnly; SameSite=Strict" + ("; Secure" if self._https() else ""))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(data)
                return
            if u.path in POST_OK:
                gui._last_hit = time.time()
                fn = {"/api/start": gui.start_job, "/api/stop": lambda b: gui.stop_job()}[u.path]
                try:
                    return self._send(200, fn(body))
                except Exception as e:
                    return self._fail(e)
            return self._send(403, {"ok": False, "msg": "다른 기기에서는 쓸 수 없는 기능이에요."})

        def _via_tunnel(self) -> bool:
            return self.client_address[0] in ("127.0.0.1", "::1", "::ffff:127.0.0.1") and bool(self.headers.get("CF-Connecting-IP"))

        def _pair(self, body):
            ip = _fail_key(self._ip())
            now = time.time()
            c = re.sub(r"\D", "", str(body.get("code") or ""))[:6]
            k = str(body.get("key") or "")[:100]
            tunnel = self._via_tunnel()
            via = "tunnel" if tunnel else "lan"
            if not (tunnel_on() if via == "tunnel" else enabled()):
                return self._send(403, {"ok": False, "msg": "이 방법(같은 와이파이/밖에서)은 컴퓨터에서 꺼져 있어요."})
            C = _CODES[via]
            nxt = ""
            with _LOCK:
                for kk in [kk for kk, t in _NEXT.items() if now > t[0]]:
                    _NEXT.pop(kk, None)
                key, kat = C["key"], C["at"]
            # 1) QR 열쇠: 맞히기가 불가능할 만큼 길어서 틀린 횟수 제한보다 먼저 확인 (남이 일부러 막아도 QR 연결은 됨)
            if k:
                ok = False
                with _LOCK:
                    if key and now - kat <= CODE_TTL and secrets.compare_digest(k.encode(), key.encode()):
                        ok = True
                    elif k in _NEXT and _NEXT[k][1] == via:
                        _NEXT.pop(k, None)                  # 홈 화면에 추가한 앱이 처음 열 때 한 번만 쓰는 열쇠
                        ok = True
                if not ok:
                    return self._send(200, {"ok": False, "msg": "QR이 오래됐어요. 컴퓨터 설정 탭에 뜬 새 QR을 찍거나 6자리 코드를 넣어 주세요."})
                if secrets.compare_digest(k.encode(), key.encode()):
                    new_code(via)
            else:
                # 2) 6자리 코드: 틀린 횟수를 먼저 적어 두고 비교 (동시에 여러 번 보내 제한을 넘는 것 막기)
                with _LOCK:
                    expired = bool(C["code"]) and now - C["at"] > CODE_TTL
                if expired:
                    new_code(via)
                    return self._send(200, {"ok": False, "msg": "연결 코드가 바뀌었어요. 컴퓨터 설정 탭에 뜬 새 6자리를 넣어 주세요."})
                with _LOCK:
                    fails = [t for t in _FAILS.get(ip, []) if now - t < 600]
                    _FAILS[ip] = fails
                    _GFAILS[:] = [t for t in _GFAILS if now - t < G_WIN]
                    _TFAILS[:] = [t for t in _TFAILS if now - t < 3600]
                    if len(fails) >= 5:
                        return self._send(429, {"ok": False, "msg": "코드를 너무 많이 틀렸어요. 10분 뒤에 다시 해 주세요."})
                    if len(_GFAILS) >= FAIL_MAX * 2:
                        return self._send(429, {"ok": False, "msg": "여러 곳에서 코드를 너무 많이 틀려서 잠깐 막아 뒀어요. 10분 뒤에 다시 하거나 QR로 연결해 주세요."})
                    if tunnel and len(_TFAILS) >= TUNNEL_FAIL_MAX:
                        return self._send(429, {"ok": False, "msg": "밖에서 코드를 너무 많이 틀려서 1시간 동안 코드 연결을 막아 뒀어요. 컴퓨터 설정 탭의 QR을 찍어 연결해 주세요."})
                    fails.append(now)
                    _GFAILS.append(now)
                    if tunnel:
                        _TFAILS.append(now)
                    cur = C["code"]
                good = bool(cur) and len(c) == 6 and secrets.compare_digest(c, cur)
                if not good:
                    with _LOCK:
                        total = sum(len(v) for v in _FAILS.values())
                    if total >= FAIL_MAX:
                        new_code(via)       # 여러 곳에서 계속 틀리면 코드 자체를 바꿈
                        with _LOCK:
                            _FAILS.clear()
                    return self._send(200, {"ok": False, "msg": "코드가 맞지 않아요. 컴퓨터의 강의록앱 설정 탭에 뜬 6자리를 넣어 주세요."})
                with _LOCK:                                   # 맞혔으면 방금 적어 둔 실패 기록은 지움
                    for lst in (fails, _GFAILS, _TFAILS):
                        if now in lst:
                            lst.remove(now)
                new_code(via)                               # 한 번 쓴 코드는 바꿈
            if body.get("next"):                            # 사파리에서 연결 → 홈 화면에 추가할 앱이 쓸 열쇠 (30분 · 한 번)
                nxt = secrets.token_urlsafe(18)
                with _LOCK:
                    _NEXT[nxt] = (now + CODE_TTL, via)
                    while len(_NEXT) > 10:
                        _NEXT.pop(next(iter(_NEXT)))
            tok = _add_device(_dev_name(self.headers.get("User-Agent", "")), via)
            data = json.dumps({"ok": True, "next": nxt}).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Set-Cookie", f"{COOKIE}={tok}; Max-Age=31536000; Path=/; HttpOnly; SameSite=Strict"
                             + ("; Secure" if self._https() else ""))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(data)

    return RH
