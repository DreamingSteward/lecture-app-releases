"""휴대폰·아이패드에서 열기: 같은 와이파이(또는 핫스팟)의 다른 기기에서 강의록앱 화면을 보고 받기를 시작.

- 기본은 꺼져 있음. 설정에서 켜면 RPORT(8766)로 따로 문을 엶 (원래 화면 8765 는 이 컴퓨터만 그대로).
- 처음 접속한 기기는 이 컴퓨터 화면에 뜬 6자리 코드를 입력해야 함 → 기기마다 열쇠(쿠키)를 줌.
- 다른 기기에서 되는 것: 현황·받기 진행·기록 보기, 받기 시작·중지, PDF 보기. 설정·계정·파일 바꾸기는 안 됨.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import secrets
import socket
import subprocess
import sys
import threading
import time
from http.server import ThreadingHTTPServer
from pathlib import Path
from typing import List, Optional
from urllib.parse import parse_qs, quote, urlparse

from . import main as M

RPORT = 8766
COOKIE = "la_rt"
_SRV: List[Optional[ThreadingHTTPServer]] = [None]
_CODE = {"code": "", "at": 0.0}
_FAILS: dict = {}
_LOCK = threading.Lock()

GET_OK = {"/api/state", "/api/progress", "/api/job", "/api/log", "/api/events", "/api/runs", "/api/run"}
POST_OK = {"/api/start", "/api/stop"}


# ---------------------------------------------------------------- 설정
def _cfg() -> dict:
    try:
        return dict(M.read_cfg().get("remote") or {})
    except Exception:
        return {}


def enabled() -> bool:
    return bool(_cfg().get("enabled"))


def _hash(tok: str) -> str:
    return hashlib.sha256(tok.encode("utf-8")).hexdigest()


def new_code() -> str:
    with _LOCK:
        _CODE["code"] = f"{secrets.randbelow(1000000):06d}"
        _CODE["at"] = time.time()
        _FAILS.clear()
        return _CODE["code"]


CODE_TTL = 30 * 60          # 연결 코드는 30분이 지나면 새로 (화면에는 늘 지금 코드가 보여요)
FAIL_MAX = 20               # 모든 기기 합쳐서 이만큼 틀리면 코드를 새로 (주소를 바꿔 가며 맞혀 보는 것 막기)


def code() -> str:
    with _LOCK:
        c = _CODE["code"]
        old = c and time.time() - _CODE["at"] > CODE_TTL
    return new_code() if (not c or old) else c


def _fail_key(ip: str) -> str:
    """틀린 횟수를 세는 단위: IPv4는 주소, IPv6는 앞 64비트(한 기기가 주소를 바꿔 가며 시도해도 같이 셈)"""
    try:
        import ipaddress
        a = ipaddress.ip_address(ip.split("%")[0])
        if a.version == 6 and not a.ipv4_mapped:
            return str(ipaddress.ip_network(f"{a}/64", strict=False))
    except Exception:
        pass
    return ip


def devices() -> list:
    return [{"id": d.get("id"), "name": d.get("name", ""), "added": d.get("added", ""), "seen": d.get("seen", "")}
            for d in _cfg().get("devices") or []]


def _device_of(tok: str) -> Optional[dict]:
    if not tok:
        return None
    h = _hash(tok)
    for d in _cfg().get("devices") or []:
        if secrets.compare_digest(str(d.get("hash", "")), h):
            return d
    return None


def _add_device(name: str) -> str:
    tok = secrets.token_urlsafe(32)
    with M.CFG_LOCK:
        cfg = M.read_cfg()
        r = dict(cfg.get("remote") or {})
        devs = list(r.get("devices") or [])
        devs.append({"id": secrets.token_hex(4), "name": name[:40], "hash": _hash(tok),
                     "added": time.strftime("%Y-%m-%d %H:%M")})
        r["devices"] = devs[-10:]                     # 기기는 10개까지
        cfg["remote"] = r
        M.write_cfg(cfg)
    return tok


def forget(dev_id: str) -> bool:
    with M.CFG_LOCK:
        cfg = M.read_cfg()
        r = dict(cfg.get("remote") or {})
        devs = [d for d in r.get("devices") or [] if d.get("id") != dev_id]
        if len(devs) == len(r.get("devices") or []):
            return False
        r["devices"] = devs
        cfg["remote"] = r
        M.write_cfg(cfg)
    return True


def _dev_name(ua: str) -> str:
    ua = ua or ""
    for k, v in (("iPad", "아이패드"), ("iPhone", "아이폰"), ("Android", "안드로이드"), ("Macintosh", "맥"), ("Windows", "윈도우")):
        if k in ua:
            return v
    return "기기"


# ---------------------------------------------------------------- 주소·QR
def addresses() -> List[str]:
    """다른 기기에서 쳐 넣을 주소 (이름 주소 먼저, 그다음 숫자 주소)"""
    out = []
    name = ""
    try:
        if sys.platform == "darwin":
            name = subprocess.run(["scutil", "--get", "LocalHostName"], capture_output=True, text=True, timeout=3).stdout.strip()
        else:
            name = socket.gethostname().split(".")[0]
    except Exception:
        pass
    if name and re.fullmatch(r"[A-Za-z0-9-]+", name):
        out.append(f"http://{name}.local:{RPORT}")
    ips = []
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))           # 실제로 보내지는 않음 (밖으로 나가는 주소 확인용)
        ips.append(s.getsockname()[0])
        s.close()
    except Exception:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ips.append(info[4][0])
    except Exception:
        pass
    import ipaddress
    clat = ipaddress.ip_network("192.0.0.0/29")     # 아이폰 핫스팟(IPv6 통신사)에서 맥이 받는 가짜 IPv4 → 폰에서 못 들어옴
    good = []
    for ip in dict.fromkeys(ips):
        try:
            a = ipaddress.ip_address(ip)
        except ValueError:
            continue
        if a.is_loopback or a.is_link_local or a in clat:
            continue
        good.append((0 if a.is_private else 1, ip))
    if any(k == 0 for k, _ in good):            # 집·핫스팟 같은 내부 주소만 (밖에서 보이는 주소는 같은 와이파이에선 안 쓰임)
        good = [g for g in good if g[0] == 0]
    v4 = [f"http://{ip}:{RPORT}" for _, ip in good]
    v6 = [f"http://[{ip}]:{RPORT}" for ip in _ipv6_addrs()]
    # 이름(.local) 주소를 먼저 (QR에 씀): 와이파이·핫스팟이 바뀌어도 그대로라 홈 화면 바로가기도 계속 쓸 수 있음
    # 안 열릴 때 쓰는 숫자 주소(IPv4 → IPv6)는 그 아래에
    return out + v4 + v6


def _ipv6_addrs() -> List[str]:
    """이 컴퓨터의 IPv6 주소 (link-local 빼고, 영구 주소 먼저)"""
    import ipaddress
    found = []
    try:
        s = socket.socket(socket.AF_INET6, socket.SOCK_DGRAM)
        s.connect(("2001:4860:4860::8888", 1))       # 실제로 보내지는 않음
        found.append(s.getsockname()[0].split("%")[0])
        s.close()
    except Exception:
        pass
    if sys.platform == "darwin":
        try:
            out = subprocess.run(["ifconfig"], capture_output=True, text=True, timeout=3).stdout
            for m in re.finditer(r"inet6 ([0-9a-f:]+)[^\n]*?(temporary)?\n", out):
                if not m.group(2):
                    found.insert(0, m.group(1))
                else:
                    found.append(m.group(1))
        except Exception:
            pass
    good = []
    for ip in dict.fromkeys(found):
        try:
            a = ipaddress.ip_address(ip)
        except ValueError:
            continue
        if a.version == 6 and not (a.is_loopback or a.is_link_local or a.is_multicast or a.is_unspecified):
            good.append(ip)
    return good[:2]


def qr_svg(text: str) -> str:
    try:
        import qrcode
        import qrcode.image.svg
    except ImportError:
        threading.Thread(target=_install_qr, daemon=True).start()
        return ""
    try:
        img = qrcode.make(text, image_factory=qrcode.image.svg.SvgPathImage, box_size=8, border=2)
        s = img.to_string()
        return s.decode("utf-8") if isinstance(s, bytes) else str(s)
    except Exception:
        return ""


_QR_TRY = [0.0]


def _install_qr():
    if time.time() - _QR_TRY[0] < 3600:
        return
    _QR_TRY[0] = time.time()
    kw = {"creationflags": 0x08000000} if os.name == "nt" else {}
    try:
        subprocess.run([sys.executable, "-m", "pip", "install", "-q", "--disable-pip-version-check", "qrcode"],
                       capture_output=True, timeout=300, **kw)
    except Exception:
        pass


_ADDR = {"t": 0.0, "v": []}


def state(lite: bool = False) -> dict:
    """설정 화면·메뉴 막대용 (이 컴퓨터에서만). lite: QR 그림 없이"""
    on = enabled()
    if on and (not lite or time.time() - _ADDR["t"] > 30):
        _ADDR["v"], _ADDR["t"] = addresses(), time.time()
    adds = _ADDR["v"] if on else []
    return {"enabled": on, "running": _SRV[0] is not None, "code": code() if on else "",
            "urls": adds, "qr": "" if lite else (qr_svg(adds[0]) if adds else ""), "devices": devices(), "port": RPORT}


def set_enabled(on: bool) -> dict:
    with M.CFG_LOCK:
        cfg = M.read_cfg()
        r = dict(cfg.get("remote") or {})
        r["enabled"] = bool(on)
        cfg["remote"] = r
        M.write_cfg(cfg)
    if on:
        if _SRV[0] is None or not _CODE["code"]:
            new_code()
        err = start()
        if err:
            return {"ok": False, "msg": err}
        return {"ok": True, "msg": "켰어요. 휴대폰·아이패드에서 아래 주소로 들어가 코드를 입력해 주세요."}
    stop()
    return {"ok": True, "msg": "껐어요. 이제 이 컴퓨터에서만 열려요."}


# ---------------------------------------------------------------- 서버
class _DualServer(ThreadingHTTPServer):
    address_family = socket.AF_INET6

    def server_bind(self):
        try:
            self.socket.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 0)
        except (OSError, AttributeError):
            pass
        super().server_bind()


def start() -> Optional[str]:
    if _SRV[0] is not None:
        return None
    from . import gui
    last = None
    for _ in range(20):                    # 다시 켜는 중이면 앞 서버가 문을 닫을 때까지 잠깐 기다림
        try:
            try:
                srv = _DualServer(("::", RPORT), _handler(gui))      # IPv4·IPv6 둘 다 (아이폰 핫스팟은 IPv6로 들어옴)
            except OSError:
                srv = ThreadingHTTPServer(("0.0.0.0", RPORT), _handler(gui))
            break
        except OSError as e:
            last = e
            time.sleep(0.5)
    else:
        return f"다른 기기용 문({RPORT})을 열지 못했어요: {last}"
    srv.daemon_threads = True
    _SRV[0] = srv
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return None


def stop():
    srv = _SRV[0]
    _SRV[0] = None
    if srv:
        try:
            srv.shutdown()
            srv.server_close()
        except Exception:
            pass


def _handler(gui):
    H = gui.H

    class RH(H):
        """다른 기기용: 열쇠(쿠키)가 있어야 하고, 보기·받기 시작만"""

        def _host_ok(self) -> bool:
            return True

        def _token(self) -> str:
            m = re.search(rf"(?:^|;\s*){COOKIE}=([A-Za-z0-9_\-]+)", self.headers.get("Cookie") or "")
            return m.group(1) if m else ""

        def _authed(self) -> bool:
            if not enabled():
                return False
            d = _device_of(self._token())
            return d is not None

        def _deny(self, code=401):
            return self._send(code, {"ok": False, "auth": False, "msg": "연결 코드를 입력해 주세요."})

        def do_GET(self):
            if not enabled():
                return self._send(403, {"ok": False, "msg": "다른 기기에서 열기가 꺼져 있어요."})
            u = urlparse(self.path)
            q = parse_qs(u.query)
            if u.path == "/":
                html = gui.HTML.read_text("utf-8")
                html = html.replace("<script>", "<script>window.REMOTE=true;</script><script>", 1)
                return self._send(200, html.encode("utf-8"), "text/html; charset=utf-8")
            if u.path in ("/manifest.webmanifest", "/sw.js", "/api/ping") or re.fullmatch(r"/icon-(32|64|192|512)\.png", u.path) \
                    or re.fullmatch(r"/help-img/[a-z0-9_]+\.webp", u.path):
                return H.do_GET(self)
            if u.path == "/api/remote/me":
                return self._send(200, {"ok": True, "auth": self._authed()})
            if not self._authed():
                return self._deny()
            if u.path == "/remote/file":
                return self._file((q.get("rel") or [""])[0], bool(q.get("dl")))
            if u.path in GET_OK:
                return H.do_GET(self)
            return self._send(403, {"ok": False, "msg": "다른 기기에서는 쓸 수 없는 기능이에요."})

        def _file(self, rel: str, dl: bool = False):
            p = (M.SAVE_ROOT / rel).resolve()
            root = M.SAVE_ROOT.resolve()
            if (root not in p.parents) or p.suffix.lower() != ".pdf" or not p.is_file():
                return self._send(404, {"ok": False, "msg": "파일이 없어요."})
            data = p.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "application/pdf")
            self.send_header("Content-Length", str(len(data)))
            ascii_name = re.sub(r"[^A-Za-z0-9._-]+", "_", p.name).strip("_") or "lecture.pdf"
            self.send_header("Content-Disposition", ("attachment" if dl else "inline")
                             + f'; filename="{ascii_name}"; filename*=UTF-8\'\'' + quote(p.name))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(data)

        def do_POST(self):
            if not enabled():
                return self._send(403, {"ok": False, "msg": "다른 기기에서 열기가 꺼져 있어요."})
            if self.headers.get("X-Lecture-App") != "1":
                return self._send(403, {"ok": False})
            u = urlparse(self.path)
            n = min(int(self.headers.get("Content-Length") or 0), 65536)
            try:
                body = json.loads(self.rfile.read(n) or b"{}")
            except Exception:
                body = {}
            if u.path == "/api/remote/pair":
                return self._pair(body)
            if not self._authed():
                return self._deny()
            if u.path in POST_OK:
                gui._last_hit = time.time()
                fn = {"/api/start": gui.start_job, "/api/stop": lambda b: gui.stop_job()}[u.path]
                try:
                    return self._send(200, fn(body))
                except Exception as e:
                    return self._fail(e)
            return self._send(403, {"ok": False, "msg": "다른 기기에서는 쓸 수 없는 기능이에요."})

        def _pair(self, body):
            ip = _fail_key(self.client_address[0])
            now = time.time()
            with _LOCK:
                expired = bool(_CODE["code"]) and now - _CODE["at"] > CODE_TTL
            if expired:
                new_code()
                return self._send(200, {"ok": False, "msg": "연결 코드가 바뀌었어요. 컴퓨터 설정 탭에 뜬 새 6자리를 넣어 주세요."})
            with _LOCK:
                fails = [t for t in _FAILS.get(ip, []) if now - t < 600]
                _FAILS[ip] = fails
                if len(fails) >= 5:
                    return self._send(429, {"ok": False, "msg": "코드를 너무 많이 틀렸어요. 10분 뒤에 다시 해 주세요."})
                cur = _CODE["code"]
            c = re.sub(r"\D", "", str(body.get("code") or ""))
            if not cur or not secrets.compare_digest(c, cur):
                with _LOCK:
                    _FAILS.setdefault(ip, []).append(now)
                    total = sum(len(v) for v in _FAILS.values())
                if total >= FAIL_MAX:
                    new_code()          # 여러 곳에서 계속 틀리면 코드 자체를 바꿈 (_FAILS도 비워짐)
                return self._send(200, {"ok": False, "msg": "코드가 맞지 않아요. 컴퓨터의 강의록앱 설정 탭에 뜬 6자리를 넣어 주세요."})
            tok = _add_device(_dev_name(self.headers.get("User-Agent", "")))
            new_code()                                  # 한 번 쓴 코드는 바꿈
            data = json.dumps({"ok": True}).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Set-Cookie", f"{COOKIE}={tok}; Max-Age=31536000; Path=/; HttpOnly; SameSite=Strict")
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(data)

    return RH
