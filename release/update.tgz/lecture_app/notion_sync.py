"""노션 「<과목> 강의록 정리 / 강의록 현황」 표 채우기.

- 노션 내부 통합(Integration) 토큰은 macOS 키체인(강의록앱-Notion)에 저장
- 과목 → 데이터 소스 id 는 config.json 의 notion.sources
- 행은 '키' 열(시간표 강의 키)로 찾아 있으면 수정, 없으면 추가
- 바뀐 행만 보낸다 (노션_상태.json 에 마지막으로 보낸 값 기억)
"""
from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path
from typing import Dict, List, Optional

import requests

from .timetable import norm_course

API = "https://api.notion.com/v1"
VERSION = "2025-09-03"
KEYCHAIN = "강의록앱-Notion"


def token() -> Optional[str]:
    from . import secrets_store
    r = secrets_store.get(KEYCHAIN)
    return (r[1].strip() or None) if r else None


def check(tok: str) -> str:
    """토큰이 맞는지, 표에 접근되는지 바로 확인"""
    try:
        r = requests.get(API + "/users/me", headers={"Authorization": f"Bearer {tok}", "Notion-Version": VERSION}, timeout=20)
    except Exception as e:
        return f"노션에 연결 못 함 ({type(e).__name__})"
    if r.status_code == 401:
        return "토큰이 틀렸어요 (복사가 덜 됐거나 다른 값). 통합 페이지에서 '내부 통합 시크릿'을 다시 복사해 주세요."
    if not r.ok:
        return f"노션 응답 {r.status_code}"
    return "ok:" + (r.json().get("name") or "통합")


def save_token():
    import getpass
    print("노션 통합 시크릿(ntn_ 또는 secret_ 로 시작)을 붙여넣고 Enter. 화면에 안 보여요.")
    tok = getpass.getpass("> ").strip().strip('"').strip("'")
    if not tok.startswith(("ntn_", "secret_")):
        print("ntn_ 또는 secret_ 로 시작하는 값이 아니에요. 통합 페이지의 '내부 통합 시크릿'을 복사해 주세요.")
        return 1
    res = check(tok)
    if not res.startswith("ok:"):
        print(res)
        return 1
    from . import secrets_store
    ok, msg = secrets_store.put(KEYCHAIN, "notion", tok)
    if not ok:
        print(msg or "저장 실패")
        return 1
    print(f"저장했어요. ({res[3:]} 로 연결됨)")
    print("「본과 2학년 정리본 모음」 페이지 → ··· → 연결 에 이 통합을 추가했는지도 확인해 주세요.")
    return 0


class Notion:
    def __init__(self, tok: str):
        self.s = requests.Session()
        self.s.headers.update({"Authorization": f"Bearer {tok}", "Notion-Version": VERSION,
                               "Content-Type": "application/json"})

    def _req(self, method, path, **kw):
        for attempt in range(5):
            r = self.s.request(method, API + path, timeout=60, **kw)
            if r.status_code == 429 or r.status_code >= 500:
                time.sleep(float(r.headers.get("Retry-After", 1 + attempt)))
                continue
            if not r.ok:
                raise RuntimeError(f"노션 {r.status_code}: {r.json().get('message', r.text)[:200]}")
            time.sleep(0.34)          # 초당 3회 제한
            return r.json()
        raise RuntimeError("노션 응답 없음")

    def rows(self, ds: str) -> Dict[str, str]:
        """키 → 페이지 id"""
        out, cursor = {}, None
        while True:
            body = {"page_size": 100}
            if cursor:
                body["start_cursor"] = cursor
            d = self._req("POST", f"/data_sources/{ds}/query", json=body)
            for p in d.get("results", []):
                k = "".join(t.get("plain_text", "") for t in p["properties"].get("키", {}).get("rich_text", []))
                if k:
                    out[k] = p["id"]
            if not d.get("has_more"):
                return out
            cursor = d.get("next_cursor")

    def create(self, ds: str, props: dict):
        return self._req("POST", "/pages", json={"parent": {"type": "data_source_id", "data_source_id": ds},
                                                 "properties": props})["id"]

    def update(self, page: str, props: dict):
        self._req("PATCH", f"/pages/{page}", json={"properties": props})


# ---------------------------------------------------------------- 값 → 속성
def _text(s: str):
    return {"rich_text": [{"type": "text", "text": {"content": s[:1900]}}] if s else []}


def _date(s: Optional[str]):
    return {"date": {"start": s[:10]} if s else None}


def props(row: dict) -> dict:
    return {
        "제목": {"title": [{"type": "text", "text": {"content": row["제목"][:1900]}}]},
        "강의날짜": _date(row["강의날짜"]),
        "교시": _text(row["교시"]),
        "차수": {"select": {"name": row["차수"]}},
        "LMS 업로드": _date(row.get("LMS 업로드")),
        "드라이브 업로드": _date(row.get("드라이브 업로드")),
        "최신 강의록": _date(row.get("최신 강의록")),
        "처리 여부": {"select": {"name": row["처리 여부"]}},
        "비고": _text(row.get("비고", "")),
        "키": _text(row["키"]),
    }


def sync(rows_by_course: Dict[str, List[dict]], sources: Dict[str, str], state_path: Path, log) -> int:
    tok = token()
    if not tok:
        log("노션: 토큰이 없어 건너뜀 → '강의록앱 노션연결'")
        return 0
    n = Notion(tok)
    state = json.loads(state_path.read_text("utf-8")) if state_path.exists() else {}
    src_by = {norm_course(k): v for k, v in sources.items()}
    sent = 0
    for course, rows in rows_by_course.items():
        ds = src_by.get(norm_course(course))
        if not ds:
            log(f"노션: '{course}' 표가 config에 없음")
            continue
        try:
            existing = n.rows(ds)
        except Exception as e:
            log(f"노션: '{course}' 표를 못 읽음 ({e}) — 통합이 페이지에 연결됐는지 확인")
            continue
        for row in sorted(rows, key=lambda r: (r["강의날짜"], r["교시"])):
            h = hashlib.sha1(json.dumps(row, ensure_ascii=False, sort_keys=True).encode()).hexdigest()
            k = row["키"]
            if k in existing and state.get(k) == h:
                continue
            try:
                if k in existing:
                    n.update(existing[k], props(row))
                else:
                    existing[k] = n.create(ds, props(row))
                state[k] = h
                sent += 1
            except Exception as e:
                log(f"노션: {row['제목']} 기록 실패 ({e})")
        state_path.write_text(json.dumps(state, ensure_ascii=False), "utf-8")
    log(f"노션: {sent}행 갱신")
    return sent
