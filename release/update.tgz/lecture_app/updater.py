"""앱 업데이트: 새 버전이 있는지 확인하고, 받아서 서명을 확인한 뒤 앱 코드만 바꿔 끼움.

- 최신 버전 정보는 GitHub 공개 저장소의 최신 릴리스(update.json + update.json.sig)에서 읽음
- update.json 은 앱 만든 사람의 비밀 키로 서명돼 있고, 앱에는 확인용 공개 키만 들어 있음
  → 누가 파일을 바꿔치기해도 서명이 안 맞으면 설치하지 않음
- 바꾸는 것: lecture_app 폴더 · requirements.txt · lecture_app_run.pyw · VERSION (받은 강의록·설정·기억은 그대로)
- 직전 버전은 logs/업데이트_이전/ 에 남겨 둠 (문제가 생기면 되돌리기)
- 보내는 정보 없음: 버전 정보를 읽기만 함
"""
from __future__ import annotations

import hashlib
import io
import json
import os
import py_compile
import re
import shutil
import subprocess
import sys
import tarfile
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

from . import ed25519

APP = Path(__file__).resolve().parent.parent
CODE = APP / "lecture_app"
STATE = APP / "logs" / "업데이트.json"
BACKUP = APP / "logs" / "업데이트_이전"
LOCK = APP / "logs" / "업데이트중"

REPO = "DreamingSteward/lecture-app-releases"                   # 예: "owner/lecture-app-releases" (비어 있으면 업데이트 확인 안 함)
PUBKEY = "7aa9699f0372df9b00e4ea68be362e1b450bd83d10c0a6d599f124813c46c95f"                 # 서명 확인용 공개 키 (hex 64자)
NOTION = "https://app.notion.com/p/40647858add781f6b80ae605c93fa1f8"

VER_RE = re.compile(r"^\d{4}\.\d{2}\.\d{2}-\d{4}$")
CHECK_EVERY = 3 * 3600        # 켜 둔 동안 3시간마다
OPEN_EVERY = 5 * 60           # 앱 화면을 열 때는 5분이 지났으면 바로 확인
MAX_SIZE = 60 * 1024 * 1024
TOP_FILES = {"requirements.txt", "lecture_app_run.pyw", "VERSION"}


# ---------------------------------------------------------------- 상태 파일
def _load() -> dict:
    try:
        d = json.loads(STATE.read_text("utf-8"))
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _save(d: dict):
    try:
        STATE.parent.mkdir(parents=True, exist_ok=True)
        tmp = STATE.with_suffix(f".{os.getpid()}.tmp")       # 화면 서버·메뉴 막대가 동시에 써도 안 섞이게
        tmp.write_text(json.dumps(d, ensure_ascii=False, indent=1), "utf-8")
        os.replace(tmp, STATE)
    except Exception:
        pass


def _edit(fn):
    """상태 파일을 읽고-고치고-쓰기 (다른 곳에서 바꾼 값을 덮어쓰지 않게 쓰기 직전에 다시 읽음)"""
    st = _load()
    fn(st)
    _save(st)
    return st


def _log(msg: str):
    try:
        with open(APP / "logs" / "업데이트.log", "a", encoding="utf-8") as f:
            f.write(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] {msg}\n")
    except Exception:
        pass


def current() -> str:
    try:
        return (APP / "VERSION").read_text("utf-8").strip()[:40]
    except Exception:
        return ""


def enabled() -> bool:
    return bool(REPO and PUBKEY)


def _newer(v: str, than: str) -> bool:
    return bool(VER_RE.match(v or "")) and (not than or v > than)


# ---------------------------------------------------------------- 받기 (작은 파일)
def _get(url: str, limit: int, timeout: int = 20) -> bytes:
    import requests
    with requests.get(url, timeout=timeout, stream=True, headers={"User-Agent": "lecture-app-updater"}) as r:
        r.raise_for_status()
        buf = io.BytesIO()
        for chunk in r.iter_content(1 << 16):
            buf.write(chunk)
            if buf.tell() > limit:
                raise RuntimeError("파일이 너무 커요")
        return buf.getvalue()


def _base(tag: str = "") -> str:
    return f"https://github.com/{REPO}/releases/" + (f"download/v{tag}/" if tag else "latest/download/")


def _manifest() -> dict:
    """최신 릴리스의 update.json 을 받아 서명까지 확인한 뒤 돌려줌 (안 맞으면 오류)"""
    raw = _get(_base() + "update.json", 256 * 1024)
    sig = _get(_base() + "update.json.sig", 4096).strip()
    try:
        sig_b = bytes.fromhex(sig.decode("ascii"))
    except Exception:
        raise RuntimeError("서명 형식이 이상해요")
    if not ed25519.verify(bytes.fromhex(PUBKEY), raw, sig_b):
        raise RuntimeError("서명이 맞지 않아요 (앱 만든 사람이 올린 파일이 아니에요)")
    m = json.loads(raw.decode("utf-8"))
    if not isinstance(m, dict) or not VER_RE.match(str(m.get("version") or "")) \
            or not re.fullmatch(r"[0-9a-f]{64}", str(m.get("sha256") or "")):
        raise RuntimeError("업데이트 정보 형식이 이상해요")
    return m


# ---------------------------------------------------------------- 확인
def check(force: bool = False, opening: bool = False) -> dict:
    """새 버전이 있는지 확인 · force: 바로 · opening: 앱 화면을 열 때 (5분 안에 확인했으면 건너뜀) · 그 밖엔 3시간마다
    (GitHub 파일 두 개만 읽음 · 보내는 정보 없음)"""
    st = _load()
    if not enabled():
        return status()
    if opening and time.time() - float(st.get("checked") or 0) >= OPEN_EVERY:
        force = True
    if not force and time.time() < float(st.get("next") or 0):
        return status()
    try:
        m = _manifest()
        lt = {k: m.get(k) for k in ("version", "sha256", "size", "full", "notes", "page", "file")}

        def ok(x):
            x["checked"], x["next"], x["latest"] = time.time(), time.time() + CHECK_EVERY, lt
            x.pop("err", None)
        _edit(ok)
        _log(f"확인: 최신 {m.get('version')} (지금 {current()})")
    except Exception as e:
        def bad(x):                                   # 인터넷이 아직 안 됐을 수 있어서 40분 뒤 다시
            x["checked"], x["next"], x["err"] = time.time(), time.time() + 40 * 60, str(e)[:200]
        _edit(bad)
        _log(f"확인 실패: {e}")
    return status()


def status() -> dict:
    st = _load()
    cur = current()
    lt = st.get("latest") or {}
    v = str(lt.get("version") or "")
    avail = _newer(v, cur)
    sched = st.get("schedule") if avail and (st.get("schedule") or {}).get("at") else None
    lst = st.get("last") or {}
    can_back = bool(lst.get("from") and lst.get("to") == cur and _backup_version() == lst.get("from"))
    return {"enabled": enabled(), "current": cur, "latest": v if VER_RE.match(v) else "",
            "available": avail, "full": bool(lt.get("full")) if avail else False,
            "notes": [str(x)[:200] for x in (lt.get("notes") or [])][:8] if avail else [],
            "page": NOTION, "checked": st.get("checked") or 0, "err": st.get("err") or "",
            "later": (st.get("later") or {}).get("version") == v and time.time() < float((st.get("later") or {}).get("until") or 0),
            "schedule": sched, "last": lst if can_back else {}, "running": _locked(),
            "notified": st.get("notified") == v, "auto": bool(st.get("auto"))}


def _backup_version() -> str:
    try:
        return (BACKUP / "VERSION").read_text("utf-8").strip()[:40]
    except Exception:
        return ""


def _locked() -> bool:
    """업데이트하는 중인지 (30분 넘은 표시는 멈춘 것으로 봄)"""
    try:
        return LOCK.exists() and time.time() - LOCK.stat().st_mtime < 1800
    except OSError:
        return False


def set_auto(on: bool) -> dict:
    """새 버전이 나오면 물어보지 않고 받기가 없을 때 저절로 업데이트"""
    _edit(lambda x: x.__setitem__("auto", bool(on)))
    return {"ok": True, **status()}


def later(hours: float = 20) -> dict:
    def f(x):
        x["later"] = {"version": ((x.get("latest") or {}).get("version")) or "", "until": time.time() + hours * 3600}
    _edit(f)
    return status()


def set_schedule(at: Optional[str]) -> dict:
    """at = 'YYYY-MM-DD HH:MM' (그 시각 이후 받기가 없을 때 업데이트) · 비우면 예약 취소"""
    if at:
        try:
            when = datetime.strptime(at, "%Y-%m-%d %H:%M")
        except Exception:
            return {"ok": False, "msg": "시각 형식이 이상해요"}
        if when <= datetime.now():
            return {"ok": False, "msg": "지난 시각이에요. 앞으로의 시각을 골라 주세요."}
        def f(x):
            x["schedule"] = {"at": at}
            x.pop("later", None)
        _edit(f)
    else:
        _edit(lambda x: x.pop("schedule", None))
    return {"ok": True, **status()}


def mark_notified():
    _edit(lambda x: x.__setitem__("notified", ((x.get("latest") or {}).get("version")) or ""))


def due() -> bool:
    """예약한 시각이 지났는지"""
    s = status()
    if not s["available"] or s["full"] or s["later"]:      # 「나중에」·되돌린 버전은 자동으로도 안 함
        return False
    if s["auto"]:
        return True
    if not s["schedule"]:
        return False
    try:
        return datetime.now() >= datetime.strptime(s["schedule"]["at"], "%Y-%m-%d %H:%M")
    except Exception:
        return False


# ---------------------------------------------------------------- 설치
def _safe_members(tf: tarfile.TarFile):
    out = []
    for m in tf.getmembers():
        n = m.name
        if n.startswith("./"):
            n = n[2:]
        if not n or n.startswith("/") or "\\" in n or ".." in Path(n).parts:
            raise RuntimeError(f"이상한 경로가 들어 있어요: {m.name}")
        if not (m.isfile() or m.isdir()):
            raise RuntimeError(f"파일이 아닌 항목이 들어 있어요: {m.name}")
        if not (n == "lecture_app" or n.startswith("lecture_app/") or n in TOP_FILES):
            raise RuntimeError(f"앱 파일이 아닌 게 들어 있어요: {m.name}")
        if "__pycache__" in n:
            continue
        m.name = n
        out.append(m)
    return out


def _run(args, timeout):
    r = subprocess.run([sys.executable, *args], capture_output=True, text=True, timeout=timeout,
                       creationflags=0x08000000 if os.name == "nt" else 0)
    return None if r.returncode == 0 else ((r.stderr or r.stdout) or "")[-300:]


def _pip(req: Path) -> Optional[str]:
    """새 라이브러리 설치. 맥 메뉴 막대(rumps)는 설치 때처럼 따로 · 실패해도 계속.
    playwright 가 바뀌었을 수 있어서 자동 로그인 브라우저도 맞춰 받음."""
    try:
        lines = req.read_text("utf-8").splitlines()
        main_req = req.with_name("requirements_main.txt")
        main_req.write_text("\n".join(x for x in lines if not x.strip().lower().startswith("rumps")) + "\n", "utf-8")
        err = _run(["-m", "pip", "install", "-q", "-r", str(main_req)], 900)
        if err:
            return err
        if sys.platform == "darwin" and any(x.strip().lower().startswith("rumps") for x in lines):
            _run(["-m", "pip", "install", "-q", "rumps>=0.4"], 300)
        return _run(["-m", "playwright", "install", "chromium"], 900)
    except Exception as e:
        return str(e)


def _overwrite(src: Path, dst: Path):
    """dst 를 src 와 똑같이 (새 파일 덮어쓰기 + src 에 없는 파일 지우기)"""
    shutil.copytree(src, dst, dirs_exist_ok=True, ignore=shutil.ignore_patterns("__pycache__"))
    keep = {p.relative_to(src) for p in src.rglob("*")}
    for p in sorted(dst.rglob("*"), reverse=True):
        r = p.relative_to(dst)
        if "__pycache__" in r.parts or r in keep:
            continue
        try:
            shutil.rmtree(p) if p.is_dir() else p.unlink()
        except Exception:
            pass


def _take_lock() -> bool:
    LOCK.parent.mkdir(parents=True, exist_ok=True)
    try:
        LOCK.mkdir()
        return True
    except FileExistsError:
        if _locked():
            return False
        try:                                              # 30분 넘게 남은 표시는 멈춘 것 → 치우고 다시
            LOCK.rmdir()
            LOCK.mkdir()
            return True
        except OSError:
            return False


def _restore_backup():
    """바꿔 끼우다 실패했을 때 직전 버전으로 되돌림"""
    try:
        if (BACKUP / "lecture_app" / "__main__.py").exists():
            if not CODE.exists():
                for d in sorted(APP.glob("lecture_app_이전_*"), reverse=True):
                    os.replace(d, CODE)
                    break
            _overwrite(BACKUP / "lecture_app", CODE)
            for f in TOP_FILES:
                if (BACKUP / f).exists():
                    shutil.copy2(BACKUP / f, APP / f)
            _log("바꿔 끼우기 실패 → 직전 버전으로 되돌림")
    except Exception as e:
        _log(f"되돌리기도 실패: {e}")


def apply(busy=False) -> dict:
    """새 버전을 받아 바꿔 끼움. 성공하면 앱을 새 코드로 다시 켜야 함 (gui 가 함).
    busy: 받기가 진행 중인지 (bool 또는 함수 · 함수면 잠근 뒤에 한 번 더 확인)"""
    is_busy = busy if callable(busy) else (lambda: bool(busy))
    if not enabled():
        return {"ok": False, "msg": "업데이트 확인이 꺼져 있어요."}
    if is_busy():
        return {"ok": False, "msg": "받기가 진행 중이에요. 끝난 뒤에 업데이트할게요."}
    try:
        if not _take_lock():
            return {"ok": False, "msg": "이미 업데이트하는 중이에요."}
    except OSError as e:
        return {"ok": False, "msg": f"업데이트를 시작하지 못했어요: {e}"}
    if is_busy():                    # 잠그는 사이에 받기가 시작됐으면 (잠근 뒤로는 받기가 시작되지 않음)
        try:
            LOCK.rmdir()
        except OSError:
            pass
        return {"ok": False, "msg": "받기가 진행 중이에요. 끝난 뒤에 업데이트할게요."}
    work = APP / "logs" / f"_업데이트_받는중_{os.getpid()}"
    swapping = False
    try:
        m = _manifest()                                      # 받기 직전에 한 번 더 (서명 확인 포함)
        v = m["version"]
        cur = current()
        if not _newer(v, cur):
            return {"ok": False, "msg": "이미 최신 버전이에요."}
        if m.get("full"):
            return {"ok": False, "full": True, "msg": "이번 버전은 설치 파일이 바뀌어서, 노션에서 새 zip을 받아 설치해야 해요."}
        data = _get(_base(v) + str(m.get("file") or "update.tgz"), MAX_SIZE, timeout=120)
        if hashlib.sha256(data).hexdigest() != m["sha256"]:
            raise RuntimeError("받은 파일이 서명된 정보와 달라요")
        shutil.rmtree(work, ignore_errors=True)
        work.mkdir(parents=True)
        with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as tf:
            for mem in _safe_members(tf):
                tf.extract(mem, work)
        new_code = work / "lecture_app"
        if not (new_code / "__main__.py").exists() or not (new_code / "gui.html").exists():
            raise RuntimeError("앱 파일이 빠져 있어요")
        if (work / "VERSION").read_text("utf-8").strip() != v:
            raise RuntimeError("버전 표시가 맞지 않아요")
        for f in new_code.rglob("*.py"):                   # 깨진 파일이면 바꾸기 전에 멈춤
            py_compile.compile(str(f), cfile=str(work / "_chk.pyc"), doraise=True)
        try:
            (work / "_chk.pyc").unlink()
        except Exception:
            pass
        # 새 라이브러리가 필요하면 먼저 설치 (실패하면 바꾸지 않음)
        nreq, oreq = work / "requirements.txt", APP / "requirements.txt"
        if nreq.exists() and (not oreq.exists() or nreq.read_bytes() != oreq.read_bytes()):
            err = _pip(nreq)
            if err:
                raise RuntimeError("필요한 프로그램을 설치하지 못했어요: " + err)
        # 직전 버전 백업
        shutil.rmtree(BACKUP, ignore_errors=True)
        BACKUP.mkdir(parents=True)
        shutil.copytree(CODE, BACKUP / "lecture_app", ignore=shutil.ignore_patterns("__pycache__"))
        for f in TOP_FILES:
            if (APP / f).exists():
                shutil.copy2(APP / f, BACKUP / f)
        # 바꿔 끼우기: 폴더째 이름 바꾸기 (중간에 멈춰도 반쯤 섞인 상태가 안 생기게)
        swapping = True
        old = APP / f"lecture_app_이전_{int(time.time())}"
        try:
            os.replace(CODE, old)
        except OSError:                                    # 윈도우에서 폴더가 잠겨 있으면 파일 단위로 덮어씀
            old = None
            _overwrite(new_code, CODE)
        if old is not None:
            try:
                os.replace(new_code, CODE)
            except Exception:
                os.replace(old, CODE)
                raise
        for f in ("requirements.txt", "lecture_app_run.pyw"):
            if (work / f).exists():
                shutil.copy2(work / f, APP / f)
        tmpv = APP / "VERSION.tmp"
        tmpv.write_text(v + "\n", "utf-8")
        os.replace(tmpv, APP / "VERSION")
        now = time.time()
        for d in ([old] if old else []) + list(APP.glob("lecture_app_이전_*")):          # 예전 폴더 정리 (윈도우에서 잠겨 있으면 다음에)
            shutil.rmtree(d, ignore_errors=True)
        try:
            os.utime(CODE / "__init__.py", (now, now))     # 켜져 있는 앱이 '코드가 바뀜'을 알아채게
        except Exception:
            pass
        swapping = False

        def done(x):
            x.pop("schedule", None)
            x["last"] = {"from": cur, "to": v, "at": f"{datetime.now():%Y-%m-%d %H:%M}"}
        _edit(done)
        _log(f"업데이트 완료: {cur} → {v}")
        return {"ok": True, "version": v, "from": cur, "msg": f"{v}(으)로 업데이트했어요. 앱이 다시 켜져요."}
    except Exception as e:
        _log(f"업데이트 실패: {e}")
        if swapping:
            _restore_backup()
        return {"ok": False, "msg": f"업데이트하지 못했어요: {e}"}
    finally:
        shutil.rmtree(work, ignore_errors=True)
        try:
            LOCK.rmdir()
        except Exception:
            pass


def rollback(busy=False) -> dict:
    """직전 버전으로 되돌리기 (방금 업데이트한 버전에서만) · 그 버전은 다시 자동으로 깔지 않음"""
    is_busy = busy if callable(busy) else (lambda: bool(busy))
    st0 = _load()
    lst = st0.get("last") or {}
    if not (BACKUP / "lecture_app" / "__main__.py").exists() or not lst.get("from") \
            or lst.get("to") != current() or _backup_version() != lst.get("from"):
        return {"ok": False, "msg": "되돌릴 이전 버전이 없어요."}
    if is_busy():
        return {"ok": False, "msg": "받기가 진행 중이에요. 끝난 뒤에 해 주세요."}
    if not _take_lock():
        return {"ok": False, "msg": "업데이트하는 중이에요. 끝난 뒤에 해 주세요."}
    tmp = APP / f"lecture_app_되돌림_{os.getpid()}"
    try:
        if is_busy():
            return {"ok": False, "msg": "받기가 진행 중이에요. 끝난 뒤에 해 주세요."}
        bad = current()
        shutil.rmtree(tmp, ignore_errors=True)
        shutil.copytree(BACKUP / "lecture_app", tmp)
        old = APP / f"lecture_app_이전_{int(time.time())}"
        try:
            os.replace(CODE, old)
            os.replace(tmp, CODE)
        except OSError:
            if not CODE.exists() and old.exists():
                os.replace(old, CODE)
            _overwrite(BACKUP / "lecture_app", CODE)
        for f in TOP_FILES:
            if (BACKUP / f).exists():
                shutil.copy2(BACKUP / f, APP / f)
        for d in APP.glob("lecture_app_이전_*"):
            shutil.rmtree(d, ignore_errors=True)
        now = time.time()
        os.utime(CODE / "__init__.py", (now, now))

        def f(x):                                     # 되돌린 버전은 자동 업데이트로도 다시 깔지 않음 (더 새 버전은 받음)
            x["later"] = {"version": bad, "until": now + 60 * 86400}
            x.pop("schedule", None)
            x.pop("last", None)
        _edit(f)
        _log(f"되돌리기: {bad} → {current()}")
        return {"ok": True, "msg": "이전 버전으로 되돌렸어요. 앱이 다시 켜져요."}
    except Exception as e:
        _log(f"되돌리기 실패: {e}")
        return {"ok": False, "msg": f"되돌리지 못했어요: {e}"}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
        try:
            LOCK.rmdir()
        except OSError:
            pass
