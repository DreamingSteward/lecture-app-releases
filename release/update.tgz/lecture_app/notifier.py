"""시스템 알림을 「강의록앱」 이름·로고로 보내기. 실패하면 예전 방식으로 보내고, 그것도 안 되면 조용히 넘어가요.

- 맥: 알림은 「알림을 보낸 프로그램」의 이름·아이콘으로 떠요. osascript 로 보내면 「스크립트 편집기」로 보여서,
  맥에 기본으로 있는 osacompile 로 작은 알림 전용 앱(logs/알림/강의록앱.app · Dock 에 안 보임)을 만들고
  로고를 붙여 서명한 뒤, 알림 내용을 파일로 넘겨 그 앱이 띄우게 해요. 처음 한 번 macOS 가 「알림 허용」을 물어요.
- 윈도우: 「강의록앱」 이름과 로고를 내 계정 설정(HKCU)에 등록하고 그 이름으로 윈도우 알림(토스트)을 보내요.
  안 되면 풍선 알림(로고 아이콘)으로 보내요.
"""
from __future__ import annotations

import os
import subprocess
import sys
import threading
import uuid
from pathlib import Path

APP = Path(__file__).resolve().parent.parent
ASSETS = Path(__file__).resolve().parent / "assets"
HELPER_VER = "2"
AUMID = "KCM.LectureApp"

_lock = threading.Lock()


# ---------------------------------------------------------------- 맥
def _mac_dir() -> Path:
    return APP / "logs" / "알림"


def _mac_helper() -> Path:
    return _mac_dir() / "강의록앱.app"


def _applescript() -> str:
    """ASCII 만 쓰는 스크립트 (osacompile 이 글자 인코딩을 잘못 읽지 않게) · 큐 폴더는 앱 자신 옆의 queue"""
    return '''on run
	set me_ to POSIX path of (path to me)
	set d to do shell script "cd " & quoted form of me_ & "/.. && pwd"
	set d to d & "/queue"
	set fs to paragraphs of (do shell script "ls -1 " & quoted form of d & " 2>/dev/null | grep '[.]txt$' || true")
	repeat with f in fs
		if (f as text) is not "" then
			set fp to d & "/" & f
			try
				set L to paragraphs of (do shell script "cat " & quoted form of fp & "; rm -f " & quoted form of fp)
				set ttl to ""
				set msg to ""
				set snd to ""
				if (count of L) >= 1 then set ttl to item 1 of L
				if (count of L) >= 2 then set msg to item 2 of L
				if (count of L) >= 3 then set snd to item 3 of L
				if snd is "" then
					display notification msg with title ttl
				else
					display notification msg with title ttl sound name snd
				end if
				delay 0.4
			end try
		end if
	end repeat
end run
'''


def mac_ensure() -> bool:
    """알림 전용 앱이 없거나 예전 것이면 새로 만들어요 (몇 초) · 성공하면 True"""
    if sys.platform != "darwin":
        return False
    h = _mac_helper()
    ver = h / "Contents" / "Resources" / "lecture_notify_ver.txt"
    try:
        if ver.read_text().strip() == HELPER_VER:
            return True
    except OSError:
        pass
    with _lock:
        try:
            d = _mac_dir()
            (d / "queue").mkdir(parents=True, exist_ok=True)
            src = d / "notify.applescript"
            src.write_text(_applescript(), "ascii")
            tmp = d / f"_만드는중_{os.getpid()}.app"
            subprocess.run(["rm", "-rf", str(tmp)], timeout=30)
            r = subprocess.run(["/usr/bin/osacompile", "-o", str(tmp), str(src)], capture_output=True, timeout=60)
            if r.returncode != 0 or not tmp.exists():
                return False
            res = tmp / "Contents" / "Resources"
            png = ASSETS / "icon-512.png"
            if png.exists():                                   # 로고 → 앱 아이콘 (맥 기본 도구 sips)
                subprocess.run(["/usr/bin/sips", "-s", "format", "icns", str(png), "--out", str(res / "applet.icns")],
                               capture_output=True, timeout=60)
            plist = tmp / "Contents" / "Info.plist"
            pb = "/usr/libexec/PlistBuddy"
            for k, t, v in (("CFBundleIdentifier", "string", "kr.knu.lecture-app.notify"), ("CFBundleName", "string", "강의록앱"),
                            ("CFBundleDisplayName", "string", "강의록앱"), ("LSUIElement", "bool", "true")):
                if subprocess.run([pb, "-c", f"Add :{k} {t} {v}", str(plist)], capture_output=True, timeout=10).returncode != 0:
                    subprocess.run([pb, "-c", f"Set :{k} {v}", str(plist)], capture_output=True, timeout=10)   # 이미 있으면 바꾸기
            subprocess.run([pb, "-c", "Delete :CFBundleIconName", str(plist)], capture_output=True, timeout=10)   # 기본 아이콘(Assets.car) 대신 로고
            try:
                (res / "Assets.car").unlink()
            except OSError:
                pass
            (res / "lecture_notify_ver.txt").write_text(HELPER_VER)
            subprocess.run(["/usr/bin/codesign", "--force", "--deep", "-s", "-", str(tmp)], capture_output=True, timeout=60)
            subprocess.run(["rm", "-rf", str(h)], timeout=30)
            tmp.rename(h)
            subprocess.run(["/usr/bin/touch", str(h)], timeout=10)     # 아이콘 새로 읽게
            return True
        except Exception:
            return False


def _mac_send(title: str, msg: str, sound: str) -> bool:
    try:
        if not mac_ensure():
            return False
        q = _mac_dir() / "queue"
        q.mkdir(parents=True, exist_ok=True)
        one = lambda s: " ".join(str(s or "").split())                # 줄바꿈은 한 줄로 (줄마다 제목·내용·소리)
        tmp = q / f"{uuid.uuid4().hex}.part"
        tmp.write_text(f"{one(title)}\n{one(msg)}\n{one(sound)}\n", "utf-8")
        tmp.rename(tmp.with_suffix(".txt"))
        r = subprocess.run(["/usr/bin/open", "-g", "-n", str(_mac_helper())], capture_output=True, timeout=15)
        return r.returncode == 0
    except Exception:
        return False


def _mac_fallback(title: str, msg: str, sound: str):
    q = lambda t: str(t).replace("\\", "\\\\").replace('"', '\\"')
    s = f' sound name "{q(sound)}"' if sound else ""
    subprocess.run(["/usr/bin/osascript", "-e", f'display notification "{q(msg)}" with title "{q(title)}"{s}'],
                   capture_output=True, timeout=10)


# ---------------------------------------------------------------- 윈도우
def win_register() -> bool:
    """윈도우에 「강의록앱」 이름·로고 등록 (내 계정 설정만 · 관리자 권한 필요 없음)"""
    if os.name != "nt":
        return False
    try:
        import winreg
        icon = ASSETS / "icon-192.png"
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, rf"Software\Classes\AppUserModelId\{AUMID}") as k:
            winreg.SetValueEx(k, "DisplayName", 0, winreg.REG_SZ, "강의록앱")
            if icon.exists():
                winreg.SetValueEx(k, "IconUri", 0, winreg.REG_SZ, str(icon))
            winreg.SetValueEx(k, "IconBackgroundColor", 0, winreg.REG_SZ, "FFFFFFFF")
        return True
    except Exception:
        return False


_WIN_PS = r"""
$t=$env:LA_N_TITLE; $m=$env:LA_N_MSG
try {
  $null=[Windows.UI.Notifications.ToastNotificationManager,Windows.UI.Notifications,ContentType=WindowsRuntime]
  $null=[Windows.Data.Xml.Dom.XmlDocument,Windows.Data.Xml.Dom.XmlDocument,ContentType=WindowsRuntime]
  $x=New-Object Windows.Data.Xml.Dom.XmlDocument
  $x.LoadXml('<toast><visual><binding template="ToastGeneric"><text></text><text></text></binding></visual></toast>')
  $n=$x.GetElementsByTagName('text'); $null=$n.Item(0).AppendChild($x.CreateTextNode($t)); $null=$n.Item(1).AppendChild($x.CreateTextNode($m))
  [Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier($env:LA_N_ID).Show([Windows.UI.Notifications.ToastNotification]::new($x))
} catch {
  [reflection.assembly]::loadwithpartialname('System.Windows.Forms')|Out-Null; [reflection.assembly]::loadwithpartialname('System.Drawing')|Out-Null
  $b=New-Object System.Windows.Forms.NotifyIcon
  try { $b.Icon=New-Object System.Drawing.Icon($env:LA_N_ICO) } catch { $b.Icon=[System.Drawing.SystemIcons]::Information }
  $b.Text='강의록앱'; $b.Visible=$true; $b.ShowBalloonTip(8000,$t,$m,0); Start-Sleep 9; $b.Dispose()
}
"""


def _win_send(title: str, msg: str):
    win_register()
    env = dict(os.environ, LA_N_TITLE=str(title), LA_N_MSG=str(msg), LA_N_ID=AUMID, LA_N_ICO=str(APP / "icon.ico"))
    subprocess.Popen(["powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command", _WIN_PS], env=env,
                     creationflags=0x08000000)


# ---------------------------------------------------------------- 공통
def notify(title: str, msg: str, sound: str = "Glass"):
    """시스템 알림 · 실패해도 조용히 넘어감"""
    try:
        if sys.platform == "darwin":
            if not _mac_send(title, msg, sound):
                _mac_fallback(title, msg, sound)
        elif os.name == "nt":
            _win_send(title, msg)
    except Exception:
        pass


def prepare():
    """앱을 켤 때 미리 준비 (알림이 처음 필요할 때 기다리지 않게) · 따로 돌려요"""
    def run():
        try:
            if sys.platform == "darwin":
                mac_ensure()
            elif os.name == "nt":
                win_register()
        except Exception:
            pass
    threading.Thread(target=run, daemon=True).start()
