"""시간표(「의학과 2학년 2학기 강좌별 교수」 아티팩트에서 내보낸 시간표.json) 읽기.

한 줄(row) = 강의 하나. 같은 날·같은 교시·같은 교수가 여러 주제를 한 번에 하면
하나의 '강의 묶음'으로 합친다 (예: 10/23 6-7교시 착상·배아의 발달·태반 호르몬).
한 강의가 두 번에 나뉘어 있으면(10/19(월)·10/21(수), 4·3) 날짜별로 따로 만든다.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

def _year_key() -> str:
    """'올해' 기준 연도 (시간표의 올해 교수님 칸). 설정에 tt_year 가 있으면 그것, 없으면 지금 학년도
    (1·2월은 아직 지난해 2학기라 지난해). 새 학년도 시간표를 넣으면 그 해가 '올해', 예전 해는 역대 교수가 됨."""
    try:
        from . import grades as _g
        cfg = _g.merge(_g.raw_cfg())
        y = str(cfg.get("tt_year") or "").strip()
        if re.fullmatch(r"20\d\d", y):
            return y
    except Exception:
        pass
    from datetime import date
    t = date.today()
    return str(t.year - 1 if t.month <= 2 else t.year)


YEAR_KEY = _year_key()
SKIP_TITLE = re.compile(r"(중간|기말)고사|휴강|오리엔테이션\s*$")   # 시험 일정은 AI 프롬프트에서 뺌


def norm_course(name: str) -> str:
    """과목명 비교용 키: '생식·성장·발달 II | 001 분반 (...)' → '생식성장발달II'."""
    s = name.split("|")[0]
    s = re.sub(r"^\s*\d+\.\s*", "", s)          # 드라이브 '2. 생식성장발달II'
    s = re.sub(r"[\s·・ㆍ•∙‧⋅･.,\-_/&+()\[\]]", "", s).replace("및", "")      # 「호흡기• 알레르기」 같은 다른 점·괄호도 무시
    s = s.replace("Ⅰ", "I").replace("Ⅱ", "II").replace("Ⅲ", "III")
    return s


def folder_course(name: str) -> str:
    """저장 폴더용 과목명: 공백 제거 ('생식성장발달 II' → '생식성장발달II')."""
    return re.sub(r"\s+", "", name.split("|")[0]).replace("·", "")


@dataclass
class Lecture:
    course: str              # 시간표 과목명 (예: 생식성장발달 II)
    term: int                # 차수 (0 = 차수 없음)
    mmdd: str                # '1023'
    start: int               # 시작 교시
    hours: int               # 시간수
    titles: List[str]        # 묶인 주제들
    profs: List[str]         # 교수님들
    key: str = ""            # 고유 키 (매칭 기억용)
    extra: dict = field(default_factory=dict)

    @property
    def title(self) -> str:
        return "·".join(self.titles)

    def history(self) -> List[tuple]:
        """[(연도, [교수님들])] 최근 연도부터 — 표지 왼쪽 '역대 담당 교수' 목록용"""
        return self.extra.get("hist", [])

    @property
    def month(self) -> int:
        return int(self.mmdd[:2])

    @property
    def day(self) -> int:
        return int(self.mmdd[2:])

    @property
    def course_folder(self) -> str:
        return folder_course(self.course)

    @property
    def term_folder(self) -> Optional[str]:
        return f"{self.term}차" if self.term else None

    def periods(self) -> List[int]:
        return list(range(self.start, self.start + self.hours))


def _parse_period(g: str):
    m = re.match(r"\s*(\d+)\s*(?:[-~–]\s*(\d+))?", g or "")
    if not m:
        return None
    a = int(m.group(1))
    b = int(m.group(2) or a)
    return a, max(1, b - a + 1)


def _parse_dates(d: str) -> List[str]:
    """'10/19(월)·10/21(수)' → ['1019','1021'], '10/8·10/15(목)' → ['1008','1015']."""
    out = []
    for part in re.split(r"[·,]", d or ""):
        m = re.search(r"(\d{1,2})/(\d{1,2})", part)
        if m:
            out.append(f"{int(m.group(1)):02d}{int(m.group(2)):02d}")
    return out


def _profs(raw: str) -> List[str]:
    raw = (raw or "").strip().lstrip("*")
    if not raw or raw in ("—", "-"):
        return []
    return [p.strip().lstrip("*") for p in re.split(r"[·,/]", raw) if p.strip() and p.strip() != "—"]


def load(path: Path) -> List[Lecture]:
    data = json.loads(Path(path).read_text(encoding="utf-8-sig"))
    singles: List[Lecture] = []
    for course in data:
        cname = course["name"]
        years = [str(y) for y in course.get("years") or []]
        for r in course["rows"]:
            title = (r.get("t") or "").strip()
            if not title or SKIP_TITLE.search(title):
                continue
            dates = _parse_dates(r.get("d", ""))
            gparts = [p for p in re.split(r"·", r.get("g", "") or "")]
            if not dates:
                continue
            profs = _profs((r.get("y") or {}).get(YEAR_KEY, ""))
            for i, dd in enumerate(dates):
                g = gparts[i] if i < len(gparts) else (gparts[-1] if gparts else "")
                p = _parse_period(g)
                if not p:
                    continue
                yp = r.get("y") or {}
                hist = [(y, _profs(yp.get(y, ""))) for y in (years or sorted(yp, reverse=True))]
                singles.append(Lecture(cname, int(r.get("term") or 0), dd, p[0], p[1], [title], profs,
                                       extra={"hist": hist}))
    # 같은 날·같은 교시·같은 교수 → 묶기
    grouped: dict = {}
    for L in singles:
        k = (L.course, L.term, L.mmdd, L.start, L.hours, tuple(L.profs))
        if k in grouped:
            g = grouped[k]
            g.titles.append(L.titles[0])
            # 묶인 주제들의 연도별 교수님을 합침 (같은 분이면 한 번만)
            merged = []
            for (y, a), (_, b) in zip(g.extra.get("hist", []), L.extra.get("hist", [])):
                merged.append((y, a + [x for x in b if x not in a]))
            g.extra["hist"] = merged
        else:
            grouped[k] = L
    out = list(grouped.values())
    for L in out:
        L.key = f"{folder_course(L.course)}|{L.mmdd}-{L.start}|{L.title}"
    out.sort(key=lambda L: (L.course, L.mmdd, L.start))
    return out


def courses(lectures: List[Lecture]) -> List[str]:
    seen = []
    for L in lectures:
        if L.course not in seen:
            seen.append(L.course)
    return seen
