"""시간표(「의학과 2학년 2학기 강좌별 교수」 아티팩트에서 내보낸 시간표.json) 읽기.

한 줄(row) = 강의 하나. 같은 날·같은 교시·같은 교수가 여러 주제를 한 번에 하면
하나의 '강의 묶음'으로 합친다 (예: 10/23 6-7교시 착상·배아의 발달·태반 호르몬).
한 강의가 두 번에 나뉘어 있으면(10/19(월)·10/21(수), 4·3) 날짜별로 따로 만든다.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

def year_num(key) -> int:
    """학기 이름표('2026', '2026 계절') → 학년도 숫자 (달력 날짜 계산용: 1·2월 수업은 다음 해)"""
    m = re.match(r"\s*(20\d\d)", str(key or ""))
    if m:
        return int(m.group(1))
    from datetime import date
    t = date.today()
    return t.year - 1 if t.month <= 2 else t.year


def key_from_data(data) -> Optional[str]:
    """시간표.json 에서 '이번 학기' 칸 이름: 저장해 둔 cur, 없으면 날짜가 적힌 수업 줄의 가장 최근 칸"""
    keys = {str(c["cur"]) for c in data or [] if isinstance(c, dict) and c.get("cur")}
    if keys:
        return max(keys)
    cnt: dict = {}            # 예전 시간표(cur 없음): 날짜가 적힌 수업 줄 '모두'에 있는 칸이 이번 학기 (지난 기록 칸은 일부 줄에만)
    for c in data or []:
        for r in (c.get("rows") or []) if isinstance(c, dict) else []:
            if str(r.get("d") or "").strip():
                for k in (r.get("y") or {}):
                    if re.match(r"20\d\d", str(k)):
                        cnt[str(k)] = cnt.get(str(k), 0) + 1
    return max(cnt, key=lambda k: (cnt[k], k)) if cnt else None


def _year_key() -> str:
    """'이번 학기' 칸 이름 (시간표의 이번 학기 교수님 칸).
    오늘 날짜가 아니라 그 학기 시간표 자체로 정함: 날짜·교시가 적힌 수업 = 이번 학기 수업.
    (시간표가 비어 있을 때만 예전 설정 tt_year → 지금 학년도)"""
    try:
        from . import grades as _g
        data = json.loads((_g.data_dir() / "시간표.json").read_text("utf-8-sig"))
        k = key_from_data(data)
        if k:
            return k
    except Exception:
        pass
    try:
        from . import grades as _g
        cfg = _g.merge(_g.raw_cfg())
        y = str(cfg.get("tt_year") or "").strip()
        if re.fullmatch(r"20\d\d", y):
            return y
    except Exception:
        pass
    return str(year_num(""))


_MONTHS: set = set()      # 이번 학기 수업이 있는 달 (달력 연도 계산용)


def _months_from_data(data) -> set:
    out = set()
    for c in data or []:
        for r in (c.get("rows") or []) if isinstance(c, dict) else []:
            for m in re.finditer(r"(\d{1,2})/\d{1,2}", str(r.get("d") or "")):
                if 1 <= int(m.group(1)) <= 12:
                    out.add(int(m.group(1)))
    return out


def _load_months():
    global _MONTHS
    try:
        from . import grades as _g
        _MONTHS = _months_from_data(json.loads((_g.data_dir() / "시간표.json").read_text("utf-8-sig")))
    except Exception:
        _MONTHS = set()


def cal_year(month: int, key: Optional[str] = None, months: Optional[set] = None) -> int:
    """이번 학기 수업의 달 → 실제 달력 연도 (오늘 날짜와 상관없이 학기 이름표로).
    - 2학기처럼 가을(8월~)부터 이어지면 1·2월 수업은 다음 해
    - 겨울 계절학기(이름표에 '계절', 1·2월에 시작하고 가을 수업 없음)는 모두 다음 해 (예: 2025 계절 = 2026년 1~4월)"""
    y = year_num(YEAR_KEY if key is None else key)
    ms = _MONTHS if months is None else months
    k = str(YEAR_KEY if key is None else key)
    fall = any(m >= 8 for m in ms)
    if "계절" in k and not fall and (ms & {1, 2}):
        return y + 1
    if month <= 2 and (fall or not ms):
        return y + 1
    return y


def set_year_key(k: str):
    """이번 학기 칸 이름을 바꿈 (시간표를 새로 넣을 때). 이 값을 import 해 둔 모듈도 같이."""
    import sys
    global YEAR_KEY
    YEAR_KEY = str(k)
    for name in ("tt_edit", "render", "gui", "main", "covers"):
        m = sys.modules.get(f"{__package__}.{name}")
        if m is not None and hasattr(m, "YEAR_KEY"):
            m.YEAR_KEY = YEAR_KEY


def refresh_year_key():
    _load_months()
    set_year_key(_year_key())


YEAR_KEY = _year_key()
_load_months()
SKIP_TITLE = re.compile(r"(중간|기말)고사|휴강")   # 시험 일정은 AI 프롬프트에서 뺌 · 오리엔테이션은 수업으로 (2026-11-04)


def norm_course(name: str) -> str:
    """과목명 비교용 키: '생식·성장·발달 II | 001 분반 (...)' → '생식성장발달II'."""
    s = name.split("|")[0]
    s = re.sub(r"^\s*\d+\.\s*", "", s)          # 드라이브 '2. 생식성장발달II'
    s = re.sub(r"[\s·・ㆍ•∙‧⋅･.,\-_/&+()\[\]]", "", s).replace("및", "")      # 「호흡기• 알레르기」 같은 다른 점·괄호도 무시
    s = s.replace("Ⅰ", "I").replace("Ⅱ", "II").replace("Ⅲ", "III")
    return s


def folder_course(name: str) -> str:
    """저장 폴더용 과목명: 공백 제거 ('생식성장발달 II' → '생식성장발달II').
    · 폴더 경로가 되므로 / \\ : * ? " < > | 같은 글자와 앞뒤 점은 뺌 (시간표의 과목 이름이 '../x' 여도 정리 폴더 밖으로 못 나가게)"""
    s = re.sub(r"\s+", "", str(name or "").split("|")[0]).replace("·", "")
    s = re.sub(r'[\\/:*?"<>|\x00-\x1f]', "", s).strip(".")
    return s or "과목"


@dataclass
class Lecture:
    course: str              # 시간표 과목명 (예: 생식성장발달 II)
    term: int                # 차수 (0 = 차수 없음)
    mmdd: str                # '1023'
    start: int               # 시작 교시
    hours: int               # 시간수
    titles: List[str]        # 묶인 주제들
    profs: List[str]         # 교수님들
    key: str = ""            # 고유 키 (매칭 기억용)
    extra: dict = field(default_factory=dict)

    @property
    def title(self) -> str:
        return "·".join(self.titles)

    def history(self) -> List[tuple]:
        """[(연도, [교수님들])] 최근 연도부터 — 표지 왼쪽 '역대 담당 교수' 목록용"""
        return self.extra.get("hist", [])

    @property
    def month(self) -> int:
        return int(self.mmdd[:2])

    @property
    def day(self) -> int:
        return int(self.mmdd[2:])

    @property
    def course_folder(self) -> str:
        return folder_course(self.course)

    @property
    def term_folder(self) -> Optional[str]:
        return f"{self.term}차" if self.term else None

    def periods(self) -> List[int]:
        return list(range(self.start, self.start + self.hours))

    @property
    def period_label(self) -> str:
        """교시 표기: 「1-2」「3」 · 예과처럼 30분 칸이 있으면 「2B-3」"""
        return self.extra.get("g") or (f"{self.start}" if self.hours <= 1 else f"{self.start}-{self.start + self.hours - 1}")

    def halves(self):
        """30분 칸 (h0, h1) · n교시 = (2n-1, 2n)"""
        return half_span(self.extra.get("g")) if self.extra.get("g") else (2 * self.start - 1, 2 * (self.start + self.hours - 1))


_PER = re.compile(r"\s*(\d+)\s*([AaBb])?\s*(?:[-~–]\s*(\d+)\s*([AaBb])?)?")


def _parse_period(g: str):
    """「1-2」「3」「2B-3」「6A~6B」 → (시작 교시, 걸친 교시 수) · A = 그 교시 앞 30분, B = 뒤 30분 (예과 시간표)"""
    m = _PER.match(g or "")
    if not m:
        return None
    a = int(m.group(1))
    b = int(m.group(3) or a)
    return a, max(1, b - a + 1)


def period_label(g: str) -> str:
    """반 교시(A·B)가 있으면 정리한 표기 (예: 「2B~3」 → 「2B-3」, 「6A-6B」 → 「6」) · 없으면 "" """
    m = _PER.match(str(g or "").replace("교시", "").strip())
    if not m or not (m.group(2) or m.group(4)):
        return ""
    h0, h1 = half_span(m.group(0))
    lab = half_label(h0, h1)
    return lab if re.search(r"[AB]", lab) else ""          # 「6A~6B」처럼 딱 교시면 그냥 교시로


def half_span(g: str):
    """교시 표기 → 30분 칸 (h0, h1) · n교시 = (2n-1, 2n) · nA = 2n-1 · nB = 2n"""
    m = _PER.match(g or "")
    if not m:
        return None
    a, sa = int(m.group(1)), (m.group(2) or "").upper()
    b, sb = (int(m.group(3)), (m.group(4) or "").upper()) if m.group(3) else (a, sa)
    h0 = 2 * a if sa == "B" else 2 * a - 1
    h1 = 2 * b - 1 if sb == "A" else 2 * b
    return h0, max(h0, h1)


def half_label(h0: int, h1: int) -> str:
    n0, n1 = (h0 + 1) // 2, (h1 + 1) // 2
    if h0 == h1:
        return f"{n0}{'A' if h0 % 2 else 'B'}"
    s = f"{n0}" if h0 % 2 else f"{n0}B"
    e = f"{n1}" if h1 % 2 == 0 else f"{n1}A"
    return s if s == e else f"{s}-{e}"


def _parse_dates(d: str) -> List[str]:
    """'10/19(월)·10/21(수)' → ['1019','1021'], '10/8·10/15(목)' → ['1008','1015']."""
    out = []
    for part in re.split(r"[·,]", d or ""):
        m = re.search(r"(\d{1,2})/(\d{1,2})", part)
        if m:
            out.append(f"{int(m.group(1)):02d}{int(m.group(2)):02d}")
    return out


def _profs(raw: str) -> List[str]:
    raw = (raw or "").strip().lstrip("*")
    if not raw or raw in ("—", "-"):
        return []
    return [p.strip().lstrip("*") for p in re.split(r"[·,/]", raw) if p.strip() and p.strip() != "—"]


PICK_F = "분반선택.json"          # 내 분반 · 선택교과목 고르기 {"sec": {과목: 분반}, "elect": {"선택교과목1": 과목 | "안 들음"}} (시간표.json 옆)
ELECT_RE = re.compile(r"^\s*(선택\s*교과목\s*\d*)\s*[(（]\s*(.+?)\s*[)）]\s*$")


def elect_slot(title: str):
    """「선택교과목1 (의공학/임상의학영양학/의학교육학개요)」 → ("선택교과목1", ["의공학", "임상의학영양학", "의학교육학개요"]) · 아니면 None"""
    m = ELECT_RE.match(title or "")
    if not m:
        return None
    opts = [x.strip() for x in re.split(r"\s*[/·,]\s*", m.group(2)) if x.strip()]
    return (re.sub(r"\s+", "", m.group(1)), opts) if opts else None


def read_pick(folder: Path) -> dict:
    try:
        v = json.loads((Path(folder) / PICK_F).read_text("utf-8"))
    except Exception:
        return {"sec": {}, "elect": {}}
    sec = {str(k): int(n) for k, n in (v.get("sec") or {}).items() if isinstance(n, int) and 1 <= n <= 20} if isinstance(v, dict) else {}
    el = {str(k): str(x) for k, x in (v.get("elect") or {}).items() if isinstance(x, str) and x.strip()} if isinstance(v, dict) else {}
    return {"sec": sec, "elect": el}


def load(path: Path) -> List[Lecture]:
    data = json.loads(Path(path).read_text(encoding="utf-8-sig"))
    pick = read_pick(Path(path).parent)          # 고른 분반 · 선택 과목 (고르지 않았으면 모두 그대로)
    singles: List[Lecture] = []
    for course in data:
        cname0 = course["name"]
        years = [str(y) for y in course.get("years") or []]
        for r in course["rows"]:
            title = (r.get("t") or "").strip()
            if not title or SKIP_TITLE.search(title):
                continue
            cname = cname0
            mine = pick["sec"].get(cname0)
            if mine and str(r.get("sec") or "").isdigit() and int(r["sec"]) != mine:
                continue                         # 다른 분반 수업 (분반이 없는 공통 수업은 그대로)
            es = elect_slot(title)
            if es and es[0] in pick["elect"]:
                ch = pick["elect"][es[0]]
                if ch == "안 들음":
                    continue
                if ch in es[1]:
                    cname = title = ch            # 고른 선택 과목 이름으로 (LMS 과목과 맞춤)
            dates = _parse_dates(r.get("d", ""))
            gparts = [p for p in re.split(r"·", r.get("g", "") or "")]
            sparts = re.split(r"·", r.get("s", "") or "")      # 같은 칸에 따로 두는 강의 표시 (옮기다 같은 자리에 모인 다른 강의 · 한 카드로 안 합침)
            if not dates:
                continue
            profs = _profs((r.get("y") or {}).get(YEAR_KEY, ""))
            for i, dd in enumerate(dates):
                g = gparts[i] if i < len(gparts) else (gparts[-1] if gparts else "")
                p = _parse_period(g)
                if not p:
                    continue
                yp = r.get("y") or {}
                hist = [(y, _profs(yp.get(y, ""))) for y in (years or sorted(yp, reverse=True))]
                ex = {"hist": hist}
                lab = period_label(g)
                if lab:
                    ex["g"] = lab               # 반 교시(30분) 표기 · 표지·화면에 그대로
                if i < len(sparts) and sparts[i].strip():
                    ex["sep"] = sparts[i].strip()
                singles.append(Lecture(cname, int(r.get("term") or 0), dd, p[0], p[1], [title], profs,
                                       extra=ex))
    # 같은 날·같은 교시·같은 교수 → 묶기
    grouped: dict = {}
    for L in singles:
        k = (L.course, L.term, L.mmdd, L.start, L.hours, tuple(L.profs), L.extra.get("g") or "", L.extra.get("sep") or "")   # 반 교시(2A·2B)·따로 둔 강의는 따로
        if k in grouped:
            g = grouped[k]
            g.titles.append(L.titles[0])
            # 묶인 주제들의 연도별 교수님을 합침 (같은 분이면 한 번만)
            merged = []
            for (y, a), (_, b) in zip(g.extra.get("hist", []), L.extra.get("hist", [])):
                merged.append((y, a + [x for x in b if x not in a]))
            g.extra["hist"] = merged
        else:
            grouped[k] = L
    out = list(grouped.values())
    base = {}
    for L in out:
        base.setdefault((folder_course(L.course), L.mmdd, L.start, L.title), []).append(L)
    for grp in base.values():
        # key 는 예전과 같게 (날짜-교시) · 같은 칸에 같은 제목 강의가 둘 이상일 때만 교시 표기(2A·2B·6-7)로 나눔 (그래도 같으면 교수)
        if len(grp) > 1:
            labs = [L.period_label for L in grp]
            for L, lab in zip(grp, labs):
                L.extra["kg"] = lab if labs.count(lab) == 1 else f"{lab}_{'·'.join(L.profs) or L.term}"
    for L in out:
        kg = L.extra.get("kg")                 # 파일 이름의 {교시}도 이걸로 (안 그러면 같은 이름)
        L.key = f"{folder_course(L.course)}|{L.mmdd}-{kg or L.start}|{L.title}"
    out.sort(key=lambda L: (L.course, L.mmdd, L.start))
    return out


def courses(lectures: List[Lecture]) -> List[str]:
    seen = []
    for L in lectures:
        if L.course not in seen:
            seen.append(L.course)
    return seen
