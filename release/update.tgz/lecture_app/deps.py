"""필요한 프로그램 받기 (앱 안에서) — 처음 설정 C02 「필요한 프로그램 설치」에 동의한 뒤에만 받음.

설치 파일(윈도우 exe · 맥 dmg)은 앱 파일 복사 · 파이썬 환경 만들기 · 바로가기까지만 하고 바로 앱 화면을 엶 (검은 창 없음).
여기서 하는 일 (예전 install.ps1 3·4단계 · setup.sh 3·4단계와 같음):
  1. 파이썬 꾸러미 (requirements.txt 를 읽어서 · 없거나 버전이 낮은 것)
  2. 자동 로그인용 브라우저 (Playwright 크로미움)
  3. LibreOffice (PPT → PDF 변환) — 이미 있으면 건너뜀 · 설치가 실패하면 기억해 두고 다시 자동으로 받지 않음(「직접 설치」 안내 · 설정 › 화면 › 필요한 프로그램의 [LibreOffice 다시 받기]), 받는 중 인터넷이 끊긴 것은 기억하지 않음
진행은 status() 로 화면(처음 설정 위 칩 · 홈 띠 · 상태 점)에 보여 줌. 실패하면 그 단계 메시지 + 「다시 받기」.
메뉴 막대(맥 rumps) · 알림 영역 아이콘(윈도우 pystray · Pillow)도 여기서 같이 받음 (없어도 받기는 됨 · 실패해도 계속).
"""
from __future__ import annotations

import glob
import importlib
import importlib.machinery
import importlib.util
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path

from . import main as M

WIN, MAC = os.name == "nt", sys.platform == "darwin"
# requirements.txt 이름 → 파이썬에서 부르는 이름 (다른 것만 · 나머지는 이름의 - 를 _ 로)
_IMPORT = {"python-pptx": "pptx", "fonttools": "fontTools", "pillow": "PIL", "pyyaml": "yaml", "beautifulsoup4": "bs4"}
_OPT = {"rumps", "pystray", "pillow"}          # 메뉴 막대 · 알림 영역 아이콘만 씀 → 없어도 강의록 받기는 됨
if not (WIN or MAC):
    _OPT.add("keyring")                        # 리눅스(개발 · 검토용)는 keyring 없이도 받기가 되게 (예전 목록도 윈도우만)
# requirements.txt 를 못 읽을 때만 (예전 목록)
_FALLBACK = ["playwright>=1.44", "python-pptx>=0.6.23", "pypdf>=4.0", "requests>=2.31", "gdown>=5.1", "lxml>=4.9",
             'keyring>=24; sys_platform != "darwin"', 'rumps>=0.4; sys_platform == "darwin"',
             'pystray>=0.19; sys_platform == "win32"', 'Pillow>=9; sys_platform == "win32"', "qrcode>=7", "fonttools>=4.40"]
# 받는 크기 (대략 · 화면 안내용) — 꾸러미 · 크로미움(Playwright 1.4x: 크로미움 + 창 없는 크로미움) · LibreOffice 설치 파일
SIZE_MB = {"mods": 70, "chromium": 300, "lo": 350 if WIN else 300}    # 크로미움: 2026-11 실측 191 + 120 + 2MiB (설치 뒤 디스크 약 680MB)
WHAT = {"준비": "준비하는 중", "pip": "파이썬 꾸러미", "opt": "메뉴 막대 아이콘", "chromium": "자동 로그인용 브라우저", "lo": "LibreOffice (PPT 변환)"}

_lock = threading.Lock()
_ST = {"busy": False, "pct": 0, "step": "", "msg": "", "err": "", "done_at": 0, "started": 0, "plan_lo": False, "detail": ""}


def _log(t: str):
    try:
        d = M.APP / "logs"
        d.mkdir(parents=True, exist_ok=True)
        with open(d / "필요한 프로그램.log", "a", encoding="utf-8") as f:
            f.write(time.strftime("%m-%d %H:%M:%S ") + t.rstrip() + "\n")
    except Exception:
        pass


# ---------------------------------------------------------------- requirements.txt 읽기
def _norm(n: str) -> str:
    return re.sub(r"[-_.]+", "-", n).lower()


def _marker_ok(mk: str) -> bool:
    """`; sys_platform == "win32"` 같은 조건 (and 로 이은 == · != 만 · 모르는 조건은 맞는 것으로)"""
    mk = (mk or "").strip()
    if not mk or " or " in mk:
        return True
    env = {"sys_platform": sys.platform, "platform_system": platform.system(), "os_name": os.name,
           "platform_machine": platform.machine()}
    for p in re.split(r"\s+and\s+", mk):
        m = re.fullmatch(r"\(?\s*(\w+)\s*(==|!=)\s*[\"']([^\"']*)[\"']\s*\)?", p.strip())
        if not m or m.group(1) not in env:
            continue
        if (env[m.group(1)] == m.group(3)) != (m.group(2) == "=="):
            return False
    return True


def _reqs() -> list:
    """이 기기에 필요한 꾸러미: [{name, key, min, mod, opt, spec}]"""
    try:
        lines = (M.APP / "requirements.txt").read_text("utf-8").splitlines()
    except Exception:
        lines = []
    out = []
    for l in (lines or _FALLBACK):
        l = l.split(" #", 1)[0].strip()
        if not l or l.startswith(("#", "-")):
            continue
        spec, _, mk = l.partition(";")
        if not _marker_ok(mk):
            continue
        m = re.match(r"([A-Za-z0-9][A-Za-z0-9._-]*)\s*(\[[^\]]*\])?\s*(.*)$", spec.strip())
        if not m:
            continue
        name = m.group(1)
        mn = re.search(r">=\s*([0-9][0-9.]*)", m.group(3) or "")
        out.append({"name": name, "key": _norm(name), "min": mn.group(1) if mn else "", "opt": _norm(name) in _OPT,
                    "mod": _IMPORT.get(_norm(name), name.replace("-", "_")), "spec": spec.strip()})
    return out


def _vt(v: str) -> tuple:
    return tuple(int(x) for x in re.findall(r"\d+", v or "")[:4])


def _ver(name: str):
    try:
        from importlib import metadata
        return metadata.version(name)
    except Exception:
        return None


def _have(r: dict) -> bool:
    """깔려 있고 버전도 맞는지 (설치 파일로 덮어 깔아 requirements.txt 가 바뀌었을 때도 알아챔)"""
    v = _ver(r["name"])
    if v is None:                                    # 꾸러미 정보가 없으면 불러오는 이름으로만 확인
        from . import _lazy
        m = sys.modules.get(r["mod"])
        if m is not None and not _lazy._proxy(m):
            return True
        _lazy._F.off = True                          # 자리표시(_lazy)가 「있다」고 답하지 않게
        try:
            return importlib.machinery.PathFinder.find_spec(r["mod"]) is not None
        except (ImportError, ValueError):
            return False
        finally:
            _lazy._F.off = False
    return not (r["min"] and _vt(v) < _vt(r["min"]))


def _mods_missing(opt: bool = False) -> list:
    importlib.invalidate_caches()
    return [r["name"] for r in _reqs() if r["opt"] == opt and not _have(r)]


def _pw_dir() -> Path:
    if os.environ.get("PLAYWRIGHT_BROWSERS_PATH"):
        return Path(os.environ["PLAYWRIGHT_BROWSERS_PATH"])
    if WIN:
        return Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "ms-playwright"
    if MAC:
        return Path.home() / "Library" / "Caches" / "ms-playwright"
    return Path.home() / ".cache" / "ms-playwright"


def _chromium_ok() -> bool:
    return any(Path(p).is_dir() for p in glob.glob(str(_pw_dir() / "chromium-*")))


def _lo_ok() -> bool:
    try:
        from . import render
        return bool(render.soffice_bin())
    except Exception:
        return False


def need() -> dict:
    """아직 없는 것: {"mods": [...], "opt": [...], "chromium", "lo", "any", "core"} — opt(메뉴 막대 아이콘)는 없어도 받기는 됨"""
    m = _mods_missing()
    ch = not _chromium_ok()
    lo = not _lo_ok()
    return {"mods": m, "opt": _mods_missing(True), "chromium": ch, "lo": lo, "any": bool(m or ch or lo), "core": bool(m or ch)}


def _cfg() -> dict:
    try:
        return M.read_cfg() or {}
    except Exception:
        return {}


def _cfg_set(**k):
    try:
        with M.CFG_LOCK:
            c = M.read_cfg()
            for a, b in k.items():
                if b is None:
                    c.pop(a, None)
                else:
                    c[a] = b
            M.write_cfg(c)
    except Exception as e:
        _log(f"설정 저장 실패: {e}")


def consented() -> bool:
    c = _cfg()
    return bool(c.get("deps_ok") or c.get("setup_done"))     # 예전 설치 프로그램으로 깐 사람(처음 설정을 마침)은 이미 동의한 것으로 (LibreOffice 는 자동으로 안 받음)


def _mb(n: int) -> str:
    if n >= 1000:
        return f"약 {n / 1000:.1f}GB"
    if n < 100:
        return f"약 {max(10, int(round(n / 10.0)) * 10)}MB"
    return f"약 {-(-n // 50) * 50}MB"                 # 올림 (동의하는 크기가 「무엇을 받나요?」 표 합보다 작아 보이지 않게: 670 → 700)


def size_info(n: dict | None = None, lo_try: bool | None = None) -> dict:
    """지금 받을 것과 크기 (C02 · 「무엇을 받나요?」)"""
    n = n or need()
    if lo_try is None:
        lo_try = not _cfg().get("deps_lo_fail")
    items = [
        {"k": "mods", "name": "파이썬 꾸러미", "use": "PDF 합치기 · 표지 · 드라이브 받기", "mb": SIZE_MB["mods"], "need": bool(n["mods"] or n.get("opt"))},
        {"k": "chromium", "name": "LMS 자동 로그인용 브라우저", "use": "LMS에서 강의록 받기 (앱 안에서만 써요)", "mb": SIZE_MB["chromium"], "need": bool(n["chromium"])},
        {"k": "lo", "name": "LibreOffice", "use": "PPT 강의록을 PDF로 바꾸기", "mb": SIZE_MB["lo"], "need": bool(n["lo"] and lo_try), "have": not n["lo"]},
    ]
    tot = sum(i["mb"] for i in items if i["need"])
    return {"items": items, "mb": tot, "size": _mb(tot) if tot else "", "size_nolo": _mb(SIZE_MB["mods"] + SIZE_MB["chromium"])}


def status() -> dict:
    with _lock:
        st = dict(_ST)
    n = need()
    c = _cfg()
    busy, step = st["busy"], st["step"]
    mods = bool(n["mods"]) or (busy and step in ("준비", "pip"))
    core = n["core"] or (busy and step in ("준비", "pip", "opt", "chromium"))
    fail_at = c.get("deps_lo_fail") or ""
    if not n["lo"]:
        lo = "ok"
    elif busy and step == "lo":
        lo = "busy"
    elif busy and st.get("plan_lo"):
        lo = "wait"
    elif fail_at:
        lo = "fail"
    else:
        lo = "missing"
    si = size_info(n, not fail_at)
    st.update({"ok": True, "need": n["any"] or busy, "core": core, "mods": mods,
               "mods_ok": not mods, "chromium_ok": not n["chromium"] and not (busy and step == "chromium"), "core_ok": not core,
               "lo": lo, "lo_missing": n["lo"], "lo_at": fail_at or ("old" if n["lo"] else ""),
               "consent": consented(), "what": WHAT.get(step, ""), "size": si["size"] or si["size_nolo"], "items": si["items"], "mb": si["mb"],
               "plat": "win" if WIN else "mac" if MAC else "other"})
    if lo == "ok" and st.get("err") == "lo":                 # 직접 설치했으면 경고를 거둠
        st["err"] = ""
    return st


def _set(**k):
    with _lock:
        _ST.update(k)


def start(body: dict | None = None) -> dict:
    """동의하고 받기 시작 (이미 받는 중이면 그대로).
    agree=True: C02 동의 · auto=True: 앱을 켤 때(꾸러미 · 브라우저만) · 그 밖(「다시 받기」): LibreOffice 는 전에 실패하지 않았을 때만"""
    body = body or {}
    if body.get("agree") is True:
        _cfg_set(deps_ok=time.strftime("%Y-%m-%d"))
    if not consented():
        return {"ok": False, "msg": "먼저 「필요한 프로그램 설치」에 동의해 주세요."}
    lo_try = body.get("lo") is True or (not body.get("auto") and not _cfg().get("deps_lo_fail"))
    with _lock:
        if _ST["busy"]:
            return {"ok": True, "busy": True}
        _ST.update({"busy": True, "pct": 1, "step": "준비", "msg": "필요한 프로그램을 받을 준비를 하는 중…", "err": "", "detail": "",
                    "started": time.time(), "plan_lo": bool(lo_try)})
    threading.Thread(target=_run, args=(bool(lo_try),), daemon=True).start()
    return {"ok": True, "busy": True}


def auto_start():
    """앱을 켤 때: 예전에 동의했는데 꾸러미 · 자동 로그인 브라우저가 빠졌으면(업데이트로 꾸러미가 늘었거나 중간에 꺼짐) 조용히 다시 받음.
    LibreOffice 는 자동으로 받지 않음 (관리자 권한이 없는 PC 에서 켤 때마다 큰 받기 + 관리자 확인 창이 뜨지 않게)"""
    try:
        if consented() and need()["core"]:
            start({"auto": True})
    except Exception as e:
        _log(f"자동 시작 실패: {e}")


def menubar_ready() -> bool:
    """메뉴 막대 · 알림 영역 아이콘을 띄워도 되는지: 동의했고, 받는 중이 아니고, 아이콘 꾸러미가 있음 (설치 전 · 동의 전엔 인터넷으로 아무것도 안 받음)"""
    try:
        with _lock:
            if _ST["busy"]:
                return False
        return consented() and not _mods_missing(True)
    except Exception:
        return False


# ---------------------------------------------------------------- 실행
def _popen(args, **k):
    kw = dict(stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace", bufsize=1)
    if WIN:
        kw["creationflags"] = 0x08000000          # 검은 창 없이
    kw.update(k)
    return subprocess.Popen(args, **kw)


def _py() -> list:
    exe = sys.executable
    if WIN and exe.lower().endswith("pythonw.exe"):  # pythonw 로 켜진 앱: 꾸러미 설치는 python.exe 로 (창은 안 뜸)
        c = exe[:-len("pythonw.exe")] + "python.exe"
        if os.path.exists(c):
            exe = c
    if MAC and platform.machine() == "arm64" and shutil.which("arch"):
        return ["/usr/bin/arch", "-arm64", exe]
    return [exe]


class _Creep:
    """오래 말없이 도는 단계(설치 · winget): 퍼센트를 천천히 올려 멈춰 보이지 않게 (hi 바로 아래까지만)"""

    def __init__(self, lo: int, hi: int, every: float = 4.0):
        self.hi, self.every, self.on = hi, every, True
        _set(pct=max(lo, _ST["pct"]))
        threading.Thread(target=self._go, daemon=True).start()

    def _go(self):
        while self.on:
            time.sleep(self.every)
            with _lock:
                if self.on and _ST["busy"] and _ST["pct"] < self.hi - 1:
                    _ST["pct"] += 1

    def stop(self):
        self.on = False


def _bump(p: int):
    with _lock:
        if p > _ST["pct"]:
            _ST["pct"] = p


def _why(tail: str, what: str) -> str:
    t = tail.lower()
    if "no space left" in t or "errno 28" in t or "not enough space" in t:
        return f"{what}를 받다가 멈췄어요 · 디스크 공간이 모자라요. 공간을 비운 뒤 「다시 받기」를 눌러 주세요."
    if "winerror 32" in t or "winerror 5" in t or "being used by another process" in t or "access is denied" in t:
        return f"{what}를 받다가 멈췄어요 · 다른 프로그램(백신 등)이 파일을 쓰고 있어요. 잠시 뒤 「다시 받기」를 눌러 주세요."
    return f"{what}를 받다가 멈췄어요 · 인터넷 연결을 확인하고 「다시 받기」를 눌러 주세요."


def _has_pip() -> bool:
    try:
        return subprocess.run(_py() + ["-m", "pip", "--version"], capture_output=True, timeout=60,
                              creationflags=0x08000000 if WIN else 0).returncode == 0
    except Exception:
        return False


def _ensure_pip():
    """앱 전용 파이썬에 pip 이 없을 때 (새 맥 · 일부 파이썬은 venv 를 pip 없이 만듦): ensurepip → 안 되면 get-pip.py"""
    if _has_pip():
        return
    _log("pip 없음 → ensurepip")
    p = _popen(_py() + ["-m", "ensurepip", "--upgrade", "--default-pip"])
    for line in p.stdout:
        _log("ensurepip: " + line)
    p.wait()
    if _has_pip():
        return
    _log("ensurepip 안 됨 → get-pip.py")
    tmp = Path(tempfile.mkstemp(suffix=".py")[1])
    try:
        import urllib.request
        with urllib.request.urlopen("https://bootstrap.pypa.io/get-pip.py", timeout=120) as r:
            tmp.write_bytes(r.read())
        p = _popen(_py() + [str(tmp), "--disable-pip-version-check"])
        for line in p.stdout:
            _log("get-pip: " + line)
        p.wait()
    except Exception as e:
        _log(f"get-pip 실패: {e!r}")
    finally:
        try:
            tmp.unlink()
        except Exception:
            pass
    if not _has_pip():
        raise RuntimeError("파이썬 꾸러미를 받다가 멈췄어요 · 앱 전용 파이썬에 꾸러미 설치 도구(pip)가 없어요. 인터넷 연결을 확인하고 「다시 받기」를 눌러 주세요. 계속 안 되면 앱을 지우고 다시 설치해 주세요.")


def _pip(lo: int, hi: int):
    _ensure_pip()
    reqs = _reqs()
    main = [r for r in reqs if not r["opt"]]
    opt = [r for r in reqs if r["opt"]]
    _set(step="pip", pct=lo, msg="파이썬 꾸러미를 받는 중…", detail="")
    cr = _Creep(lo, lo + 3, 3)
    p = _popen(_py() + ["-m", "pip", "install", "--disable-pip-version-check", "--upgrade", "pip"])
    for line in p.stdout:
        _log("pip: " + line)
    p.wait()
    cr.stop()
    top = hi - (3 if opt else 0)
    tmp = Path(tempfile.mkstemp(suffix=".txt")[1])
    tmp.write_text("\n".join(r["spec"] for r in main) + "\n", "utf-8")       # 이 기기 조건이 맞는 것만 · 아이콘 꾸러미는 따로
    total, seen, tail = max(1, len(main)), 0, []
    try:
        p = _popen(_py() + ["-m", "pip", "install", "--disable-pip-version-check", "--progress-bar", "off", "-r", str(tmp)])
        for line in p.stdout:
            _log("pip: " + line)
            tail = (tail + [line])[-30:]
            if line.startswith(("Collecting ", "Requirement already satisfied")):
                seen += 1
                _bump(lo + min(top - lo - 1, int((top - lo) * seen / (total * 2.5))))
            elif line.startswith("Installing collected packages"):
                _bump(lo + int((top - lo) * 0.8))
            m = re.match(r"Collecting (\S+)", line)
            if m:
                _set(detail=m.group(1))
        rc = p.wait()
    finally:
        try:
            tmp.unlink()
        except OSError:
            pass
    if rc != 0:
        raise RuntimeError(_why("".join(tail), "파이썬 꾸러미"))
    try:
        from . import _lazy
        _lazy.refresh()                        # 자리표시를 진짜 꾸러미로 (앱을 다시 켜지 않아도 됨 · 아이콘 꾸러미보다 먼저: 「꾸러미 다 받음」이 되는 순간 바로 쓰게)
    except Exception:
        pass
    if opt:                                    # 메뉴 막대 · 알림 영역 아이콘: 실패해도 계속 (예전 setup.sh 와 같음)
        _set(step="opt", detail="")
        q = _popen(_py() + ["-m", "pip", "install", "--disable-pip-version-check", "--progress-bar", "off", *[r["spec"] for r in opt]])
        for line in q.stdout:
            _log("pip(아이콘): " + line)
        if q.wait() != 0:
            _log("아이콘 꾸러미를 받지 못함 (강의록 받기는 그대로 됨)")
    _set(pct=hi, detail="")


def _chromium(lo: int, hi: int):
    _set(step="chromium", pct=lo, msg="자동 로그인용 브라우저를 받는 중…", detail="")
    p = _popen(_py() + ["-m", "playwright", "install", "chromium"])
    k, est, tail = 0, 2, []                        # 받는 파일 수 (크로미움 · 창 없는 크로미움 — 버전에 따라 1~3개)
    for line in p.stdout:
        _log("playwright: " + line)
        tail = (tail + [line])[-30:]
        if line.lstrip().lower().startswith("downloading "):
            k += 1
            est = max(est, k)
        m = re.search(r"(\d{1,3})%", line)
        if m:
            f = min(1.0, (max(k, 1) - 1 + min(100, int(m.group(1))) / 100) / est)
            _bump(lo + int((hi - lo) * f * 0.98))
        m = re.search(r"of\s+([\d.]+)\s*(Mi?B|MB)", line)
        if m:
            _set(detail=f"{m.group(1)}MB")
    if p.wait() != 0 or not _chromium_ok():
        raise RuntimeError(_why("".join(tail), "자동 로그인용 브라우저"))
    _set(pct=hi, detail="")


def _download(url: str, dst: Path, lo: int, hi: int, label: str):
    req = urllib.request.Request(url, headers={"User-Agent": "lecture-app"})
    with urllib.request.urlopen(req, timeout=60) as r, open(dst, "wb") as f:
        total = int(r.headers.get("Content-Length") or 0)
        got, last = 0, 0
        while True:
            b = r.read(1 << 20)
            if not b:
                break
            f.write(b)
            got += len(b)
            if total and time.time() - last > 0.5:
                last = time.time()
                _set(pct=lo + int((hi - lo) * got / total), detail=f"{got >> 20}/{total >> 20}MB")


def _lo_version() -> str:
    base = "https://download.documentfoundation.org/libreoffice/stable/"
    html = urllib.request.urlopen(urllib.request.Request(base, headers={"User-Agent": "lecture-app"}), timeout=30).read().decode("utf-8", "replace")
    vs = sorted(set(re.findall(r'href="(\d+\.\d+\.\d+)/"', html)), key=lambda v: tuple(int(x) for x in v.split(".")))
    if not vs:
        raise RuntimeError("LibreOffice 최신 버전을 찾지 못했어요.")
    return vs[-1]


_UNIT = {"KB": 1 / 1024, "MB": 1, "GB": 1024}


def _winget(lo: int, hi: int):
    """winget 으로 LibreOffice (관리자 확인 창이 뜰 수 있음 · 받는 크기를 읽어 진행 표시)"""
    _set(msg="LibreOffice 설치 중… 관리자 확인 창이 뜨면 [예]를 눌러 주세요", detail="관리자 확인 창이 뜨면 [예]")
    cr = _Creep(lo, hi, 6)
    try:
        p = _popen(["winget", "install", "-e", "--id", "TheDocumentFoundation.LibreOffice", "--silent",
                    "--accept-package-agreements", "--accept-source-agreements"])
        for line in p.stdout:                      # 진행 막대는 \r 로 바뀌어서 한 줄씩 들어옴
            s = line.strip()
            if s and not re.fullmatch(r"[-\\|/ ]+", s):
                _log("winget: " + s)
            m = re.search(r"([\d.]+)\s*(KB|MB|GB)\s*/\s*([\d.]+)\s*(KB|MB|GB)", s)
            if m:
                got, tot = float(m.group(1)) * _UNIT[m.group(2)], float(m.group(3)) * _UNIT[m.group(4)]
                if tot > 0:
                    _bump(lo + int((hi - lo) * 0.85 * min(1.0, got / tot)))
                    _set(detail=f"{int(got)}/{int(tot)}MB")
            elif re.search(r"(?i)starting package install|installing|설치하는", s):
                _bump(lo + int((hi - lo) * 0.86))
                _set(detail="설치 중 · 관리자 확인 창이 뜨면 [예]")
        p.wait()
    finally:
        cr.stop()


def _libreoffice(lo: int, hi: int):
    if _lo_ok():
        _set(pct=hi)
        return
    _set(step="lo", pct=lo, msg="LibreOffice(PPT → PDF 변환)를 받는 중…", detail="")
    base = "https://download.documentfoundation.org/libreoffice/stable/"
    arm = platform.machine().lower() in ("arm64", "aarch64")
    try:
        if WIN:
            if shutil.which("winget"):               # 1) winget (창 없이 · 관리자 확인 창은 뜰 수 있음)
                _winget(lo, hi - 2)
            if not _lo_ok():                         # 2) 공식 설치 파일 (관리자 확인 창이 한 번 뜸)
                v = _lo_version()
                fa, la = ("aarch64", "aarch64") if arm else ("x86_64", "x86-64")
                msi = Path(tempfile.gettempdir()) / f"LibreOffice_{v}.msi"
                _download(f"{base}{v}/win/{fa}/LibreOffice_{v}_Win_{la}.msi", msi, max(lo, _ST["pct"]), hi - 8, "LibreOffice")
                _set(msg="LibreOffice 설치 중… 관리자 확인 창이 뜨면 [예]를 눌러 주세요", detail="설치 중 · 관리자 확인 창이 뜨면 [예]")
                cr = _Creep(hi - 8, hi, 6)
                try:
                    subprocess.run(["powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command",
                                    f"Start-Process msiexec.exe -ArgumentList '/i','\"{msi}\"','/passive','/norestart' -Verb RunAs -Wait"],
                                   creationflags=0x08000000)
                finally:
                    cr.stop()
                try:
                    msi.unlink()
                except Exception:
                    pass
        elif MAC:
            brew = shutil.which("brew") or next((b for b in ("/opt/homebrew/bin/brew", "/usr/local/bin/brew") if os.path.exists(b)), None)
            if brew:
                _set(detail="Homebrew로 설치 중")
                cr = _Creep(lo, hi - 2, 5)
                try:
                    p = _popen([brew, "install", "--cask", "libreoffice"])
                    for line in p.stdout:
                        _log("brew: " + line)
                    p.wait()
                finally:
                    cr.stop()
            if not _lo_ok():
                v = _lo_version()
                fa, la = ("aarch64", "aarch64") if arm else ("x86_64", "x86-64")
                td = Path(tempfile.mkdtemp())
                dmg = td / "lo.dmg"
                _download(f"{base}{v}/mac/{fa}/LibreOffice_{v}_MacOS_{la}.dmg", dmg, max(lo, _ST["pct"]), hi - 8, "LibreOffice")
                _set(msg="LibreOffice 설치 중…", detail="설치 중")
                cr = _Creep(hi - 8, hi, 4)
                try:
                    out = subprocess.run(["/usr/bin/hdiutil", "attach", "-nobrowse", "-readonly", str(dmg)], capture_output=True, text=True).stdout
                    mp = next((l.split("\t")[-1].strip() for l in out.splitlines() if "/Volumes/" in l), "")
                    if mp and os.path.isdir(f"{mp}/LibreOffice.app"):
                        if subprocess.run(["/usr/bin/ditto", f"{mp}/LibreOffice.app", "/Applications/LibreOffice.app"]).returncode != 0:
                            (Path.home() / "Applications").mkdir(exist_ok=True)
                            subprocess.run(["/usr/bin/ditto", f"{mp}/LibreOffice.app", str(Path.home() / "Applications" / "LibreOffice.app")])
                    if mp:
                        subprocess.run(["/usr/bin/hdiutil", "detach", "-quiet", mp])
                finally:
                    cr.stop()
                    shutil.rmtree(td, ignore_errors=True)
    except Exception as e:                         # 받는 곳 · 설치 오류도 LibreOffice 만 실패로 (꾸러미 · 브라우저는 이미 받음)
        _log(f"LibreOffice 오류: {e!r}")
        net = isinstance(e, (urllib.error.URLError, TimeoutError, ConnectionError)) or "timed out" in str(e).lower()
        if net and not _lo_ok():                   # 받는 중 인터넷이 끊김 = 잠깐 실패 → 기억하지 않음 (다음 「다시 받기」에서 또 받음)
            raise LoMissing("인터넷이 끊겨서 LibreOffice를 다 받지 못했어요. 「다시 받기」를 눌러 주세요 (PDF 강의록은 받아져요).", net=True)
    if not _lo_ok():
        # 강의록 받기는 되고 PPT 강의록만 실패하므로 전체를 실패로 두지 않음 → 화면에 직접 설치 안내
        raise LoMissing("LibreOffice를 자동으로 설치하지 못했어요. PPT로 올라온 강의록만 「실패」로 떠요 (PDF 강의록은 받아져요).")
    _set(pct=hi)


class LoMissing(RuntimeError):
    def __init__(self, msg: str = "", net: bool = False):
        super().__init__(msg)
        self.net = net


ON_LO_OK = None      # LibreOffice 를 이번에 새로 받았을 때 부름 (gui.py: LibreOffice 없이 받다 실패한 PPT 강의록을 다시 받기)


def _plan(n: dict, lo_try: bool) -> list:
    parts = []
    if n["mods"] or n.get("opt"):
        parts.append("pip")
    parts.append("chromium")                       # 이미 있으면 바로 지나감 (playwright 가 바뀌었으면 맞춰 받음)
    if lo_try and n["lo"]:
        parts.append("lo")
    w = {"pip": 1, "chromium": 1, "lo": 1}
    tot = sum(w[p] for p in parts)
    out, a = [], 2
    for p in parts:
        b = a + int(97 * w[p] / tot)
        out.append((p, a, min(99, b)))
        a = b
    return out


def _run(lo_try: bool = True):
    n = need()
    _log("시작 " + json.dumps({**n, "lo_try": lo_try}, ensure_ascii=False))
    try:
        pw0 = _ver("playwright")
        for part, a, b in _plan(n, lo_try):
            if part == "pip":
                _pip(a, b)
            elif part == "chromium":
                pw1 = _ver("playwright")
                if not _chromium_ok() or (pw0 and pw1 and pw0 != pw1):   # 덮어 깔기로 playwright 가 바뀌면 그 버전의 브라우저를 받음
                    _chromium(a, b)
                else:
                    _set(pct=b)
            elif part == "lo":
                _libreoffice(a, b)
        if _lo_ok() and _cfg().get("deps_lo_fail"):
            _cfg_set(deps_lo_fail=None)
        _set(busy=False, pct=100, step="done", msg="필요한 프로그램을 다 받았어요", err="", detail="", done_at=time.time())
        _log("끝")
        if n["lo"] and _lo_ok() and ON_LO_OK:
            try:
                ON_LO_OK()
            except Exception as e:
                _log(f"LibreOffice 받은 뒤 다시 받기 오류: {e!r}")
    except LoMissing as e:
        if not getattr(e, "net", False):
            _cfg_set(deps_lo_fail=time.strftime("%Y-%m-%d %H:%M"))  # 기억: 앱을 켤 때마다 다시 받지 않음 (직접 설치 안내 · 설정 › 화면 › 필요한 프로그램에서 다시 받기)
        _set(busy=False, pct=100, step="lo_fail", msg=str(e), err="lo", detail="", done_at=time.time())
        _log("LibreOffice 실패 " + ("(인터넷 끊김 · 다음에 다시 받음)" if getattr(e, "net", False) else "(기억해 두고 자동으로 다시 받지 않음)"))
    except Exception as e:
        _set(busy=False, step="fail", msg=str(e) if isinstance(e, RuntimeError) else "인터넷 연결을 확인하고 「다시 받기」를 눌러 주세요.", err="fail", detail="")
        _log(f"실패: {e!r}")


def api(body: dict) -> dict:
    a = (body or {}).get("a")
    if a == "start":
        return start(body)
    if a == "lo_page":
        try:
            import webbrowser
            webbrowser.open("https://www.libreoffice.org/download/download-libreoffice/")
        except Exception:
            pass
        return {"ok": True}
    return status()
