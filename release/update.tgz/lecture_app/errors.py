"""받기에서 같이 쓰는 오류 (드라이브 · 받기 공통)"""
from __future__ import annotations


class RetryLater(Exception):
    """지금은 안 받아짐 → 다른 강의 먼저 하고 나중에 다시"""


class DiskFull(RuntimeError):
    """저장 공간이 꽉 참 → 이번 받기는 멈춤"""


def is_nospace(e: BaseException) -> bool:
    import errno
    return isinstance(e, OSError) and (e.errno == errno.ENOSPC or getattr(e, "winerror", 0) in (39, 112))
