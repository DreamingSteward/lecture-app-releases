"""비밀번호·토큰 저장: macOS는 키체인(security), 그 밖(Windows 등)은 keyring(자격 증명 관리자).
값은 절대 파일·로그에 남기지 않는다."""
from __future__ import annotations

import re
import subprocess
import sys
from typing import Optional, Tuple

MAC = sys.platform == "darwin"


def _kr():
    try:
        import keyring
        return keyring
    except Exception:
        return None


def get(service: str) -> Optional[Tuple[str, str]]:
    """(계정, 비밀) 또는 None"""
    if MAC:
        try:
            a = subprocess.run(["security", "find-generic-password", "-s", service], capture_output=True, text=True, timeout=20)
            m = re.search(r'"acct"<blob>="([^"]*)"', a.stdout)
            p = subprocess.run(["security", "find-generic-password", "-s", service, "-w"], capture_output=True, text=True, timeout=20)
            if p.returncode == 0:
                return (m.group(1) if m else ""), p.stdout.rstrip("\n")
        except Exception:
            pass
        return None
    kr = _kr()
    if not kr:
        return None
    try:
        acct = kr.get_password(service, "__account__") or ""
        pw = kr.get_password(service, "__secret__")
        return (acct, pw) if pw else None
    except Exception:
        return None


def account(service: str) -> str:
    """비밀 없이 계정 이름만 (화면 표시용)"""
    if MAC:
        try:
            a = subprocess.run(["security", "find-generic-password", "-s", service], capture_output=True, text=True, timeout=20)
            m = re.search(r'"acct"<blob>="([^"]*)"', a.stdout)
            return m.group(1) if m else ""
        except Exception:
            return ""
    kr = _kr()
    try:
        return (kr.get_password(service, "__account__") or "") if kr else ""
    except Exception:
        return ""


def has(service: str) -> bool:
    return get(service) is not None


def put(service: str, acct: str, secret: str) -> Tuple[bool, str]:
    if MAC:
        subprocess.run(["security", "delete-generic-password", "-s", service], capture_output=True)
        r = subprocess.run(["security", "add-generic-password", "-s", service, "-a", acct or "-", "-U", "-w", secret],
                           capture_output=True, text=True)
        return (r.returncode == 0, "" if r.returncode == 0 else "키체인에 저장하지 못했어요")
    kr = _kr()
    if not kr:
        return False, "비밀번호 저장소(keyring)가 없어요. 설치 프로그램을 다시 실행해 주세요."
    try:
        kr.set_password(service, "__account__", acct or "")
        kr.set_password(service, "__secret__", secret)
        return True, ""
    except Exception as e:
        return False, f"자격 증명 저장 실패 ({type(e).__name__})"


def delete(service: str) -> None:
    if MAC:
        subprocess.run(["security", "delete-generic-password", "-s", service], capture_output=True)
        return
    kr = _kr()
    if kr:
        for k in ("__account__", "__secret__"):
            try:
                kr.delete_password(service, k)
            except Exception:
                pass
