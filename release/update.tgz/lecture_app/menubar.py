"""받기 현황 아이콘: 맥은 위쪽 메뉴 막대, 윈도우는 작업 표시줄 알림 영역(시스템 트레이).
받는 중/대기 중, 진행(전체·강의록·필야 학번별), 「오늘 강의록 지금 받기」.

화면 서버(--상주)가 켜질 때 따로 띄움 (python -m lecture_app 메뉴막대).
화면 서버의 /api/progress 를 2초마다 읽어서 보여 줌. 서버가 꺼져 있으면 그렇게 표시.
필요한 라이브러리(맥 rumps / 윈도우 pystray·Pillow)가 없으면 처음 한 번 설치함.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

PORT = 8765
BASE = f"http://127.0.0.1:{PORT}"
PKG = Path(__file__).resolve().parent
APP = PKG.parent
LOGS = APP / "logs"
PID = LOGS / "메뉴막대.pid"
FAIL = LOGS / "메뉴막대_설치실패"
MAX_ROWS = 6
MAC, WIN = sys.platform == "darwin", os.name == "nt"
_OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}))     # 이 컴퓨터 주소라 프록시 안 거침


def _log(msg: str):
    try:
        LOGS.mkdir(parents=True, exist_ok=True)
        with open(LOGS / "메뉴막대.log", "a", encoding="utf-8") as f:
            f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {msg}\n")
    except OSError:
        pass


def enabled() -> bool:
    try:
        cfg = json.loads((APP / "config.json").read_text("utf-8-sig"))
        return cfg.get("menubar", True) is not False
    except Exception:
        return True


def _alive(pid: int) -> bool:
    if WIN:                 # 윈도우: os.kill(pid, 0)은 프로그램을 꺼 버려서 따로 확인
        try:
            import ctypes
            k = ctypes.windll.kernel32
            h = k.OpenProcess(0x1000, False, pid)              # PROCESS_QUERY_LIMITED_INFORMATION
            if not h:
                return False
            try:
                code = ctypes.c_ulong()
                if not k.GetExitCodeProcess(h, ctypes.byref(code)) or code.value != 259:     # STILL_ACTIVE
                    return False
                buf = ctypes.create_unicode_buffer(1024)
                n = ctypes.c_ulong(1024)
                if k.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(n)):
                    return "python" in Path(buf.value).name.lower()
                return True
            finally:
                k.CloseHandle(h)
        except Exception:
            return False
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    try:                    # 번호가 다른 프로그램에 다시 쓰였을 수 있어서 강의록앱인지 확인 (글자는 영어로 비교)
        env = dict(os.environ, LC_ALL="en_US.UTF-8")
        r = subprocess.run(["ps", "-p", str(pid), "-o", "command="], capture_output=True, text=True, timeout=5, env=env)
        return "lecture_app" in r.stdout
    except Exception:
        return False


def running_pid() -> int:
    try:
        pid = int(PID.read_text().strip())
        return pid if _alive(pid) else 0
    except Exception:
        return 0


def launch() -> bool:
    """화면 서버가 부름: 맥·윈도우이고, 켜 두기로 했고, 아직 안 떠 있으면 현황 아이콘을 띄움"""
    if not (MAC or WIN) or not enabled() or running_pid():
        return False
    try:                                   # 설치에 실패했으면 하루 동안은 다시 시도 안 함
        if FAIL.exists() and time.time() - FAIL.stat().st_mtime < 86400:
            return False
    except OSError:
        pass
    try:
        LOGS.mkdir(parents=True, exist_ok=True)
        out = open(LOGS / "메뉴막대.log", "a", encoding="utf-8")
        exe = sys.executable
        if WIN:                            # 창 없이 (pythonw)
            w = Path(exe).with_name("pythonw.exe")
            exe = str(w) if w.exists() else exe
            p = subprocess.Popen([exe, "-m", "lecture_app", "메뉴막대"], cwd=str(APP), stdout=out, stderr=out,
                                 stdin=subprocess.DEVNULL, creationflags=0x08000000 | 0x00000200)   # NO_WINDOW | NEW_PROCESS_GROUP
        else:
            p = subprocess.Popen([exe, "-m", "lecture_app", "메뉴막대"], cwd=str(APP),
                                 stdout=out, stderr=out, stdin=subprocess.DEVNULL, start_new_session=True)
        PID.write_text(str(p.pid))        # 바로 적어 둠: 처음 준비(설치) 중에 또 띄우지 않게
        return True
    except Exception as e:
        _log(f"띄우기 실패: {e}")
        return False


def stop():
    pid = running_pid()
    if pid:
        try:
            os.kill(pid, 15)
        except OSError:
            pass


def _ensure_rumps(mods=("rumps",), pkgs=("rumps>=0.4",)):
    try:
        for m in mods:
            __import__(m)
        return True
    except ImportError:
        pass
    _log(" · ".join(pkgs) + " 설치 중…")
    try:
        kw = {"creationflags": 0x08000000} if WIN else {}
        r = subprocess.run([sys.executable, "-m", "pip", "install", "--quiet", "--disable-pip-version-check", *pkgs],
                           capture_output=True, text=True, timeout=600, **kw)
    except Exception as e:
        r = subprocess.CompletedProcess([], 1, "", str(e))
    if r.returncode != 0:
        _log("rumps 설치 실패: " + (r.stderr or r.stdout)[-400:])
        try:
            FAIL.write_text(time.strftime("%Y-%m-%d %H:%M"))
        except OSError:
            pass
        return False
    try:
        import importlib
        importlib.invalidate_caches()
        for m in mods:
            __import__(m)
        return True
    except ImportError as e:
        _log(f"불러오기 실패: {e}")
        return False


def _get(path: str, timeout: float = 2.0):
    req = urllib.request.Request(BASE + path, headers={"X-Lecture-App": "1"})
    with _OPENER.open(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def _post(path: str, body: dict, timeout: float = 10.0):
    data = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(BASE + path, data=data, method="POST",
                                 headers={"X-Lecture-App": "1", "Content-Type": "application/json"})
    with _OPENER.open(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def _bar(pct: int, n: int = 10) -> str:
    k = max(0, min(n, round(pct * n / 100)))
    return "▰" * k + "▱" * (n - k)


class _BarView:
    """메뉴 한 줄: [이름]  ━━━━━━━━━━ (둥근 굵은 막대, 전체·강의록은 진한 초록, 추가자료는 연한 초록)"""
    W, H = 300, 24

    def __init__(self, item):
        from AppKit import NSView, NSTextField, NSFont, NSColor, NSBox
        from Foundation import NSMakeRect
        self.NSColor, self.NSMakeRect = NSColor, NSMakeRect
        v = NSView.alloc().initWithFrame_(NSMakeRect(0, 0, self.W, self.H))
        t = NSTextField.labelWithString_("")
        t.setFrame_(NSMakeRect(16, 4, 84, 16))
        t.setFont_(NSFont.systemFontOfSize_(12.5))
        v.addSubview_(t)
        self.name, self.NSFont = t, NSFont
        self.bx, self.bw, self.bh = 106, self.W - 106 - 16, 7
        y = (self.H - self.bh) / 2
        def box(w):                          # 둥근 색 막대 (NSBox 사용자 지정 모양)
            b = NSBox.alloc().initWithFrame_(NSMakeRect(self.bx, y, w, self.bh))
            b.setBoxType_(4)                 # NSBoxCustom
            b.setBorderWidth_(0)
            b.setCornerRadius_(self.bh / 2)
            b.setTitlePosition_(0)           # 제목 없음
            b.setContentViewMargins_((0, 0))
            v.addSubview_(b)
            return b
        track = box(self.bw)
        fill = box(0)
        track.setFillColor_(NSColor.colorWithCalibratedWhite_alpha_(0.5, 0.18))
        self.fill, self.y = fill, y
        item._menuitem.setView_(v)
        self.view, self.mi, self.on = v, item._menuitem, True

    def show(self, on: bool):
        """쓰지 않는 줄은 막대 보기를 떼고 숨김 (보기가 붙은 항목은 숨겨도 빈 막대가 남는 경우가 있어서)"""
        if on == self.on:
            return
        self.on = on
        try:
            self.mi.setView_(self.view if on else None)
            self.mi.setHidden_(not on)
        except Exception:
            pass

    def set(self, name: str, done: int, total: int, pct: int):
        main = name in ("전체", "강의록")
        self.name.setStringValue_(name)
        self.name.setFont_(self.NSFont.boldSystemFontOfSize_(12.5) if name == "전체" else self.NSFont.systemFontOfSize_(12.5))
        w = max(self.bh if pct > 0 else 0, self.bw * max(0, min(100, pct)) / 100)
        self.fill.setFrame_(self.NSMakeRect(self.bx, self.y, w, self.bh))
        c = (0x0E, 0x6B, 0x63) if main else (0x6F, 0xA8, 0xA1)            # 앱 초록 / 연한 초록
        self.fill.setFillColor_(self.NSColor.colorWithCalibratedRed_green_blue_alpha_(c[0] / 255, c[1] / 255, c[2] / 255, 1))
        self.fill.setHidden_(w <= 0)
        try:
            self.view.setToolTip_(f"{name} {done}/{total} · {pct}%")
        except Exception:
            pass


def _qr_matrix(text: str):
    try:
        import qrcode
    except ImportError:
        return None
    q = qrcode.QRCode(border=2, error_correction=qrcode.constants.ERROR_CORRECT_M)
    q.add_data(text)
    q.make(fit=True)
    return q.get_matrix()


class _QRView:
    """메뉴 안에 QR 코드 + 연결 코드 + 주소"""
    W, H = 260, 300

    def __init__(self, item):
        from AppKit import NSView, NSTextField, NSFont, NSImageView, NSColor, NSCenterTextAlignment
        from Foundation import NSMakeRect
        self.NSMakeRect = NSMakeRect
        v = NSView.alloc().initWithFrame_(NSMakeRect(0, 0, self.W, self.H))
        self.img = NSImageView.alloc().initWithFrame_(NSMakeRect((self.W - 170) / 2, 112, 170, 170))
        v.addSubview_(self.img)

        def lab(y, h, size, bold=False, gray=False):
            t = NSTextField.labelWithString_("")
            t.setFrame_(NSMakeRect(12, y, self.W - 24, h))
            t.setAlignment_(NSCenterTextAlignment)
            t.setFont_(NSFont.monospacedDigitSystemFontOfSize_weight_(size, 0.6) if bold else NSFont.systemFontOfSize_(size))
            if gray:
                t.setTextColor_(NSColor.secondaryLabelColor())
            v.addSubview_(t)
            return t
        self.hint = lab(88, 16, 11, gray=True)
        self.code = lab(52, 34, 28, bold=True)
        self.url = lab(30, 16, 11.5, gray=True)
        self.url.setSelectable_(True)
        self.foot = lab(8, 16, 10.5, gray=True)
        item._menuitem.setView_(v)
        self._url = None

    def set(self, url: str, code: str, qr: str = "", view: str = "lan"):
        """url: 보여 줄 주소 / qr: QR에 넣을 주소 (# 뒤 열쇠 포함 → 찍으면 코드 없이 연결)"""
        from AppKit import NSImage, NSColor, NSBezierPath
        qr = qr if (qr or "").startswith("http") else ""        # 주소일 때만 QR (오류 문장을 QR로 그리지 않게)
        tn = view == "tunnel"
        self.hint.setStringValue_("휴대폰 카메라로 QR (코드 없이 연결) · 홈 화면 앱은 코드")
        self.code.setStringValue_(" ".join(code) if code else "------")
        self.url.setStringValue_(url or ("터널 여는 중…" if tn else "와이파이에 연결돼 있지 않아요"))
        self.foot.setStringValue_("LTE·5G 등 어디서나" if tn else "같은 와이파이 또는 핫스팟에서")
        if not qr:
            self.img.setImage_(None)
            self._url = None
        if qr and qr != self._url:
            self._url = qr
            m = _qr_matrix(qr)
            if m:
                n, sz = len(m), 170.0
                im = NSImage.alloc().initWithSize_((sz, sz))
                im.lockFocus()
                NSColor.whiteColor().set()
                NSBezierPath.fillRect_(((0, 0), (sz, sz)))
                NSColor.blackColor().set()
                c = sz / n
                for y, row in enumerate(m):
                    for x, on in enumerate(row):
                        if on:
                            NSBezierPath.fillRect_(((x * c, (n - 1 - y) * c), (c + 0.4, c + 0.4)))
                im.unlockFocus()
                self.img.setImage_(im)
            else:
                self._url = None                  # QR 프로그램이 아직 없으면 다음에 다시


def _open_app():
    kw = {"creationflags": 0x08000000} if WIN else {"start_new_session": True}
    exe = sys.executable
    if WIN:
        w = Path(exe).with_name("pythonw.exe")
        exe = str(w) if w.exists() else exe
    subprocess.Popen([exe, "-m", "lecture_app", "창"], cwd=str(APP),
                     stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, **kw)


def _start_today() -> str:
    try:
        r = _post("/api/start", {"mode": "today", "courses": [], "target": "둘다"})
        return "오늘 강의록 받기를 시작했어요" if r.get("ok") else (r.get("msg") or "시작하지 못했어요")
    except Exception:
        return "앱이 꺼져 있어요 · 「강의록앱 열기」를 눌러 주세요"


def _hide_setting():
    """'아이콘 숨기기': 설정에 기록 (서버가 있으면 서버로)"""
    try:
        if _post("/api/settings", {"menubar": False}).get("ok"):
            return
    except Exception:
        pass
    try:
        p = APP / "config.json"
        cfg = json.loads(p.read_text("utf-8-sig"))
        cfg["menubar"] = False
        tmp = p.with_suffix(".menubar.tmp")
        tmp.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), "utf-8")
        tmp.replace(p)
    except Exception:
        pass


def _tray_image(pct, running: bool):
    """트레이 아이콘: 앱 아이콘 + 받는 중이면 아래에 진행 막대"""
    from PIL import Image, ImageDraw
    S = 64
    try:
        im = Image.open(PKG / "assets" / "icon-64.png").convert("RGBA").resize((S, S))
    except Exception:
        im = Image.new("RGBA", (S, S), (14, 107, 99, 255))
    if running:
        d = ImageDraw.Draw(im)
        d.rounded_rectangle([2, S - 16, S - 3, S - 3], radius=6, fill=(255, 255, 255, 235))
        w = int((S - 9) * max(0, min(100, pct or 0)) / 100)
        if w > 0:
            d.rounded_rectangle([5, S - 13, 5 + w, S - 6], radius=3, fill=(14, 107, 99, 255))
    return im


def _phone_win():
    """윈도우: 앱 설정 화면의 휴대폰 연결(QR·코드)을 보여 줌 (켜기·끄기는 거기서)"""
    import webbrowser
    webbrowser.open(f"http://127.0.0.1:8765/#remote")


def _mac_notify(title: str, msg: str):
    from . import notifier                     # 「강의록앱」 이름·로고로
    notifier.notify(title, msg, "")


_UPD = {"t": 0.0, "s": None}


def _upd_state() -> dict:
    """새 버전 정보 (30초마다 파일만 읽음 · 인터넷 확인은 화면 서버가 (앱을 열 때·3시간마다))"""
    if time.time() - _UPD["t"] > 30:
        _UPD["t"] = time.time()
        try:
            from . import updater
            _UPD["s"] = updater.status()
        except Exception:
            _UPD["s"] = None
    return _UPD["s"] or {}


def _upd_title() -> str:
    u = _upd_state()
    if not u.get("available") or u.get("later"):          # 되돌린 버전은 메뉴에도 안 띄움
        return ""
    return f"⬆︎ 새 버전 {u.get('latest')} " + ("받기 (노션)" if u.get("full") else "업데이트")


def _upd_notify(show):
    """새 버전이 나오면 버전마다 한 번만 알림"""
    u = _upd_state()
    if not u.get("available") or u.get("notified") or u.get("later"):
        return
    try:
        from . import notifier
        if not notifier.allowed("update"):
            return
    except Exception:
        pass
    try:
        from . import updater
        updater.mark_notified()
        _UPD["t"] = 0
        show("강의록앱 새 버전", f"{u.get('latest')} 버전이 나왔어요. 메뉴에서 바로 업데이트할 수 있어요.")
    except Exception as e:
        _log(f"업데이트 알림 실패: {e}")


def _upd_click() -> str:
    u = _upd_state()
    if u.get("full"):
        import webbrowser
        webbrowser.open(u.get("page") or "")
        return "노션에서 새 zip을 받아 설치해 주세요"
    try:
        r = _post("/api/update/apply", {}, timeout=1800)
        _UPD["t"] = 0
        return r.get("msg") or ("업데이트했어요" if r.get("ok") else "업데이트하지 못했어요")
    except Exception:
        try:
            from . import updater
            if updater._locked():
                return "업데이트하는 중이에요 · 끝나면 앱이 다시 켜져요"
        except Exception:
            pass
        return "앱이 꺼져 있어요 · 「강의록앱 열기」를 눌러 주세요"


def win_main() -> int:
    """윈도우: 작업 표시줄 알림 영역 아이콘 (pystray). 메뉴는 글자라서 진행은 ▰▱ 막대로."""
    if not _ensure_rumps(("pystray", "PIL"), ("pystray>=0.19", "Pillow")):
        return 1
    import threading
    import pystray
    st = {"p": None, "note": "", "until": 0.0, "key": None, "rm": {}, "rmt": 0.0}

    def lines():
        p = st["p"]
        if p is None:
            return []
        a = p.get("all") or {}
        out = [a] if a.get("total") else []
        return out + [r for r in (p.get("rows") or []) if r.get("total")]

    def status_text(_=None):
        if st["note"] and time.time() < st["until"]:
            return st["note"]
        p = st["p"]
        if p is None:
            return "강의록앱이 꺼져 있어요"
        if p.get("running"):
            return f"● {p.get('status') or '받는 중…'}" + (f" · {p['phase']}" if p.get("phase") else "")
        return f"○ {p.get('status') or '대기 중'}" + (f" · 애매한 자료 {p['pending']}개" if p.get("pending") else "")

    def row(i):
        def t(_=None):
            ls = lines()
            if i >= len(ls):
                return ""
            r = ls[i]
            return f"{r['name']}   {_bar(r.get('pct', 0))}   {r['done']}/{r['total']} ({r.get('pct', 0)}%)"
        return pystray.MenuItem(t, None, enabled=False, visible=lambda _: i < len(lines()))

    def last_text(_=None):
        p = st["p"] or {}
        return "지난 받기: " + p.get("last", "") + (f" · {p['started']} 시작" if p.get("started") else "")

    def today(icon, _):
        st["note"], st["until"] = _start_today(), time.time() + 8
        refresh()

    def hide(icon, _):
        _hide_setting()
        icon.stop()

    def upd_go():
        st["note"], st["until"] = "새 버전 받는 중…", time.time() + 900

        def work():
            st["note"], st["until"] = _upd_click(), time.time() + 10
            refresh()
        threading.Thread(target=work, daemon=True).start()

    running = lambda: bool((st["p"] or {}).get("running"))
    menu = pystray.Menu(
        pystray.MenuItem(lambda _: _upd_title(), lambda icon, _: upd_go(), visible=lambda _: bool(_upd_title())),
        pystray.MenuItem(status_text, None, enabled=False),
        pystray.Menu.SEPARATOR,
        *[row(i) for i in range(MAX_ROWS)],
        pystray.MenuItem(last_text, None, enabled=False, visible=lambda _: bool((st["p"] or {}).get("last")) and not running()),
        pystray.Menu.SEPARATOR,
        pystray.MenuItem(lambda _: "받는 중…" if running() else "오늘 강의록 지금 받기", today, enabled=lambda _: not running()),
        pystray.MenuItem("강의록앱 열기", lambda icon, _: _open_app(), default=True),
        pystray.MenuItem(lambda _: "휴대폰·아이패드 연결" + (" · 켜짐 (QR 보기)" if st["rm"].get("serving") else " (켜기·QR)"),
                         lambda icon, _: _phone_win(), visible=lambda _: st["rm"].get("mb_show", True) is not False),
        pystray.Menu.SEPARATOR,
        pystray.MenuItem("이 아이콘 숨기기", hide),
    )
    icon = pystray.Icon("강의록앱", _tray_image(0, False), "강의록앱", menu)
    code_t = Path(__file__).stat().st_mtime

    def refresh():
        try:
            st["p"] = _get("/api/progress")
        except Exception:
            st["p"] = None
        if time.time() - st["rmt"] > 10:
            st["rmt"] = time.time()
            try:
                st["rm"] = _get("/api/remote?lite=1", timeout=3)
            except Exception:
                st["rm"] = {}
        p = st["p"] or {}
        a = p.get("all") or {}
        run = bool(p.get("running"))
        pct = a.get("pct", 0) if a.get("total") else 0
        key = (run, pct if run else None, st["p"] is None)
        if key != st["key"]:
            st["key"] = key
            icon.icon = _tray_image(pct, run)
        icon.title = ("강의록앱 · 받는 중 " + (f"{pct}%" if a.get("total") else "")) if run else ("강의록앱 · 꺼져 있음" if st["p"] is None else "강의록앱 · 대기 중")
        try:
            icon.update_menu()
        except Exception:
            pass

    def loop():
        while True:
            if not enabled():
                icon.stop()
                return
            try:
                if Path(__file__).stat().st_mtime != code_t:          # 앱이 업데이트되면 새 코드로
                    icon.stop()
                    _open_self_again()
                    return
            except OSError:
                pass
            refresh()
            _upd_notify(lambda t, m: icon.notify(m, t))
            time.sleep(2)

    def _open_self_again():
        try:
            PID.unlink()                    # 새로 켜질 아이콘이 '이미 떠 있음'으로 보고 그냥 꺼지지 않게
        except OSError:
            pass
        exe = sys.executable
        subprocess.Popen([exe, "-m", "lecture_app", "메뉴막대"], cwd=str(APP), creationflags=0x08000000 | 0x00000200,
                         stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    def setup(ic):
        ic.visible = True
        threading.Thread(target=loop, daemon=True).start()

    try:
        icon.run(setup=setup)
    finally:
        try:
            if PID.read_text().strip() == str(os.getpid()):
                PID.unlink()
        except OSError:
            pass
    return 0


def main() -> int:
    if WIN:
        rp = running_pid()
        if rp and rp != os.getpid():
            return 0
        LOGS.mkdir(parents=True, exist_ok=True)
        PID.write_text(str(os.getpid()))
        return win_main()
    if not MAC:
        print("현황 아이콘은 맥·윈도우에서만 써요.")
        return 0
    rp = running_pid()
    if rp and rp != os.getpid():
        return 0
    LOGS.mkdir(parents=True, exist_ok=True)
    PID.write_text(str(os.getpid()))
    if not _ensure_rumps():
        return 1
    import rumps
    try:
        from AppKit import NSApplication
        NSApplication.sharedApplication().setActivationPolicy_(1)     # Dock에 아이콘 안 띄움
    except Exception:
        pass
    LOGS.mkdir(parents=True, exist_ok=True)
    PID.write_text(str(os.getpid()))

    icon = PKG / "assets" / "menubar.png"
    app = rumps.App("강의록앱", icon=str(icon) if icon.exists() else None, template=True, quit_button=None)
    if not icon.exists():
        app.title = "강의록"

    st = rumps.MenuItem("강의록앱 · 확인 중…")
    rows = [rumps.MenuItem("") for _ in range(MAX_ROWS)]
    last = rumps.MenuItem("")
    note = {"text": "", "until": 0.0}

    def hide(item, h=True):
        try:
            item._menuitem.setHidden_(h)
        except Exception:
            pass

    def run_today(_):
        try:
            r = _post("/api/start", {"mode": "today", "courses": [], "target": "둘다"})
            note["text"] = "오늘 강의록 받기를 시작했어요" if r.get("ok") else (r.get("msg") or "시작하지 못했어요")
        except Exception:
            note["text"] = "앱이 꺼져 있어요 · 「강의록앱 열기」를 눌러 주세요"
        note["until"] = time.time() + 8
        tick(None)

    def open_app(_):
        subprocess.Popen([sys.executable, "-m", "lecture_app", "창"], cwd=str(APP),
                         stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)

    def quit_bar(_):
        try:                                    # 다시 안 뜨게 설정에 기록 (설정 탭에서 다시 켤 수 있음)
            if _post("/api/settings", {"menubar": False}).get("ok"):
                rumps.quit_application()
                return
        except Exception:
            pass
        try:
            p = APP / "config.json"
            cfg = json.loads(p.read_text("utf-8-sig"))
            cfg["menubar"] = False
            tmp = p.with_suffix(".menubar.tmp")
            tmp.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), "utf-8")
            tmp.replace(p)
        except Exception:
            pass
        rumps.quit_application()

    go = rumps.MenuItem("오늘 강의록 지금 받기", callback=run_today)
    rm = {"r": None, "t": 0.0}

    def rm_post(path, body):                   # 켜고 끄는 데 몇 초 걸려도 메뉴 막대가 멈추지 않게 뒤에서
        import threading

        def work():
            try:
                _post(path, body, timeout=30)
            except Exception:
                pass
            rm["t"] = 0
        threading.Thread(target=work, daemon=True).start()

    def rm_lan(it):                             # 같은 와이파이에서 열기 켜기·끄기
        rm_post("/api/remote/set", {"enabled": not it.state})

    def rm_tn(it):                              # 밖에서도 열기 켜기·끄기
        rm_post("/api/remote/tunnel", {"on": not it.state})

    def rm_view(v):
        return lambda _: rm_post("/api/remote/menubar", {"view": v})

    def rm_new(_):                              # 지금 보이는 쪽(와이파이/밖) 코드만 새로
        rm_post("/api/remote/newcode", {"via": (rm["r"] or {}).get("mb_view") or "lan"})

    phone = rumps.MenuItem("휴대폰·아이패드 연결")
    qr_item = rumps.MenuItem("")
    p_lan = rumps.MenuItem("같은 와이파이에서 열기", callback=rm_lan)
    p_tn = rumps.MenuItem("밖에서도 열기 (LTE·5G)", callback=rm_tn)
    v_lan = rumps.MenuItem("    같은 와이파이 QR 보기", callback=rm_view("lan"))
    v_tn = rumps.MenuItem("    밖에서 QR 보기", callback=rm_view("tunnel"))
    p_new = rumps.MenuItem("새 연결 코드", callback=rm_new)
    phone.update([p_tn, None, v_lan, v_tn, qr_item, p_new])   # 같은 와이파이에서 열기는 없앰
    def upd_go(_):
        import threading
        note["text"], note["until"] = "새 버전 받는 중…", time.time() + 900

        def work():
            note["text"], note["until"] = _upd_click(), time.time() + 10
        threading.Thread(target=work, daemon=True).start()
    upd = rumps.MenuItem("", callback=upd_go)
    app.menu = [upd, st, None, *rows, last, None, go, rumps.MenuItem("강의록앱 열기", callback=open_app), phone, None,
                rumps.MenuItem("메뉴 막대에서 숨기기", callback=quit_bar)]
    qv = None
    try:
        qv = _QRView(qr_item)
    except Exception as e:
        _log(f"QR 보기 못 씀: {e}")
    for it in rows + [last, st]:
        it.set_callback(None)
    views = []
    try:
        views = [_BarView(it) for it in rows]
    except Exception as e:                # 오래된 macOS 등: 글자 막대로
        _log(f"막대 보기 못 씀: {e}")
        views = []

    def _code_t():                              # 코드·아이콘 그림이 바뀌면 다시 켬
        return tuple(f.stat().st_mtime if f.exists() else 0 for f in (Path(__file__), icon))
    code_t = _code_t()

    def tick(_):
        try:                                    # 앱이 업데이트되면 새 코드로 다시 켬
            if _code_t() != code_t:
                os.chdir(str(APP))
                os.execv(sys.executable, [sys.executable, "-m", "lecture_app", "메뉴막대"])
        except OSError:
            pass
        if not enabled():
            rumps.quit_application()
            return
        try:
            ut = _upd_title()
            upd.title = ut or " "
            hide(upd, not ut)
            _upd_notify(_mac_notify)
        except Exception:
            pass
        try:
            p = _get("/api/progress")
        except Exception:
            p = None
        if p is None:
            app.title = "" if icon.exists() else "강의록"
            st.title = "강의록앱이 꺼져 있어요"
            for it in rows:
                hide(it)
            hide(last)
            go.set_callback(run_today)
            return
        running = bool(p.get("running"))
        a = p.get("all") or {}
        if running:
            app.title = f" {a.get('pct', 0)}%" if a.get("total") else " 받는 중"
            st.title = f"● {p.get('status') or '받는 중…'}" + (f" · {p['phase']}" if p.get("phase") else "")
        else:
            app.title = "" if icon.exists() else "강의록"
            st.title = f"○ {p.get('status') or '대기 중'}" + (f" · 애매한 자료 {p['pending']}개" if p.get("pending") else "")
        if note["text"] and time.time() < note["until"]:
            st.title = note["text"]
        lines = []
        if a.get("total"):
            lines.append(a)
        lines += [r for r in (p.get("rows") or []) if r.get("total")]
        for i, it in enumerate(rows):
            if i < len(lines):
                r = lines[i]
                if views:
                    views[i].show(True)
                    views[i].set(r["name"], r["done"], r["total"], int(r.get("pct", 0)))
                else:
                    it.title = f"{r['name']}   {_bar(r.get('pct', 0))}  {r['done']}/{r['total']} ({r.get('pct', 0)}%)"
                hide(it, False)
            else:
                if views:
                    views[i].show(False)
                hide(it)
        if p.get("last") and not running:
            last.title = "지난 받기: " + p["last"] + (f" · {p['started']} 시작" if p.get("started") else "")
            hide(last, False)
        else:
            hide(last)
        if time.time() - rm["t"] > 5 and not rm.get("busy"):      # 휴대폰 연결 (QR·코드) · 뒤에서 받아 와 다음 차례에 그림
            rm["t"], rm["busy"] = time.time(), True
            import threading

            def fetch():
                try:
                    rm["r"], rm["miss"] = _get("/api/remote?lite=1", timeout=8), 0
                except Exception:
                    rm["miss"] = rm.get("miss", 0) + 1
                    if rm["miss"] >= 3:                  # 한두 번 늦은 건 무시 (메뉴가 깜빡이지 않게)
                        rm["r"] = None
                rm["busy"] = False
            threading.Thread(target=fetch, daemon=True).start()
        r = rm["r"] or {}
        lan, tn = bool(r.get("enabled")), bool((r.get("tunnel") or {}).get("on"))
        view = r.get("mb_view") or ""
        hide(phone, rm["r"] is None or r.get("mb_show") is False)     # 설정에서 「메뉴 막대에 휴대폰 연결 보이기」를 끄면 숨김
        p_lan.state, p_tn.state = int(lan), int(tn)
        hide(v_lan, not (lan and tn))
        hide(v_tn, not (lan and tn))
        v_lan.state, v_tn.state = int(view == "lan"), int(view == "tunnel")
        on = lan or tn
        for it in (qr_item, p_new):
            hide(it, not on)
        phone.title = "휴대폰·아이패드 연결" + (" · 켜짐" if on else "")
        if on:
            t = r.get("tunnel") or {}
            if view == "tunnel":
                url, qr = (t.get("url") or (t.get("msg") if t.get("status") == "error" else "")), r.get("tunnel_qr", "")
            else:
                urls = r.get("urls") or []
                url, qr = (urls[0] if urls else ""), r.get("lan_qr", "")
            if qv:
                try:
                    qv.set(url, r.get("code", ""), qr, view)
                except Exception as e:
                    _log(f"QR 그리기 실패: {e}")
            else:
                qr_item.title = f"코드 {r.get('code', '')} · {url}"
        go.title = "받는 중…" if running else "오늘 강의록 지금 받기"
        go.set_callback(None if running else run_today)

    tm = rumps.Timer(tick, 2)
    tm.start()
    try:                                       # 메뉴를 펼친 동안에도 막대가 움직이게
        from Foundation import NSRunLoop, NSRunLoopCommonModes
        NSRunLoop.currentRunLoop().addTimer_forMode_(tm._nstimer, NSRunLoopCommonModes)
    except Exception:
        pass
    tick(None)
    try:
        app.run()
    finally:
        try:
            if PID.read_text().strip() == str(os.getpid()):
                PID.unlink()
        except OSError:
            pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
