"""공휴일: 과학기술정보통신부 월력요항을 정리한 공개 자료(hyunbinseo/holidays-kr · MIT)를 받아 앱 폴더의 공휴일.json 에 둠.

- 앱을 켤 때 + 하루에 한 번 (작년 · 올해 · 내년)
- 못 받으면 마지막으로 받은 것을 그대로 쓰고, 그것도 없으면 화면에 들어 있는 목록(gui.html 의 HM_HOL)을 씀
- 임시공휴일 · 대체공휴일이 새로 정해지면 자료가 바뀌는 대로 따라감
"""
from __future__ import annotations

import json
import re
import threading
import time
from datetime import date
from pathlib import Path
from typing import Dict, List, Optional

from . import main as M

FILE = "공휴일.json"                     # {"fetched": 시각, "years": [2025, 2026, 2027], "days": {"2026-01-01": "1월 1일", …}}
SRC_YEAR = "https://holidays.hyunbin.page/{y}.json"                                  # 해마다 파일 (기본)
SRC_CDN = "https://cdn.jsdelivr.net/npm/@hyunbinseo/holidays-kr/dist/"                # 안 되면 npm 묶음 (all.js → 해마다 조각)
DAY_RE = re.compile(r'"(20\d\d-\d\d-\d\d)"\s*:\s*(\[[^\]]*\]|"[^"]*")')
EVERY = 24 * 3600
_LOCK = threading.Lock()


def _path() -> Path:
    return M.APP / FILE


def _parse(text: str, year: Optional[int] = None) -> Dict[str, str]:
    """JSON · JS 어느 쪽이든 「"2026-01-01": ["1월 1일"]」 모양만 골라 읽음 (이름이 여럿이면 「·」로)"""
    out: Dict[str, str] = {}
    for d, v in DAY_RE.findall(text or ""):
        if year and not d.startswith(str(year)):
            continue
        try:
            names = json.loads(v)
        except ValueError:
            continue
        names = [names] if isinstance(names, str) else names
        names = [re.sub(r"\s+", " ", str(x)).strip()[:30] for x in names if str(x).strip()]
        if names:
            out[d] = " · ".join(dict.fromkeys(names))
    return out


def _get(url: str) -> str:
    import requests
    r = requests.get(url, timeout=12)
    r.raise_for_status()
    return r.text


def _fetch_year(y: int, cdn: dict) -> Optional[Dict[str, str]]:
    try:
        got = _parse(_get(SRC_YEAR.format(y=y)), y)
        if got:
            return got
    except Exception:
        pass
    try:                                    # npm 묶음: all.js 에 해마다 조각 파일 이름이 있음
        if "all" not in cdn:
            cdn["all"] = _get(SRC_CDN + "all.js")
        m = re.search(r'from\s+"\./(%d-[\w-]+\.js)"' % y, cdn["all"])
        if m:
            got = _parse(_get(SRC_CDN + m.group(1)), y)
            if got:
                return got
    except Exception:
        pass
    return None


def read() -> dict:
    try:
        v = json.loads(_path().read_text("utf-8"))
        if isinstance(v, dict) and isinstance(v.get("days"), dict):
            return v
    except Exception:
        pass
    return {"fetched": 0, "years": [], "days": {}}


def refresh(force: bool = False) -> bool:
    """하루가 지났으면 다시 받음. 받은 해만 바꾸고(못 받은 해는 전에 받은 것 그대로) 저장. 바꿨으면 True"""
    with _LOCK:
        cur = read()
        if not force and time.time() - float(cur.get("fetched") or 0) < EVERY:
            return False
        y0 = date.today().year
        days = dict(cur.get("days") or {})
        years = set(int(y) for y in cur.get("years") or [] if str(y).isdigit())
        cdn: dict = {}
        ok = 0
        for y in (y0 - 1, y0, y0 + 1):
            got = _fetch_year(y, cdn)
            if got is None:
                continue
            ok += 1
            days = {k: v for k, v in days.items() if not k.startswith(str(y))}
            days.update(got)
            years.add(y)
        new = {"fetched": time.time() if ok else float(cur.get("fetched") or 0), "years": sorted(years),
               "days": dict(sorted(days.items()))}
        if ok:
            try:
                p = _path()
                tmp = p.with_name(FILE + ".tmp")
                tmp.write_text(json.dumps(new, ensure_ascii=False, indent=1), "utf-8")
                from .matching import safe_replace
                safe_replace(tmp, p)
            except Exception:
                return False
        return bool(ok) and new["days"] != cur.get("days")


def state() -> dict:
    """화면용: {"years": [받은 해], "days": {날짜: 이름}} — 받은 해는 화면 목록 대신 이것을 씀"""
    v = read()
    return {"years": v.get("years") or [], "days": v.get("days") or {}}


def loop():
    """앱을 켜 두는 동안: 켤 때 한 번 + 6시간마다 확인 (하루가 지났을 때만 실제로 받음)"""
    time.sleep(5)
    while True:
        try:
            refresh()
        except Exception:
            pass
        time.sleep(6 * 3600)
