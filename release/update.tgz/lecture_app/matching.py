"""받은 자료(Item)를 시간표 강의(Lecture)에 짝짓기 + 출처 우선순위·최신본 고르기."""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from .timetable import Lecture, norm_course

LMS_SOURCES = ("강의실", "게시판")


@dataclass
class Item:
    source: str                  # 강의실 | 게시판 | 드라이브
    course: str                  # 출처의 과목명 (norm_course로 비교)
    uid: str                     # 출처 안에서 고유한 id
    title: str                   # 게시글/항목 제목
    filename: str
    uploaded: str                # ISO 시각 (최신본 판단)
    date_hint: Optional[str] = None   # 출처가 알려 주는 강의 날짜 MMDD (강의실 모듈, 드라이브 폴더)
    size: int = 0
    fetch: dict = field(default_factory=dict)   # 다운로드에 필요한 정보

    def __post_init__(self):
        # 맥에서 올린 파일 이름은 한글이 자모로 풀린 형태(NFD)라 같은 이름도 다르게 보임 → 합친 형태(NFC)로 통일
        import unicodedata
        self.title = unicodedata.normalize("NFC", self.title or "")
        self.filename = unicodedata.normalize("NFC", self.filename or "")

    @property
    def ext(self) -> str:
        return Path(self.filename).suffix.lower().lstrip(".")

    @property
    def text(self) -> str:
        return f"{self.title} {Path(self.filename).stem}"


DOC_EXT = {"pdf", "ppt", "pptx", "doc", "docx", "hwp", "hwpx", "key", "odp"}


# ---------------------------------------------------------------- 힌트 뽑기
def date_hints(text: str) -> List[str]:
    out = []
    for m in re.finditer(r"(?<!\d)(?:20)?(\d{2})(\d{2})(\d{2})(?!\d)", text):       # 20261012, 261012
        y, mo, d = m.groups()
        if 1 <= int(mo) <= 12 and 1 <= int(d) <= 31 and y in ("25", "26", "27"):
            out.append(mo + d)
    for m in re.finditer(r"(?<!\d)(?:\d{2}\.)?(\d{1,2})[./](\d{1,2})(?!\d)", text):  # 26.10.22, 10/22, 9/29
        mo, d = int(m.group(1)), int(m.group(2))
        if 1 <= mo <= 12 and 1 <= d <= 31:
            out.append(f"{mo:02d}{d:02d}")
    for m in re.finditer(r"(?<!\d)(\d{1,2})\s*월\s*(\d{1,2})\s*일((?:\s*[,·및와과]\s*\d{1,2}\s*일)*)", text):  # 10월 22일, 29일
        mo = int(m.group(1))
        for d in [int(m.group(2))] + [int(x) for x in re.findall(r"(\d{1,2})\s*일", m.group(3) or "")]:
            if 1 <= mo <= 12 and 1 <= d <= 31:
                out.append(f"{mo:02d}{d:02d}")
    for m in re.finditer(r"(?<!\d)(\d{2})(\d{2})(?=[_\s\-(.])", text):              # 1022_3,4교시, 1002(1)_
        mo, d = int(m.group(1)), int(m.group(2))
        if 1 <= mo <= 12 and 1 <= d <= 31:
            out.append(f"{mo:02d}{d:02d}")
    return list(dict.fromkeys(out))


def period_hints(text: str) -> List[int]:
    ps = []
    for m in re.finditer(r"(\d{1,2}(?:\s*[,~\-]\s*\d{1,2})*)\s*교시", text):
        ps += [int(x) for x in re.findall(r"\d{1,2}", m.group(1))]
    for m in re.finditer(r"\((\d{1,2}(?:\s*[,~\-]\s*\d{1,2})*)\)", text):            # (6,7) (1) (8,9)
        ps += [int(x) for x in re.findall(r"\d{1,2}", m.group(1))]
    return [p for p in dict.fromkeys(ps) if 1 <= p <= 10]


# 영어 제목 → 시간표 한글 제목 연결용 (자주 나오는 것만)
GLOSSARY = {
    "cervical": "자궁경부", "cervix": "자궁경부", "vulva": "외음부", "vulvar": "외음부", "ovarian": "난소", "ovary": "난소",
    "endometri": "자궁내막", "uterus": "자궁", "uterine": "자궁", "fibroid": "근종 양성", "myoma": "근종 양성",
    "prolapse": "탈출", "cin": "상피내암", "std": "성병", "sti": "성병", "menopause": "폐경", "amenorrhea": "무월경",
    "infertility": "불임", "contracept": "피임", "puberty": "사춘기", "obstetric": "산과", "overview": "개관",
    "maternal": "모성", "physiology": "생리", "drug": "약물", "prenatal": "산전", "preconception": "산전",
    "ultrasound": "초음파", "labor": "분만", "induction": "유도분만", "augmentation": "유도분만",
    "abnormal": "난산", "anesthesia": "마취", "hypertension": "고혈압", "placenta": "태반", "amniotic": "양수",
    "hemorrhage": "출혈", "preterm": "조산", "abortion": "유산", "rheumat": "류마티스", "nutrition": "영양",
    "neonat": "신생아", "newborn": "신생아", "growth": "성장", "development": "발달", "sleep": "수면",
    "breast": "유방", "cancer": "암", "carcinoma": "암", "tumor": "종양", "pathology": "병리",
    "endocrin": "내분비", "infection": "감염", "genetic": "유전", "metabolic": "대사", "pharmacolog": "약리",
    "aging": "노화", "geriatric": "노년", "psychiatr": "정신", "intro": "서론", "embryo": "배아",
    "implantation": "착상", "twin": "다태", "multiple": "다태", "kidney": "신장", "renal": "신장",
}


# 여러 단어 영어 제목 / 한글 동의어 (단어 하나짜리 GLOSSARY보다 먼저 본다)
PHRASES = {
    r"physiology[\s_]*of[\s_]*labor": "분만개시", r"onset[\s_]*of[\s_]*labor": "분만개시",
    r"(?<!ab)normal[\s_]*labor": "진통과 분만", r"abnormal[\s_]*labor": "난산", r"dystocia": "난산",
    r"induction|augmentation": "유도분만", r"prenatal[\s_]*care|preconception": "산전관리",
    r"obstetric[\s_]*ultrasound": "임신 중 초음파", r"maternal[\s_]*physiology": "모성 생리",
    r"overview[\s_]*of[\s_]*obstetric": "산과개관", r"intrapartum|fetal[\s_]*monitoring": "진통 중 태아 감시",
    r"fibroid|myoma|leiomyoma": "여성생식기 양성질환", r"pelvic[\s_]*organ[\s_]*prolapse|탈출증": "자궁탈출증",
    r"젖흐름증|galactorrhea|nipple[\s_]*discharge": "유두분비", r"\bstd\b|\bsti\b|성매개": "전염성 성병",
    r"\bcin\b": "상피내암", r"rheumat": "류마티스", r"enuresis": "야뇨증",
}


def _expand(text: str) -> str:
    low = text.lower()
    add = [ko for pat, ko in PHRASES.items() if re.search(pat, low)]
    add += [ko for en, ko in GLOSSARY.items() if re.search(rf"(?<![a-z]){en}", low)]
    return text + " " + " ".join(add)


def _ko_bigrams(s: str) -> set:
    """한글 덩어리별로 2글자씩 (덩어리를 이어 붙여 생기는 가짜 조합은 만들지 않음)"""
    out = set()
    for w in re.findall(r"[가-힣]+", s):
        out |= {w[i:i + 2] for i in range(len(w) - 1)}
    return out


def _clean(s: str) -> str:
    s = s.lower()
    s = re.sub(r"\.(pdf|pptx?|docx?|hwpx?)$", "", s)
    s = re.sub(r"20\d{2}|\d{6,8}|\d+\s*교시|교수님?|강의록?|자료|슬라이드|수업|본2|생성발\d?|tbl|_?s$", " ", s)
    return re.sub(r"[\s_\-·,.()\[\]/]+", "", s)


def _bigrams(s: str) -> set:
    return {s[i:i + 2] for i in range(len(s) - 1)} if len(s) > 1 else {s}


def title_score(item_text: str, L: Lecture) -> float:
    """두 방향으로 본다: 강의 제목 글자가 자료명에 얼마나 들어있나 / 자료명(한글 부분)이 강의 제목에 얼마나 들어있나"""
    ex = _expand(item_text)
    a = _bigrams(_clean(ex))
    ak = _ko_bigrams(re.sub(r"20\d{2}|\d+\s*교시|교수님?|강의록?|자료|수업|본2|생성발\d?", " ", ex)) - {"의대", "본과"}
    best = 0.0
    for t in L.titles + [L.title]:
        parts = [t] + [p for p in re.split(r"[-·/]", t) if len(p.strip()) >= 2]
        for p in parts:
            b = _bigrams(_clean(p))
            if a and b:
                best = max(best, len(a & b) / len(b))
            if len(ak) >= 1 and b:
                best = max(best, 0.95 * len(ak & b) / len(ak))
    return best


# ---------------------------------------------------------------- 매칭
@dataclass
class Decision:
    item: Item
    lecture: Optional[Lecture]
    how: str                     # 기억 | 확실 | 추정 | 애매 | 제외
    candidates: List[Lecture] = field(default_factory=list)


import threading as _th
_MEM_LOCK = _th.Lock()


def safe_replace(tmp: Path, dst: Path):
    """임시 파일로 바꿔치기. Windows에서는 누가 잠깐 읽고 있으면 실패하니 몇 번 다시 시도."""
    import time
    for i in range(20):
        try:
            tmp.replace(dst)
            return
        except PermissionError:
            if i == 19:
                raise
            time.sleep(0.1)


def _tmp_name(path: Path) -> Path:
    """쓰는 쪽마다 다른 임시 파일 (받기와 화면이 같은 파일을 동시에 저장해도 서로의 임시 파일을 안 건드리게)"""
    import os
    return path.with_name(f"{path.stem}.{os.getpid()}.{_th.get_ident()}.tmp")


class Memory:
    """사용자가 한 번 정해 준 매칭을 기억 (매칭기억.json: uid → 강의 key | '제외')."""

    def __init__(self, path: Path):
        self.path = path
        self.data: Dict[str, str] = {}
        bad = False
        for i in range(4):               # 다른 쪽이 바꿔치기하는 순간이거나 잠깐 잠겨 있으면 다시 읽어 봄
            try:
                self.data = json.loads(path.read_text("utf-8-sig")) if path.exists() else {}
                bad = False
                break
            except json.JSONDecodeError:
                bad = True
            except Exception:
                bad = False
            import time as _t
            _t.sleep(0.1 * (i + 1))
        if bad:                          # 여러 번 읽어도 형식이 깨졌을 때만 백업해 두고 빈 기억으로 시작 (받기가 멈추지 않게)
            try:
                path.replace(path.with_name(path.stem + "_깨짐.json"))
            except Exception:
                pass
        # 사람이 알아보도록 자료 이름 등을 따로 저장 (매칭기억.json 형식은 그대로 둠)
        self.info_path = path.with_name(path.stem + "_정보.json")
        try:
            self.info: Dict[str, dict] = json.loads(self.info_path.read_text("utf-8-sig")) if self.info_path.exists() else {}
        except Exception:
            self.info = {}

    def key(self, it: Item) -> str:
        return f"{it.source}:{it.uid}"

    def get(self, it: Item) -> Optional[str]:
        v = self.data.get(self.key(it))
        mk = (it.fetch or {}).get("mkey") if isinstance(it.fetch, dict) else None
        if v is None and mk:        # 공개 전에 골라 둔 자료가 열리면 번호가 바뀜 → 그때 고른 것을 그대로 씀
            v = self.data.get(f"{it.source}:{mk}")
        return v

    @staticmethod
    def describe(it: Item) -> dict:
        return {"source": it.source, "course": it.course, "uid": it.uid, "title": it.title,
                "filename": it.filename, "uploaded": it.uploaded}

    def set(self, it: Item, value: str):
        from datetime import datetime
        k = self.key(it)
        self.data[k] = value
        self.info[k] = {**self.info.get(k, {}), **{a: b for a, b in self.describe(it).items() if b},
                        "at": datetime.now().strftime("%Y-%m-%d %H:%M")}
        self.save()

    def save(self):
        for path, obj in ((self.path, self.data), (self.info_path, self.info)):   # 임시 파일에 쓰고 바꿔치기
            tmp = _tmp_name(path)
            tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=1), "utf-8")
            safe_replace(tmp, path)

    def remember(self, items: List[Item]):
        """예전 기억에 자료 이름 정보가 없으면 이번 목록에서 채움 (최신 업로드 날짜도 갱신)."""
        with _MEM_LOCK:
            self._remember(items)

    def _remember(self, items: List[Item]):
        changed = False
        for it in items:
            k = self.key(it)
            if k not in self.data:
                continue
            cur = self.info.get(k, {})
            new = {**cur, **{a: b for a, b in self.describe(it).items() if b}}
            if new != cur:
                self.info[k] = new
                changed = True
        if changed:
            if True:     # 강의록·필야가 동시에 채울 수 있어서, 파일을 다시 읽고 합쳐서 씀
                try:
                    disk = json.loads(self.info_path.read_text("utf-8")) if self.info_path.exists() else {}
                except Exception:
                    disk = {}
                for k, v in self.info.items():
                    if k in self.data:
                        disk[k] = {**disk.get(k, {}), **v}
                try:
                    tmp = _tmp_name(self.info_path)
                    tmp.write_text(json.dumps(disk, ensure_ascii=False, indent=1), "utf-8")
                    safe_replace(tmp, self.info_path)
                except Exception:
                    pass


_AUTO_LOCK = _th.Lock()


def save_auto(path: Path, decisions: List[Decision]):
    """앱이 스스로 정한 분류(확실·추정 등)를 기록 → 「앱이 정한 자료」에서 보고 고칠 수 있게.
    이번에 본 자료는 새 결과로 바꾸고(애매·기억이 됐으면 뺌), 이번에 안 본 자료는 그대로 둠."""
    from datetime import datetime
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    groups: Dict[str, dict] = {}
    seen = set()
    for d in decisions:
        k = f"{d.item.source}:{d.item.uid}"
        seen.add(k)
        if d.lecture is None or d.how in ("기억", "애매", "제외"):
            continue
        g = groups.setdefault(k, {**{a: b for a, b in Memory.describe(d.item).items() if b}, "how": d.how, "keys": []})
        if d.lecture.key not in g["keys"]:
            g["keys"].append(d.lecture.key)
    with _AUTO_LOCK:
        try:
            disk = json.loads(path.read_text("utf-8-sig")) if path.exists() else {}
        except Exception:
            disk = {}
        for k in seen:
            old = disk.pop(k, None)
            if k in groups:
                g = groups[k]
                g["at"] = old["at"] if old and old.get("keys") == g["keys"] and old.get("at") else now
                disk[k] = g
        try:
            tmp = _tmp_name(path)
            tmp.write_text(json.dumps(disk, ensure_ascii=False, indent=1), "utf-8")
            safe_replace(tmp, path)
        except Exception:
            pass


def _candidates(it: Item, lectures: List[Lecture]) -> List[Lecture]:
    ck = norm_course(it.course)
    pool = [L for L in lectures if norm_course(L.course) == ck]
    dates = ([it.date_hint] if it.date_hint else []) + date_hints(it.text)
    if dates:
        d_pool = [L for L in pool if L.mmdd in dates]
        if d_pool:
            pool = d_pool
        elif it.date_hint:
            return []          # 강의실 모듈 날짜에 해당 강의가 없음
    ps = period_hints(it.text)
    if ps:
        p_pool = [L for L in pool if set(L.periods()) & set(ps)]
        if p_pool:
            pool = p_pool
    return pool


def _name_sim(a: Item, b: Item) -> float:
    """두 자료 이름이 얼마나 같은지 (날짜·교시·교수·확장자·연도는 빼고, 영어는 한글로 풀어서)"""
    def key(it):
        t = re.sub(r"\(\d[\d,\s]*\)|\d{4}|20\d{2}|교수님?|\.\w+$", " ", Path(it.filename).stem)
        for p in it_profs(t):
            t = t.replace(p, " ")
        return _bigrams(_clean(_expand(t)))
    ka, kb = key(a), key(b)
    if not ka or not kb:
        return 0.0
    return len(ka & kb) / min(len(ka), len(kb))


def it_profs(t: str) -> List[str]:
    return re.findall(r"_([가-힣]{2,4})(?:T|\s*교수)?$", t)


def _is_cp(t: str) -> bool:
    return bool(re.search(r"(?<![a-z])cp(?![a-z])|tbl", t.lower()))


def _score(it: Item, L: Lecture) -> float:
    sc = title_score(it.text, L)
    if any(p and p in it.text for p in L.profs):
        sc += 0.3
    if _is_cp(L.title) != _is_cp(it.text):      # CP·TBL 자료는 CP 강의로, 일반 자료는 일반 강의로
        sc -= 0.3
    return sc


def _numbered_pair(it: Item, good: List[Lecture]) -> List[Lecture]:
    """제목이 '성장 I', '성장 II'처럼 번호만 다른 강의들이고 자료명에 12 / 1,2 / I,II 가 있으면 둘 다"""
    if len(good) < 2:
        return []
    stem = lambda t: re.sub(r"\s*(I{1,3}|IV|\d)\s*$", "", t.strip())
    base = {stem(L.title) for L in good}
    if len(base) != 1 or not re.search(r"(?<!\d)1\s*[,·&]?\s*2(?!\d)|I\s*[,·&]\s*II", it.text):
        return []
    return sorted(good, key=lambda L: (L.mmdd, L.start))


def _same_lecture_key(L: Lecture):
    return (_clean(L.title), tuple(L.profs))


def _whole_course_best(it: Item, lectures: List[Lecture]):
    whole = [L for L in lectures if norm_course(L.course) == norm_course(it.course)]
    ws = sorted(((_score(it, L), L) for L in whole), key=lambda x: -x[0])
    if not ws or ws[0][0] < 0.7:
        return None
    if len(ws) == 1 or ws[0][0] - ws[1][0] >= 0.25:
        return ws[0][1], [L for _, L in ws[:4]]
    return None


def match(items: List[Item], lectures: List[Lecture], mem: Memory) -> List[Decision]:
    by_key = {L.key: L for L in lectures}
    out: List[Decision] = []
    pending: List[Decision] = []
    for it in items:
        if it.ext not in DOC_EXT:
            out.append(Decision(it, None, "제외"))
            continue
        m = mem.get(it)
        if m:
            if m in ("제외", "범위밖", "보류"):        # 범위밖: 이번 시간표에 없는 강의 자료 · 보류: 잘 모르겠음 (다시 안 물어봄, 내가 정한 자료에서 나중에 고르기)
                out.append(Decision(it, None, "제외"))
                continue
            keys = [k for k in m.split("||") if k in by_key]
            if keys:
                for k in keys:
                    out.append(Decision(it, by_key[k], "기억"))
                continue
            # 시간표가 바뀌어 기억한 강의가 없어졌으면 다시 판단
        cands = _candidates(it, lectures)
        if not cands:
            # 강의실 주차 날짜에 강의가 없음(사전학습 자료를 앞 주차에 올린 경우 등) → 과목 전체에서 확실한 것만
            w = _whole_course_best(it, lectures) if it.date_hint else None
            if w:
                out.append(Decision(it, w[0], "확실", w[1]))
            else:
                out.append(Decision(it, None, "애매", []))
            continue
        # 같은 제목 강의가 여러 날에 나뉜 경우('사회적 약자' 10/22, 10/29): 후보가 모두 같은 강의면 전부
        if len(cands) > 1 and len({_same_lecture_key(L) for L in cands}) == 1:
            for L in cands:
                out.append(Decision(it, L, "확실", cands))
            continue
        # 한 파일이 여러 교시 강의를 함께 담은 경우: '1019(8,9)_소아약리, 노인약리' → 두 강의 모두
        ps = set(period_hints(it.text))
        has_date = bool(it.date_hint or date_hints(it.text))
        if has_date and len(ps) > 1 and len(cands) > 1 and all(set(L.periods()) <= ps for L in cands):
            for L in cands:
                out.append(Decision(it, L, "확실", cands))
            continue
        scored = sorted(((_score(it, L), L) for L in cands), key=lambda x: -x[0])
        top, L0 = scored[0]
        second = scored[1][0] if len(scored) > 1 else 0.0
        # '성장12', '성장 1,2' → 같은 이름의 I·II 강의 둘 다
        pair = _numbered_pair(it, [L for sc, L in scored if sc >= 0.5])
        if pair:
            for L in pair:
                out.append(Decision(it, L, "확실", cands))
            continue
        # 강의실 주차 날짜에 맞는 강의가 없으면(교수님이 다른 주차에 올린 경우) 과목 전체에서 찾아본다
        if top < 0.3 and it.date_hint:
            w = _whole_course_best(it, lectures)
            if w:
                out.append(Decision(it, w[0], "확실", w[1]))
                continue
        # 점수가 가장 높은 강의들이 같은 제목·교수(여러 날에 나뉜 강의)면 모두
        same_top = [L for sc, L in scored if sc >= 0.5 and top - sc < 0.05]
        if len(same_top) > 1 and len({_same_lecture_key(L) for L in same_top}) == 1:
            for L in same_top:
                out.append(Decision(it, L, "확실", cands))
            continue
        if len(cands) == 1 and (top >= 0.2 or it.date_hint or date_hints(it.text) or period_hints(it.text)):
            out.append(Decision(it, L0, "확실", cands))
        elif top >= 0.5 and top - second >= 0.2:
            out.append(Decision(it, L0, "확실", cands))
        else:
            pending.append(Decision(it, None, "애매", [L for _, L in scored]))
    # 소거법: 후보 중 아직 자료가 없는 강의가 딱 하나면 그쪽으로 (추정)
    taken = {d.lecture.key for d in out if d.lecture}
    changed = True
    while changed:
        changed = False
        for d in pending:
            if d.lecture or not d.candidates:
                continue
            free = [L for L in d.candidates if L.key not in taken]
            if len(free) == 1 and len(d.candidates) <= 3:
                d.lecture, d.how = free[0], "추정"
                taken.add(free[0].key)
                changed = True
    # 드라이브 기준: 드라이브는 날짜 폴더 + 파일명에 교시·제목이 있어 짝이 확실하다.
    # 애매한 LMS 자료와 이름이 거의 같은 드라이브 파일이 같은 날짜에 있으면 그 강의로.
    anchors = [d for d in out if d.lecture and d.item.source == "드라이브"]
    extra = []
    for d in pending:
        if d.lecture or d.item.source == "드라이브":
            continue
        days = set(([d.item.date_hint] if d.item.date_hint else []) + date_hints(d.item.text))
        best, best_sim, second = None, 0.0, 0.0
        for a in anchors:
            if norm_course(a.item.course) != norm_course(d.item.course):
                continue
            a_days = set(([a.item.date_hint] if a.item.date_hint else []) + date_hints(a.item.text))
            if days and a_days and not (days & a_days):
                continue
            sim = _name_sim(d.item, a.item)
            if sim > best_sim:
                best, best_sim, second = a, sim, best_sim
            elif sim > second:
                second = sim
        if best and best_sim >= 0.5 and best_sim - second >= 0.15:
            same = [a for a in anchors if a.item is best.item]          # 드라이브 파일 하나가 여러 강의면 모두
            d.lecture, d.how = same[0].lecture, "드라이브기준"
            for a in same[1:]:
                extra.append(Decision(d.item, a.lecture, "드라이브기준"))
    return out + pending + extra


# ---------------------------------------------------------------- 출처·버전 고르기
_VER = re.compile(r"(최종|final|수정본?|rev\.?\d*|v\d+|ver\.?\d*|\(\d+\)|_?\d{6,8}|20\d{2}|update[d]?)", re.I)


SLIDE_EXT = ("ppt", "pptx", "key", "odp")


def _day(it: Item):
    """올린 날짜 (날짜만, 모르면 None)"""
    from datetime import date
    m = re.search(r"(\d{4})[-./](\d{1,2})[-./](\d{1,2})", it.uploaded or "")
    try:
        return date(int(m.group(1)), int(m.group(2)), int(m.group(3))) if m else None
    except ValueError:
        return None


def pdf_is_newer(pdf: Item, slide: Item) -> bool:
    """LMS에서 PDF가 PPT보다 하루 넘게 늦게 올라왔으면 '교수님이 고쳐서 다시 올린 것'으로 보고 PDF를 씀.
    드라이브(필야 포함)는 학생회가 LMS에서 받아 올린 것·교수님께 따로 받은 것이 섞여 있어 올린 날짜가
    고친 날짜가 아님 → 드라이브는 날짜와 상관없이 항상 PPT"""
    if pdf.source not in LMS_SOURCES or slide.source not in LMS_SOURCES:
        return False
    a, b = _day(pdf), _day(slide)
    return bool(a and b and (a - b).days > 1)


def prefer_slides(g: List[Item]) -> List[Item]:
    """같은 이름 자료 묶음 정렬 → 마지막이 쓸 자료.
    PPT판이 있으면 PPT 우선 (같은 날 올린 PDF판보다). 단 PDF가 하루 넘게 늦게 올라왔으면 고친 자료라 PDF."""
    g = sorted(g, key=lambda i: i.uploaded)
    slides = [i for i in g if i.ext in SLIDE_EXT]
    if not slides:
        return g
    best = slides[-1]
    if any(i.ext not in SLIDE_EXT and pdf_is_newer(i, best) for i in g):
        return g                       # 그냥 가장 최근 것
    return [i for i in g if i is not best] + [best]


def part_nums(it: Item) -> set:
    """파일 이름의 부분 번호: '심장1', '심장 1,2', '심장_2', '심장-2', 'Part2', '파트 2'
    (앞의 날짜·교시 '1019-6.' 이나 6자리 이상 날짜는 빼고)"""
    t = _num_norm(Path(it.filename).stem)
    t = re.sub(r"^\s*\d{3,4}\s*[-_]\s*\d{1,2}\s*[.)]?\s*", " ", t)      # 1019-6. (드라이브 날짜-교시)
    t = re.sub(r"\d{5,}", " ", t)                                           # 날짜
    t = re.sub(r"\d+\s*교시", " ", t)
    out = set(_nums_after(t))
    for m in re.finditer(r"(?:part|파트|[-_\s])\s*(\d(?:\s*[,·&]\s*\d)*)(?!\d)", t, re.I):
        out |= {int(x) for x in re.findall(r"\d", m.group(1))}
    return out


def base_name(it: Item) -> str:
    s = Path(it.filename).stem.lower()
    s = _VER.sub("", s)
    return re.sub(r"[\s_\-.()\[\]]+", "", s)


REF_RE = re.compile(r"참고\s*자료|부록|reference|appendix|supplement", re.I)


def is_ref(it: Item) -> bool:
    """참고자료·부록 (합본에 붙이지 않고 강의별 '참고자료' 폴더에 따로 넣음)"""
    return bool(REF_RE.search(Path(it.filename).stem))


def _part_key(it: Item):
    stem = Path(it.filename).stem
    # 참고자료·부록은 본 강의록 뒤로 (참고자료1, 2, … 순서)
    r = re.search(r"(?:참고\s*자료|부록|reference|appendix)\s*(\d*)", stem, re.I)
    if r:
        return (200 + int(r.group(1) or 0), it.uploaded)
    m = re.search(r"(?:part|파트|ca-?|-|_|\s)(\d)(?!\d)", stem, re.I)
    return (int(m.group(1)) if m else 99, it.uploaded)


def choose(decisions: List[Decision]) -> Dict[str, Tuple[Lecture, List[Item], List[Item]]]:
    """강의별 (강의, 쓸 자료 목록(순서대로), 버린 자료 목록).
    - LMS(강의실·게시판)에 하나라도 있으면 LMS만, 없으면 드라이브
    - 이름이 같은 자료(버전 표기만 다름)는 가장 늦게 올라온 것 하나
    - 이름이 다른 자료는 여러 부분으로 보고 순서대로 합침
    """
    per: Dict[str, Tuple[Lecture, List[Item]]] = {}
    for d in decisions:
        if d.lecture:
            per.setdefault(d.lecture.key, (d.lecture, []))[1].append(d.item)
    out = {}
    for k, (L, its) in per.items():
        lms = [i for i in its if i.source in LMS_SOURCES and i.fetch.get("kind") != "closed"]
        drv = [i for i in its if i.source == "드라이브"]
        closed = [i for i in its if i.fetch.get("kind") == "closed"]
        own = [i for i in its if i.source == "직접"]        # 앱에서 직접 넣은 자료가 있으면 그것만
        # LMS 우선. 단, 학습 기간이 끝나 LMS에서 못 받는 자료만 있으면 드라이브로 (드라이브도 없으면 그대로 두어 사유를 남김)
        use = own if own else (lms if lms else (drv if drv else closed))
        dropped = [i for i in its if i not in use]
        groups: Dict[str, List[Item]] = {}
        for i in use:
            groups.setdefault(base_name(i), []).append(i)
        # 같은 파일이 강의실·게시판 양쪽에 있으면 크기·이름으로 하나로
        chosen = []
        for g in groups.values():
            g[:] = prefer_slides(g)        # 이름이 같은 PDF·PPT → PPT (늦게 올라온 PDF가 있어도)
            chosen.append(g[-1])
            dropped += g[:-1]
        # 같은 자료가 PDF판과 PPT판으로 같이 올라온 경우(수업부가 PDF로도 올림) → PPT 원본만 (애니메이션·숨긴 슬라이드 처리 가능)
        # 강의실·게시판처럼 올린 곳이 달라도 같은 자료로 봄 (use 는 LMS 끼리 또는 드라이브 끼리만 모여 있음)
        slides = [i for i in chosen if i.ext in SLIDE_EXT]
        if slides:
            for pdf in [i for i in chosen if i.ext == "pdf" and not is_ref(i)]:
                like = [i for i in slides if _name_sim(i, pdf) >= 0.6 and not pdf_is_newer(pdf, i)]
                if not like:
                    continue
                # 강의 제목에 든 번호('신생아질환 III'의 3)는 부분 번호가 아님 → 빼고 비교
                tn = part_nums(Item(source="", course="", uid="", title=L.title, filename=f"{L.title}.x", uploaded=""))
                pn = part_nums(pdf) - tn
                # 번호가 있는 PDF는 그 번호들이 PPT 쪽에 다 있을 때만 'PPT의 PDF판'으로 봄 ('심장_1.pptx' + '심장_2.pdf' → 둘 다 씀)
                if pn and not pn <= set().union(*[part_nums(i) - tn for i in like]):
                    continue
                chosen.remove(pdf)
                dropped.append(pdf)
        chosen.sort(key=_part_key)
        out[k] = (L, chosen, dropped)
    return out


# ---------------------------------------------------------------- 선배 필야 (다른 해 자료: 날짜가 달라 제목·교수로만 맞춤)
def _roman(n: str) -> str:
    """'생식성장발달2' ↔ '생식성장발달II' 를 같게"""
    k = norm_course(n)
    return re.sub(r"(?<=[가-힣])(3|2|1)$", lambda m: {"1": "I", "2": "II", "3": "III"}[m.group(1)], k)


def same_course(a: str, b: str) -> bool:
    return _roman(a) == _roman(b)


_RN = {"IV": "4", "III": "3", "II": "2", "I": "1", "Ⅳ": "4", "Ⅲ": "3", "Ⅱ": "2", "Ⅰ": "1"}


def _num_norm(t: str) -> str:
    """로마 숫자 → 아라비아 숫자 ('신생아질환 III' → '신생아질환3', '성장I,II' → '성장1,2')"""
    t = re.sub(r"(?<![A-Za-z])(IV|III|II|I|Ⅳ|Ⅲ|Ⅱ|Ⅰ)(?![A-Za-z])", lambda m: _RN[m.group(1)], t)
    return re.sub(r"(?<=[가-힣])\s+(?=\d(?!\d))", "", t)


def _nums_after(t: str) -> set:
    """제목 끝/중간의 '질환1', '성장1,2', '영양 2' 같은 번호"""
    out = set()
    for m in re.finditer(r"(?<=[가-힣])\s*(\d(?:\s*[,·&]\s*\d)*)(?!\d)", t):
        out |= {int(x) for x in re.findall(r"\d", m.group(1))}
    return out


def _old_score(txt: str, L: Lecture) -> float:
    a = _num_norm(txt)
    best = 0.0
    for t in L.titles + [L.title]:
        tn = _num_norm(t)
        best = max(best, _ts(a, tn))
    # 번호(1·2·3)가 있는 강의면 번호가 맞아야 함
    ln, inum = _nums_after(_num_norm(L.title)), _nums_after(a)
    if ln and inum:
        best += 0.2 if ln & inum else -0.35
    # CP(증례) 강의 구분
    icp, lcp = bool(re.search(r"(?<![a-z])cp(?![a-z])", a, re.I)), bool(re.search(r"(?<![a-z])cp(?![a-z])", L.title, re.I))
    if icp != lcp:
        best -= 0.2
    elif icp:
        best += 0.1
    return best


def _ts(a: str, t: str) -> float:
    """title_score 와 같은 방식 (강의 제목 문자열로)"""
    ex = _expand(a)
    A = _bigrams(_clean(ex))
    AK = _ko_bigrams(re.sub(r"20\d{2}|\d+\s*교시|교수님?|강의록?|자료|수업|본2|생성발\d?", " ", ex)) - {"의대", "본과"}
    best = 0.0
    for p in [t] + [q for q in re.split(r"[-·/]", t) if len(q.strip()) >= 2]:
        B = _bigrams(_clean(p))
        cap = 0.6 if (p is not t and len(B) < 2) else 1.0   # '병리' 같은 두 글자 조각은 어디에나 들어 있어 점수를 깎음
        if A and B:
            best = max(best, cap * len(A & B) / len(B))
        if AK and B:
            best = max(best, cap * 0.95 * len(AK & B) / len(AK))
    return best


def match_old(items: List[Item], lectures: List[Lecture], mem: Memory) -> List[Decision]:
    """선배 필야: 날짜·교시는 해마다 달라서 무시하고, 제목 + 교수(올해·역대)로 강의를 찾는다.
    확실하면 그 강의, 비슷한 게 여럿이면 '애매'(앱에서 고르기), 거의 안 맞으면 버림.
    '골반통+CP 월경통' 처럼 + 로 묶인 자료는 나눠서 각각 찾고, '성장 I,II' 는 둘 다에 넣는다."""
    by_key = {L.key: L for L in lectures}
    out: List[Decision] = []
    for it in items:
        if it.ext not in DOC_EXT:
            continue
        m = mem.get(it)
        if m:
            if m in ("제외", "범위밖", "보류"):        # 범위밖: 이번 시간표에 없는 강의 자료 · 보류: 잘 모르겠음 (다시 안 물어봄, 내가 정한 자료에서 나중에 고르기)
                out.append(Decision(it, None, "제외"))
                continue
            keys = [k for k in m.split("||") if k in by_key]
            if keys:
                out += [Decision(it, by_key[k], "기억") for k in keys]
                continue
        pool = [L for L in lectures if same_course(L.course, it.course)]
        if not pool:
            continue
        profs = set()
        for L in pool:
            profs |= set(L.profs)
            for _y, ps in L.history():
                profs |= set(ps)
        stem = re.sub(r"\.\w+$", "", it.filename)
        names = set(re.findall(r"[가-힣]{2,4}[A-Z]?(?![a-z])", stem))   # 박지영B 와 박지영은 다른 교수님
        txt = re.sub(r"\(수정본?\)|\(최종\)|수정본", " ", stem)
        for p in sorted(profs, key=len, reverse=True):
            txt = txt.replace(p, " ")
        txt = re.sub(r"^\s*\d{4,8}[_\s]*", " ", txt)                     # 230823 / 0903
        txt = re.sub(r"\d+(\s*[,~\-]\s*\d+)*\s*교시(\(\d\))?", " ", txt)  # 1,2교시(3)
        txt = re.sub(r"^\s*\d(\s*,\s*\d)*\s+", " ", txt)                  # '1,2 ' (20학번 형식)
        txt = re.sub(r"[_\-]\s*[가-힣]{2,4}\s*$", " ", txt)               # 끝의 필기 담당자
        txt = re.sub(r"교수님?", " ", txt)

        def rank(t):
            sc = []
            for L in pool:
                s = _old_score(t, L)
                lp = set(L.profs) | {p for _y, ps in L.history() for p in ps}
                if names & lp:
                    s += 0.15
                sc.append((s, L))
            sc.sort(key=lambda x: (-x[0], x[1].mmdd, x[1].start))
            return sc

        def pick(sc, t):
            best = sc[0][0]
            close = [L for s, L in sc if s >= best - 0.12]
            if best < 0.7:
                return None
            if len(close) == 1 or len({_clean(_num_norm(L.title)) for L in close}) == 1:
                return close
            # '성장 I,II' → 번호만 다른 강의들이고, 자료 번호가 그걸 다 덮으면 모두
            base = {re.sub(r"\d", "", _clean(_num_norm(L.title))) for L in close}
            nums = set()
            for L in close:
                nums |= _nums_after(_num_norm(L.title))
            if len(base) == 1 and nums and nums <= _nums_after(_num_norm(t)):
                return close
            return None

        parts = [q for q in re.split(r"\+", txt) if len(re.sub(r"\W", "", q)) >= 2]
        chosen: List[Lecture] = []
        ok = True
        if len(parts) > 1:
            for q in parts:
                got = pick(rank(q), q)
                if got is None:
                    ok = False
                    break
                chosen += [L for L in got if L not in chosen]
        else:
            got = pick(rank(txt), txt)
            ok = got is not None
            chosen = got or []
        sc = rank(txt)
        if ok and chosen:
            out += [Decision(it, L, "추정") for L in chosen]
        elif sc[0][0] >= 0.35:
            out.append(Decision(it, None, "애매", [L for _s, L in sc[:6]]))
    return out
