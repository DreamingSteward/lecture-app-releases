"""강의록앱 계정 — 구글 로그인(컴퓨터 앱) · 강의록앱 서버 · 학교 인증 · 시간표 모음.

- 구글 로그인: 데스크톱 OAuth(루프백 127.0.0.1 + PKCE). 클라이언트 id·비밀은 앱 폴더의 google_client.json
  (구글 문서상 데스크톱 앱의 비밀은 '비밀이 아님' — 앱에 같이 배포). 없으면 로그인 단계를 건너뜀.
- 새로 고침 토큰·사람 키 표(ticket)는 키체인(secrets_store)에만. 파일·로그에 남기지 않음.
- 서버에 보내는 건 구글 ID 토큰과 그 요청에 필요한 값뿐. 학번·비밀번호·메일 주소는 보내지 않음
  (LMS 인증은 인증 전용으로 새로 로그인한 세션의 canvas 쿠키만 보내고 바로 로그아웃).
"""
from __future__ import annotations

import base64
import hashlib
import json
import secrets
import shutil
import tempfile
import threading
import time
import webbrowser
from datetime import date
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Optional
from urllib.parse import urlencode, urlparse, parse_qs

from . import secrets_store

SERVER_URL = "https://script.google.com/macros/s/AKfycby1FuXSHZPRAbkPbK6ez6aE0XY5VAdHki01Q2x7zhLim1ttMveyhxnpo9W0GALbGB6Y/exec"
SVC_RT = "강의록앱-google"          # 구글 새로 고침 토큰 (계정 이름 = 메일 주소, 화면 표시용)
SVC_TK = "강의록앱-ticket"          # 학교 인증 사람 키 표
CANVAS = "https://canvas.knu.ac.kr"
HERE = Path(__file__).resolve().parent

ERR = {   # 서버 오류 코드 → 화면 문구 (API.md 와 같음)
    "no_login": "구글 로그인이 풀렸어요. 다시 로그인해 주세요", "bad_login": "구글 로그인이 풀렸어요. 다시 로그인해 주세요",
    "not_verified": "학교 인증을 먼저 해 주세요", "not_school_email": "@knu.ac.kr 학교 메일만 돼요",
    "too_many_codes": "코드를 너무 많이 보냈어요. 1시간 뒤에 다시 해 주세요",
    "mail_failed:daily_limit": "오늘은 인증 메일이 많이 나갔어요. 내일 다시 하거나 LMS 로그인으로 인증해 주세요",
    "mail_busy": "오늘은 인증 메일이 많이 나갔어요. 내일 다시 하거나 LMS 로그인으로 인증해 주세요",
    "wrong": "숫자가 달라요", "expired": "시간이 지났어요 — 다시 보내 주세요", "too_many_tries": "여러 번 틀렸어요 — 다시 보내 주세요",
    "lms_busy": "LMS 확인을 너무 많이 했어요. 잠시 뒤에 하거나 학교 메일로 인증해 주세요",
    "lms_failed": "LMS 확인이 안 됐어요. 학교 메일로 인증해 주세요",
    "too_fast": "잠시 뒤에 다시 해 주세요", "login_busy": "잠시 뒤에 다시 해 주세요", "busy": "잠시 뒤에 다시 해 주세요",
    "server_error": "잠시 뒤에 다시 해 주세요", "need_ticket": "학교 인증을 다시 해 주세요",
    "no_ai_consent": "AI 정리 동의가 필요해요", "mail_failed": "인증 메일을 보내지 못했어요. 잠시 뒤에 다시 하거나 LMS로 인증해 주세요",
    "share_limit": "이번 학기에는 시간표를 더 보낼 수 없어요 (학기마다 3번)", "bad_timetable": "시간표 모양이 맞지 않아요. 다시 붙여 넣어 주세요",
    "not_found": "찾을 수 없어요", "bad_feature": "지원하지 않는 기능이에요", "bad_input": "보낼 폴더 이름이 없어요", "bad_grade": "학년 · 학기를 확인해 주세요",
    "ai_limit": "이번 학기 AI 정리를 다 썼어요 (사람당 학기 2번) · [직접 고르기]로 맞춰 주세요",
    "ai_grade_limit": "이번 학기 우리 학년 AI 정리 횟수를 다 썼어요 · [직접 고르기]로 맞춰 주세요",
    "ai_busy": "지금은 AI 정리를 쓰는 사람이 많아요. 잠시 뒤에 하거나 [직접 고르기]로 맞춰 주세요",
    "ai_too_often": "AI 정리를 너무 자주 눌렀어요. 1시간 뒤에 다시 해 주세요",
    "ai_bad_today": "오늘은 AI 정리가 잘 안 돼요. 내일 하거나 [직접 고르기]로 맞춰 주세요",
    "ai_bad_limit": "이번 학기엔 AI 정리가 잘 안 돼요. [직접 고르기]로 맞춰 주세요",
    "ai_failed": "AI 정리가 안 됐어요. 잠시 뒤에 다시 해 주세요", "ai_bad_answer": "AI가 과목을 못 맞췄어요. [직접 고르기]로 맞춰 주세요",
    "ai_too_long": "폴더가 너무 많아 AI 정리가 안 돼요. [직접 고르기]로 맞춰 주세요",
    "ai_off": "AI 정리를 잠시 쉬고 있어요. [직접 고르기]로 맞춰 주세요",
    "grade_locked": "이번 학기엔 처음 AI 정리를 쓴 학년에서만 쓸 수 있어요",
}


def _msg(code: str) -> str:
    return ERR.get(code or "", "서버와 연결이 잘 안 됐어요. 잠시 뒤에 다시 해 주세요")


DRIVE_SCOPE = "https://www.googleapis.com/auth/drive.file"     # 내 드라이브의 「앱이 만든 파일만」 (강의록앱/_상태)


class Account:
    def __init__(self, app_dir: Path):
        self.app_dir = Path(app_dir)
        self.state_path = self.app_dir / "account.json"
        self._id = None            # (id_token, 만료 시각)
        self._at = None            # (access_token, 만료 시각) — 드라이브 _상태 파일용
        self._login = None         # 진행 중인 로그인 {"state", "verifier", "port", "srv", "err", "done"}
        self._lms = {"busy": False, "msg": "", "ok": None}
        self._lock = threading.Lock()

    # ---------------------------------------------------------------- 저장
    def _st(self) -> dict:
        try:
            return json.loads(self.state_path.read_text("utf-8"))
        except Exception:
            return {}

    def _save(self, **kw):
        d = self._st()
        d.update(kw)
        d = {k: v for k, v in d.items() if v is not None}
        self.state_path.write_text(json.dumps(d, ensure_ascii=False, indent=1), "utf-8")

    def client(self) -> Optional[dict]:
        for p in (self.app_dir / "google_client.json", HERE / "google_client.json"):
            try:
                c = json.loads(p.read_text("utf-8"))
                c = c.get("installed") or c        # 구글 콘솔에서 받은 JSON 그대로도 됨
                if c.get("client_id") and c.get("client_secret"):
                    return {"client_id": c["client_id"], "client_secret": c["client_secret"]}
            except Exception:
                pass
        return None

    # ---------------------------------------------------------------- 화면에 보낼 상태
    def state(self) -> dict:
        d = self._st()
        lg = self._login
        return {"ok": True, "configured": bool(self.client()), "logged_in": bool(d.get("email")) and secrets_store.has(SVC_RT),
                "email": d.get("email", ""), "consent": d.get("consent", ""), "verified": bool(d.get("verified")),
                "method": d.get("method", ""), "drive": bool(d.get("drive")), "ai_consent": d.get("ai_consent", ""), "ticket": secrets_store.has(SVC_TK), "pending": bool(lg and not lg.get("done")),
                "login_err": (lg or {}).get("err", ""), "lms": dict(self._lms)}

    # ---------------------------------------------------------------- 구글 로그인 (루프백 + PKCE)
    def login_start(self, _b=None) -> dict:
        c = self.client()
        if not c:
            return {"ok": False, "msg": "이 버전에는 구글 로그인이 아직 준비되지 않았어요. 「로그인 없이 시작하기」로 진행해 주세요."}
        self._stop_listener()
        verifier = secrets.token_urlsafe(64)
        challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode()
        state = secrets.token_urlsafe(24)
        acct = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def do_GET(self):
                q = parse_qs(urlparse(self.path).query)
                ok, msg = False, "로그인이 취소됐어요. 앱으로 돌아가 다시 시도해 주세요."
                if (q.get("state") or [""])[0] == state and q.get("code"):
                    ok, msg = acct._finish(q["code"][0], verifier, f"http://127.0.0.1:{self.server.server_port}")
                elif q.get("error"):
                    acct._login.update(err="로그인을 취소했어요")
                else:
                    return self._out(404, "")
                acct._login["done"] = True
                body = (f"<!doctype html><meta charset=utf-8><title>강의록앱</title><body style=\"font-family:-apple-system,sans-serif;"
                        f"display:grid;place-items:center;height:90vh;color:#16242A\"><div style=\"text-align:center\"><h2>"
                        f"{'로그인됐어요' if ok else '로그인하지 못했어요'}</h2><p>{msg}</p></div>")
                self._out(200, body)
                threading.Thread(target=acct._stop_listener, daemon=True).start()

            def _out(self, code, body):
                b = body.encode()
                self.send_response(code)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(b)))
                self.end_headers()
                self.wfile.write(b)

        srv = HTTPServer(("127.0.0.1", 0), H)
        port = srv.server_port
        self._login = {"state": state, "srv": srv, "done": False, "err": "", "t": time.time()}
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        tm = threading.Timer(600, lambda: self._stop_listener(timeout=True))       # 10분 지나면 닫음
        tm.daemon = True
        tm.start()
        url = "https://accounts.google.com/o/oauth2/v2/auth?" + urlencode({
            "client_id": c["client_id"], "redirect_uri": f"http://127.0.0.1:{port}", "response_type": "code",
            "scope": "openid email profile " + DRIVE_SCOPE, "include_granted_scopes": "true", "code_challenge": challenge, "code_challenge_method": "S256",
            "state": state, "prompt": "select_account"})
        try:
            webbrowser.open(url)
        except Exception:
            pass
        return {"ok": True, "url": url}

    def _stop_listener(self, timeout=False):
        lg = self._login
        if not lg:
            return
        if timeout and not lg.get("done"):
            lg.update(done=True, err="로그인 시간이 지났어요. 다시 눌러 주세요")
        srv = lg.pop("srv", None)
        if srv:
            try:
                srv.shutdown()
                srv.server_close()
            except Exception:
                pass

    def _finish(self, code: str, verifier: str, redirect: str):
        import requests
        c = self.client()
        try:
            r = requests.post("https://oauth2.googleapis.com/token", data={
                "code": code, "client_id": c["client_id"], "client_secret": c["client_secret"],
                "redirect_uri": redirect, "grant_type": "authorization_code", "code_verifier": verifier}, timeout=20)
            j = r.json()
        except Exception as e:
            self._login.update(err=f"구글과 연결이 안 됐어요 ({type(e).__name__})")
            return False, "인터넷 연결을 확인하고 앱에서 다시 눌러 주세요."
        idt, rt = j.get("id_token"), j.get("refresh_token")
        if not idt or not rt:
            self._login.update(err="구글 로그인을 마치지 못했어요")
            return False, "앱에서 다시 눌러 주세요."
        email = (self._claims(idt).get("email") or "").strip()
        ok, m = secrets_store.put(SVC_RT, email, rt)
        if not ok:
            self._login.update(err=m)
            return False, m
        self._id = (idt, time.time() + int(j.get("expires_in") or 3000) - 120)
        if j.get("access_token"):
            self._at = (j["access_token"], self._id[1])
        old = self._st()
        if old.get("email") and old.get("email") != email:      # 다른 계정이면 인증 기록은 새로
            secrets_store.delete(SVC_TK)
            self._save(verified=None, method=None, consent=None)
        self._save(email=email, drive=(DRIVE_SCOPE in str(j.get("scope") or "")) or None)
        try:                                                   # 서버에 이미 인증돼 있으면 (폰에서 한 것 등) 그대로
            me = self.call("me")
            if me.get("ok"):
                self._save(verified=bool(me.get("verified")) or None, method=me.get("method") or None)
                if me.get("aiConsent") is True:          # 다시 로그인해도 서버에 남은 AI 동의를 화면에 보여 줌 (날짜는 이 기기에서 확인한 날)
                    self._save(ai_consent=self._st().get("ai_consent") or date.today().isoformat())
                elif me.get("aiConsent") is False and self._st().get("ai_consent"):
                    self._save(ai_consent="no")
        except Exception:
            pass
        return True, "강의록앱으로 돌아가 주세요. 이 창은 닫아도 돼요."

    @staticmethod
    def _claims(idt: str) -> dict:
        try:
            p = idt.split(".")[1]
            return json.loads(base64.urlsafe_b64decode(p + "=" * (-len(p) % 4)))
        except Exception:
            return {}

    def id_token(self) -> Optional[str]:
        if self._id and self._id[1] > time.time():
            return self._id[0]
        c, rt = self.client(), secrets_store.get(SVC_RT)
        if not c or not rt:
            return None
        import requests
        try:
            j = requests.post("https://oauth2.googleapis.com/token", data={
                "client_id": c["client_id"], "client_secret": c["client_secret"],
                "refresh_token": rt[1], "grant_type": "refresh_token"}, timeout=20).json()
        except Exception:
            return None
        if j.get("error") == "invalid_grant":                 # 계정에서 앱 접근을 끊었음
            secrets_store.delete(SVC_RT)
            return None
        if not j.get("id_token"):
            return None
        self._id = (j["id_token"], time.time() + int(j.get("expires_in") or 3000) - 120)
        if j.get("access_token"):
            self._at = (j["access_token"], self._id[1])
            if j.get("scope"):
                self._save(drive=(DRIVE_SCOPE in str(j["scope"])) or None)
        return self._id[0]

    def access_token(self) -> Optional[str]:
        """드라이브용 접근 토큰 (「앱이 만든 파일만」 권한이 있을 때만)"""
        if not self._at or self._at[1] <= time.time():
            self._id = None
            self.id_token()
        if not self._st().get("drive"):
            return None
        return self._at[0] if self._at and self._at[1] > time.time() else None

    def quota(self) -> dict:
        """내 구글 드라이브 남은 용량 (첫 설정 「다른 곳에도 복사」에서 모자라는지 보기)"""
        at = self.access_token()
        if not at:
            return {"ok": False}
        import requests
        try:
            q = requests.get("https://www.googleapis.com/drive/v3/about", params={"fields": "storageQuota"},
                             headers={"Authorization": "Bearer " + at}, timeout=15).json().get("storageQuota") or {}
            lim, use = int(q.get("limit") or 0), int(q.get("usage") or 0)
            return {"ok": True, "limit": lim, "usage": use, "free": (lim - use) if lim else None}
        except Exception:
            return {"ok": False}

    def tt_offer(self, b: dict) -> dict:
        """시간표 「공유하기」: 서버 후보함으로 (관리자가 확인한 뒤에만 모음에 들어감)"""
        keep = {k: b[k] for k in ("grade", "year", "term", "cohort", "timetable", "note") if k in b}
        r = self.call("tt_offer", **keep)
        return r

    # ---------------------------------------------------------------- AI 정리 (국외 이전 동의)
    def ai_consent(self, b: dict) -> dict:
        """동의 · 철회를 서버에 기록하고 이 기기에도 날짜만 남김 (화면 표시용)"""
        agree = b.get("agree") is True
        r = self.call("ai_consent", agree=agree)
        if r.get("ok"):
            self._save(ai_consent=date.today().isoformat() if agree else "no")
            return {**self.state(), "ok": True}
        return r

    def ai_folders(self, names: list, subjects: list, grade: str, year: int, term: int, revise: bool = False) -> dict:
        """학년 드라이브 폴더 이름 → 과목 짝짓기 (서버가 AI를 대신 부름 · 폴더 · 과목 이름만 보냄)"""
        tk = secrets_store.get(SVC_TK)
        if not tk:
            return {"ok": False, "error": "need_ticket", "msg": _msg("need_ticket")}
        r = self.call("ai", feature="folders", ticket=tk[1], grade=grade, year=year, term=term,
                      names=names, subjects=subjects, **({"revise": True} if revise else {}))
        if r.get("error") == "no_ai_consent":
            self._save(ai_consent="no")
        return r

    def logout(self, _b=None) -> dict:
        secrets_store.delete(SVC_RT)
        secrets_store.delete(SVC_TK)
        self._id = self._at = None
        try:
            self.state_path.unlink()
        except Exception:
            pass
        return {"ok": True}

    # ---------------------------------------------------------------- 서버
    def call(self, action: str, _timeout: int = 45, **body) -> dict:
        import requests
        t = self.id_token()
        if not t:
            return {"ok": False, "error": "no_login", "msg": _msg("no_login")}
        try:
            r = requests.post(SERVER_URL, data=json.dumps({"action": action, "idToken": t, **body}),
                              headers={"Content-Type": "text/plain;charset=utf-8"}, timeout=_timeout, allow_redirects=True)
            j = r.json()
        except Exception as e:
            return {"ok": False, "error": "net", "msg": f"강의록앱 서버와 연결이 안 됐어요 ({type(e).__name__})"}
        if not j.get("ok"):
            j["msg"] = _msg(j.get("error", ""))
            if j.get("error") in ("no_login", "bad_login"):
                self._id = None
        return j

    def consent(self, b: dict) -> dict:
        self._save(consent=date.today().isoformat() if b.get("agree") else "no")
        return self.state()

    def otp_send(self, b: dict) -> dict:
        em = str(b.get("email") or "").strip().lower()
        if not em.endswith("@knu.ac.kr") or "+" in em:
            return {"ok": False, "msg": _msg("not_school_email")}
        return self.call("otp_send", email=em)              # 메일 주소는 저장하지 않음

    def otp_verify(self, b: dict) -> dict:
        em = str(b.get("email") or "").strip().lower()
        r = self.call("otp_verify", email=em, code=str(b.get("code") or "").strip())
        if r.get("ok") and r.get("verified"):
            if r.get("ticket"):
                secrets_store.put(SVC_TK, self._st().get("email", ""), r["ticket"])
            self._save(verified=True, method="mail")
        return r

    def delete_me(self, _b=None) -> dict:
        r = self.call("delete_me")
        if r.get("ok"):
            self.logout()
        return r

    # ---------------------------------------------------------------- 학교 인증 = LMS (인증 전용 새 세션)
    def lms_verify_start(self, _b=None) -> dict:
        check = bool((_b or {}).get("check"))           # check: 학교 인증 없이 학번·비밀번호로 실제 로그인되는지만 (처음 설정 C06)
        with self._lock:
            if self._lms["busy"]:
                return {"ok": True, "busy": True}
            self._lms = {"busy": True, "msg": "LMS에 실제로 로그인해 보는 중…" if check else "LMS에 로그인하는 중…", "ok": None, "check": check}
        threading.Thread(target=self._lms_run, args=(check,), daemon=True).start()
        return {"ok": True, "busy": True}

    def _lms_run(self, check: bool = False):
        from . import lms as _lms
        prof = Path(tempfile.mkdtemp(prefix="la-verify-"))
        L = None
        try:
            if not _lms.keychain_get():
                raise RuntimeError("LMS 학번·비밀번호를 먼저 저장해 주세요")
            L = _lms.LMS(self.app_dir, lambda *a: None, interactive=False)
            L.profile_dir = prof                              # 평소 세션과 따로 (빈 프로필)
            L._open(headless=True)
            if not L._auto_login():
                raise RuntimeError("LMS 로그인이 안 됐어요. 학번·비밀번호를 확인해 주세요")
            if check:
                self._lms = {"busy": False, "msg": "LMS 로그인 확인됨", "ok": True, "check": True}
                return
            ck = {c["name"]: c["value"] for c in L.ctx.cookies(CANVAS)}
            ck = dict(list(ck.items())[:12])
            r = self.call("lms_verify", lmsCookies=ck)
            if r.get("ok") and r.get("verified"):
                if r.get("ticket"):
                    secrets_store.put(SVC_TK, self._st().get("email", ""), r["ticket"])
                self._save(verified=True, method="lms")
                self._lms = {"busy": False, "msg": "학교 인증 완료", "ok": True}
            else:
                self._lms = {"busy": False, "msg": r.get("msg") or _msg(r.get("error", "")), "ok": False}
        except Exception as e:
            self._lms = {"busy": False, "msg": str(e) if isinstance(e, RuntimeError) else f"LMS 확인 중 문제가 생겼어요 ({type(e).__name__})", "ok": False}
        finally:
            if L is not None:
                try:                                          # 그 세션 로그아웃 → 보낸 쿠키는 쓸모없어짐
                    csrf = next((c["value"] for c in L.ctx.cookies(CANVAS) if c["name"] == "_csrf_token"), "")
                    from urllib.parse import unquote
                    L.page.request.delete(CANVAS + "/logout", headers={"X-CSRF-Token": unquote(csrf)}, timeout=15000)
                except Exception:
                    pass
                try:
                    L.close()
                except Exception:
                    pass
            shutil.rmtree(prof, ignore_errors=True)

    # ---------------------------------------------------------------- 시간표 모음 (학교 인증한 사람만)
    def lib_get(self, school: str = "knu-med") -> Optional[dict]:
        d = self._st()
        if not d.get("verified") or d.get("consent") in ("", "no", None):
            return None
        cache = self.app_dir / f".lib_{school}.json"
        sig = ""
        try:
            old = json.loads(cache.read_text("utf-8"))
            sig = old.get("sig", "")
        except Exception:
            old = None
        r = self.call("lib_get", school=school, **({"sig": sig} if sig else {}))
        if r.get("ok") and r.get("same") and old:
            return old.get("library")
        if r.get("ok") and isinstance(r.get("library"), dict):
            try:
                cache.write_text(json.dumps({"sig": r.get("sig", ""), "library": r["library"]}, ensure_ascii=False), "utf-8")
            except Exception:
                pass
            return r["library"]
        if r.get("error") == "not_verified":
            self._save(verified=None)
        return old.get("library") if old else None
