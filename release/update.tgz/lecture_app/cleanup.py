"""예전 학교 LMS 기능이 남긴 것 정리 (한 번만)

- 2026-11-17 학교 보안 공지 때 한 번 모두 로그아웃 (그 버전에서 이미 한 사람은 다시 안 함)
- LMS 기능을 뺀 뒤: 남은 LMS 로그인 정보 · 브라우저 세션 · 로그인 화면 캡처 · 로그인 쉬기 기록을 한 번 지움
"""
from __future__ import annotations

import shutil
from pathlib import Path

OLD_KEYCHAIN = "강의록앱-KNU"                   # 예전 LMS 아이디 · 비밀번호 (키체인 · 자격 증명 관리자)
LOCKDOWN_FLAG = "lms_lockdown_2026-11-17"       # 이 파일이 있으면 그때 이미 로그아웃됨
REMOVED_FLAG = "lms_removed"


def _leftovers(app: Path):
    try:
        from . import secrets_store
        secrets_store.delete(OLD_KEYCHAIN)
    except Exception:
        pass
    shutil.rmtree(app / ".browser", ignore_errors=True)
    shutil.rmtree(app / "logs" / "로그인화면", ignore_errors=True)
    try:
        (app / "logs" / "로그인쉬기.json").unlink(missing_ok=True)
    except Exception:
        pass


def _flag(f: Path, text: str):
    try:
        f.parent.mkdir(parents=True, exist_ok=True)
        f.write_text(text, "utf-8")
    except Exception:
        pass


def mark_done(app_dir):
    """정리할 것이 없을 때(이 PC에서 내 정보 지우기 뒤 등): 다음에 켤 때 다시 로그아웃하지 않게 표시만"""
    cache = Path(app_dir) / ".cache"
    _flag(cache / LOCKDOWN_FLAG, "2026-11-17")
    _flag(cache / REMOVED_FLAG, "1")


def once(app_dir, acct=None) -> bool:
    """앱 · 예약 받기를 켤 때 부름 → 이번에 지웠으면 True"""
    app = Path(app_dir)
    lock, done = app / ".cache" / LOCKDOWN_FLAG, app / ".cache" / REMOVED_FLAG
    did = False
    if not lock.exists():                       # 예전 버전에서 아직 한 번 모두 로그아웃을 안 함
        _leftovers(app)
        try:
            if acct is None:
                from .account import Account
                acct = Account(app)
            acct.logout()
        except Exception:
            pass
        _flag(lock, "2026-11-17")
        did = True
    if not done.exists():                       # LMS 흔적은 계정과 상관없이 한 번
        if not did:
            _leftovers(app)
        _flag(done, "1")
        did = True
    return did
