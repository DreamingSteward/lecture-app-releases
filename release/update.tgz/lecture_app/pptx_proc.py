"""PPT/PPTX 전처리.

1) 숨긴 슬라이드 → 보이게 바꾸고 '숨긴 슬라이드' 표시 대상으로 기록
2) 애니메이션 때문에 PDF에서 사진·도형이 겹쳐 가려지는 슬라이드 → 클릭 순서대로 여러 장으로 분할
   (분할된 장은 '애니메이션 k/n' 표시 대상)

판단 원리
- 슬라이드쇼에서 클릭 k번 뒤에 보이는 개체 집합을 계산한다 (등장/퇴장 효과).
- PDF는 모든 개체를 한꺼번에 그리므로, 위에 있는 개체에 절반 이상 덮이는 개체는 '안 보이는 내용'이 된다.
- 각 단계에서 '실제로 보이는 내용'을 구하고, 다음 단계에 그대로 포함되는 단계는 버린다.
  남는 단계가 2개 이상이면 = 어떤 단계의 내용이 이후에 가려지거나 사라진다 = 분할 필요.
- 애니메이션이 없는 단순 겹침은 건드리지 않고 '보고만' 한다.
"""
from __future__ import annotations

import copy
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

from pptx import Presentation
from pptx.oxml.ns import qn

P_NS = "http://schemas.openxmlformats.org/presentationml/2006/main"
A_NS = "http://schemas.openxmlformats.org/drawingml/2006/main"
R_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"

COVER_RATIO = 0.5     # 위 개체가 아래 개체 면적의 50% 이상 덮으면 '가려짐'
PIC_RATIO = 0.25      # 사진 위에 사진이 겹치면 25%만 덮여도 '가려짐' (엑스레이·CT를 겹쳐 놓은 슬라이드)
OVERLAP_RATIO = 0.15  # 단순 겹침 보고 기준


@dataclass
class SlideReport:
    index: int                    # 원본 슬라이드 번호 (1부터)
    hidden: bool = False
    split: int = 1                # 나눈 장 수
    plain_overlap: bool = False   # 애니메이션 없는 겹침 (보고만)


@dataclass
class Result:
    labels: List[str] = field(default_factory=list)   # 출력 슬라이드 순서대로 오른쪽 위 표시 문구 ('' = 없음)
    reports: List[SlideReport] = field(default_factory=list)

    @property
    def hidden_count(self) -> int:
        return sum(r.hidden for r in self.reports)

    @property
    def split_slides(self) -> List[SlideReport]:
        return [r for r in self.reports if r.split > 1]

    @property
    def overlap_slides(self) -> List[SlideReport]:
        return [r for r in self.reports if r.plain_overlap]


# ---------------------------------------------------------------- 도형 위치
def _xfrm_box(el) -> Optional[Tuple[int, int, int, int]]:
    for path in ("p:spPr/a:xfrm", "p:grpSpPr/a:xfrm", "p:xfrm"):
        x = el.find(path.replace("p:", f"{{{P_NS}}}").replace("a:", f"{{{A_NS}}}"))
        if x is not None:
            off, ext = x.find(qn("a:off")), x.find(qn("a:ext"))
            if off is not None and ext is not None:
                return int(off.get("x")), int(off.get("y")), int(ext.get("cx")), int(ext.get("cy"))
    return None


SHAPE_TAGS = {qn("p:sp"), qn("p:pic"), qn("p:grpSp"), qn("p:graphicFrame"), qn("p:cxnSp")}


def _shape_id(el) -> Optional[str]:
    for c in el.iter(qn("p:cNvPr")):
        return c.get("id")
    return None


def _top_shapes(sptree) -> List:
    return [el for el in sptree if el.tag in SHAPE_TAGS]


def _id_to_top(sptree) -> Dict[str, object]:
    """모든 개체 id(그룹 안 포함) → 최상위 개체 element."""
    m = {}
    for top in _top_shapes(sptree):
        for c in top.iter(qn("p:cNvPr")):
            m[c.get("id")] = top
    return m


def _area(b):
    return max(0, b[2]) * max(0, b[3])


def _inter(a, b):
    x1, y1 = max(a[0], b[0]), max(a[1], b[1])
    x2, y2 = min(a[0] + a[2], b[0] + b[2]), min(a[1] + a[3], b[1] + b[3])
    return max(0, x2 - x1) * max(0, y2 - y1)


def _is_placeholder_empty(el) -> bool:
    """텍스트 없는 자리표시자/빈 도형은 '내용'으로 치지 않음."""
    if el.tag == qn("p:sp"):
        txt = "".join(t.text or "" for t in el.iter(qn("a:t"))).strip()
        has_fill = el.find(f"{{{P_NS}}}spPr/{{{A_NS}}}blipFill") is not None
        return not txt and not has_fill and el.find(qn("p:nvSpPr") + "/" + qn("p:nvPr") + "/" + qn("p:ph")) is not None
    return False


# ---------------------------------------------------------------- 애니메이션 단계
def _click_steps(sld) -> List[List[Tuple[str, str]]]:
    """클릭 단계별 [(presetClass, spid)] 목록. 문단 단위 효과(txEl)는 도형 전체로 보지 않으므로 제외."""
    timing = sld.find(qn("p:timing"))
    if timing is None:
        return []
    main = None
    for ctn in timing.iter(qn("p:cTn")):
        if ctn.get("nodeType") == "mainSeq":
            main = ctn
            break
    if main is None:
        return []
    lst = main.find(qn("p:childTnLst"))
    if lst is None:
        return []
    steps = []
    for par in lst.findall(qn("p:par")):
        effs = []
        for ctn in par.iter(qn("p:cTn")):
            cls = ctn.get("presetClass")
            if cls not in ("entr", "exit"):
                continue
            tgt = ctn.find(".//" + qn("p:spTgt"))
            if tgt is None or tgt.find(qn("p:txEl")) is not None:
                continue
            effs.append((cls, tgt.get("spid")))
        if effs:
            steps.append(effs)
    return steps


def _states(top_ids: List[str], steps, id2top) -> List[Set[str]]:
    """클릭 0..n 뒤 보이는 최상위 개체 id 집합."""
    def top_of(spid):
        el = id2top.get(spid)
        return _shape_id(el) if el is not None else None

    first: Dict[str, str] = {}
    for st in steps:
        for cls, spid in st:
            t = top_of(spid)
            if t and t not in first:
                first[t] = cls
    vis = {i for i in top_ids if first.get(i) != "entr"}
    out = [set(vis)]
    for st in steps:
        for cls, spid in st:
            t = top_of(spid)
            if not t:
                continue
            if cls == "entr":
                vis.add(t)
            else:
                vis.discard(t)
        out.append(set(vis))
    return out


def _effective(vis: Set[str], order: List[str], boxes: Dict[str, tuple], content: Set[str]) -> Set[str]:
    """보이는 개체 중 위 개체에 절반 이상 가려지지 않은 '내용' 개체."""
    eff = set()
    for i, a in enumerate(order):
        if a not in vis or a not in content:
            continue
        ba = boxes.get(a)
        covered = False
        if ba and _area(ba):
            for b in order[i + 1:]:
                ratio = PIC_RATIO if (a in _PICS and b in _PICS) else COVER_RATIO
                if b in vis and b in boxes and _inter(ba, boxes[b]) >= ratio * _area(ba):
                    # 위 개체가 투명 텍스트상자면 가리지 않음
                    if b in content and _occludes(b):
                        covered = True
                        break
        if not covered:
            eff.add(a)
    return eff


_OCCLUDERS: Set[str] = set()
_PICS: Set[str] = set()


def _occludes(i: str) -> bool:
    return i in _OCCLUDERS


def _is_occluder(el) -> bool:
    """그림·그룹·표/차트·채워진 도형은 아래를 가린다. 채움 없는 텍스트상자는 가리지 않는다."""
    if el.tag in (qn("p:pic"), qn("p:grpSp"), qn("p:graphicFrame")):
        return True
    if el.tag == qn("p:sp"):
        sppr = el.find(qn("p:spPr"))
        if sppr is None:
            return False
        if sppr.find(qn("a:noFill")) is not None:
            return False
        return any(sppr.find(qn(t)) is not None for t in ("a:solidFill", "a:blipFill", "a:gradFill", "a:pattFill"))
    return False


def analyze_slide(sld) -> Tuple[List[Set[str]], bool]:
    """(남길 단계별 보이는 개체 집합 목록, 단순겹침여부). 목록 길이 1이면 분할 불필요."""
    sptree = sld.find(qn("p:cSld")).find(qn("p:spTree"))
    tops = _top_shapes(sptree)
    order = [_shape_id(e) for e in tops]
    boxes = {i: b for i, e in zip(order, tops) if (b := _xfrm_box(e))}
    content = {i for i, e in zip(order, tops) if not _is_placeholder_empty(e)}
    global _OCCLUDERS, _PICS
    _OCCLUDERS = {i for i, e in zip(order, tops) if _is_occluder(e)}
    _PICS = {i for i, e in zip(order, tops) if e.tag == qn("p:pic")}

    steps = _click_steps(sld)
    id2top = _id_to_top(sptree)
    if not steps:
        plain = any(
            a in _OCCLUDERS and b in _OCCLUDERS and a in boxes and b in boxes
            and _inter(boxes[a], boxes[b]) >= OVERLAP_RATIO * min(_area(boxes[a]), _area(boxes[b]) or 1)
            for k, a in enumerate(order) for b in order[k + 1:]
        )
        return [set(order)], plain
    states = _states(order, steps, id2top)
    effs = [_effective(v, order, boxes, content) for v in states]
    keep = []
    for k in range(len(states)):
        if k < len(states) - 1 and effs[k] <= effs[k + 1]:
            continue
        if not effs[k] and k < len(states) - 1:
            continue
        keep.append(states[k])
    if not keep:
        keep = [states[-1]]
    return keep, False


# ---------------------------------------------------------------- 슬라이드 복제
def _duplicate(prs, slide):
    """slide를 복제해 맨 끝에 추가하고 (새 slide, 새 sldId element) 반환."""
    new = prs.slides.add_slide(slide.slide_layout)
    # 관계 복사 (레이아웃/노트 제외) 후 rId 치환
    rmap = {}
    for rid, rel in list(slide.part.rels.items()):
        if rel.reltype.endswith("/slideLayout") or rel.reltype.endswith("/notesSlide"):
            continue
        if rel.is_external:
            nrid = new.part.rels.get_or_add_ext_rel(rel.reltype, rel.target_ref)
        else:
            nrid = new.part.rels.get_or_add(rel.reltype, rel.target_part)
        rmap[rid] = nrid
    old_csld = slide._element.find(qn("p:cSld"))
    new_csld = copy.deepcopy(old_csld)
    for el in new_csld.iter():
        for attr in list(el.attrib):
            if attr.startswith(f"{{{R_NS}}}") and el.attrib[attr] in rmap:
                el.attrib[attr] = rmap[el.attrib[attr]]
    cur = new._element.find(qn("p:cSld"))
    new._element.replace(cur, new_csld)
    # 색 매핑 등 나머지 요소
    for tag in ("p:clrMapOvr",):
        o = slide._element.find(qn(tag))
        if o is not None:
            n = new._element.find(qn(tag))
            if n is not None:
                new._element.remove(n)
            new._element.append(copy.deepcopy(o))
    sld_id = prs.slides._sldIdLst[-1]
    return new, sld_id


def _keep_only(slide, visible: Set[str]):
    sptree = slide._element.find(qn("p:cSld")).find(qn("p:spTree"))
    for el in _top_shapes(sptree):
        if _shape_id(el) not in visible:
            sptree.remove(el)
    t = slide._element.find(qn("p:timing"))
    if t is not None:
        slide._element.remove(t)


def process(src: Path, dst: Path) -> Result:
    """src(.pptx)를 분석·수정해 dst(.pptx)로 저장. 출력 슬라이드별 표시 문구를 돌려준다."""
    prs = Presentation(str(src))
    res = Result()
    sld_list = prs.slides._sldIdLst
    originals = list(prs.slides)
    orig_ids = list(sld_list)
    plan = []  # (slide, sldId, hidden, states, plain)
    for i, (slide, sid) in enumerate(zip(originals, orig_ids), start=1):
        el = slide._element
        hidden = el.get("show") == "0"
        if hidden:
            del el.attrib["show"]
        try:
            states, plain = analyze_slide(el)
        except Exception:
            states, plain = [None], False
        plan.append((slide, sid, hidden, states, plain))
        res.reports.append(SlideReport(i, hidden, len(states), plain))

    new_order = []
    labels = []
    for slide, sid, hidden, states, plain in plan:
        n = len(states)
        if n == 1:
            new_order.append(sid)
            labels.append("숨긴 슬라이드" if hidden else "")
            continue
        copies = []
        for k, vis in enumerate(states):
            if k == 0:
                tgt, tsid = slide, sid
            else:
                tgt, tsid = _duplicate(prs, slide)
            copies.append((tgt, tsid, vis))
        for k, (tgt, tsid, vis) in enumerate(copies, start=1):
            _keep_only(tgt, vis)
            new_order.append(tsid)
            lab = f"애니메이션 {k}/{n}"
            labels.append(f"숨긴 슬라이드 · {k}/{n}" if hidden else lab)
    for s in list(sld_list):
        sld_list.remove(s)
    for s in new_order:
        sld_list.append(s)
    prs.save(str(dst))
    res.labels = labels
    return res
