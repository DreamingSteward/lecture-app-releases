"""클라우드(구글 드라이브·iCloud)에 있는 강의록 찾기 · 「클라우드에도 저장」 복사.

컴퓨터가 꺼져 있을 때 휴대폰이 강의록을 클라우드에서 열 수 있게, 각 PDF가 클라우드 어디에 있는지 알려 줌.
- 구글 드라이브: 「Google Drive 데스크톱」 앱의 폴더 (맥 ~/Library/CloudStorage/GoogleDrive-…/내 드라이브,
  윈도우 G:\\내 드라이브 등). 맥은 드라이브 앱이 파일에 붙여 둔 ID(확장 속성)로 바로 열리는 링크, 그 밖엔 이름 검색 링크.
- iCloud: 맥 iCloud Drive(또는 「데스크탑 및 문서」 동기화), 윈도우 「Windows용 iCloud」의 iCloudDrive 폴더.
- 「클라우드에도 저장」: 정리 폴더의 PDF를 고른 클라우드 폴더에 같은 구조로 복사 (지우거나 옮긴 건 클라우드에서 안 지움).
"""
from __future__ import annotations

import os
import re
import shutil
import sys
import threading
import time
from pathlib import Path
from typing import Optional
from urllib.parse import quote

from . import main as M

MAC, WIN = sys.platform == "darwin", os.name == "nt"
GD_NAMES = ("My Drive", "내 드라이브")
_IDC: dict = {}          # (경로, 수정 시각) → 드라이브 ID


# ---------------------------------------------------------------- 어디에 있나
def _isdir(p: Path) -> bool:
    """권한이 없어 못 여는 폴더(맥 개인정보 보호 등)도 오류 없이 False"""
    try:
        return p.is_dir()
    except OSError:
        return False


def _icloud_base() -> Optional[Path]:
    if MAC:
        b = Path.home() / "Library" / "Mobile Documents" / "com~apple~CloudDocs"
        return b if _isdir(b) else None
    if WIN:
        b = Path(os.environ.get("USERPROFILE", str(Path.home()))) / "iCloudDrive"
        return b if _isdir(b) else None
    return None


def _mac_synced() -> dict:
    """맥 「데스크탑 및 문서 폴더」 iCloud 동기화: 실제 폴더 → iCloud Drive 안의 이름"""
    b = _icloud_base()
    out = {}
    if MAC and b:
        for n in ("Desktop", "Documents"):
            try:
                home = (Path.home() / n).resolve()
                # 동기화를 꺼도 iCloud에 예전 폴더가 남으니, 실제로 같은 폴더일 때만 (같은 폴더면 파일 번호가 같음)
                if (b / n).exists() and os.path.samefile(b / n, Path.home() / n):
                    out[home] = n
            except OSError:
                continue
    return out


def _gd_root(p: Path) -> Optional[Path]:
    """경로 위쪽에서 구글 드라이브 「내 드라이브」 폴더 찾기"""
    for a in [p] + list(p.parents):
        if a.name in GD_NAMES:
            par = a.parent
            if (MAC and par.name.startswith("GoogleDrive-")) or (WIN and (len(str(par)) <= 3 or par == Path.home())) \
                    or par == Path.home() or "GoogleDrive" in str(par) or "CloudStorage" in str(par):
                return a
    return None


def _mac_xattr(path: Path, name: str) -> str:
    try:
        import ctypes
        import ctypes.util
        libc = ctypes.CDLL(ctypes.util.find_library("c"), use_errno=True)
        f = libc.getxattr
        f.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_void_p, ctypes.c_size_t, ctypes.c_uint32, ctypes.c_int]
        f.restype = ctypes.c_ssize_t
        buf = ctypes.create_string_buffer(256)
        n = f(os.fsencode(str(path)), name.encode(), buf, 256, 0, 0)
        return buf.raw[:n].decode("utf-8", "replace").strip() if n > 0 else ""
    except Exception:
        return ""


def _gd_id(p: Path) -> str:
    """맥: 드라이브 앱이 붙여 둔 파일 ID (업로드가 끝나야 생김)"""
    if not MAC:
        return ""
    try:
        k = (str(p), p.stat().st_mtime)
    except OSError:
        return ""
    if k in _IDC:
        return _IDC[k]
    v = _mac_xattr(p, "com.google.drivefs.item-id#S")
    v = v if re.fullmatch(r"[\w-]{10,}", v or "") else ""
    if v and len(_IDC) < 5000:            # 아직 업로드 전(ID 없음)은 기억하지 않음 → 올라가면 바로 링크가 생김
        _IDC[k] = v
    return v


def locate(p: Path) -> Optional[dict]:
    """파일 하나가 클라우드 어디에 있는지 → {"kind": "gdrive"|"icloud", "path": 보여 줄 경로, "id": 드라이브 ID, "ipath": 아이폰 파일 앱 경로}"""
    try:
        r = p.resolve()
    except Exception:
        return None
    g = _gd_root(r)
    if g:
        rel = r.relative_to(g).as_posix()
        return {"kind": "gdrive", "path": "내 드라이브/" + rel, "id": _gd_id(r), "name": r.name}
    b = _icloud_base()
    if b:
        try:
            rel = r.relative_to(b.resolve()).as_posix()
            return {"kind": "icloud", "path": "iCloud Drive/" + rel, "ipath": rel, "name": r.name}
        except ValueError:
            pass
    for real, nm in _mac_synced().items():
        try:
            rel = r.relative_to(real).as_posix()
            return {"kind": "icloud", "path": f"iCloud Drive/{'데스크탑' if nm == 'Desktop' else '문서'}/" + rel,
                    "ipath": f"{nm}/{rel}", "name": r.name}
        except ValueError:
            continue
    return None


KINDS = ("gdrive", "icloud")
KNAME = {"gdrive": "구글 드라이브", "icloud": "iCloud"}


def kind_of(p: Path) -> str:
    try:
        r = p.resolve()
    except Exception:
        return ""
    if _gd_root(r):
        return "gdrive"
    return "icloud" if cloud_root(r) else ""


def for_rel(rel: str) -> dict:
    """정리 폴더 안 PDF(rel) → {종류: 클라우드 위치} (정리 폴더가 클라우드면 그대로 + 켜 둔 「~에도 복사」 복사본들)"""
    out = {}
    if not rel or not rel.lower().endswith(".pdf"):
        return out
    got = locate(M.SAVE_ROOT / rel)
    if got:
        out[got["kind"]] = got
    for k, d in copy_dirs().items():
        if k in out:
            continue
        dst = d / rel
        if dst.exists():
            g = locate(dst)
            if g and g["kind"] == k:
                out[k] = g
    return out


def links(info: dict) -> dict:
    """휴대폰에서 열 주소"""
    if not info:
        return {}
    if info["kind"] == "gdrive":
        return {**info, "url": f"https://drive.google.com/file/d/{info['id']}/view" if info.get("id") else "",
                "search": "https://drive.google.com/drive/search?q=" + quote(info.get("name", ""))}
    return {**info, "ios": "shareddocuments:///private/var/mobile/Library/Mobile%20Documents/com~apple~CloudDocs/"
            + quote(info.get("ipath", "")), "web": "https://www.icloud.com/iclouddrive/"}


def state_map(rels) -> dict:
    """{rel: {"gdrive": {...}, "icloud": {...}}}"""
    out = {}
    for rel in rels:
        try:
            got = for_rel(rel)
        except Exception:
            got = {}
        if got:
            out[rel] = {k: links(v) for k, v in got.items()}
    return out


# ---------------------------------------------------------------- 「iCloud에도 / 구글 드라이브에도 복사」 (따로 켜고 끔)
def _cfg(cfg: Optional[dict] = None) -> dict:
    """{"gdrive": {"on", "dir"}, "icloud": {"on", "dir"}} · 예전 한 칸짜리 설정({"on","dir"})은 폴더 종류로 옮겨 읽음"""
    try:
        c = dict((cfg if cfg is not None else M.read_cfg()).get("cloud_copy") or {})
    except Exception:
        return {}
    if "dir" in c or "on" in c:
        old = {"on": bool(c.get("on")), "dir": c.get("dir") or ""}
        c = {k: v for k, v in c.items() if k in KINDS}
        k = kind_of(Path(os.path.expanduser(old["dir"]))) if old["dir"] else ""
        if k and k not in c:
            c[k] = old
    return c


def copy_dirs() -> dict:
    """켜 둔 복사 폴더들 {종류: 폴더} · 정리 폴더가 이미 그 클라우드 안이면 빼기 (같은 클라우드에 중복으로 쌓이지 않게)"""
    out = {}
    try:
        rk = kind_of(M.SAVE_ROOT / "x.pdf")
    except Exception:
        rk = ""
    for k, v in _cfg().items():
        if k == rk:
            continue
        if k in KINDS and isinstance(v, dict) and v.get("on") and v.get("dir"):
            try:
                out[k] = Path(os.path.expanduser(str(v["dir"]))).resolve()
            except Exception:
                pass
    return out


SCOPE_DEF = {"lec": True, "x": True, "xold": False}     # 구글 드라이브에 복사할 범위: 강의록 · 올해 추가자료 · 선배 추가자료
_XOLD = re.compile(r"_추가자료\(\d+학번\)")


def scope(kind: str = "gdrive") -> dict:
    """복사 범위 (구글 드라이브만 고를 수 있음 · iCloud는 전부)"""
    if kind != "gdrive":
        return {k: True for k in SCOPE_DEF}
    v = _cfg().get("gdrive") or {}
    sc = v.get("scope") if isinstance(v, dict) else None
    return {k: bool(sc.get(k, d)) if isinstance(sc, dict) else d for k, d in SCOPE_DEF.items()}


def part_of(relp: Path) -> str:
    """정리 폴더 안 파일 → "lec" | "x" | "xold" (선배 추가자료 = 우리 학번이 아닌 학번 폴더 · 예전 이름 '(21학번)')"""
    try:
        xr = M.EXTRA_ROOT.resolve().relative_to(M.SAVE_ROOT.resolve())
    except Exception:
        xr = None
    if xr is not None and relp.parts[:len(xr.parts)] == xr.parts:
        if _XOLD.search(relp.name):
            return "xold"
        olds = {M.xfolder(str(s.get("label", "")).strip()) for s in M.old_sources()}
        return "xold" if olds & set(relp.parts[len(xr.parts):-1]) else "x"
    return "lec"


def copy_dir() -> Optional[Path]:
    """(예전 이름) 아무 복사 폴더 하나"""
    d = copy_dirs()
    return next(iter(d.values()), None)


_DRV = {"t": 0.0, "v": []}


def _win_fixed_drives() -> list:
    """D: ~ Z: 중 로컬 디스크만 (끊긴 네트워크 드라이브·카드 리더기를 건드려 멈추지 않게) · 1분 묵힘"""
    if time.time() - _DRV["t"] < 60:
        return _DRV["v"]
    out = []
    try:
        import ctypes
        k = ctypes.windll.kernel32
        mask = k.GetLogicalDrives()
        for i in range(3, 26):
            if mask & (1 << i):
                L = chr(65 + i)
                t = k.GetDriveTypeW(f"{L}:\\")
                if t == 3:                                       # DRIVE_FIXED (구글 드라이브 가상 드라이브도 보통 여기)
                    out.append(L)
                elif t == 4:                                     # 네트워크 드라이브로 잡히는 경우: 이름표가 Google Drive면만
                    buf = ctypes.create_unicode_buffer(261)
                    if k.GetVolumeInformationW(f"{L}:\\", buf, 261, None, None, None, None, 0) and "google" in buf.value.lower():
                        out.append(L)
    except Exception:
        out = []
    _DRV.update(t=time.time(), v=out)
    return out


def _gd_bases() -> list:
    """구글 드라이브 「내 드라이브」 폴더들 [(폴더, 계정)]"""
    out = []
    if MAC:
        cs = Path.home() / "Library" / "CloudStorage"
        if _isdir(cs):
            for g in sorted(cs.glob("GoogleDrive-*")):
                for n in GD_NAMES:
                    if _isdir(g / n):
                        out.append((g / n, g.name.replace("GoogleDrive-", "")))
    if WIN:
        for L in _win_fixed_drives():
            for n in GD_NAMES:
                p = Path(f"{L}:\\") / n
                try:
                    if _isdir(p):
                        out.append((p, f"{L}:"))
                except OSError:
                    pass
    for n in GD_NAMES:                   # 「미러링」 방식이면 홈 폴더 바로 아래 내 드라이브
        p = Path.home() / n
        if _isdir(p) and not any(c[0] == p for c in out):
            out.append((p, ""))
    return out


def _gd_installed() -> bool:
    if MAC:
        return Path("/Applications/Google Drive.app").exists() or bool(_gd_bases())
    if WIN:
        pf = os.environ.get("ProgramFiles", r"C:\Program Files")
        return Path(pf, "Google", "Drive File Stream").exists() or bool(_gd_bases())
    return bool(_gd_bases())


def suggestions() -> list:
    """고르기 쉬운 클라우드 폴더 후보: 구글 드라이브 「내 드라이브/강의록」, iCloud Drive/강의록"""
    out = [{"kind": "gdrive", "dir": str(b / "강의록"), "label": "내 드라이브 › 강의록" + (f" ({a})" if a else "")} for b, a in _gd_bases()]
    b = _icloud_base()
    if b:
        out.append({"kind": "icloud", "dir": str(b / "강의록"), "label": "iCloud Drive › 강의록"})
    return out


def cloud_root(p: Path) -> Optional[Path]:
    """p 가 들어 있는 클라우드의 맨 위 폴더 (구글 드라이브 「내 드라이브」 · iCloud Drive · iCloud와 동기화되는 바탕 화면/문서)"""
    try:
        r = p.resolve()
    except Exception:
        return None
    g = _gd_root(r)
    if g:
        return g
    b = _icloud_base()
    if b:
        try:
            r.relative_to(b.resolve())
            return b
        except ValueError:
            pass
    for real in _mac_synced():
        try:
            r.relative_to(real)
            return real
        except ValueError:
            continue
    return None


def _overlap(a: Path, b: Path) -> bool:
    return a == b or a in b.parents or b in a.parents


def check_dir(d: str, kind: str = "") -> Optional[str]:
    """복사할 폴더 확인 (그 종류의 클라우드 폴더인지 · 정리 폴더와 겹치지 않는지). 문제가 있으면 이유"""
    if not d:
        return "복사할 폴더를 골라 주세요."
    p = Path(os.path.expanduser(d)).resolve()
    if _overlap(p, M.SAVE_ROOT.resolve()):
        return "정리 폴더와 겹치지 않는 폴더를 골라 주세요."
    cr = cloud_root(p)
    k = kind_of(p)
    if not cr or (kind and k != kind):
        return {"gdrive": "구글 드라이브(데스크톱 앱)의 「내 드라이브」 안 폴더를 골라 주세요.",
                "icloud": "iCloud Drive 안의 폴더를 골라 주세요."}.get(kind, "구글 드라이브나 iCloud Drive 안의 폴더를 골라 주세요.")
    if not _isdir(cr):
        return "클라우드 폴더가 지금 안 보여요. 구글 드라이브 앱이 켜져 있고 로그인돼 있는지 확인해 주세요."
    return None


_SYNC = {k: {"busy": False, "last": 0.0, "n": 0, "err": ""} for k in KINDS}
_SLOCK = threading.Lock()
_PEND = [False]


def sync(force: bool = False) -> dict:
    """정리 폴더의 PDF 중 새로 생기거나 바뀐 것을 켜 둔 클라우드 폴더(들)에 복사"""
    ds = copy_dirs()
    if not ds:
        return {"ok": True, "n": 0}
    if not _SLOCK.acquire(blocking=False):
        _PEND[0] = True                       # 지금 복사 중이면 끝나고 한 번 더 (새로 켠 쪽이 2분 기다리지 않게)
        return {"ok": True, "n": 0, "busy": True}
    total = 0
    try:
        root = M.SAVE_ROOT.resolve()
        if not _isdir(root):
            for k in ds:
                _SYNC[k]["err"] = "정리 폴더가 없어요."
            return {"ok": False, "msg": "정리 폴더가 없어요."}
        cbs = []
        for base, vrel in M.custom_bases():          # 저장 위치를 바꾼 과목: 클라우드에는 원래 자리 경로로 (정리 폴더 안이어도)
            try:
                b = base.resolve()
                if b != root and _isdir(b):
                    cbs.append((b, vrel))
            except OSError:
                pass
        try:
            files = [(f, f.relative_to(root)) for f in root.rglob("*.pdf")
                     if not any(b in f.parents for b, _ in cbs)]
            ferr = ""
        except OSError as e:
            files, ferr = [], f"정리 폴더를 읽지 못했어요: {str(e)[:120]}"
        for b, vrel in cbs:
            try:
                files += [(f, vrel / f.relative_to(b)) for f in b.rglob("*.pdf")]
            except OSError:
                pass
        for k, d in ds.items():
            st = _SYNC[k]
            st["busy"] = True
            sc = scope(k)
            try:
                if _overlap(d, root):              # 정리 폴더를 나중에 바꿔서 겹치게 됐으면 (복사본을 또 복사하는 것 막기)
                    st["err"] = "정리 폴더와 클라우드 폴더가 겹쳐요. 폴더를 다시 골라 주세요."
                    continue
                cr = cloud_root(d)
                if not cr or not _isdir(cr):      # 드라이브 앱이 꺼져 있거나 로그아웃 → 빈 자리에 폴더를 만들지 않음
                    st["err"] = "클라우드 폴더가 지금 안 보여요" + (" (구글 드라이브 앱이 켜져 있는지 확인)" if k == "gdrive" else "") + "."
                    continue
                n, err = 0, ferr
                now = time.time()
                for src, relp in files:
                    try:
                        if any(part.startswith(".") for part in relp.parts) or not sc[part_of(relp)]:
                            continue
                        s_ = src.stat()
                        if now - s_.st_mtime < 30:         # 지금 만드는 중일 수 있음 → 다음 차례에
                            continue
                        dst = d / relp
                        if dst.exists():
                            t = dst.stat()
                            if t.st_size == s_.st_size and t.st_mtime >= s_.st_mtime - 1:
                                continue
                        dst.parent.mkdir(parents=True, exist_ok=True)
                        tmp = dst.with_name("." + dst.name + ".part")
                        try:
                            shutil.copy2(src, tmp)
                            tmp.replace(dst)
                        except OSError:
                            try:
                                tmp.unlink(missing_ok=True)      # 실패한 임시 파일이 클라우드에 남지 않게
                            except OSError:
                                pass
                            raise
                        n += 1
                    except OSError as e:
                        err = str(e)[:200]
                st.update(last=time.time(), n=st["n"] + n, err=err)
                total += n
            finally:
                st["busy"] = False
        return {"ok": True, "n": total}
    finally:
        _SLOCK.release()
        if _PEND[0]:
            _PEND[0] = False
            threading.Thread(target=sync, daemon=True).start()


def sync_state() -> dict:
    """설정 화면용: 종류마다 켜짐·폴더·정리 폴더가 이미 그 안인지(auto)·앱 있음·후보·마지막 복사"""
    c, ds = _cfg(), copy_dirs()
    root_kind = kind_of(M.SAVE_ROOT / "x.pdf")
    sug = suggestions()
    gd = _gd_bases()
    out = {"root_cloud": root_kind}
    for k in KINDS:
        v = c.get(k) or {}
        st = _SYNC[k]
        dd = str(ds[k]) if k in ds else (v.get("dir") or "")
        nice = ""
        if dd:
            try:
                li = locate(Path(os.path.expanduser(dd)) / "x.pdf")
                if li:
                    nice = ("구글 드라이브 › " if k == "gdrive" else "") + li["path"].rsplit("/", 1)[0].replace("/", " › ")
            except Exception:
                nice = ""
        out[k] = {"on": k in ds, "dir": dd, "nice": nice or dd, "auto": root_kind == k,
                  "found": (_gd_installed() if k == "gdrive" else bool(_icloud_base())),
                  "account": ", ".join(a for _, a in gd if a and "@" in a) if k == "gdrive" else "",
                  "scope": scope(k) if k == "gdrive" else None,
                  "suggest": [x for x in sug if x["kind"] == k], "busy": st["busy"], "err": st["err"],
                  "last": time.strftime("%m/%d %H:%M", time.localtime(st["last"])) if st["last"] else ""}
    return out


def set_copy(body: dict) -> dict:
    """body: {"kind": "gdrive"|"icloud", "on"?: bool, "dir"?: str, "scope"?: {"lec"|"x"|"xold": bool} (구글 드라이브만)}"""
    k = body.get("kind")
    if k not in KINDS:
        return {"ok": False, "msg": "어느 클라우드인지 알 수 없어요."}
    with M.CFG_LOCK:
        cfg = M.read_cfg()
        c = _cfg(cfg)
        v = dict(c.get(k) or {})
        if "dir" in body:
            d = str(body.get("dir") or "").strip()
            if d:
                err = check_dir(d, k)
                if err:
                    return {"ok": False, "msg": err}
            v["dir"] = d
        if "on" in body:
            if body["on"] and not v.get("dir"):
                return {"ok": False, "msg": "복사할 폴더를 먼저 골라 주세요."}
            v["on"] = bool(body["on"])
        if "scope" in body and k == "gdrive" and isinstance(body["scope"], dict):
            sc = {kk: bool(body["scope"].get(kk, dd)) for kk, dd in scope(k).items()}
            if not any(sc.values()):
                return {"ok": False, "msg": "복사할 것을 하나 이상 골라 주세요."}
            v["scope"] = sc
        c[k] = v
        cfg["cloud_copy"] = {kk: c[kk] for kk in KINDS if kk in c}
        M.write_cfg(cfg)
    if v.get("on"):
        threading.Thread(target=sync, daemon=True).start()
    nm = KNAME[k]
    if "scope" in body and "on" not in body:
        return {"ok": True, "msg": "복사할 범위를 바꿨어요. 이미 복사한 파일은 그대로 있어요."}
    if "on" not in body:
        return {"ok": True, "msg": "폴더를 정했어요."}
    if v.get("on"):
        return {"ok": True, "msg": f"{nm}에도 복사를 켰어요. 지금 있는 강의록부터 복사하고, 새로 만든 강의록도 몇 분 안에 복사해요."}
    return {"ok": True, "msg": f"{nm} 복사를 껐어요. 이미 복사한 파일은 그대로 있어요."}


def loop():
    """앱이 켜져 있는 동안 2분마다: 새로 만든 강의록 복사"""
    time.sleep(20)                       # 앱을 켜고 조금 뒤 한 번
    while True:
        try:
            if copy_dirs():
                sync()
        except Exception:
            pass
        time.sleep(120)
