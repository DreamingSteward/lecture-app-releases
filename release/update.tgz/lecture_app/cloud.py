"""클라우드(구글 드라이브·iCloud)에 있는 강의록 찾기 · 「클라우드에도 저장」 복사.

컴퓨터가 꺼져 있을 때 휴대폰이 강의록을 클라우드에서 열 수 있게, 각 PDF가 클라우드 어디에 있는지 알려 줌.
- 구글 드라이브: 「Google Drive 데스크톱」 앱의 폴더 (맥 ~/Library/CloudStorage/GoogleDrive-…/내 드라이브,
  윈도우 G:\\내 드라이브 등). 맥은 드라이브 앱이 파일에 붙여 둔 ID(확장 속성)로 바로 열리는 링크, 그 밖엔 이름 검색 링크.
- iCloud: 맥 iCloud Drive(또는 「데스크탑 및 문서」 동기화), 윈도우 「Windows용 iCloud」의 iCloudDrive 폴더.
- 「클라우드에도 저장」: 정리 폴더의 PDF를 고른 클라우드 폴더에 같은 구조로 복사 (지우거나 옮긴 건 클라우드에서 안 지움).
"""
from __future__ import annotations

import os
import re
import shutil
import sys
import threading
import time
from pathlib import Path
from typing import Optional
from urllib.parse import quote

from . import main as M

MAC, WIN = sys.platform == "darwin", os.name == "nt"
GD_NAMES = ("My Drive", "내 드라이브")
_IDC: dict = {}          # (경로, 수정 시각) → 드라이브 ID


# ---------------------------------------------------------------- 어디에 있나
def _icloud_base() -> Optional[Path]:
    if MAC:
        b = Path.home() / "Library" / "Mobile Documents" / "com~apple~CloudDocs"
        return b if b.is_dir() else None
    if WIN:
        b = Path(os.environ.get("USERPROFILE", str(Path.home()))) / "iCloudDrive"
        return b if b.is_dir() else None
    return None


def _mac_synced() -> dict:
    """맥 「데스크탑 및 문서 폴더」 iCloud 동기화: 실제 폴더 → iCloud Drive 안의 이름"""
    b = _icloud_base()
    out = {}
    if MAC and b:
        for n in ("Desktop", "Documents"):
            if (b / n).exists():
                out[(Path.home() / n).resolve()] = n
    return out


def _gd_root(p: Path) -> Optional[Path]:
    """경로 위쪽에서 구글 드라이브 「내 드라이브」 폴더 찾기"""
    for a in [p] + list(p.parents):
        if a.name in GD_NAMES:
            par = a.parent
            if (MAC and par.name.startswith("GoogleDrive-")) or (WIN and (len(str(par)) <= 3 or par == Path.home())) \
                    or par == Path.home() or "GoogleDrive" in str(par) or "CloudStorage" in str(par):
                return a
    return None


def _mac_xattr(path: Path, name: str) -> str:
    try:
        import ctypes
        import ctypes.util
        libc = ctypes.CDLL(ctypes.util.find_library("c"), use_errno=True)
        f = libc.getxattr
        f.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_void_p, ctypes.c_size_t, ctypes.c_uint32, ctypes.c_int]
        f.restype = ctypes.c_ssize_t
        buf = ctypes.create_string_buffer(256)
        n = f(os.fsencode(str(path)), name.encode(), buf, 256, 0, 0)
        return buf.raw[:n].decode("utf-8", "replace").strip() if n > 0 else ""
    except Exception:
        return ""


def _gd_id(p: Path) -> str:
    """맥: 드라이브 앱이 붙여 둔 파일 ID (업로드가 끝나야 생김)"""
    if not MAC:
        return ""
    try:
        k = (str(p), p.stat().st_mtime)
    except OSError:
        return ""
    if k in _IDC:
        return _IDC[k]
    v = _mac_xattr(p, "com.google.drivefs.item-id#S")
    v = v if re.fullmatch(r"[\w-]{10,}", v or "") else ""
    if v and len(_IDC) < 5000:            # 아직 업로드 전(ID 없음)은 기억하지 않음 → 올라가면 바로 링크가 생김
        _IDC[k] = v
    return v


def locate(p: Path) -> Optional[dict]:
    """파일 하나가 클라우드 어디에 있는지 → {"kind": "gdrive"|"icloud", "path": 보여 줄 경로, "id": 드라이브 ID, "ipath": 아이폰 파일 앱 경로}"""
    try:
        r = p.resolve()
    except Exception:
        return None
    g = _gd_root(r)
    if g:
        rel = r.relative_to(g).as_posix()
        return {"kind": "gdrive", "path": "내 드라이브/" + rel, "id": _gd_id(r), "name": r.name}
    b = _icloud_base()
    if b:
        try:
            rel = r.relative_to(b.resolve()).as_posix()
            return {"kind": "icloud", "path": "iCloud Drive/" + rel, "ipath": rel, "name": r.name}
        except ValueError:
            pass
    for real, nm in _mac_synced().items():
        try:
            rel = r.relative_to(real).as_posix()
            return {"kind": "icloud", "path": f"iCloud Drive/{'데스크탑' if nm == 'Desktop' else '문서'}/" + rel,
                    "ipath": f"{nm}/{rel}", "name": r.name}
        except ValueError:
            continue
    return None


def for_rel(rel: str) -> Optional[dict]:
    """정리 폴더 안 PDF(rel) → 클라우드 위치 (정리 폴더가 클라우드면 그대로, 아니면 「클라우드에도 저장」 복사본)"""
    if not rel or not rel.lower().endswith(".pdf"):
        return None
    src = M.SAVE_ROOT / rel
    got = locate(src)
    if got:
        return got
    d = copy_dir()
    if d:
        dst = d / rel
        if dst.exists():
            return locate(dst)
    return None


def links(info: dict) -> dict:
    """휴대폰에서 열 주소"""
    if not info:
        return {}
    if info["kind"] == "gdrive":
        return {**info, "url": f"https://drive.google.com/file/d/{info['id']}/view" if info.get("id") else "",
                "search": "https://drive.google.com/drive/search?q=" + quote(info.get("name", ""))}
    return {**info, "ios": "shareddocuments:///private/var/mobile/Library/Mobile%20Documents/com~apple~CloudDocs/"
            + quote(info.get("ipath", "")), "web": "https://www.icloud.com/iclouddrive/"}


def state_map(rels) -> dict:
    out = {}
    for rel in rels:
        try:
            i = for_rel(rel)
        except Exception:
            i = None
        if i:
            out[rel] = links(i)
    return out


# ---------------------------------------------------------------- 「클라우드에도 저장」
def _cfg() -> dict:
    try:
        return dict(M.read_cfg().get("cloud_copy") or {})
    except Exception:
        return {}


def copy_dir() -> Optional[Path]:
    c = _cfg()
    if not c.get("on") or not c.get("dir"):
        return None
    try:
        return Path(os.path.expanduser(str(c["dir"]))).resolve()
    except Exception:
        return None


_DRV = {"t": 0.0, "v": []}


def _win_fixed_drives() -> list:
    """D: ~ Z: 중 로컬 디스크만 (끊긴 네트워크 드라이브·카드 리더기를 건드려 멈추지 않게) · 1분 묵힘"""
    if time.time() - _DRV["t"] < 60:
        return _DRV["v"]
    out = []
    try:
        import ctypes
        k = ctypes.windll.kernel32
        mask = k.GetLogicalDrives()
        for i in range(3, 26):
            if mask & (1 << i):
                L = chr(65 + i)
                if k.GetDriveTypeW(f"{L}:\\") == 3:           # DRIVE_FIXED (구글 드라이브 가상 드라이브도 여기)
                    out.append(L)
    except Exception:
        out = []
    _DRV.update(t=time.time(), v=out)
    return out


def suggestions() -> list:
    """고르기 쉬운 클라우드 폴더 후보: 구글 드라이브 「내 드라이브/강의록」, iCloud Drive/강의록"""
    out = []
    cands = []
    if MAC:
        cs = Path.home() / "Library" / "CloudStorage"
        if cs.is_dir():
            for g in sorted(cs.glob("GoogleDrive-*")):
                for n in GD_NAMES:
                    if (g / n).is_dir():
                        cands.append(("gdrive", g / n, g.name.replace("GoogleDrive-", "")))
    if WIN:
        for L in _win_fixed_drives():
            for n in GD_NAMES:
                p = Path(f"{L}:\\") / n
                try:
                    if p.is_dir():
                        cands.append(("gdrive", p, f"{L}:"))
                except OSError:
                    pass
    for n in GD_NAMES:                   # 「미러링」 방식이면 홈 폴더 바로 아래 내 드라이브
        p = Path.home() / n
        if p.is_dir() and not any(c[1] == p for c in cands):
            cands.append(("gdrive", p, ""))
    b = _icloud_base()
    if b:
        cands.append(("icloud", b, ""))
    for kind, base, acct in cands:
        out.append({"kind": kind, "dir": str(base / "강의록"), "label": ("구글 드라이브" + (f" ({acct})" if acct else "")) if kind == "gdrive" else "iCloud Drive"})
    return out


def cloud_root(p: Path) -> Optional[Path]:
    """p 가 들어 있는 클라우드의 맨 위 폴더 (구글 드라이브 「내 드라이브」 · iCloud Drive · iCloud와 동기화되는 바탕 화면/문서)"""
    try:
        r = p.resolve()
    except Exception:
        return None
    g = _gd_root(r)
    if g:
        return g
    b = _icloud_base()
    if b:
        try:
            r.relative_to(b.resolve())
            return b
        except ValueError:
            pass
    for real in _mac_synced():
        try:
            r.relative_to(real)
            return real
        except ValueError:
            continue
    return None


def _overlap(a: Path, b: Path) -> bool:
    return a == b or a in b.parents or b in a.parents


def check_dir(d: str) -> Optional[str]:
    """복사할 폴더 확인 (클라우드 폴더인지 · 정리 폴더와 겹치지 않는지). 문제가 있으면 이유"""
    if not d:
        return "복사할 폴더를 골라 주세요."
    p = Path(os.path.expanduser(d)).resolve()
    if _overlap(p, M.SAVE_ROOT.resolve()):
        return "정리 폴더와 겹치지 않는 폴더를 골라 주세요."
    cr = cloud_root(p)
    if not cr:
        return "구글 드라이브(데스크톱 앱) 폴더나 iCloud Drive 안의 폴더를 골라 주세요."
    if not cr.is_dir():
        return "클라우드 폴더가 지금 안 보여요. 구글 드라이브 앱이 켜져 있고 로그인돼 있는지 확인해 주세요."
    return None


_SYNC = {"busy": False, "last": 0.0, "n": 0, "err": ""}
_SLOCK = threading.Lock()


def sync(force: bool = False) -> dict:
    """정리 폴더의 PDF 중 새로 생기거나 바뀐 것을 클라우드 폴더에 복사"""
    d = copy_dir()
    if not d:
        return {"ok": True, "n": 0}
    if not _SLOCK.acquire(blocking=False):
        return {"ok": True, "n": 0, "busy": True}
    try:
        _SYNC["busy"] = True
        root = M.SAVE_ROOT.resolve()
        if not root.is_dir():
            return {"ok": False, "msg": "정리 폴더가 없어요."}
        if _overlap(d, root):              # 정리 폴더를 나중에 바꿔서 겹치게 됐으면 (복사본을 또 복사하는 것 막기)
            _SYNC["err"] = "정리 폴더와 클라우드 폴더가 겹쳐요. 클라우드 폴더를 다시 골라 주세요."
            return {"ok": False, "msg": _SYNC["err"]}
        cr = cloud_root(d)
        if not cr or not cr.is_dir():      # 드라이브 앱이 꺼져 있거나 로그아웃 → 빈 자리에 폴더를 만들지 않음
            _SYNC["err"] = "클라우드 폴더가 지금 안 보여요 (구글 드라이브 앱이 켜져 있는지 확인)."
            return {"ok": False, "msg": _SYNC["err"]}
        n, err = 0, ""
        now = time.time()
        try:
            files = list(root.rglob("*.pdf"))
        except OSError as e:
            files, err = [], f"정리 폴더를 읽지 못했어요: {str(e)[:120]}"
        for src in files:
            try:
                relp = src.relative_to(root)
                if any(part.startswith(".") for part in relp.parts):
                    continue
                s_ = src.stat()
                if now - s_.st_mtime < 30:         # 지금 만드는 중일 수 있음 → 다음 차례에
                    continue
                dst = d / relp
                if dst.exists():
                    t = dst.stat()
                    if t.st_size == s_.st_size and t.st_mtime >= s_.st_mtime - 1:
                        continue
                dst.parent.mkdir(parents=True, exist_ok=True)
                tmp = dst.with_name("." + dst.name + ".part")
                try:
                    shutil.copy2(src, tmp)
                    tmp.replace(dst)
                except OSError:
                    try:
                        tmp.unlink(missing_ok=True)      # 실패한 임시 파일이 클라우드에 남지 않게
                    except OSError:
                        pass
                    raise
                n += 1
            except OSError as e:
                err = str(e)[:200]
        _SYNC.update(last=time.time(), n=_SYNC["n"] + n, err=err)
        return {"ok": True, "n": n}
    finally:
        _SYNC["busy"] = False
        _SLOCK.release()


def sync_state() -> dict:
    d = copy_dir()
    return {"on": bool(d), "dir": str(d) if d else (_cfg().get("dir") or ""), "busy": _SYNC["busy"],
            "last": time.strftime("%m/%d %H:%M", time.localtime(_SYNC["last"])) if _SYNC["last"] else "",
            "err": _SYNC["err"], "suggest": suggestions(), "root_cloud": (locate(M.SAVE_ROOT / "x.pdf") or {}).get("kind", "")}


def set_copy(body: dict) -> dict:
    with M.CFG_LOCK:
        cfg = M.read_cfg()
        c = dict(cfg.get("cloud_copy") or {})
        if "dir" in body:
            d = str(body.get("dir") or "").strip()
            if d:
                err = check_dir(d)
                if err:
                    return {"ok": False, "msg": err}
            c["dir"] = d
        if "on" in body:
            if body["on"] and not c.get("dir"):
                return {"ok": False, "msg": "복사할 클라우드 폴더를 먼저 골라 주세요."}
            c["on"] = bool(body["on"])
        cfg["cloud_copy"] = c
        M.write_cfg(cfg)
    if c.get("on"):
        threading.Thread(target=sync, daemon=True).start()
    if "on" not in body:
        return {"ok": True, "msg": "폴더를 정했어요."}
    if c.get("on"):
        return {"ok": True, "msg": "켰어요. 지금 있는 강의록부터 복사하고, 새로 만든 강의록도 몇 분 안에 복사해요."}
    return {"ok": True, "msg": "껐어요. 이미 복사한 파일은 클라우드에 그대로 있어요."}


def loop():
    """앱이 켜져 있는 동안 2분마다: 새로 만든 강의록 복사"""
    time.sleep(20)                       # 앱을 켜고 조금 뒤 한 번
    while True:
        try:
            if copy_dir():
                sync()
        except Exception:
            pass
        time.sleep(120)
