"""새 자료 알림 (컴퓨터 앱 쪽) — 알림 서버 lecture-app-notify 와 이어요.

- 컴퓨터 앱에는 서버가 푸시를 보내지 않아요. 앱이 켜져 있는 동안 5분마다 GET /msg 로 확인하고,
  새 자료가 있으면 기존 notifier.py 로 운영체제 알림을 띄워요 (제목 · 본문은 서버가 만든 그대로).
- 방해 금지 시간이면(/msg 의 hold) 띄우지 않고 기다렸다가, 끝난 뒤 다음 확인 때 합쳐서 띄워요.
- 등록 정보는 설정 파일(config.json)의 "newnt" 에 저장해요: 켬 · 종류 · 방해 금지 · 무작위 기기 주소(app://…) · 등록 번호 · 읽음 시각.
  이름 · 이메일 · 학번 · 비밀번호는 저장하지도 보내지도 않아요.
- NOTIFY_URL 이 비어 있으면(아직 서버를 안 만들었으면) 모든 기능이 꺼져 있고 화면에도 안 보여요.
"""
from __future__ import annotations

import json
import secrets
import sys
import threading
import time
import urllib.error
import urllib.request

NOTIFY_URL = ""            # 알림 서버 주소 (예: https://lecture-app-notify.<계정>.workers.dev) · 비면 알림 줄을 모두 숨겨요
POLL = 5 * 60              # 앱이 켜져 있는 동안 5분마다 확인
HB_EVERY = 24 * 3600       # 살아 있음 표시는 하루 한 번
TIMEOUT = 10

_lock = threading.Lock()
_started = False


def avail() -> bool:
    return bool(NOTIFY_URL.strip())


def _M():
    from . import main as M
    return M


def _get() -> dict:
    try:
        c = _M().read_cfg().get("newnt") or {}
        return dict(c) if isinstance(c, dict) else {}
    except Exception:
        return {}


def _put(**kw) -> dict:
    M = _M()
    with M.CFG_LOCK:
        cfg = M.read_cfg()
        c = dict(cfg.get("newnt") or {})
        for k, v in kw.items():
            if v is None:
                c.pop(k, None)
            else:
                c[k] = v
        cfg["newnt"] = c
        M.write_cfg(cfg)
    return c


def _req(method: str, path: str, body: dict | None = None) -> dict:
    """알림 서버에 요청 (컴퓨터 앱 표시 X-Lecture-App: 1 · Origin 없음)"""
    url = NOTIFY_URL.rstrip("/") + path
    data = json.dumps(body or {}).encode("utf-8") if method == "POST" else None
    rq = urllib.request.Request(url, data=data, method=method,
                                headers={"X-Lecture-App": "1", "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(rq, timeout=TIMEOUT) as r:
            return json.loads(r.read().decode("utf-8") or "{}")
    except urllib.error.HTTPError as e:
        try:
            j = json.loads(e.read().decode("utf-8") or "{}")
        except Exception:
            j = {}
        j.setdefault("ok", False)
        j["status"] = e.code
        return j


def _dev() -> str:
    return "mac" if sys.platform == "darwin" else "win"


def _folder() -> str:
    try:
        return str(_M().read_cfg().get("drive_sem_id") or "")
    except Exception:
        return ""


def _quiet(q):
    """{"start": 0, "end": 7} 또는 None"""
    if not isinstance(q, dict):
        return None
    s, e = q.get("start"), q.get("end")
    if not (isinstance(s, int) and isinstance(e, int) and 0 <= s <= 23 and 0 <= e <= 23 and s != e):
        return None
    return {"start": s, "end": e}


def _kinds(ks) -> list:
    return sorted({k for k in (ks or []) if k in ("lec", "x")})


_ERR = {"우리 학년 드라이브만": "이 드라이브는 알림을 받을 수 없어요",
        "서버에 학기 폴더가 아직 안 정해졌어요": "알림 서버 준비 중이에요"}


def _msg(r: dict) -> str:
    e = str(r.get("err") or "")
    return _ERR.get(e) or ("알림 서버에 연결하지 못했어요. 인터넷 연결을 확인해 주세요." if not e else f"알림을 켜지 못했어요 ({e})")


def state(body: dict | None = None) -> dict:
    """설정 화면용 상태 (GET /api/newnt)"""
    c = _get()
    return {"ok": True, "avail": avail(), "on": bool(c.get("on")), "kinds": c.get("kinds") or ["x"],
            "quiet": _quiet(c.get("quiet")), "folder": _folder(), "err": c.get("err") or ""}


def _sub(c: dict) -> dict:
    ep = c.get("ep") or ("app://" + secrets.token_urlsafe(16))
    body = {"folder": _folder(), "kinds": _kinds(c.get("kinds")) or ["x"], "sub": {"endpoint": ep}, "dev": _dev(),
            "quiet": _quiet(c.get("quiet"))}
    if c.get("term_end"):
        body["term_end"] = c["term_end"]
    r = _req("POST", "/sub", body)
    if r.get("ok"):
        _put(ep=ep, sid=r.get("id"), folder=body["folder"], read=c.get("read") or int(time.time() * 1000), err=None)
    return r


def set_(body: dict) -> dict:
    """POST /api/newnt/set: {on, kinds?, quiet?, term_end?} — 켜기 · 끄기 · 종류 · 방해 금지 시간"""
    if not avail():
        return {"ok": False, "msg": "알림 서버가 아직 없어요."}
    with _lock:
        c = _get()
        if "kinds" in body:
            ks = _kinds(body.get("kinds"))
            if not ks:
                return {"ok": False, "msg": "강의록 · 추가자료 중 하나는 골라 주세요."}
            c["kinds"] = ks
        if "quiet" in body:
            c["quiet"] = _quiet(body.get("quiet"))
        if body.get("term_end"):
            c["term_end"] = str(body["term_end"])[:10]
        try:
            if body.get("on") is False:
                if c.get("ep"):
                    try:
                        _req("POST", "/unsub", {"endpoint": c["ep"]})
                    except Exception:
                        pass        # 서버는 30일 뒤 스스로 지워요
                _put(on=False, ep=None, sid=None, read=None, kinds=c.get("kinds"), quiet=c.get("quiet"), err=None)
                return {"ok": True, **state()}
            if body.get("on") is True:                       # 켜기 (또는 다시 등록)
                if not _folder():
                    return {"ok": False, "msg": "학년 드라이브 주소를 넣으면 켤 수 있어요."}
                _put(on=True, kinds=c.get("kinds") or ["x"], quiet=c.get("quiet"), term_end=c.get("term_end"))
                r = _sub(_get())
                if not r.get("ok"):
                    _put(on=False, err=_msg(r))
                    return {"ok": False, "msg": _msg(r)}
            else:                                            # 종류 · 방해 금지 시간만 바꾸기
                _put(kinds=c.get("kinds"), quiet=c.get("quiet"), term_end=c.get("term_end"))
                if c.get("on") and c.get("ep"):
                    r = _req("POST", "/pref", {"endpoint": c["ep"], "kinds": c.get("kinds") or ["x"], "quiet": c.get("quiet")})
                    if r.get("gone"):
                        r = _sub(_get())
                    if not r.get("ok"):
                        return {"ok": False, "msg": _msg(r)}
        except Exception:
            return {"ok": False, "msg": "알림 서버에 연결하지 못했어요. 인터넷 연결을 확인해 주세요."}
    return {"ok": True, **state()}


def status(body: dict | None = None) -> dict:
    """GET /api/newnt/status → 서버 /status ({ok, last_run, last_err?})"""
    if not avail():
        return {"ok": False}
    try:
        return _req("GET", "/status")
    except Exception:
        return {"ok": False}


def forget():
    """로그아웃 · 내 기록 삭제 · 이 PC 에서 지우기: 서버 등록도 지워요 (실패해도 이 컴퓨터 기록은 지움)"""
    c = _get()
    if c.get("ep") and avail():
        try:
            _req("POST", "/unsub", {"endpoint": c["ep"]})
        except Exception:
            pass
    try:
        M = _M()
        with M.CFG_LOCK:
            cfg = M.read_cfg()
            if "newnt" in cfg:
                cfg.pop("newnt", None)
                M.write_cfg(cfg)
    except Exception:
        pass


def _mac_text(t: str) -> str:
    """맥 알림 전용 앱은 본문을 한 줄만 읽어요 → 줄을 「 · 」로 이어요"""
    return " · ".join(x for x in str(t).split("\n") if x) if sys.platform == "darwin" else str(t)


def check_once(now: float | None = None) -> dict:
    """한 번 확인: /msg → 알림 · 읽음 시각 저장 (돌려주는 값은 시험용)"""
    now = now or time.time()
    c = _get()
    if not avail() or not c.get("on"):
        return {"skip": True}
    out = {}
    if c.get("folder") != _folder() and _folder():         # 학기 폴더(학년 드라이브 주소)가 바뀌었으면 다시 등록
        r = _sub(c)
        out["resub"] = bool(r.get("ok"))
        c = _get()
    if c.get("ep") and now - float(c.get("hb_at") or 0) > HB_EVERY:
        r = _req("POST", "/hb", {"endpoint": c["ep"]})
        if r.get("gone"):
            r = _sub(c)
            out["resub"] = bool(r.get("ok"))
            c = _get()
        _put(hb_at=int(now))
    if not c.get("sid"):
        return out
    m = _req("GET", f"/msg?id={c['sid']}&since={int(c.get('read') or 0)}")
    if m.get("gone"):
        r = _sub(c)
        return {**out, "resub": bool(r.get("ok"))}
    if not m.get("ok"):
        return {**out, "err": True}
    if m.get("n", 0) > 0 and m.get("hold"):
        return {**out, "hold": True}          # 방해 금지: 읽음 시각을 그대로 두고 끝난 뒤 합쳐서
    if m.get("n", 0) > 0:
        from . import notifier
        if notifier.allowed():                # 설정 › 알림 › 「알림 받기」를 끄면 띄우지 않아요
            notifier.notify(m.get("title") or "새 자료가 올라왔어요", _mac_text(m.get("text") or ""))
        out["shown"] = {"title": m.get("title"), "text": m.get("text")}
    if m.get("last"):
        _put(read=int(m["last"]))
    return out


def loop():
    """앱이 켜져 있는 동안 5분마다 (gui.serve 에서 따로 돌려요)"""
    global _started
    if _started or not avail():
        return
    _started = True
    time.sleep(20)
    while True:
        try:
            check_once()
        except Exception:
            pass
        time.sleep(POLL)
