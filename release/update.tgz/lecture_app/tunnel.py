"""밖에서도 열기: Cloudflare 터널로 휴대폰 데이터(LTE·5G)에서도 강의록앱 화면(다른 기기용 문 RPORT)에 들어오게 함.

- 기본은 무료 「빠른 터널」(계정·도메인 필요 없음): https://무작위.trycloudflare.com 주소가 생김.
  cloudflared 를 다시 켜면(컴퓨터 재시동) 주소가 바뀜 → 바뀌면 알림.
- 고급: 내 Cloudflare 터널 토큰 + 주소를 넣으면 고정 주소로 엶 (도메인이 있는 사람만). 토큰은 키체인/자격 증명 관리자에.
- cloudflared 는 처음 켤 때 GitHub(cloudflare/cloudflared 공식 릴리스, 버전 고정 + SHA-256 확인)에서 logs/터널/ 에 받음.
- 앱이 새 코드로 다시 켜지거나(업데이트) 잠깐 꺼져도 cloudflared 는 그대로 두고 이어받음 → 주소가 안 바뀜.
  (끄기를 누르면 같이 닫음)
- 인증은 그대로 remote.py (기기 열쇠 쿠키 · 연결 코드 / QR 열쇠).
"""
from __future__ import annotations

import hashlib
import json
import os
import platform
import re
import subprocess
import sys
import tarfile
import threading
import time
from pathlib import Path
from typing import Optional

from . import main as M

DIR = M.APP / "logs" / "터널"
BIN = DIR / ("cloudflared.exe" if os.name == "nt" else "cloudflared")
PIDF = DIR / "pid.json"
CF_VER = "2026.10.5"
REL = f"https://github.com/cloudflare/cloudflared/releases/download/{CF_VER}/"
SHA = {     # 공식 릴리스 파일의 SHA-256 (받은 파일이 다르면 쓰지 않음)
    "cloudflared-darwin-arm64.tgz": "184c7d4f5f977348243a6d7ca8f6cf6073b9b2746cfe8c1fe15aa59e9a522bf0",
    "cloudflared-darwin-amd64.tgz": "6699392fed92367808c248c2d90bed66e49bbf66e1b4ee3e4141230f3f7391b3",
    "cloudflared-windows-amd64.exe": "db4e4c413612a0916f3e1679d3caaf376f94911952d163028fb726fb2e0516a9",
    "cloudflared-windows-386.exe": "66cba8003e4f87a8e6b772f331b8c04c7d41ac4f2dc30dd2c13ae09de3b6007e",
}
URL_RE = re.compile(r"https://(?!api\.)[a-z0-9-]+\.trycloudflare\.com")
READY_RE = re.compile(r"Registered tunnel connection|Connection [0-9a-f-]+ registered")
NOWIN = 0x08000000
SECRET = "lecture-app-tunnel-token"

_ST = {"status": "off", "msg": "", "url": "", "gen": -1}
_LOCK = threading.Lock()
_BINLOCK = threading.Lock()
_GEN = [0]                      # 켜기/끄기 할 때마다 바뀜 → 예전 지킴이 스레드는 스스로 끝남
_PROC: list = [None]            # 이 프로세스가 띄운 Popen (이어받은 경우 None, pid 만)


# ---------------------------------------------------------------- 설정
def _rcfg() -> Optional[dict]:
    """설정의 remote 부분. 읽기 실패(잠깐 잠김 등)면 None — 「꺼짐」으로 보지 않음"""
    try:
        return dict(M.read_cfg().get("remote") or {})
    except Exception:
        return None


def wanted() -> bool:
    """밖에서 열기를 켜 뒀는지 (같은 와이파이 켜기와는 따로)"""
    r = _rcfg() or {}
    return bool(r.get("tunnel"))


def _token() -> str:
    try:
        from . import secrets_store
        g = secrets_store.get(SECRET)
        return g[1] if g else ""
    except Exception:
        return ""


def _mode(r: dict) -> str:
    return "named" if (r.get("tunnel_has_token") and r.get("tunnel_host")) else "quick"


def _sig(r: dict, tok: str = "") -> str:
    """지금 설정을 나타내는 값 (이어받을 cloudflared 가 같은 설정으로 떠 있는지 확인용)"""
    if _mode(r) == "named":
        return "named:" + hashlib.sha256((tok or _token()).encode()).hexdigest()[:16] + ":" + r.get("tunnel_host", "")
    return "quick"


def _host(h: str) -> str:
    h = str(h or "").strip()
    h = re.sub(r"^https?://", "", h).split("/")[0].strip().lower()
    return h if re.fullmatch(r"[a-z0-9.-]+\.[a-z]{2,}", h) else ""


def state() -> dict:
    r = _rcfg() or {}
    return {"on": bool(r.get("tunnel")), "status": _ST["status"], "msg": _ST["msg"], "url": _ST["url"],
            "mode": _mode(r), "host": r.get("tunnel_host", ""), "has_token": bool(r.get("tunnel_has_token"))}


def configure(on: Optional[bool] = None, token: Optional[str] = None, host: Optional[str] = None) -> dict:
    t = None
    if token is not None:
        t = re.sub(r"\s+", "", str(token))
        m = re.search(r"--token\s*([A-Za-z0-9_\-=]+)", str(token))    # 「cloudflared ... --token XXX」 통째로 붙여넣어도
        if m:
            t = m.group(1)
        if t and not re.fullmatch(r"[A-Za-z0-9_\-=]{40,}", t):
            return {"ok": False, "msg": "터널 토큰 모양이 아니에요. Cloudflare 터널 화면의 토큰(긴 글자)을 붙여넣어 주세요."}
    h = None
    if host is not None:
        h = _host(host)
        if host.strip() and not h:
            return {"ok": False, "msg": "주소는 lecture.example.com 처럼 적어 주세요."}
    old_tok = _token() if t is not None else None
    if t is not None:
        from . import secrets_store
        if t:
            ok, err = secrets_store.put(SECRET, "cloudflared", t)
            if not ok:
                return {"ok": False, "msg": err or "토큰을 저장하지 못했어요."}
        else:
            secrets_store.delete(SECRET)
    with M.CFG_LOCK:
        cfg = M.read_cfg()
        r = dict(cfg.get("remote") or {})
        before = (bool(r.get("tunnel")), bool(r.get("tunnel_has_token")), r.get("tunnel_host", ""))
        r.pop("tunnel_token", None)                 # 예전(파일에 저장하던) 방식 흔적 지우기
        if on is not None:
            r["tunnel"] = bool(on)
        if t is not None:
            r["tunnel_has_token"] = bool(t)
        if h is not None:
            r["tunnel_host"] = h
        cfg["remote"] = r
        M.write_cfg(cfg)
        changed = before != (bool(r.get("tunnel")), bool(r.get("tunnel_has_token")), r.get("tunnel_host", "")) \
            or (t is not None and t != old_tok)
    if changed:
        stop()
    from . import remote
    err = remote.ensure()                        # 다른 기기용 문 열기·닫기 (와이파이 꺼져 있으면 이 컴퓨터 안으로만) + 터널 켜기·끄기
    if err:
        return {"ok": False, "msg": err}
    return {"ok": True}


# ---------------------------------------------------------------- cloudflared 받기
def _mac_arm() -> bool:
    try:
        out = subprocess.run(["sysctl", "-n", "hw.optional.arm64"], capture_output=True, text=True, timeout=5).stdout
        return out.strip() == "1"          # 로제타로 돌아가는 파이썬이어도 실제 칩 기준
    except Exception:
        return platform.machine().lower() in ("arm64", "aarch64")


def _asset() -> str:
    mach = platform.machine().lower()
    if sys.platform == "darwin":
        return "cloudflared-darwin-arm64.tgz" if _mac_arm() else "cloudflared-darwin-amd64.tgz"
    if os.name == "nt":
        return "cloudflared-windows-386.exe" if mach in ("x86", "i386", "i686") else "cloudflared-windows-amd64.exe"
    return "cloudflared-linux-arm64" if mach in ("arm64", "aarch64") else "cloudflared-linux-amd64"


def _bin_ok(timeout: int = 60) -> Optional[bool]:
    """True: 실행됨 / False: 없음·망가짐 / None: 시간 초과 (윈도우 백신이 처음 검사 중일 수 있음 → 다시 받지 않음)"""
    if not BIN.is_file() or BIN.stat().st_size < 1_000_000:
        return False
    try:
        out = subprocess.run([str(BIN), "--version"], capture_output=True, text=True, timeout=timeout,
                             **({"creationflags": NOWIN} if os.name == "nt" else {}))
        return "cloudflared" in (out.stdout + out.stderr).lower()
    except subprocess.TimeoutExpired:
        return None
    except Exception:
        return False


def ensure_bin() -> Optional[str]:
    """cloudflared 가 없으면 받음. 실패하면 이유 글"""
    with _BINLOCK:
        ok = _bin_ok()
        if ok or ok is None:
            return None
        import requests
        DIR.mkdir(parents=True, exist_ok=True)
        name = _asset()
        want = SHA.get(name)
        tmp = DIR / (name + ".part")
        part = DIR / "cloudflared.new"
        try:
            h = hashlib.sha256()
            with requests.get(REL + name, timeout=60, stream=True, headers={"User-Agent": "lecture-app"}) as r:
                r.raise_for_status()
                with open(tmp, "wb") as f:
                    for ch in r.iter_content(1 << 16):
                        f.write(ch)
                        h.update(ch)
            if want and h.hexdigest() != want:
                tmp.unlink(missing_ok=True)
                return "받은 터널 프로그램이 공식 파일과 달라요 (인터넷 연결을 확인하고 잠시 뒤 다시 해요)."
            if name.endswith(".tgz"):
                with tarfile.open(tmp) as t:
                    mem = next((m for m in t.getmembers() if m.isfile() and Path(m.name).name == "cloudflared"), None)
                    if not mem:
                        return "받은 파일에 cloudflared 가 없어요."
                    with open(part, "wb") as f:
                        f.write(t.extractfile(mem).read())
                tmp.unlink(missing_ok=True)
            else:
                tmp.replace(part)
            if os.name != "nt":
                part.chmod(0o755)
            part.replace(BIN)
        except Exception as e:
            for x in (tmp, part):
                try:
                    x.unlink(missing_ok=True)
                except Exception:
                    pass
            return f"터널 프로그램(cloudflared)을 받지 못했어요: {str(e)[:120]}"
        return None if _bin_ok() is not False else "터널 프로그램(cloudflared)을 실행하지 못했어요."


# ---------------------------------------------------------------- 프로세스
def _alive(pid: int) -> bool:
    if not pid:
        return False
    if os.name == "nt":
        try:
            import ctypes
            k = ctypes.windll.kernel32
            h = k.OpenProcess(0x1000, False, int(pid))         # PROCESS_QUERY_LIMITED_INFORMATION
            if not h:
                return False
            code = ctypes.c_ulong()
            ok = k.GetExitCodeProcess(h, ctypes.byref(code))
            k.CloseHandle(h)
            return bool(ok) and code.value == 259               # STILL_ACTIVE
        except Exception:
            return False
    try:
        r = os.waitpid(pid, os.WNOHANG)                         # 내 자식이면(다시 켜진 뒤 이어받음) 끝난 것 거두기
        if r[0] == pid:
            return False
    except ChildProcessError:
        pass
    except Exception:
        pass
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _is_cf(pid: int) -> bool:
    try:
        if os.name == "nt":
            out = subprocess.run(["tasklist", "/FI", f"PID eq {int(pid)}", "/NH", "/FO", "CSV"],
                                 capture_output=True, text=True, timeout=10, creationflags=NOWIN).stdout
        else:
            out = subprocess.run(["ps", "-ww", "-p", str(int(pid)), "-o", "args="], capture_output=True, text=True, timeout=5).stdout
        return "cloudflared" in out.lower()
    except Exception:
        return False


def _kill(pid: int):
    if not pid or not _alive(pid) or not _is_cf(pid):
        return
    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/PID", str(int(pid)), "/F", "/T"], capture_output=True, timeout=15, creationflags=NOWIN)
        else:
            import signal
            os.kill(pid, signal.SIGTERM)
            for _ in range(30):
                if not _alive(pid):
                    break
                time.sleep(0.1)
            else:
                os.kill(pid, signal.SIGKILL)
    except Exception:
        pass


def _pidinfo() -> dict:
    try:
        return json.loads(PIDF.read_text("utf-8"))
    except Exception:
        return {}


def _set(status: str, msg: str = "", url: Optional[str] = None, gen: Optional[int] = None) -> bool:
    """상태 바꾸기. gen 을 주면 그 지킴이가 아직 현역일 때만 (끈 뒤에 늦게 「열림」으로 덮지 않게)"""
    with _LOCK:
        if gen is not None and gen != _GEN[0]:
            return False
        _ST["status"], _ST["msg"] = status, msg
        if url is not None:
            _ST["url"] = url
        return True


def _logf(pid_hint: str) -> Path:
    return DIR / f"cloudflared-{pid_hint}.log"


def _launch(r: dict, tok: str):
    from .remote import RPORT
    DIR.mkdir(parents=True, exist_ok=True)
    for old in DIR.glob("cloudflared-*.log"):          # 지난 기록 정리 (지금 쓰는 프로그램 것은 열려 있어 윈도우에선 안 지워짐 → 괜찮음)
        try:
            old.unlink()
        except Exception:
            pass
    env = dict(os.environ)
    if _mode(r) == "named":
        env["TUNNEL_TOKEN"] = tok                                              # 명령줄에 안 보이게
        args = [str(BIN), "tunnel", "--no-autoupdate", "run"]
    else:
        args = [str(BIN), "tunnel", "--no-autoupdate", "--url", f"http://127.0.0.1:{RPORT}"]
    log = _logf(f"{int(time.time() * 1000)}")
    lf = open(log, "wb")
    kw = {"stdout": lf, "stderr": subprocess.STDOUT, "stdin": subprocess.DEVNULL, "env": env, "cwd": str(DIR)}
    if os.name == "nt":
        kw["creationflags"] = NOWIN | 0x00000200               # 창 없이 · 새 프로세스 그룹
    else:
        kw["start_new_session"] = True                         # 앱이 새 코드로 다시 켜져도 그대로 (주소 유지)
    try:
        p = subprocess.Popen(args, **kw)
    finally:
        lf.close()
    _PROC[0] = p
    return p.pid, log


def _read(log: Path) -> str:
    try:
        with open(log, "rb") as f:
            f.seek(0, 2)
            n = f.tell()
            f.seek(max(0, n - 200_000))
            return f.read().decode("utf-8", "replace")
    except Exception:
        return ""


def _wait_ready(pid: int, log: Path, r: dict, gen: int, limit: float = 90) -> Optional[str]:
    """주소가 나올 때까지 기다림. 주소(또는 None)"""
    t0 = time.time()
    while time.time() - t0 < limit and _GEN[0] == gen:
        if not _alive(pid):
            return None
        txt = _read(log)
        if READY_RE.search(txt):
            if _mode(r) == "named":
                return "https://" + r.get("tunnel_host", "")
            m = URL_RE.search(txt)
            if m:
                return m.group(0)
        time.sleep(0.7)
    return None


def _why(log: str) -> str:
    low = log.lower()
    if "429" in low or "too many requests" in low:
        return "Cloudflare가 잠깐 막았어요(너무 자주 켬). 몇 분 뒤 저절로 다시 해요."
    if "unauthorized" in low or "invalid token" in low or "tunnel not found" in low:
        return "터널 토큰이 맞지 않아요. Cloudflare 터널 화면에서 토큰을 다시 복사해 주세요."
    if "dial tcp" in low or "no such host" in low or "network is unreachable" in low or "i/o timeout" in low:
        return "인터넷이 안 되거나 회사·학교 망에서 막혀 있어요. 와이파이를 확인해 주세요."
    return "터널을 열지 못했어요. 잠시 뒤 저절로 다시 해요."


def _notify_change():
    try:
        from . import notifier
        notifier.notify("강의록앱 · 휴대폰 주소 바뀜",
                        "밖에서 여는 주소가 바뀌었어요. 휴대폰의 예전 홈 화면 아이콘은 지우고, 설정 탭의 새 QR을 찍어 다시 추가해 주세요.")
    except Exception:
        pass


def _save_url(url: str, mode: str):
    try:
        with M.CFG_LOCK:
            cfg = M.read_cfg()
            r = dict(cfg.get("remote") or {})
            old = r.get("tunnel_url", "")
            if old == url:
                return
            r["tunnel_url"] = url
            cfg["remote"] = r
            M.write_cfg(cfg)
        if old and mode == "quick" and "trycloudflare.com" in old:
            _notify_change()
    except Exception:
        pass


def _keeper(gen: int):
    try:
        _keep(gen)
    except Exception as e:
        _set("error", f"터널 관리 중 오류: {str(e)[:100]}", "", gen)
    finally:
        with _LOCK:
            if _ST.get("gen") == gen:          # 이 지킴이가 끝났으니 다음 start() 가 새로 띄울 수 있게
                _ST["gen"] = -1


def _keep(gen: int):
    """켜 둔 동안 cloudflared 를 지킴: 꺼지면 다시 켬 (점점 천천히)"""
    back = 5

    def nap(sec):
        end = time.time() + sec
        while time.time() < end and _GEN[0] == gen:
            time.sleep(1)

    while _GEN[0] == gen:
        r = _rcfg()
        if r is None:                          # 설정을 잠깐 못 읽음 → 꺼진 걸로 보지 않고 기다림
            nap(5)
            continue
        if not r.get("tunnel"):
            _set("off", "", "", gen)
            return
        tok = _token() if _mode(r) == "named" else ""
        if _mode(r) == "named" and not tok:
            _set("error", "저장된 터널 토큰이 없어요. 고정 주소 칸에 토큰을 다시 넣어 주세요.", "", gen)
            nap(60)
            continue
        info = _pidinfo()
        pid = int(info.get("pid") or 0)
        url = None
        if pid and _alive(pid) and _is_cf(pid) and info.get("sig") == _sig(r, tok) and info.get("url"):
            url = info["url"]                                   # 앱이 다시 켜지기 전부터 떠 있던 것 이어받기
        else:
            if pid:
                _kill(pid)
            _set("starting", "준비 중… (처음엔 터널 프로그램을 받느라 1분쯤 걸려요)" if not BIN.exists() else "여는 중…", "", gen)
            err = ensure_bin()
            if _GEN[0] != gen:
                return
            if err:
                _set("error", err, "", gen)
                nap(back)
                back = min(back * 3, 600)
                continue
            with _LOCK:
                if _GEN[0] != gen:
                    return
                pid, log = _launch(r, tok)
            url = _wait_ready(pid, log, r, gen)
            if _GEN[0] != gen:
                _kill(pid)
                return
            if not url:
                msg = _why(_read(log))
                _kill(pid)
                _set("error", msg, "", gen)
                nap(back)
                back = min(back * 3, 600)
                continue
            with _LOCK:
                if _GEN[0] != gen:
                    _kill(pid)
                    return
                try:
                    PIDF.write_text(json.dumps({"pid": pid, "sig": _sig(r, tok), "url": url, "at": time.time()}), "utf-8")
                except Exception:
                    pass
        if not _set("ready", "", url, gen):
            return
        _save_url(url, _mode(r))
        back = 5
        while _GEN[0] == gen and _alive(pid):
            time.sleep(3)
        if _GEN[0] != gen:
            return
        _set("starting", "터널이 끊겨서 다시 여는 중…", "", gen)
        nap(2)


def start():
    """켜 둔 설정이면 지킴이 시작 (이미 돌고 있으면 그대로)"""
    if not wanted():
        return
    with _LOCK:
        if _ST.get("gen") == _GEN[0] and _ST["gen"] != -1:
            return                                             # 지금 지킴이가 일하는 중
        _GEN[0] += 1
        g = _GEN[0]
        _ST["gen"] = g
        _ST["status"], _ST["msg"], _ST["url"] = "starting", "여는 중…", ""
    threading.Thread(target=_keeper, args=(g,), daemon=True).start()


def restart():
    stop()
    start()


def stop(kill: bool = True):
    """끄기: 지킴이를 멈추고 cloudflared 도 닫음"""
    with _LOCK:
        _GEN[0] += 1
        _ST["gen"] = -1
        _ST["status"], _ST["msg"], _ST["url"] = "off", "", ""
    if kill:
        pid = int(_pidinfo().get("pid") or 0)
        p = _PROC[0]
        if p is not None:
            try:
                p.terminate()
                p.wait(5)
            except Exception:
                pass
        _kill(pid)
        try:
            PIDF.unlink(missing_ok=True)
        except Exception:
            pass
        _PROC[0] = None
