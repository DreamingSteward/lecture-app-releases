"""밖에서도 열기: Cloudflare 터널로 휴대폰 데이터(LTE·5G)에서도 강의록앱 화면(다른 기기용 문 RPORT)에 들어오게 함.

- 기본은 무료 「빠른 터널」(계정·도메인 필요 없음): https://무작위.trycloudflare.com 주소가 생김.
  cloudflared 를 다시 켜면(컴퓨터 재시동·앱 종료) 주소가 바뀜 → 바뀌면 알림.
- 고급: 내 Cloudflare 터널 토큰 + 주소를 넣으면 고정 주소로 엶 (도메인이 있는 사람만).
- cloudflared 는 처음 켤 때 GitHub(cloudflare/cloudflared 공식 릴리스)에서 logs/터널/ 에 받음.
- 앱이 새 코드로 다시 켜질 때(업데이트)는 cloudflared 를 그대로 두고 이어받음 → 주소가 안 바뀜.
- 인증은 그대로 remote.py (기기 열쇠 쿠키 · 연결 코드 / QR 열쇠).
"""
from __future__ import annotations

import hashlib
import json
import os
import platform
import re
import subprocess
import sys
import tarfile
import threading
import time
from pathlib import Path
from typing import Optional

from . import main as M

DIR = M.APP / "logs" / "터널"
BIN = DIR / ("cloudflared.exe" if os.name == "nt" else "cloudflared")
LOG = DIR / "cloudflared.log"
PIDF = DIR / "pid.json"
REL = "https://github.com/cloudflare/cloudflared/releases/latest/download/"
URL_RE = re.compile(r"https://[a-z0-9-]+\.trycloudflare\.com")
NOWIN = 0x08000000

_ST = {"status": "off", "msg": "", "url": "", "mode": "", "since": 0.0}
_LOCK = threading.Lock()
_GEN = [0]                      # 켜기/끄기 할 때마다 바뀜 → 예전 지킴이 스레드는 스스로 끝남
_PROC: list = [None]            # 이 프로세스가 띄운 Popen (이어받은 경우 None, pid 만)


# ---------------------------------------------------------------- 설정
def _rcfg() -> dict:
    try:
        return dict(M.read_cfg().get("remote") or {})
    except Exception:
        return {}


def wanted() -> bool:
    r = _rcfg()
    return bool(r.get("enabled")) and bool(r.get("tunnel"))


def _mode(r: dict) -> str:
    return "named" if (r.get("tunnel_token") and r.get("tunnel_host")) else "quick"


def _sig(r: dict) -> str:
    """지금 설정을 나타내는 값 (이어받을 cloudflared 가 같은 설정으로 떠 있는지 확인용)"""
    if _mode(r) == "named":
        return "named:" + hashlib.sha256(str(r.get("tunnel_token")).encode()).hexdigest()[:16]
    return "quick"


def _host(h: str) -> str:
    h = str(h or "").strip()
    h = re.sub(r"^https?://", "", h).split("/")[0].strip().lower()
    return h if re.fullmatch(r"[a-z0-9.-]+\.[a-z]{2,}", h) else ""


def state() -> dict:
    r = _rcfg()
    return {"on": bool(r.get("tunnel")), "status": _ST["status"], "msg": _ST["msg"], "url": _ST["url"],
            "mode": _mode(r), "host": r.get("tunnel_host", ""), "has_token": bool(r.get("tunnel_token"))}


def configure(on: Optional[bool] = None, token: Optional[str] = None, host: Optional[str] = None) -> dict:
    with M.CFG_LOCK:
        cfg = M.read_cfg()
        r = dict(cfg.get("remote") or {})
        before = (bool(r.get("tunnel")), r.get("tunnel_token", ""), r.get("tunnel_host", ""))
        if on is not None:
            r["tunnel"] = bool(on)
        if token is not None:
            t = re.sub(r"\s+", "", str(token))
            m = re.search(r"--token\s*([A-Za-z0-9_\-=]+)", str(token))    # 「cloudflared ... --token XXX」 통째로 붙여넣어도
            if m:
                t = m.group(1)
            if t and not re.fullmatch(r"[A-Za-z0-9_\-=]{40,}", t):
                return {"ok": False, "msg": "터널 토큰 모양이 아니에요. Cloudflare 터널 화면의 토큰(긴 글자)을 붙여넣어 주세요."}
            r["tunnel_token"] = t
        if host is not None:
            h = _host(host)
            if host.strip() and not h:
                return {"ok": False, "msg": "주소는 lecture.example.com 처럼 적어 주세요."}
            r["tunnel_host"] = h
        cfg["remote"] = r
        M.write_cfg(cfg)
        changed = before != (bool(r.get("tunnel")), r.get("tunnel_token", ""), r.get("tunnel_host", ""))
    if wanted():
        restart() if changed else start()
    else:
        stop()
    return {"ok": True}


# ---------------------------------------------------------------- cloudflared 받기
def _asset() -> str:
    mach = platform.machine().lower()
    if sys.platform == "darwin":
        return "cloudflared-darwin-arm64.tgz" if mach in ("arm64", "aarch64") else "cloudflared-darwin-amd64.tgz"
    if os.name == "nt":
        return "cloudflared-windows-386.exe" if mach in ("x86", "i386", "i686") else "cloudflared-windows-amd64.exe"
    return "cloudflared-linux-arm64" if mach in ("arm64", "aarch64") else "cloudflared-linux-amd64"


def _bin_ok() -> bool:
    if not BIN.is_file() or BIN.stat().st_size < 1_000_000:
        return False
    try:
        out = subprocess.run([str(BIN), "--version"], capture_output=True, text=True, timeout=20,
                             **({"creationflags": NOWIN} if os.name == "nt" else {}))
        return "cloudflared" in (out.stdout + out.stderr).lower()
    except Exception:
        return False


def ensure_bin() -> Optional[str]:
    """cloudflared 가 없으면 받음. 실패하면 이유 글"""
    if _bin_ok():
        return None
    import requests
    DIR.mkdir(parents=True, exist_ok=True)
    name = _asset()
    tmp = DIR / (name + ".part")
    try:
        with requests.get(REL + name, timeout=60, stream=True, headers={"User-Agent": "lecture-app"}) as r:
            r.raise_for_status()
            with open(tmp, "wb") as f:
                for ch in r.iter_content(1 << 16):
                    f.write(ch)
        if name.endswith(".tgz"):
            with tarfile.open(tmp) as t:
                mem = next((m for m in t.getmembers() if m.isfile() and Path(m.name).name == "cloudflared"), None)
                if not mem:
                    return "받은 파일에 cloudflared 가 없어요."
                src = t.extractfile(mem)
                part = DIR / "cloudflared.new"
                with open(part, "wb") as f:
                    f.write(src.read())
            tmp.unlink(missing_ok=True)
            tmp = part
        if BIN.exists():
            BIN.unlink()
        tmp.replace(BIN)
        if os.name != "nt":
            BIN.chmod(0o755)
    except Exception as e:
        try:
            tmp.unlink(missing_ok=True)
        except Exception:
            pass
        return f"터널 프로그램(cloudflared)을 받지 못했어요: {str(e)[:120]}"
    return None if _bin_ok() else "터널 프로그램(cloudflared)을 실행하지 못했어요."


# ---------------------------------------------------------------- 프로세스
def _alive(pid: int) -> bool:
    if not pid:
        return False
    if os.name == "nt":
        try:
            import ctypes
            k = ctypes.windll.kernel32
            h = k.OpenProcess(0x1000, False, int(pid))         # PROCESS_QUERY_LIMITED_INFORMATION
            if not h:
                return False
            code = ctypes.c_ulong()
            ok = k.GetExitCodeProcess(h, ctypes.byref(code))
            k.CloseHandle(h)
            return bool(ok) and code.value == 259               # STILL_ACTIVE
        except Exception:
            return False
    try:
        r = os.waitpid(pid, os.WNOHANG)                         # 내 자식이면(다시 켜진 뒤 이어받음) 끝난 것 거두기
        if r[0] == pid:
            return False
    except ChildProcessError:
        pass
    except Exception:
        pass
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _is_cf(pid: int) -> bool:
    try:
        if os.name == "nt":
            out = subprocess.run(["tasklist", "/FI", f"PID eq {int(pid)}", "/NH", "/FO", "CSV"],
                                 capture_output=True, text=True, timeout=10, creationflags=NOWIN).stdout
        else:
            out = subprocess.run(["ps", "-ww", "-p", str(int(pid)), "-o", "args="], capture_output=True, text=True, timeout=5).stdout
        return "cloudflared" in out.lower()
    except Exception:
        return False


def _kill(pid: int):
    if not pid or not _alive(pid) or not _is_cf(pid):
        return
    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/PID", str(int(pid)), "/F", "/T"], capture_output=True, timeout=15, creationflags=NOWIN)
        else:
            import signal
            os.kill(pid, signal.SIGTERM)
            for _ in range(30):
                if not _alive(pid):
                    break
                time.sleep(0.1)
            else:
                os.kill(pid, signal.SIGKILL)
    except Exception:
        pass


def _pidinfo() -> dict:
    try:
        return json.loads(PIDF.read_text("utf-8"))
    except Exception:
        return {}


def _set(status: str, msg: str = "", url: Optional[str] = None):
    _ST["status"], _ST["msg"] = status, msg
    if url is not None:
        _ST["url"] = url
    _ST["since"] = time.time()


def _launch(r: dict) -> Optional[int]:
    from .remote import RPORT
    DIR.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ)
    if _mode(r) == "named":
        env["TUNNEL_TOKEN"] = str(r.get("tunnel_token"))                       # 명령줄에 안 보이게
        args = [str(BIN), "tunnel", "--no-autoupdate", "run"]
    else:
        args = [str(BIN), "tunnel", "--no-autoupdate", "--url", f"http://127.0.0.1:{RPORT}"]
    logf = open(LOG, "wb")
    kw = {"stdout": logf, "stderr": subprocess.STDOUT, "stdin": subprocess.DEVNULL, "env": env, "cwd": str(DIR)}
    if os.name == "nt":
        kw["creationflags"] = NOWIN | 0x00000200               # 창 없이 · 새 프로세스 그룹
    else:
        kw["start_new_session"] = True                         # 앱이 새 코드로 다시 켜져도 그대로 (주소 유지)
    p = subprocess.Popen(args, **kw)
    logf.close()
    _PROC[0] = p
    return p.pid


def _read_log() -> str:
    try:
        with open(LOG, "rb") as f:
            f.seek(0, 2)
            n = f.tell()
            f.seek(max(0, n - 200_000))
            return f.read().decode("utf-8", "replace")
    except Exception:
        return ""


def _wait_ready(pid: int, r: dict, gen: int, limit: float = 90) -> Optional[str]:
    """주소가 나올 때까지 기다림. 주소(또는 None)"""
    t0 = time.time()
    while time.time() - t0 < limit and _GEN[0] == gen:
        if not _alive(pid):
            return None
        log = _read_log()
        if _mode(r) == "named":
            if re.search(r"Registered tunnel connection|Connection [0-9a-f-]+ registered", log):
                return "https://" + r.get("tunnel_host", "")
        else:
            m = URL_RE.search(log)
            if m and re.search(r"Registered tunnel connection|Connection [0-9a-f-]+ registered", log):
                return m.group(0)
        time.sleep(0.7)
    return None


def _why(log: str) -> str:
    low = log.lower()
    if "429" in low or "too many requests" in low:
        return "Cloudflare가 잠깐 막았어요(너무 자주 켬). 몇 분 뒤 저절로 다시 해요."
    if "unauthorized" in low or "invalid token" in low or "tunnel not found" in low:
        return "터널 토큰이 맞지 않아요. Cloudflare 터널 화면에서 토큰을 다시 복사해 주세요."
    if "dial tcp" in low or "no such host" in low or "network is unreachable" in low or "i/o timeout" in low:
        return "인터넷이 안 되거나 회사·학교 망에서 막혀 있어요. 와이파이를 확인해 주세요."
    return "터널을 열지 못했어요. 잠시 뒤 저절로 다시 해요."


def _notify_change(url: str):
    try:
        from . import notifier
        notifier.notify("강의록앱 · 휴대폰 주소 바뀜",
                        "밖에서 여는 주소가 바뀌었어요. 설정 탭 → 휴대폰·아이패드의 새 QR을 휴대폰으로 찍어 주세요.")
    except Exception:
        pass


def _save_url(url: str):
    try:
        with M.CFG_LOCK:
            cfg = M.read_cfg()
            r = dict(cfg.get("remote") or {})
            old = r.get("tunnel_url", "")
            if old == url:
                return
            r["tunnel_url"] = url
            cfg["remote"] = r
            M.write_cfg(cfg)
        if old and _mode(r) == "quick":
            _notify_change(url)
    except Exception:
        pass


def _keeper(gen: int):
    """켜 둔 동안 cloudflared 를 지킴: 꺼지면 다시 켬 (점점 천천히)"""
    back = 5
    while _GEN[0] == gen:
        r = _rcfg()
        if not (r.get("enabled") and r.get("tunnel")):
            return
        _set("starting", "준비 중… (처음엔 터널 프로그램을 받느라 1분쯤 걸려요)" if not BIN.exists() else "여는 중…")
        err = ensure_bin()
        if _GEN[0] != gen:
            return
        if err:
            _set("error", err, "")
            time.sleep(min(back, 600))
            back = min(back * 3, 600)
            continue
        info = _pidinfo()
        pid = int(info.get("pid") or 0)
        url = None
        if pid and _alive(pid) and _is_cf(pid) and info.get("sig") == _sig(r) and info.get("url"):
            url = info["url"]                                   # 앱이 다시 켜지기 전부터 떠 있던 것 이어받기
        else:
            if pid:
                _kill(pid)
            with _LOCK:
                if _GEN[0] != gen:
                    return
                try:
                    pid = _launch(r)
                except Exception as e:
                    _set("error", f"터널 프로그램을 켜지 못했어요: {e}", "")
                    time.sleep(min(back, 600))
                    back = min(back * 3, 600)
                    continue
            url = _wait_ready(pid, r, gen)
            if _GEN[0] != gen:
                _kill(pid)
                return
            if not url:
                msg = _why(_read_log())
                _kill(pid)
                _set("error", msg, "")
                time.sleep(min(back, 600))
                back = min(back * 3, 600)
                continue
            try:
                PIDF.write_text(json.dumps({"pid": pid, "sig": _sig(r), "url": url, "at": time.time()}), "utf-8")
            except Exception:
                pass
        _set("ready", "", url)
        _save_url(url)
        back = 5
        while _GEN[0] == gen and _alive(pid):
            time.sleep(3)
        if _GEN[0] != gen:
            return
        _set("starting", "터널이 끊겨서 다시 여는 중…", "")
        time.sleep(2)


def start():
    """켜 둔 설정이면 지킴이 시작 (이미 돌고 있으면 그대로)"""
    if not wanted():
        return
    with _LOCK:
        if _ST["status"] in ("starting", "ready") and _ST.get("gen") == _GEN[0]:
            return
        _GEN[0] += 1
        _ST["gen"] = _GEN[0]
        g = _GEN[0]
    _set("starting", "여는 중…", "")
    threading.Thread(target=_keeper, args=(g,), daemon=True).start()


def restart():
    stop()
    start()


def stop(kill: bool = True):
    """끄기. kill=False: 앱이 새 코드로 다시 켜질 때 (cloudflared 를 남겨 두고 이어받게)"""
    with _LOCK:
        _GEN[0] += 1
        _ST["gen"] = -1
    if kill:
        pid = int(_pidinfo().get("pid") or 0)
        p = _PROC[0]
        if p is not None:
            pid = pid or p.pid
            try:
                p.terminate()
                p.wait(5)
            except Exception:
                pass
        _kill(pid)
        try:
            PIDF.unlink(missing_ok=True)
        except Exception:
            pass
        _PROC[0] = None
    _set("off", "", "")
