"""강의록앱 화면: 이 맥에서만 열리는 작은 웹 화면 (현황판 + 받기 + 애매한 자료 + 예약 + 실행 기록).

`강의록앱 화면` → http://127.0.0.1:8765 를 열고 Chrome 앱 창(없으면 기본 브라우저)으로 띄운다.
창을 닫고 15분 동안 아무 요청이 없고 받는 중도 아니면 스스로 꺼진다.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import re
import signal
import subprocess
import sys
import threading
import time
import urllib.request
from datetime import date, datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Dict, List, Optional
from urllib.parse import parse_qs, urlparse

from . import main as M
from . import grades as _grades
from . import render
from .matching import Item, Memory, safe_replace
from .timetable import YEAR_KEY, courses as tt_courses, load, norm_course

PORT = 8765
HTML = Path(__file__).with_name("gui.html")
JOB_LOG = M.APP / "logs" / "화면실행.log"
IDLE_LIMIT = 15 * 60
WEEK = "월화수목금토일"

_job: Dict = {"proc": None, "started": None, "args": [], "label": ""}
_last_hit = time.time()
_lock = threading.Lock()


# ---------------------------------------------------------------- 현황
def _year_for(L) -> int:
    now = datetime.now()
    return now.year + (1 if L.month <= 2 and now.month >= 8 else 0)


def _rel(p: Path) -> str:
    try:
        return str(p.resolve().relative_to(M.SAVE_ROOT.resolve()))
    except Exception:
        return ""


def _app_version() -> str:
    try:
        return (M.APP / "VERSION").read_text("utf-8").strip()[:40]
    except Exception:
        return ""


def lectures_state() -> List[dict]:
    _xrec.clear()
    lectures = load(M.DATA / "시간표.json")
    try:
        status = json.loads(M.STATUS.read_text("utf-8")) if M.STATUS.exists() else {}
    except Exception:
        status = {}
    recs_cache: Dict[Path, Dict[str, dict]] = {}
    now = datetime.now()
    try:                                  # 설정을 바꿨으면 바로 반영 (표지·용지·글꼴이 예전 설정인 강의록 표시용)
        M.CFG.update(M.read_cfg())
        M.reload_roots()
    except Exception:
        pass
    try:
        tag = M.fmt_tag()
    except Exception:
        tag = ""
    out = []
    pend_keys = {k for e in _pending() for k in (e.get("candidates") or [])}   # 아직 골라 줘야 하는 애매한 자료의 후보 강의
    picked: Dict[str, set] = {}        # 내가 골라 준 자료: 강의 key → {"LMS", "드라이브"}
    nr_all = M.noretry_load()          # 다시 시도하지 않기로 한 강의·출처
    try:
        mem = json.loads((M.DATA / "매칭기억.json").read_text("utf-8-sig"))
        for uk, v in (mem.items() if isinstance(mem, dict) else []):
            side = {"강의실": "LMS", "게시판": "LMS", "드라이브": "드라이브"}.get(str(uk).split(":", 1)[0])
            if side and isinstance(v, str):
                for k in v.split("||"):
                    picked.setdefault(k, set()).add(side)
    except Exception:
        pass
    for L in lectures:
        y = _year_for(L)
        try:
            day = date(y, L.month, L.day)
        except ValueError:
            continue
        d, name = M.out_dir(L), M.out_name(L)
        if d not in recs_cache:
            recs_cache[d] = _safe_records(d) or {}
        rec = recs_cache[d].get(name) or {}
        f = d / name
        refs = d / (name[:-4] + "_참고자료")
        st = status.get(L.key) or {}
        exists = f.exists()
        note = rec.get("비고") or st.get("비고") or ""
        updated = False
        if exists:
            s = rec.get("상태") or "완료"
            updated = (s == "갱신" or "재업로드 반영" in note) and "직접 넣은 자료" not in note
            s = "완료"   # 드라이브 자료로 만든 것·재업로드로 갱신된 것도 '완료' (비고에 따로 적힘. LMS 확인은 계속)
        elif st.get("처리 여부"):
            s = st["처리 여부"]
            if s == "자료 없음" and "학습 기간 종료" in note:     # 예전 버전이 저장한 것도 실패로
                s = "실패"
        else:
            s = "미확인" if day <= now.date() else "예정"
        if s == "완료" and not exists:
            s = "미확인"
        parts = [x for x in (rec.get("출처") or "").split("+") if x]
        src = " + ".join(dict.fromkeys(parts)) + (f" · {len(parts)}개" if len(parts) > 1 else "")
        merged = 0
        if exists:                      # 자료 여러 개를 합친 강의록 (예전에 만든 것도 기록의 원본 파일 이름으로)
            names = [x.strip() for x in (rec.get("원본파일명") or "").split(" + ") if x.strip()]
            try:
                ref_names = {x.name for x in refs.iterdir()} if refs.is_dir() else set()
            except OSError:
                ref_names = set()
            mains = [n for n in names if M.safe(Path(n).name) not in ref_names and Path(n).name not in ref_names]
            merged = len(mains) if len(mains) > 1 else 0
            if merged and "개 합침" not in note:
                nm = [Path(n).stem if len(Path(n).stem) <= 24 else Path(n).stem[:23] + "…" for n in mains]
                note = "; ".join(x for x in (note, f"강의록 {merged}개 합침: " + " + ".join(nm)) if x)
        srcs = {k: dict(v) for k, v in _src_state(st, parts).items()}
        for v in srcs.values():          # 예전 버전이 노란 주의로 저장한 실패(학습 기간 종료·다운로드/변환 실패) → 실패(빨강)
            w = v.get("이유") or ""
            if v.get("상태") == "주의" and ("학습 기간 종료" in w or w.startswith("다운로드 실패") or "대신 만듦" in w):
                v["상태"] = "실패"
        for side, v in srcs.items():     # 다시 시도하지 않기로 한 출처
            if side in nr_all.get(L.key, {}):
                v["다시안함"] = True
                if v.get("상태") != "실패":
                    v.update({"상태": "실패", "이유": "다시 시도하지 않기로 했어요 (다음 받기부터 건너뜀)"})
        for side, v in srcs.items():     # 애매한 자료를 이미 골라 줬으면 경고를 내림 (다음 받기 때 다시 확인)
            used = exists and any(("LMS" if p_ in ("강의실", "게시판") else p_) == side for p_ in parts)
            if side in picked.get(L.key, set()) and v.get("상태") != "존재" and used:
                v.update({"상태": "존재", "이유": "애매한 자료를 이 강의로 골라 줬어요"})      # 골라 준 자료로 만들었으면 ○
            elif "애매한 자료" in (v.get("이유") or "") and L.key not in pend_keys:
                if side in picked.get(L.key, set()):
                    v.update({"상태": "", "이유": "애매한 자료를 이 강의로 골라 줬어요 · 다음 받기 때 받아요"})
                else:
                    v.update({"상태": "비존재", "이유": "애매한 자료를 다른 강의로 골라 줬어요"})
        out.append({
            "key": L.key, "course": L.course, "folder": L.course_folder, "term": L.term,
            "mmdd": L.mmdd, "date": day.isoformat(), "wd": WEEK[day.weekday()],
            "start": L.start, "hours": L.hours,
            "period": f"{L.start}" if L.hours == 1 else f"{L.start}-{L.start + L.hours - 1}",
            "title": L.title, "profs": L.profs,
            "hist": [[yy, ps] for yy, ps in L.history() if yy != YEAR_KEY],
            "status": s, "updated": updated, "note": note, "source": src,
            "file": _rel(f) if exists else "", "refs": _rel(refs) if refs.exists() else "",
            "manual": [x.name for x in M.manual_files(L)],
            "lms": st.get("LMS 업로드") or "", "drive": st.get("드라이브 업로드") or "",
            "srcs": srcs, "merged": merged,
            "extra": _extra_state(L, st),
            "xold": {lab: _extra_state(L, st, lab) for lab in _old_labels()},
            "latest": st.get("최신 강의록") or "", "checked": st.get("확인시각") or "",
            "processed": rec.get("처리일시") or "",
            "stale": bool(exists and tag and rec.get("서명") and rec["서명"].split(" || ")[0] != tag),
        })
    return out


def _src_state(st: dict, parts: List[str]) -> dict:
    """출처별 상태. 받기를 한 번 돌린 뒤엔 저장된 값, 그 전엔 만든 파일의 출처·업로드 날짜로 짐작."""
    cs = st.get("출처상태")
    if cs:
        return cs
    out = {}
    for side, has, date in (("LMS", any(x in ("강의실", "게시판") for x in parts), st.get("LMS 업로드")),
                            ("드라이브", "드라이브" in parts, st.get("드라이브 업로드"))):
        if has or date:
            out[side] = {"상태": "존재", "이유": "", "날짜": date or "", "개수": 0}
        elif st:
            out[side] = {"상태": "비존재", "이유": "", "날짜": "", "개수": 0}
        else:
            out[side] = {"상태": "", "이유": "아직 확인 안 함", "날짜": "", "개수": 0}
    return out


_xrec: Dict[Path, Dict[str, dict]] = {}


MANIFEST = {
    "name": "강의록앱", "short_name": "강의록앱", "id": "/", "start_url": "/", "scope": "/",
    "display": "standalone", "background_color": "#EEF1F0", "theme_color": "#0E6B63",
    "description": "LMS·드라이브 강의록·추가자료를 받아 정리하는 앱",
    "icons": [{"src": "/icon-192.png", "sizes": "192x192", "type": "image/png"},
              {"src": "/icon-512.png", "sizes": "512x512", "type": "image/png"},
              {"src": "/icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "maskable"}],
}
# 설치 조건용 아주 작은 서비스 워커 (아무것도 저장하지 않고 그대로 통과)
SW_JS = "self.addEventListener('install',e=>self.skipWaiting());self.addEventListener('activate',e=>self.clients.claim());" \
        "self.addEventListener('fetch',e=>{});"


def _pwa_shim() -> Optional[Path]:
    """크롬에서 '앱 설치'를 했으면 생기는 강의록앱 실행 파일 (맥: ~/Applications/Chrome Apps / Windows: 시작 메뉴 바로가기)"""
    cands = []
    if sys.platform == "darwin":
        for d in ("Chrome Apps.localized", "Chrome Apps", "Edge Apps.localized", "Edge Apps"):
            cands.append(Path.home() / "Applications" / d / "강의록앱.app")
    elif os.name == "nt":
        sm = Path(os.environ.get("APPDATA", "")) / "Microsoft" / "Windows" / "Start Menu" / "Programs"
        cands += [sm / "Chrome Apps" / "강의록앱.lnk", sm / "강의록앱 (Chrome).lnk", sm / "Edge Apps" / "강의록앱.lnk"]
    hit = next((c for c in cands if c.exists()), None)
    if hit or sys.platform != "darwin":
        return hit
    return _safari_webapp()


def _safari_webapp() -> Optional[Path]:
    """맥 사파리 '파일 → Dock에 추가'로 만든 웹 앱 (~/Applications/*.app 중 이 앱 주소를 연 것)"""
    d = Path.home() / "Applications"
    try:
        for a in d.glob("*.app"):
            for f in list((a / "Contents").glob("*.plist")) + list((a / "Contents").glob("*/*.plist"))[:20]:
                try:
                    b = f.read_bytes()
                except Exception:
                    continue
                if b"127.0.0.1:8765" in b or b"localhost:8765" in b:
                    return a
    except Exception:
        pass
    return None


def _has_chrome() -> bool:
    """주소창 없는 앱 창을 띄울 크롬 계열 브라우저가 있는지 (없으면 맥은 사파리로 열림)"""
    if sys.platform == "darwin":
        names = ("Google Chrome", "Microsoft Edge", "Chromium", "Brave Browser")
        return any((r / f"{n}.app").exists() for r in (Path("/Applications"), Path.home() / "Applications") for n in names)
    if os.name == "nt":
        return any((Path(os.environ.get(v, "")) / sub).is_file() for v in ("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA")
                   for sub in ("Google/Chrome/Application/chrome.exe", "Microsoft/Edge/Application/msedge.exe"))
    return True


def _app_updated() -> str:
    """앱 파일이 마지막으로 바뀐 날짜·시각 (하단 '최종 수정' 표시용)"""
    try:
        t = max(f.stat().st_mtime for f in Path(__file__).parent.glob("*.*") if f.suffix in (".py", ".html"))
        return datetime.fromtimestamp(t).strftime("%Y-%m-%d %H:%M")
    except Exception:
        return ""


def _old_labels() -> List[str]:
    return [str(s["label"]).strip() for s in M.old_sources()]


def _safe_records(d):
    """화면 표시용: 기록을 못 읽으면(iCloud 동기화 중 등) 빈 것으로 보여 주고 화면은 계속 (다음 새로고침 때 다시 읽음)"""
    try:
        return M.read_records(d, tries=2)
    except Exception:
        return None


def _extra_state(L, st: dict, label: str = "") -> dict:
    """필야(추가자료) 상태: 파일이 있으면 기록의 상태(완료/검수 전), 없으면 지난 받기 결과"""
    d, name = M.extra_dir(L), M.extra_name(L, label)
    recs = _xrec.get(d)
    if recs is None:
        recs = _safe_records(d)
        if recs is not None:
            _xrec[d] = recs
        else:
            recs = {}
    rec = recs.get(name) or {}
    x = dict((st.get("선배필야") or {}).get(label) or {}) if label else dict(st.get("필야") or {})
    f = d / name
    if f.exists():
        x["상태"] = rec.get("상태") or x.get("상태") or "완료"
        x["file"] = _rel(f)
        x["비고"] = rec.get("비고") or ""
        x["처리"] = rec.get("처리일시") or ""
        # 이 필야를 만든 자료 (애매한 자료의 '고치기'로 다른 강의로 옮길 수 있게)
        x["mkeys"] = [":".join(k.split(":")[:2]) for k in M._sig_items(rec.get("서명") or "")
                      if k.count(":") >= 2 and k.split(":")[0] and k.split(":")[1]]
    return x


def _pending() -> list:
    try:
        return json.loads(M.PENDING.read_text("utf-8")) if M.PENDING.exists() else []
    except Exception:
        return []


def _pend_courses(L) -> dict:
    """과목별 애매한 자료(확인 필요) 수: {과목: {"lec": n, "x": n, "xt": {차수: n}}} (필야는 후보 강의의 차수별로도)"""
    from .matching import same_course
    names = tt_courses(L)
    term = {x.key: x.term for x in L}
    out: dict = {}
    for e in _pending():
        c = str(e.get("course") or "").split("|")[0].strip()
        n = next((x for x in names if same_course(x, c) or M.norm_course(x) == M.norm_course(c)), None)
        if not n:
            continue
        o = out.setdefault(n, {"lec": 0, "x": 0, "xt": {}})
        if str(e.get("source", "")).startswith("필야"):
            o["x"] += 1
            ts = {term.get(k) for k in e.get("candidates") or [] if term.get(k)}
            if len(ts) == 1:
                t = str(ts.pop())
                o["xt"][t] = o["xt"].get(t, 0) + 1
        else:
            o["lec"] += 1
    return out


def schedule_state() -> List[dict]:
    cfg = M.read_cfg()
    on = M.schedule_on()
    out = []
    for t in (M._sched_times(cfg) if on else []):
        m = re.match(r"(\d{1,2}):(\d{2})\s*(오늘|전체)?\s*(둘다|강의록|필야)?\s*(?:학번\s*([\d,]+))?", t)
        if m:
            out.append({"time": f"{int(m.group(1)):02d}:{m.group(2)}", "mode": m.group(3) or "전체", "target": m.group(4) or "둘다",
                        "years": re.findall(r"\d+", m.group(5) or "")})
    return out


# ---------------------------------------------------------------- 실행 상태
def _external_info() -> Optional[dict]:
    """화면 밖에서(예약 실행·앱을 다시 열기 전에 시작한 받기) 돌고 있는 받기 정보"""
    info = M.run_lock()
    mine = _job["proc"].pid if _job["proc"] and _job["proc"].poll() is None else None
    if info and int(info.get("pid") or 0) not in (mine, os.getpid()):
        return info
    return None


def _external_running() -> bool:
    return _external_info() is not None


def _live_file() -> Optional[Path]:
    d = M.SAVE_ROOT / "_실행기록"
    files = sorted(d.glob("*_진행중.txt"), key=lambda p: p.stat().st_mtime, reverse=True) if d.exists() else []
    return files[0] if files else None


def job_state() -> dict:
    p = _job["proc"]
    running = bool(p and p.poll() is None)
    xi = None if running else _external_info()
    ext = xi is not None
    prog = {}
    if running and JOB_LOG.exists():
        try:
            tail = JOB_LOG.read_text("utf-8", errors="replace")[-20000:]
            ms = re.findall(r"\((\d+)/(\d+)\)\s+(.+)", tail)
            if ms:
                i, n, cur = ms[-1]
                rnd = len(re.findall(r"미룬 강의 \d+개", tail))
                prog = {"i": int(i), "n": int(n), "cur": cur.strip(), "round": rnd}
        except Exception:
            pass
    return {"running": running, "external": ext, "external_auto": bool(xi and xi.get("auto")), "started": _job["started"], "label": _job["label"],
            "exit": (p.returncode if p and not running else None), "progress": prog}


def start_job(body: dict) -> dict:
    with _lock:
        if _job["proc"] and _job["proc"].poll() is None:
            return {"ok": False, "msg": "이미 받는 중이에요."}
        if _external_running():
            return {"ok": False, "msg": "예약 실행이 지금 받는 중이에요. 끝난 뒤에 다시 눌러 주세요."}
        try:
            from . import updater
            if updater._locked():
                return {"ok": False, "msg": "앱을 업데이트하는 중이에요. 끝나면 앱이 다시 켜져요. 그 뒤에 눌러 주세요."}
        except Exception:
            pass
        args = ["받기"]
        label = []
        cl = body.get("courses") or []
        cs = [str(c).strip() for c in (cl if isinstance(cl, list) else []) if str(c).strip() and not str(c).strip().startswith("-")][:50]
        if cs:
            args += ["--과목", *cs]
            label.append(", ".join(cs))
        else:
            label.append("전체 과목")
        mode = body.get("mode") or "all"
        kl = body.get("keys") or []
        keys = [str(k) for k in (kl if isinstance(kl, list) else []) if str(k).strip() and not str(k).startswith("-")][:400]
        if mode == "keys":
            if not keys:
                return {"ok": False, "msg": "다시 만들 강의를 골라 주세요."}
            args += ["--강의", *keys]
            label.append(f"고른 강의 {len(keys)}개")
        elif mode == "today":
            args.append("--오늘")
            label.append("오늘 강의")
        elif mode == "dates":
            ds = [d for d in re.split(r"[\s,]+", str(body.get("dates") or "")) if re.fullmatch(r"\d{1,2}/?\d{1,2}", d)]
            if not ds:
                return {"ok": False, "msg": "날짜를 적어 주세요 (예: 1024 10/27)."}
            args += ["--날짜", *ds]
            label.append("날짜 " + " ".join(ds))
        elif mode == "term":
            t = str(body.get("term") or "").strip()
            if not t.isdigit():
                return {"ok": False, "msg": "차수를 골라 주세요."}
            args += ["--차수", t]
            label.append(f"{t}차")
        else:
            label.append("전체 강의")
        if body.get("force"):
            args.append("--처음부터")
            label.append("다시 만들기" if mode == "keys" else "처음부터")
        elif body.get("remake"):
            args.append("--새표지")
            label.append("새 설정으로 다시 만들기")
        tgt = body.get("target") or "둘다"
        if tgt in ("강의록", "필야"):
            args += ["--대상", tgt]
            label.append(("추가자료" if tgt == "필야" else tgt) + "만")
        if body.get("src") == "드라이브" and tgt != "필야":
            args += ["--출처", "드라이브"]
            label.append("강의록은 드라이브만")
        ys = [re.sub(r"[^\w]", "", str(y)) for y in body.get("years") or [] if str(y).strip()]
        if ys and tgt != "강의록":
            args += ["--학번", *ys]
            label.append("추가자료 " + "·".join(ys))
        JOB_LOG.parent.mkdir(parents=True, exist_ok=True)
        try:        # 지난 받기의 진행 기록을 먼저 비움 → 새 받기가 시작되기 전 화면이 지난 결과(「끝났어요」·100%)를 잠깐 보여 주지 않게
            M.Events.PATH.write_text("", "utf-8")
        except Exception:
            pass
        f = open(JOB_LOG, "w", encoding="utf-8")
        env = dict(os.environ, PYTHONUNBUFFERED="1", PYTHONIOENCODING="utf-8")
        grp = {"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP} if os.name == "nt" else {"start_new_session": True}
        _job["proc"] = subprocess.Popen([sys.executable, "-u", "-m", "lecture_app", *args], cwd=str(M.APP),
                                        stdout=f, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
                                        env=env, **grp)
        _job["started"] = f"{datetime.now():%H:%M}"
        _job["args"] = args
        _job["label"] = " · ".join(label)
        return {"ok": True}


def _kill_tree(pid: int):
    if os.name == "nt":
        subprocess.run(["taskkill", "/T", "/F", "/PID", str(pid)], capture_output=True)
        return
    try:
        os.killpg(os.getpgid(pid), signal.SIGTERM)
    except Exception:
        try:
            os.kill(pid, signal.SIGTERM)
        except Exception:
            pass


def stop_job() -> dict:
    p = _job["proc"]
    if not p or p.poll() is not None:
        xi = _external_info()
        if xi:                       # 앱을 다시 열기 전에 시작했거나 예약으로 시작한 받기도 멈출 수 있게
            _kill_tree(int(xi["pid"]))
            for _ in range(50):
                if not M.pid_alive(int(xi["pid"])):
                    break
                time.sleep(0.1)
            try:
                M.RUN_LOCK.unlink()
            except Exception:
                pass
            return {"ok": True}
        return {"ok": False, "msg": "받는 중이 아니에요."}
    if os.name == "nt":
        _kill_tree(p.pid)            # 브라우저·LibreOffice 같은 하위 프로그램까지
    else:
        try:
            os.killpg(p.pid, signal.SIGTERM)
        except Exception:
            p.terminate()
    for _ in range(50):
        if p.poll() is not None:
            break
        time.sleep(0.1)
    if p.poll() is None:
        try:
            os.killpg(p.pid, signal.SIGKILL)
        except Exception:
            p.kill()
    try:                         # 강제로 끄면 받기 쪽 정리(잠금 파일 지우기)가 안 돌아서 여기서 지움
        if int(json.loads(M.RUN_LOCK.read_text("utf-8")).get("pid") or 0) == p.pid:
            M.RUN_LOCK.unlink()
    except Exception:
        pass
    try:
        with open(JOB_LOG, "a", encoding="utf-8") as f:
            f.write("\n■ 화면에서 중지했어요. 받다 만 강의는 다음 실행 때 이어서 받아요.\n")
    except Exception:
        pass
    return {"ok": True}


def read_log(offset: int) -> dict:
    """화면에서 시작한 실행이면 그 출력, 아니면 예약 실행의 진행 기록"""
    p = _job["proc"]
    src = None
    if p is not None and JOB_LOG.exists():
        src = JOB_LOG
    elif _external_running():
        src = _live_file()
    if not src or not src.exists():
        return {"text": "", "offset": 0, "source": ""}
    data = src.read_bytes()
    if offset > len(data):
        offset = 0
    chunk = data[offset:offset + 200000].decode("utf-8", errors="replace")
    return {"text": chunk, "offset": offset + len(chunk.encode("utf-8")), "source": src.name}


def read_events(offset: int) -> dict:
    """받기 진행 기록(진행.jsonl): offset 이후 새 줄만"""
    f = M.Events.PATH
    if not f.exists():
        return {"text": "", "offset": 0, "reset": offset > 0}
    data = f.read_bytes()
    reset = offset > len(data)
    if reset:
        offset = 0
    chunk = data[offset:]
    cut = chunk.rfind(b"\n") + 1          # 쓰는 중인 마지막 줄은 다음에
    return {"text": chunk[:cut].decode("utf-8", errors="replace"), "offset": offset + cut, "reset": reset}


def progress_state() -> dict:
    """메뉴 막대용 짧은 현황: 받는 중/대기 중 + 진행 막대(전체·강의록·필야 학번별) + 마지막 결과"""
    js = job_state()
    running = bool(js["running"] or js["external"])
    plan, skipped, res = None, 0, set()
    xplan, xres, oplan, ores = None, set(), {}, {}
    end, target, started, phase = None, "둘다", "", ""
    f = M.Events.PATH
    try:
        lines = f.read_text("utf-8", errors="replace").splitlines() if f.exists() else []
    except OSError:
        lines = []
    for ln in lines:
        try:
            e = json.loads(ln)
        except ValueError:
            continue
        t = e.get("type")
        if t == "start":
            plan, skipped, res, xplan, xres, oplan, ores, end = None, 0, set(), None, set(), {}, {}, None
            target, started, phase = e.get("target") or "둘다", e.get("t") or e.get("time") or "", ""
        elif t == "plan":
            plan = set(e.get("keys") or [])
        elif t == "skip":
            skipped = int(e.get("n") or 0)
        elif t == "done" and not e.get("quiet"):
            res.add(e.get("key"))
        elif t == "xplan":
            if e.get("lab"):
                oplan[str(e["lab"])] = set(e.get("keys") or [])
            else:
                xplan = set(e.get("keys") or [])
        elif t == "xdone":
            if e.get("lab"):
                ores.setdefault(str(e["lab"]), set()).add(e.get("key"))
            else:
                xres.add(e.get("key"))
        elif t == "phase":
            phase = e.get("text") or ""
        elif t == "end":
            end = e
    lab0 = str(M.CFG.get("extras_label") or "").strip() or "올해"
    rows = []
    fin = end is not None or not running
    def row(name, d, n):
        return {"name": name, "done": min(d, n), "total": n, "pct": 100 if (fin or not n) else min(100, round(d * 100 / n))}
    if target != "필야" and plan is not None:
        rows.append(row("강의록", len(res), max(0, len(plan) - skipped)))
    if target != "강의록":
        if xplan is not None:
            rows.append(row(f"추가자료 {lab0}", len(xres), len(xplan)))
        for y in sorted(oplan, reverse=True):
            rows.append(row(f"추가자료 {y}", len(ores.get(y, set())), len(oplan[y])))
    d = sum(r["done"] for r in rows)
    n = sum(r["total"] for r in rows)
    allr = row("전체", d, n)
    summ = (end or {}).get("summary") or {}
    last = ""
    if end and not end.get("error"):
        last = f"새로 {summ.get('new', 0)} · 갱신 {summ.get('updated', 0)} · 실패 {summ.get('fail', 0)} · 추가자료 {summ.get('extras', 0)}"
    elif end and end.get("error"):
        last = "오류로 멈췄어요"
    return {"running": running, "status": "받는 중…" if running else ("오류" if end and end.get("error") else "대기 중"),
            "label": js.get("label") or "", "started": js.get("started") or started, "phase": phase if running else "",
            "all": allr, "rows": rows, "last": last, "pending": len(_pending())}


# ---------------------------------------------------------------- 시간표
def profs_state() -> dict:
    """강좌별 교수 (연도 비교) 표: 시간표.json 그대로 + 행마다 이 앱의 강의 key (애매한 자료 고를 때 씀)"""
    from .timetable import _parse_dates, _parse_period, YEAR_KEY, SKIP_TITLE
    data = json.loads((M.DATA / "시간표.json").read_text("utf-8-sig"))
    lectures = load(M.DATA / "시간표.json")
    idx = {}
    for L in lectures:
        for t in L.titles:
            idx.setdefault((L.course, L.mmdd, L.start, t.strip()), L.key)
    out = []
    for c in data:
        rows = []
        for r in c.get("rows") or []:
            t = (r.get("t") or "").strip()
            keys = []
            if t and not SKIP_TITLE.search(t):
                gparts = (r.get("g") or "").split("·")
                for i, dd in enumerate(_parse_dates(r.get("d", ""))):
                    g = gparts[i] if i < len(gparts) else (gparts[-1] if gparts else "")
                    pp = _parse_period(g)
                    k = idx.get((c["name"], dd, pp[0], t)) if pp else None
                    if k and k not in keys:
                        keys.append(k)
            rows.append({"t": t, "d": r.get("d", ""), "g": r.get("g", ""), "y": r.get("y") or {},
                         "term": r.get("term") or 0, "tm": r.get("tm") or {}, "keys": keys})
        if any(r["keys"] for r in rows):            # 올해 수업이 있는 과목만
            out.append({"name": c["name"], "years": [str(y) for y in c.get("years") or []] or [YEAR_KEY], "rows": rows})
    lab = str(M.CFG.get("extras_label") or "").strip()
    return {"courses": out, "year": YEAR_KEY, "label": lab if lab.isdigit() else ""}


def _tt_write(new_data, backup=True) -> Optional[str]:
    from . import tt_edit as T
    path = M.DATA / "시간표.json"
    bk = T.backup(path) if backup else None
    tmp = path.with_name("시간표.gui.tmp")
    tmp.write_text(json.dumps(new_data, ensure_ascii=False, indent=1), "utf-8")
    safe_replace(tmp, path)
    return bk.name if bk else None


def tt_past_preview(body: dict) -> dict:
    """지난 연도 시간표(AI 결과) → 역대 교수 칸에 무엇이 바뀌는지"""
    from . import tt_edit as T
    data = json.loads((M.DATA / "시간표.json").read_text("utf-8-sig"))
    try:
        year, changes, warn = T.plan_past(data, body.get("data"), body.get("year"))
    except json.JSONDecodeError:
        return {"ok": False, "msg": "붙여넣은 내용이 형식에 맞지 않아요. AI가 준 JSON을 그대로 붙여넣어 주세요."}
    except ValueError as e:
        return {"ok": False, "msg": str(e)}
    return {"ok": True, "year": year, "changes": changes, "warn": warn}


def tt_past_apply(body: dict) -> dict:
    from . import tt_edit as T
    data = json.loads((M.DATA / "시간표.json").read_text("utf-8-sig"))
    try:
        year, changes, warn = T.plan_past(data, body.get("data"), body.get("year"))
    except (json.JSONDecodeError, ValueError) as e:
        return {"ok": False, "msg": str(e) if isinstance(e, ValueError) else "형식이 맞지 않아요."}
    acc = body.get("accept")
    n = len(changes) if acc is None else len(set(acc) & {c["id"] for c in changes})
    if not n:
        return {"ok": True, "msg": "바뀐 게 없어요."}
    _tt_write(T.apply_past(data, year, changes, acc))
    return {"ok": True, "msg": f"{year}년 담당 교수 {n}건을 넣었어요. 표지의 「역대 담당 교수」는 강의록을 다시 만들 때 반영돼요."}


def profs_set(body: dict) -> dict:
    """강좌별 교수 표에서 지난 연도 칸 하나 고치기"""
    from . import tt_edit as T
    year = str(body.get("year") or "")
    if not re.fullmatch(r"20\d\d", year):
        return {"ok": False, "msg": "연도를 확인해 주세요."}
    if year >= T.YEAR_KEY:
        return {"ok": False, "msg": "올해 교수님은 시간표 탭에서 고쳐 주세요 (강의록 이름·표지와 같이 바뀌어서요)."}
    data = json.loads((M.DATA / "시간표.json").read_text("utf-8-sig"))
    try:
        ri = int(body.get("ri"))
        c = next(c for c in data if c["name"] == body.get("course"))
        if not (0 <= ri < len(c.get("rows") or [])) or (c["rows"][ri].get("t") or "").strip() != str(body.get("t") or "").strip():
            return {"ok": False, "msg": "시간표가 바뀌었어요. 새로고침해 주세요."}
    except (StopIteration, TypeError, ValueError):
        return {"ok": False, "msg": "시간표가 바뀌었어요. 새로고침해 주세요."}
    _tt_write(T.set_prof(data, c["name"], ri, year, str(body.get("value") or "")[:100]), backup=False)
    return {"ok": True}


def tt_state() -> dict:
    from . import tt_edit as T
    data = json.loads((M.DATA / "시간표.json").read_text("utf-8"))
    items = T.expand(data)
    for x in items:
        x["wd"] = T.wd(x["mmdd"])
        x.pop("row", None)
    return {"courses": [c["name"] for c in data], "items": items, "prompt": T.PROMPT, "prompt_past": T.PROMPT_PAST,
            "year": T.YEAR_KEY}


def _tt_plan(body: dict):
    """AI 결과(올해 + 지난 연도 함께) → 올해 시간표 변경 + 지난 연도 역대 교수 변경"""
    from . import tt_edit as T
    data = json.loads((M.DATA / "시간표.json").read_text("utf-8-sig"))
    cur = T.expand(data)
    names = [c["name"] for c in data]
    raw = body.get("data")
    if isinstance(raw, str):
        txt = raw.strip()
        mm = re.search(r"\{.*\}|\[.*\]", txt, re.S)
        raw = json.loads(mm.group(0) if mm else txt)
    cur_items, past_items, future = T.split_years(raw)
    new, warn = T.normalize(cur_items, cur, names) if cur_items else ([], [])
    if future:
        warn.append(f"{', '.join(future)}년은 올해({T.YEAR_KEY})보다 뒤라서 뺐어요")
    mode = body.get("mode") or "partial"
    changes = T.diff(cur, new, mode, body.get("courses")) if (new or mode == "all") and (cur_items or mode != "all") else []
    return T, data, cur, new, warn, changes, past_items


def _past_plan(T, data, past_items, keys=None):
    """지난 연도들 → ([변경(연도·key 포함)], [경고], 적용한 데이터).
    최근 해부터 차례로 맞추고 적용해 가며 봄 (여러 해에 같은 '올해 없는 강의'가 있어도 비교용 줄은 하나만)"""
    out, warn = [], []
    for y in sorted(past_items, reverse=True):
        try:
            _y, ch, w = T.plan_past(data, past_items[y], y)
        except ValueError as e:
            warn.append(str(e))
            continue
        out += [{**c, "year": y} for c in ch]
        warn += [f"{y}년: {x}" for x in w]
        acc = [c["id"] for c in ch] if keys is None else [c["id"] for c in ch if c["key"] in keys]
        if acc:
            data = T.apply_past(data, y, ch, acc)
    return out, warn, data


def tt_preview(body: dict) -> dict:
    try:
        T, data, cur, new, warn, changes, past_items = _tt_plan(body)
    except json.JSONDecodeError:
        return {"ok": False, "msg": "붙여넣은 내용이 형식에 맞지 않아요. AI가 준 JSON을 그대로 붙여넣어 주세요."}
    if not new and not past_items:
        return {"ok": False, "msg": "시간표에서 수업을 하나도 읽지 못했어요. AI 결과를 다시 확인해 주세요."}
    # 지난 연도는 올해 변경을 모두 적용했다고 치고 그 위에 맞춰 봄 (새 과목·새 강의도 짝을 찾게)
    sim = T.collapse(T.apply_changes(cur, changes), data) if changes else data
    past, pwarn, _d = _past_plan(T, sim, past_items)
    for c in changes:
        for side in ("before", "after"):
            if c[side]:
                c[side] = {**c[side], "wd": T.wd(c[side]["mmdd"])}
                c[side].pop("row", None)
    return {"ok": True, "changes": changes, "warn": warn + pwarn, "count": len(new), "year": T.YEAR_KEY,
            "days": sorted({x["mmdd"] for x in new}), "past": past, "past_years": sorted(past_items, reverse=True)}


def tt_apply(body: dict) -> dict:
    if (_job["proc"] and _job["proc"].poll() is None) or _external_running():
        return {"ok": False, "msg": "받기가 진행 중이에요. 끝난 뒤에 적용해 주세요."}
    try:
        T, data, cur, new, warn, changes, past_items = _tt_plan(body)
    except json.JSONDecodeError:
        return {"ok": False, "msg": "붙여넣은 내용이 형식에 맞지 않아요."}
    msgs, moved, bk = [], [], None
    acc = body.get("accept")
    n = len(changes) if acc is None else len(set(acc) & {c["id"] for c in changes})
    path = M.DATA / "시간표.json"
    if n:
        final = T.apply_changes(cur, changes, acc)
        old_lectures = load(path)
        bk = T.backup(path)
        new_data = T.collapse(final, data)
        tmp = path.with_name("시간표.gui.tmp")
        tmp.write_text(json.dumps(new_data, ensure_ascii=False, indent=1), "utf-8")
        safe_replace(tmp, path)
        new_lectures = load(path)
        res = T.tidy_outputs(M.DATA, old_lectures, new_lectures, M.out_dir, M.out_name, M.read_records, M.write_records)
        moved = res["moved"]
        mroot = M.DATA / "직접넣은자료"          # 내가 직접 넣은 자료 폴더도 새 강의 key로 옮김
        for ok_, nk_ in (res.get("remap") or {}).items():
            src_, dst_ = mroot / M.safe(ok_), mroot / M.safe(nk_)
            try:
                if ok_ != nk_ and src_.is_dir():
                    if not dst_.exists():
                        shutil.move(str(src_), str(dst_))
                    else:
                        for f_ in src_.iterdir():
                            if not (dst_ / f_.name).exists():
                                shutil.move(str(f_), str(dst_ / f_.name))
            except OSError:
                pass
        msgs.append(f"올해 시간표에 {n}건 적용했어요.")
        try:                     # 내 시간표로 바뀌었으니 배포판 시간표 이름은 지움
            cfg = _read_cfg()
            if cfg.pop("tt_label", None) is not None:
                _write_cfg(cfg)
        except Exception:
            pass
    if past_items:
        data2 = json.loads(path.read_text("utf-8-sig"))
        keys = body.get("accept_past")
        past, _w, data2 = _past_plan(T, data2, past_items, None if keys is None else set(keys))
        pick = past if keys is None else [c for c in past if c["key"] in set(keys)]
        if pick:
            if bk is None:
                bk = T.backup(path)
            _tt_write(data2, backup=False)
            ys = sorted({c["year"] for c in pick}, reverse=True)
            msgs.append(f"지난 연도({', '.join(ys)}) 담당 교수 {len(pick)}건을 넣었어요.")
    if not msgs:
        return {"ok": True, "msg": "바뀐 게 없어요."}
    msg = " ".join(msgs)
    if moved:
        msg += f" 이미 만든 강의록 {len(moved)}개는 _이전버전 으로 옮겼고, 다음 받기 때 새 시간표대로 다시 만들어요."
    return {"ok": True, "msg": msg, "backup": bk.name if bk else None, "moved": moved}


# ---------------------------------------------------------------- 애매한 자료
def pending_state() -> List[dict]:
    from .matching import same_course
    lectures = {L.key: L for L in load(M.DATA / "시간표.json")}
    sem = lambda L: ((int(L.mmdd[:2]) + (12 if int(L.mmdd[:2]) <= 2 else 0)) * 100 + int(L.mmdd[2:]), L.start)
    lab = lambda L: {"key": L.key, "label": _lec_label(L)}
    out = []
    for e in _pending():
        cands = [lectures[k] for k in e.get("candidates", []) if k in lectures]
        course_all = sorted([L for L in lectures.values() if same_course(L.course, e.get("course", ""))], key=sem)
        if not cands:
            cands = course_all
        tt_course = (course_all[0].course if course_all else (cands[0].course if cands else e.get("course", "").split("|")[0].strip()))
        out.append({**e, "course_name": e.get("course", "").split("|")[0].strip(), "course_tt": tt_course,
                    "has_file": bool(e.get("file")) and Path(e.get("file")).exists(),
                    "options": [lab(L) for L in cands[:20]],
                    "all": [lab(L) for L in course_all]})     # 후보에 없으면 과목 전체에서 고르기
    return out


def pending_open(body: dict) -> dict:
    """애매한 자료 미리 받아 둔 파일 열기 (앱 폴더의 .cache 안에 있는 것만)"""
    e = next((x for x in _pending() if x.get("uid") == body.get("uid") and x.get("source") == body.get("source")), None)
    f = Path(e.get("file") or "") if e else None
    cache = (M.APP / ".cache").resolve()
    if not f or not f.exists() or cache not in f.resolve().parents:
        return {"ok": False, "msg": "미리 받아 둔 파일이 없어요. 받기를 한 번 돌리면 받아 둬요."}
    return _open_copy(f, e.get("filename") or f.name)


def _open_copy(f: Path, fname: str) -> dict:
    cache = (M.APP / ".cache").resolve()
    if cache not in f.resolve().parents:
        return {"ok": False, "msg": "열 수 없는 위치예요."}
    # 원래 파일 이름으로 열리게 임시 사본 (미리보기 창 제목이 알아보기 쉽게)
    if Path(fname).suffix.lower() not in (".pdf", ".ppt", ".pptx", ".doc", ".docx", ".hwp", ".hwpx", ".key", ".odp",
                                          ".xls", ".xlsx", ".txt", ".png", ".jpg", ".jpeg", ".zip"):
        return {"ok": False, "msg": "문서 파일만 열 수 있어요 (실행 파일은 열지 않아요)."}
    import tempfile
    d = Path(tempfile.gettempdir()) / "강의록앱_미리보기"
    d.mkdir(exist_ok=True)
    dst = d / M.safe(Path(fname).name)
    shutil.copy(f, dst)
    try:
        _os_open(dst)
    except Exception as ex:
        return {"ok": False, "msg": f"파일을 열 프로그램을 못 찾았어요 ({type(ex).__name__})"}
    return {"ok": True}


def pending_set(body: dict) -> dict:
    data = _pending()
    e = next((x for x in data if x.get("uid") == body.get("uid") and x.get("source") == body.get("source")), None)
    if not e:
        return {"ok": False, "msg": "목록에 없는 자료예요. 새로고침해 주세요."}
    it = Item(e["source"], e["course"], e["uid"], e.get("title", ""), e.get("filename", ""), e.get("uploaded", ""))
    mem = Memory(M.DATA / "매칭기억.json")
    if body.get("exclude"):
        mem.set(it, "제외")
    elif body.get("outscope"):
        mem.set(it, "범위밖")
    elif body.get("unknown"):
        mem.set(it, "보류")
    else:
        valid = {L.key for L in load(M.DATA / "시간표.json")}
        picks = [k for k in body.get("picks") or [] if k in valid]       # 시간표에 있는 강의만
        if e.get("role_q") and not picks:
            picks = [k for k in e.get("candidates") or [] if k in valid]
        if not picks:
            return {"ok": False, "msg": "강의를 하나 이상 골라 주세요."}
        if not e.get("role_q"):          # 본/보조 질문은 이미 정해진 강의는 그대로 두고 역할만 저장
            mem.set(it, "||".join(picks))
        role = body.get("role")
        if role in ("본", "보조") or e.get("role_q"):
            roles = M.load_roles()
            roles[f"{it.source}:{it.uid}"] = role if role in ("본", "보조") else "본"
            tmp = M._roles_path().with_suffix(".tmp")
            tmp.write_text(json.dumps(roles, ensure_ascii=False, indent=1), "utf-8")
            safe_replace(tmp, M._roles_path())
        try:      # 지난 강의라도 다음 받기 때 다시 만들게
            M._redo_path().write_text(json.dumps(sorted(M.redo_keys() | set(picks)), ensure_ascii=False), "utf-8")
        except Exception:
            pass
    data = [x for x in data if x is not e]
    tmp = M.PENDING.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=1), "utf-8")
    safe_replace(tmp, M.PENDING)
    return {"ok": True}


# ---------------------------------------------------------------- 내가 정한 자료 (매칭 기억 다시 보기·고치기)
def _busy() -> bool:
    return bool((_job["proc"] and _job["proc"].poll() is None) or _external_running())


def _lec_label(L) -> str:
    return f"{L.mmdd[:2]}/{L.mmdd[2:]} {L.start}교시 · {L.title}" + (f" ({'·'.join(L.profs)})" if L.profs else "")


def _mem_cache_file(info: dict) -> Optional[Path]:
    try:
        it = Item(info["source"], info.get("course", ""), info["uid"], info.get("title", ""),
                  info.get("filename", ""), info.get("uploaded", ""))
        f = M._cache_path(M.APP / ".cache", it)
        return f if f.exists() else None
    except Exception:
        return None


def _auto_load() -> dict:
    """앱이 스스로 정한 분류 (main.save_auto 가 받을 때마다 기록)"""
    try:
        f = M.DATA / "자동분류.json"
        return json.loads(f.read_text("utf-8-sig")) if f.exists() else {}
    except Exception:
        return {}


def decided_state() -> dict:
    lectures = load(M.DATA / "시간표.json")
    by_key = {L.key: L for L in lectures}
    mem = Memory(M.DATA / "매칭기억.json")
    courses = tt_courses(lectures)
    sem = lambda mmdd: (int(mmdd[:2]) + (12 if int(mmdd[:2]) <= 2 else 0)) * 100 + int(mmdd[2:])   # 2학기: 1·2월은 뒤로
    out = []
    auto = _auto_load()
    rows = [(k, v, mem.info.get(k, {}), "") for k, v in mem.data.items()]
    rows += [(k, "||".join(e.get("keys") or []), e, e.get("how", "")) for k, e in auto.items() if k not in mem.data and e.get("keys")]
    roles = M.load_roles()
    for k, v, info, how in rows:
        src, _, uid = k.partition(":")
        cname = (info.get("course") or "").split("|")[0].strip()
        # 과목: 기억한 강의의 과목 → 출처 과목명
        picks = [] if v in ("제외", "범위밖", "보류") else [x for x in v.split("||") if x]
        course = next((by_key[x].course for x in picks if x in by_key), "")
        if not course and cname:
            course = next((c for c in courses if norm_course(c) == norm_course(cname)), cname)
        picks.sort(key=lambda x: (sem(by_key[x].mmdd), by_key[x].start) if x in by_key else (99999, 0))
        f = _mem_cache_file(info) if info else None
        out.append({"key": k, "source": info.get("source") or src, "uid": uid, "course": course or "(과목 모름)",
                    "filename": info.get("filename", ""), "title": info.get("title", ""),
                    "uploaded": info.get("uploaded", ""), "at": info.get("at", ""),
                    "exclude": v == "제외", "outscope": v == "범위밖", "unknown": v == "보류", "auto": bool(how), "how": how, "role": roles.get(k, ""),
                    "picks": [{"key": x, "label": _lec_label(by_key[x]) if x in by_key else f"(시간표에 없는 강의) {x}",
                               "missing": x not in by_key} for x in picks],
                    "has_file": bool(f), "size": f.stat().st_size if f else 0})
    first = lambda x: min([sem(by_key[p["key"]].mmdd) * 10 + by_key[p["key"]].start for p in x["picks"] if p["key"] in by_key] or [99999])
    out.sort(key=lambda x: (x["course"] == "(과목 모름)", x["course"], not x["unknown"], x["exclude"], first(x), x["filename"]))   # 잘 모르겠음은 위로
    opts = {}
    for L in sorted(lectures, key=lambda L: (L.course, sem(L.mmdd), L.start)):
        opts.setdefault(L.course, []).append({"key": L.key, "label": _lec_label(L)})
    return {"items": out, "options": opts, "busy": _busy()}


def _retire_outputs(keys, extra: bool, label: str = "") -> List[str]:
    """더 이상 이 자료를 안 쓰게 된 강의의 결과물을 _이전버전 으로 옮기고 기록을 지움 → 다음 받기 때 다시 만듦"""
    by_key = {L.key: L for L in load(M.DATA / "시간표.json")}
    moved = []
    stamp = f"{datetime.now():%m%d}"
    for k in keys:
        L = by_key.get(k)
        if not L:
            continue
        d, name = (M.extra_dir(L), M.extra_name(L, label)) if extra else (M.out_dir(L), M.out_name(L))
        if (d / name).exists():
            prev = d / "_이전버전"
            prev.mkdir(exist_ok=True)
            shutil.move(str(d / name), str(prev / name.replace(".pdf", f"_자료변경{stamp}.pdf")))
            refs = d / (name[:-4] + "_참고자료")
            if not extra and refs.exists():
                shutil.move(str(refs), str(prev / (refs.name + f"_자료변경{stamp}")))
            moved.append(name)
        recs = M.read_records(d)
        if name in recs:
            recs.pop(name, None)
            M.write_records(d, recs)
    return moved


def decided_set(body: dict) -> dict:
    if _busy():
        return {"ok": False, "msg": "받기가 진행 중이에요. 끝난 뒤에 고쳐 주세요."}
    mem = Memory(M.DATA / "매칭기억.json")
    k = body.get("key") or ""
    auto = None
    if k not in mem.data:
        auto = _auto_load().get(k)
        if not auto or not auto.get("keys"):
            return {"ok": False, "msg": "목록에 없는 자료예요. 새로고침해 주세요."}
        if body.get("forget"):
            return {"ok": True, "msg": "앱이 정한 분류는 그대로 둬요."}
        # 앱이 정한 걸 고치면 → 내가 정한 자료로 기억 (다음 받기부터 이대로)
        mem.info[k] = {a: b for a, b in auto.items() if a not in ("how", "keys", "at")}
    old = mem.data[k] if auto is None else "||".join(auto["keys"])
    old_picks = set() if old in ("제외", "범위밖", "보류") else {x for x in old.split("||") if x}
    if body.get("forget"):
        mem.data.pop(k, None)
        mem.info.pop(k, None)
        new_picks, msg = set(), "기억을 지웠어요. 다음 받기 때 앱이 다시 판단하고, 애매하면 다시 물어봐요."
    elif body.get("exclude"):
        mem.data[k] = "제외"
        new_picks, msg = set(), "강의록 아님으로 바꿨어요."
    elif body.get("outscope"):
        mem.data[k] = "범위밖"
        new_picks, msg = set(), "현재 범위 아님으로 바꿨어요."
    elif body.get("unknown"):
        mem.data[k] = "보류"
        new_picks, msg = set(), "미정으로 두었어요. 강의록에는 안 넣고, 「미정」 칸에서 나중에 고를 수 있어요."
    else:
        valid = {L.key for L in load(M.DATA / "시간표.json")}
        picks = [x for x in body.get("picks") or [] if x in valid]
        if not picks:
            return {"ok": False, "msg": "강의를 하나 이상 골라 주세요."}
        mem.data[k] = "||".join(picks)
        new_picks, msg = set(picks), "저장했어요."
    if k in mem.info:
        mem.info[k]["at"] = datetime.now().strftime("%Y-%m-%d %H:%M")
    mem.save()
    src = k.partition(":")[0]
    extra = src.startswith("필야")
    moved = _retire_outputs(sorted(old_picks - new_picks), extra, src[2:]) if old_picks - new_picks else []
    if new_picks - old_picks or moved:
        msg += " 다음 받기 때 바뀐 강의의 " + ("추가자료를" if extra else "강의록을") + " 다시 만들어요."
    if moved:
        msg += f" (이전 파일 {len(moved)}개는 _이전버전 으로 옮김)"
    return {"ok": True, "msg": msg}


def decided_open(body: dict) -> dict:
    mem = Memory(M.DATA / "매칭기억.json")
    info = mem.info.get(body.get("key") or "") or _auto_load().get(body.get("key") or "")
    f = _mem_cache_file(info) if info else None
    if not f:
        return {"ok": False, "msg": "받아 둔 파일이 없어요 (지난 받기에서 쓴 임시 파일이 지워졌어요)."}
    return _open_copy(f, info.get("filename") or f.name)


# ---------------------------------------------------------------- 설정 (계정·드라이브·노션)
def _cfg_path() -> Path:
    return M.APP / "config.json"


def _read_cfg() -> dict:
    return M.read_cfg()          # 못 읽으면 오류 (빈 설정으로 덮어쓰지 않게)


def _write_cfg(cfg: dict):
    M.write_cfg(cfg)             # 다음 받기부터 (받기는 새 프로세스라 파일을 다시 읽음)


def _icloud_synced() -> List[str]:
    """맥에서 「데스크탑 및 문서 폴더」 iCloud 동기화가 켜져 있으면 ['~/Desktop', '~/Documents']"""
    if sys.platform != "darwin":
        return []
    base = Path.home() / "Library" / "Mobile Documents" / "com~apple~CloudDocs"
    return [f"~/{n}" for n in ("Desktop", "Documents") if (base / n).exists()]


def _tt_courses_names() -> list:
    try:
        return sorted({L.course for L in load(M.DATA / "시간표.json")})
    except Exception:
        return []


def drive_list(body: dict) -> dict:
    """처음 설정·설정 탭의 「드라이브에서 고르기」: 폴더 하나의 안쪽 목록 + 시간표 과목과 맞는 폴더 표시"""
    from . import drive as D
    fid = D.folder_id_of(str(body.get("id") or body.get("url") or ""))
    if not fid or not re.fullmatch(r"[\w-]{10,}", fid):
        return {"ok": False, "msg": "구글 드라이브 폴더 링크를 넣어 주세요 (https://drive.google.com/drive/folders/…)."}
    try:
        es = D.list_folder(fid)
    except Exception as e:
        return {"ok": False, "msg": "드라이브 폴더를 열지 못했어요. 링크가 맞는지, 「링크가 있는 모든 사용자」로 공유된 폴더인지 확인해 주세요. (" + M.err(e) + ")"}
    courses = _tt_courses_names()
    cmap = _read_cfg().get("drive_course_map") or {}
    hit = {}
    for c in courses:
        f, _how = D.match_course_folder(c, es, cmap, courses)
        if f:
            hit.setdefault(f[0], c)
    out = []
    for i, n, isdir, mod in es:
        out.append({"id": i, "name": n, "dir": isdir, "mod": mod, "course": hit.get(i, "") if isdir else "",
                    "sem": bool(isdir and re.search(r"학기|semester", n, re.I))})
    out.sort(key=lambda e: (not e["dir"], e["name"]))
    return {"ok": True, "id": fid, "entries": out, "courses": courses,
            "matched": sorted({e["course"] for e in out if e["course"]})}


def drive_check(body: dict) -> dict:
    """고른 학기 폴더 확인: 과목 폴더·매뉴얼 폴더가 있는지 + 파일 날짜로 다른 학번(작년) 드라이브인지"""
    from . import drive as D
    from concurrent.futures import ThreadPoolExecutor
    sid = str(body.get("sem_id") or "").strip()
    if not re.fullmatch(r"[\w-]{10,}", sid):
        return {"ok": False, "msg": "학기 폴더를 먼저 골라 주세요."}
    try:
        es = D.list_folder(sid)
    except Exception:
        return {"ok": False, "msg": "학기 폴더를 열지 못했어요. 다시 골라 주세요."}
    courses = _tt_courses_names()
    cmap = body.get("map") if isinstance(body.get("map"), dict) else (_read_cfg().get("drive_course_map") or {})
    cmap = {str(k): str(v) for k, v in cmap.items() if v}
    year = int(YEAR_KEY) if str(YEAR_KEY).isdigit() else datetime.now().year

    def one(c):
        f, how = D.match_course_folder(c, es, cmap, courses)
        r = {"course": c, "folder": f[1] if f else "", "folder_id": f[0] if f else "", "how": how,
             "manual": False, "files": 0, "old": 0, "dates": []}
        if not f:
            return r
        try:
            ents = D.list_folder(f[0])
            man = D.find_manual(ents)
            direct = False
            if not man and any(e[2] and re.fullmatch(r"\d{4}", e[1].strip()) for e in ents):
                man, direct = (f[0], f[1], True, ""), True          # 날짜 폴더가 과목 폴더에 바로 있음
            if not man:
                return r
            r["manual"] = True
            subs = [e for e in D.list_folder(man[0]) if not direct or (e[2] and re.fullmatch(r"\d{4}", e[1].strip()))]
            files = [e for e in subs if not e[2]]
            for e in [e for e in subs if e[2]][:4]:          # 날짜 폴더 몇 개만 (빠르게)
                files += [x for x in D.list_folder(e[0]) if not x[2]]
            for e in files:
                d = D._mod_sortable(e[3])
                if re.match(r"\d{4}-", d or ""):
                    r["dates"].append(d)
            r["files"] = len(files)
            r["old"] = sum(1 for d in r["dates"] if int(d[:4]) < year)
        except Exception:
            pass
        return r
    with ThreadPoolExecutor(6) as ex:
        res = list(ex.map(one, courses))
    n_dates = sum(len(r["dates"]) for r in res)
    n_old = sum(r["old"] for r in res)
    found = [r for r in res if r["folder"]]
    newest = max((d for r in res for d in r["dates"]), default="")
    old_drive = n_dates >= 5 and n_old / n_dates >= 0.6
    hint = ""
    m = re.search(r"(\d{2})\s*학번", " ".join(n for _, n, *_ in es) + " " + str(body.get("path") or ""))   # 연도(2025)는 학번이 아니라서 「NN학번」만
    if m and m.group(1) != str(_read_cfg().get("extras_label") or "").strip():
        hint = m.group(1)
    return {"ok": True, "year": year, "courses": res, "found": len(found), "total": len(courses),
            "dirs": [{"id": i, "name": n} for i, n, isdir, _ in es if isdir],
            "manual": sum(1 for r in found if r["manual"]), "old_ratio": round(n_old / n_dates, 2) if n_dates else 0,
            "old_drive": old_drive, "newest": newest, "label_hint": hint}


def drive_check_old(body: dict) -> dict:
    """선배 필야 폴더 확인: 학기 폴더 안에서 시간표 과목마다 맞는 폴더 (직접 고른 것 포함) + 파일 수"""
    from . import drive as D
    from concurrent.futures import ThreadPoolExecutor
    src = {"folder": str(body.get("folder") or ""), "path": str(body.get("path") or "")}
    sem = str(body.get("semester") or "").strip() or "."
    try:
        sid = D.old_sem_folder(src, sem)
        es = D.list_folder(sid) if sid else []
    except Exception:
        return {"ok": False, "msg": "선배 드라이브 폴더를 열지 못했어요. 링크와 공유 설정을 확인해 주세요."}
    if not sid:
        return {"ok": False, "msg": f"추가자료 폴더 안에서 「{sem}」 폴더를 못 찾았어요."}
    cmap = body.get("map") if isinstance(body.get("map"), dict) else {}
    cmap = {str(k): str(v) for k, v in cmap.items() if v}
    courses = _tt_courses_names()

    def one(c):
        f, how = D.match_course_folder(c, es, cmap, courses)
        r = {"course": c, "folder": f[1] if f else "", "folder_id": f[0] if f else "", "how": how, "files": 0}
        if f:
            try:
                n, stack = 0, [(f[0], 0)]
                while stack and n < 300:
                    fid, dep = stack.pop()
                    for e in D.list_folder(fid):
                        if e[2] and dep < 2:
                            stack.append((e[0], dep + 1))
                        elif not e[2]:
                            n += 1
                r["files"] = n
            except Exception:
                pass
        return r
    with ThreadPoolExecutor(6) as ex:
        res = list(ex.map(one, courses))
    return {"ok": True, "courses": res, "found": sum(1 for r in res if r["folder"]), "total": len(res),
            "dirs": [{"id": i, "name": n} for i, n, isdir, _ in es if isdir]}


def settings_state() -> dict:
    from . import secrets_store, notion_sync
    from .lms import KEYCHAIN_SERVICE
    cfg = _read_cfg()
    lms_acct = secrets_store.account(KEYCHAIN_SERVICE)
    return {
        "save_root": cfg.get("save_root", ""),
        "tt_label": cfg.get("tt_label", ""),          # 배포판에 들어 있는 시간표 이름 (예: 2026 본과 2학년)
        "grades": [g["name"] for g in _grades.grades()], "grade": _grades.current()[0],
        "icloud": _icloud_synced(), "home": str(Path.home()).replace("\\", "/"),                    # 맥: iCloud와 동기화되는 바탕 화면·문서
        "drive_root": cfg.get("drive_root", ""),
        "drive_semester": cfg.get("drive_semester", ""),
        "drive_sem_label": cfg.get("drive_sem_label", ""),
        "drive_sem_id": cfg.get("drive_sem_id", ""),
        "drive_course_map": cfg.get("drive_course_map") or {}, "drive_course_map_root": cfg.get("drive_course_map_root") or "",
        "extras": cfg.get("extras", True),
        "extras_label": cfg.get("extras_label", ""),
        "extras_old": cfg.get("extras_old") or [],
        "board_include": cfg.get("board_include") or ["강의자료"],
        "cover": cfg.get("cover", True), "paper": cfg.get("paper", "A4" if cfg.get("a4", True) else ""),
        "font": _font_info(cfg), "menubar": cfg.get("menubar", True) is not False,
        "notion_sources": (cfg.get("notion") or {}).get("sources") or {},
        "courses": tt_courses(load(M.DATA / "시간표.json")) if (M.DATA / "시간표.json").exists() else [],
        "lms": {"id": lms_acct, "saved": bool(lms_acct) and secrets_store.has(KEYCHAIN_SERVICE)},
        "notion": {"saved": secrets_store.has(notion_sync.KEYCHAIN)},
        "keychain": "키체인" if sys.platform == "darwin" else "자격 증명 관리자",
    }


def settings_set(body: dict) -> dict:
    from .drive import folder_id_of
    cfg = _read_cfg()
    msgs = []
    if "save_root" in body:
        v = str(body["save_root"]).strip()
        if not v:
            return {"ok": False, "msg": "저장 폴더를 적어 주세요."}
        if v != cfg.get("save_root"):
            cfg["save_root"] = v
            msgs.append("저장 폴더를 바꿨어요 (이미 받아 둔 강의록은 예전 폴더에 그대로 있어요)")
    if "drive_root" in body:
        fid = folder_id_of(str(body["drive_root"]))
        if fid and not re.fullmatch(r"[\w-]{10,}", fid):
            return {"ok": False, "msg": "드라이브 폴더 링크를 확인해 주세요."}
        if fid != cfg.get("drive_root") and "drive_sem_id" not in body:
            cfg["drive_sem_id"] = ""            # 드라이브를 바꾸면 예전에 고른 학기 폴더는 지움
            cfg["drive_sem_label"] = ""
        cfg["drive_root"] = fid
    if "drive_course_map" in body and isinstance(body["drive_course_map"], dict):
        cfg["drive_course_map"] = {str(k)[:80]: str(v) for k, v in body["drive_course_map"].items()
                                   if v and (str(v) == "-" or re.fullmatch(r"[\w-]{10,}", str(v)))}
        cfg["drive_course_map_root"] = folder_id_of(str(body.get("drive_course_map_root") or "")) or cfg.get("drive_root", "")
    if "drive_sem_id" in body:
        sid = str(body["drive_sem_id"] or "").strip()
        if sid and not re.fullmatch(r"[\w-]{10,}", sid):
            return {"ok": False, "msg": "학기 폴더를 다시 골라 주세요."}
        cfg["drive_sem_id"] = sid
    for k in ("drive_semester", "extras_label", "drive_sem_label"):
        if k in body:
            cfg[k] = str(body[k]).strip()
    if "extras" in body:
        cfg["extras"] = bool(body["extras"])
    mb_on = None
    if "menubar" in body:                       # 맥 메뉴 막대 현황 켜기·끄기 (저장한 뒤에 켜고 끔)
        cfg["menubar"] = mb_on = bool(body["menubar"])
    changed = False
    if "cover" in body and bool(body["cover"]) != cfg.get("cover", True):
        cfg["cover"] = bool(body["cover"])
        changed = True
    if "paper" in body:
        pp = str(body["paper"] or "")
        if pp and pp not in ("A4", "B5", "A5", "Letter"):
            m = re.fullmatch(r"\s*(\d+(?:\.\d+)?)\s*[x×*]\s*(\d+(?:\.\d+)?)\s*", pp)
            if not m or not all(50 <= float(v) <= 1200 for v in m.groups()):
                return {"ok": False, "msg": "사용자 설정 용지는 가로·세로를 50~1200mm 사이로 적어 주세요."}
            pp = f"{float(m.group(1)):g}x{float(m.group(2)):g}"
        old_pp = cfg.get("paper", "A4" if cfg.get("a4", True) else "")
        if pp != old_pp:
            cfg["paper"] = pp
            cfg.pop("a4", None)
            changed = True
    if changed:
        msgs.append("앞으로 만드는 강의록부터 새 설정을 써요 (이미 만든 것은 「새 표지로 바꾸기」)")
    if "board_include" in body:
        cfg["board_include"] = [x.strip() for x in body["board_include"] if str(x).strip()] or ["강의자료"]
    if "extras_old" in body:
        olds = []
        for o in body["extras_old"] or []:
            if not isinstance(o, dict):
                continue
            lab, link = str(o.get("label", "")).strip(), str(o.get("folder", "")).strip()
            if not lab and not link:
                continue
            if not lab or not link:
                return {"ok": False, "msg": "선배 추가자료는 학번과 드라이브 링크를 둘 다 적어 주세요."}
            lab2 = re.sub(r"\D", "", lab) or lab
            if lab2 in {o["label"] for o in olds} or lab2 == str(cfg.get("extras_label", "")).strip():
                return {"ok": False, "msg": f"{lab2}학번이 두 번 들어가 있어요. 하나만 남겨 주세요."}
            olds.append({"label": lab2, "folder": folder_id_of(link),
                         "path": str(o.get("path", "")).strip().strip("/"),
                         **({"semester": str(o["semester"]).strip()} if str(o.get("semester", "")).strip() else {}),
                         **({"map": {str(k)[:80]: str(v) for k, v in o["map"].items() if v and (str(v) == "-" or re.fullmatch(r"[\w-]{10,}", str(v)))}}
                            if isinstance(o.get("map"), dict) and o["map"] else {})})
        cfg["extras_old"] = olds
    if "notion_sources" in body:
        src = {}
        for c, v in (body["notion_sources"] or {}).items():
            v = str(v or "").strip()
            if not v:
                continue
            m = re.search(r"[0-9a-f]{32}", v.split("?")[0].replace("-", "").lower())   # 링크면 ?v=(보기 id) 앞부분
            raw = m.group(0) if m else ""
            if len(raw) != 32:
                return {"ok": False, "msg": f"{c}: 노션 표 링크(또는 ID)를 확인해 주세요."}
            src[c] = f"{raw[:8]}-{raw[8:12]}-{raw[12:16]}-{raw[16:20]}-{raw[20:]}"
        cfg.setdefault("notion", {})["sources"] = src
    _write_cfg(cfg)
    _xrec.clear()
    if mb_on is not None:
        def _mb(on=mb_on):
            time.sleep(0.5)
            try:
                from . import menubar
                menubar.launch() if on else menubar.stop()
            except Exception:
                pass
        threading.Thread(target=_mb, daemon=True).start()
    return {"ok": True, "msg": "저장했어요." + (" " + " · ".join(msgs) if msgs else "")}


def open_in_browser(body: dict) -> dict:
    """앱 설치(강의록앱 아이콘)는 주소창이 있는 보통 크롬 창에서만 돼서, 보통 창으로 엶"""
    url = f"http://127.0.0.1:{PORT}/#install"
    try:
        if sys.platform == "darwin":
            for app in ("Google Chrome", "Microsoft Edge", "Chromium", "Brave Browser"):
                if subprocess.run(["open", "-a", app, url], capture_output=True).returncode == 0:
                    return {"ok": True}
        elif os.name == "nt":
            for exe in [Path(os.environ.get(v, "")) / sub for v in ("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA")
                        for sub in ("Google/Chrome/Application/chrome.exe", "Microsoft/Edge/Application/msedge.exe")]:
                if exe.is_file():
                    subprocess.Popen([str(exe), url])
                    return {"ok": True}
        import webbrowser
        webbrowser.open(url)
        return {"ok": True}
    except Exception as e:
        return {"ok": False, "msg": f"브라우저를 못 열었어요 ({type(e).__name__})"}


def pick_folder(body: dict) -> dict:
    """Finder(맥)·탐색기(Windows) 창으로 폴더 고르기 → 경로를 돌려줌 (경로를 직접 안 써도 되게)"""
    cur = Path(str(body.get("current") or "~")).expanduser()
    start = cur if cur.is_dir() else (cur.parent if cur.parent.is_dir() else Path.home())
    try:
        if sys.platform == "darwin":
            q = lambda t: t.replace("\\", "\\\\").replace('"', '\\"')
            script = (f'set f to choose folder with prompt "강의록을 정리할 폴더를 고르세요" '
                      f'default location (POSIX file "{q(str(start))}")\nreturn POSIX path of f')
            # 'activate' = osascript 자기 창을 맨 앞으로 (다른 앱 제어 권한이 필요 없음)
            r = subprocess.run(["osascript", "-e", "activate", "-e", script],
                               capture_output=True, text=True, timeout=600)
            path = (r.stdout or "").strip()
        elif os.name == "nt":
            ps = ("Add-Type -AssemblyName System.Windows.Forms;"
                  "$d=New-Object System.Windows.Forms.FolderBrowserDialog;"
                  "$d.Description='강의록을 정리할 폴더를 고르세요';$d.ShowNewFolderButton=$true;"
                  f"$d.SelectedPath='{str(start).replace(chr(39), chr(39) * 2)}';"
                  "$w=New-Object System.Windows.Forms.Form;$w.TopMost=$true;"
                  "if($d.ShowDialog($w) -eq 'OK'){[Console]::OutputEncoding=[Text.Encoding]::UTF8;Write-Output $d.SelectedPath}")
            r = subprocess.run(["powershell", "-NoProfile", "-STA", "-Command", ps], capture_output=True, timeout=600)
            path = (r.stdout or b"").decode("utf-8", "ignore").strip()
        else:
            r = subprocess.run(["zenity", "--file-selection", "--directory", f"--filename={start}/"],
                               capture_output=True, text=True, timeout=600)
            path = (r.stdout or "").strip()
    except Exception as e:
        return {"ok": False, "msg": f"폴더 고르기 창을 못 열었어요 ({type(e).__name__}). 경로를 직접 적어 주세요."}
    if not path:
        return {"ok": False, "cancel": True}
    p = Path(path).expanduser()
    home = Path.home()
    shown = "~/" + str(p.relative_to(home)).replace("\\", "/") if home in p.parents else str(p)
    return {"ok": True, "path": shown.rstrip("/") or str(p)}


def setup_done(body: dict) -> dict:
    """처음 설정 화면을 끝냈다고 표시 (다음부터 안 뜸). 설정 탭에서 언제든 다시 바꿀 수 있음."""
    cfg = _read_cfg()
    cfg["setup_done"] = bool(body.get("done", True))
    _write_cfg(cfg)
    return {"ok": True}


def _font_info(cfg: dict) -> dict:
    from . import render
    uf = render.user_font()
    lst = []
    if render.USER_FONT_DIR.is_dir():
        for f in sorted(render.USER_FONT_DIR.iterdir(), key=lambda p: p.stat().st_mtime):
            if f.is_file() and f.suffix.lower() in FONT_EXT:
                lst.append({"file": f.name, "name": render.font_family(f) or f.stem})
    base = "Apple SD 산돌고딕 Neo" if sys.platform == "darwin" else ("맑은 고딕" if os.name == "nt" and render.WIN_KO[0].exists() else "Pretendard (앱 기본)")
    if uf:
        return {"user": True, "name": render.font_family(uf), "file": uf.name, "list": lst, "default": base}
    return {"user": False, "name": base, "list": lst, "default": base}


FONT_EXT = (".ttf", ".otf", ".ttc")


# ---------------------------------------------------------------- 표지 모양 (기본 + 내가 넣은 HTML 표지)
_COVER_LOCK = threading.Lock()


def _sample_lecture():
    """미리보기용 강의: 내 시간표에서 역대 교수가 있고 올해와 다른 해가 있는 강의 (없으면 예시)"""
    from .timetable import Lecture
    try:
        ls = load(M.DATA / "시간표.json")
        ls = sorted(ls, key=lambda L: (-sum(1 for _y, ps in L.history() if ps and set(ps) != set(L.profs)),
                                       -len([1 for _y, ps in L.history() if ps]), len(L.title)))
        if ls:
            return ls[0]
    except Exception:
        pass
    sd = render.SAMPLE_LECTURE
    hist = [(sd["year"], sd["profs"])] + [(h["year"], h["profs"]) for h in sd["history"]]
    return Lecture(sd["course"], sd["term"], sd["mmdd"], sd["period_start"], sd["hours"], list(sd["titles"]),
                   list(sd["profs"]), extra={"hist": hist})


def covers_state() -> dict:
    from . import covers as C
    cfg = _read_cfg()
    cur = cfg.get("cover_template", "")
    items = C.list_covers(M.APP)
    if cur and not any(x["id"] == cur for x in items):
        cur = ""
    L = _sample_lecture()
    return {"items": items, "selected": cur, "cover": cfg.get("cover", True) is not False, "prompt": C.cover_prompt(render.cover_data(L), render.YEAR_KEY),
            "sample": render.cover_data(L)}


def cover_preview(cid: str) -> Optional[bytes]:
    """표지 미리보기 PNG (만든 것은 .cache 에 보관)"""
    from . import covers as C
    items = {x["id"]: x for x in C.list_covers(M.APP)}
    if cid not in items:
        return None
    tpl = C.read_cover(M.APP, cid) if cid else None
    L = _sample_lecture()
    sig = hashlib.md5(json.dumps([items[cid]["ver"], render.cover_data(L), str(render.user_font() or "")],
                                 ensure_ascii=False).encode("utf-8")).hexdigest()[:12]
    d = M.APP / ".cache" / "cover_prev"
    f = d / f"{(cid or 'builtin').replace('.html', '')}-{sig}.png"
    if f.exists():
        return f.read_bytes()
    with _COVER_LOCK:
        d.mkdir(parents=True, exist_ok=True)
        rd = render.Renderer()
        try:
            rd.cover_png(L, f, tpl, C.read_bg(M.APP, cid) if cid else None)
        finally:
            rd.close()
    return f.read_bytes() if f.exists() else None


def cover_add(body: dict) -> dict:
    from . import covers as C
    text = str(body.get("html") or "")
    m = re.search(r"```(?:html)?\s*(.*?)```", text, re.S | re.I)      # AI 답을 통째로 붙여 넣은 경우 코드만
    if m and "<" in m.group(1):
        text = m.group(1)
    bad = C.check_template(text)
    if bad:
        return {"ok": False, "msg": bad}
    # 미리 한 번 그려 봄 (오류면 알려 줌)
    try:
        with _COVER_LOCK:
            rd = render.Renderer()
            try:
                tmp = M.APP / ".cache" / "cover_test.pdf"
                tmp.parent.mkdir(parents=True, exist_ok=True)
                rd.render_template(text, render.cover_data(_sample_lecture()), tmp)
            finally:
                rd.close()
    except Exception as e:
        return {"ok": False, "msg": f"이 HTML로 표지를 만들지 못했어요 ({type(e).__name__}). AI에게 다시 만들어 달라고 해 주세요."}
    if body.get("id"):                     # 앱에서 만든 표지 고치기
        bad = C.update_cover(M.APP, str(body["id"]), text)
        if bad:
            return {"ok": False, "msg": bad}
        return {"ok": True, "id": body["id"], "msg": "표지를 고쳤어요. 앞으로 만드는 강의록부터 써요 (이미 만든 것은 「새 표지로 바꾸기」)."}
    cid = C.save_cover(M.APP, str(body.get("name") or ""), text)
    if body.get("select", True):
        with M.CFG_LOCK:
            cfg = _read_cfg()
            cfg["cover_template"] = cid
            cfg["cover"] = True
            _write_cfg(cfg)
    return {"ok": True, "id": cid, "msg": "표지를 넣고 골랐어요. 앞으로 만드는 강의록부터 이 표지를 써요 (이미 만든 것은 「새 표지로 바꾸기」)."}


def cover_bg(body: dict) -> dict:
    """표지 배경 사진 넣기·빼기 (화면이 사진을 줄여 JPEG data: 주소로 보냄)"""
    from . import covers as C
    import base64
    cid = str(body.get("id") or "")
    raw = None
    if not body.get("remove"):
        d = str(body.get("data") or "")
        m = re.fullmatch(r"data:image/jpeg;base64,([A-Za-z0-9+/=\s]+)", d)
        if not m:
            return {"ok": False, "msg": "사진을 읽지 못했어요. 다른 사진으로 해 주세요."}
        try:
            raw = base64.b64decode(m.group(1))
        except Exception:
            return {"ok": False, "msg": "사진을 읽지 못했어요."}
    bad = C.save_bg(M.APP, cid, raw)
    if bad:
        return {"ok": False, "msg": bad}
    return {"ok": True, "msg": "사진을 뺐어요." if raw is None else "사진을 넣었어요. 이미 만든 강의록도 바꾸려면 「새 표지로 바꾸기」를 눌러 주세요."}


def cover_make(body: dict) -> dict:
    """표지만 따로 PDF로: 시간표에서 고른 강의 또는 직접 입력한 강의 → <저장 폴더>/표지 만들기/"""
    from . import covers as C
    from .timetable import Lecture
    from pypdf import PdfReader, PdfWriter
    items = body.get("items") or []
    if not items:
        return {"ok": False, "msg": "표지를 만들 강의를 넣어 주세요."}
    if len(items) > 400:
        return {"ok": False, "msg": "한 번에 400개까지 만들 수 있어요."}
    by_key = {L.key: L for L in load(M.DATA / "시간표.json")}
    lecs = []
    for it in items:
        L = by_key.get(str(it.get("key") or ""))
        if L is None:
            md = re.sub(r"\D", "", str(it.get("mmdd") or ""))
            if len(md) == 3:
                md = "0" + md
            title = str(it.get("title") or "").strip()
            if len(md) != 4 or not title or not (1 <= int(md[:2]) <= 12 and 1 <= int(md[2:]) <= 31):
                return {"ok": False, "msg": "날짜(예: 1012)와 강의 제목을 확인해 주세요."}
            per = re.findall(r"\d+", str(it.get("period") or "1"))
            st = int(per[0]) if per else 1
            hrs = max(1, int(per[-1]) - st + 1) if len(per) > 1 else 1
            profs = [x for x in re.split(r"[,·/\s]+", str(it.get("prof") or "")) if x]
            try:
                term = int(str(it.get("term") or 0) or 0)
            except ValueError:
                term = 0
            L = Lecture(course=str(it.get("course") or "").strip(), term=term, mmdd=md, start=st, hours=hrs,
                        titles=[title], profs=profs, extra={"hist": []})
        lecs.append(L)
    design = str(body.get("design") if body.get("design") is not None else "")
    tpl = C.read_cover(M.APP, design) if design else None
    bg = C.read_bg(M.APP, design) if design else None
    out = M.SAVE_ROOT / "표지 만들기"
    out.mkdir(parents=True, exist_ok=True)
    tmpd = M.APP / ".cache" / "cover_make"
    tmpd.mkdir(parents=True, exist_ok=True)
    made = []
    with _COVER_LOCK:
        rd = render.Renderer()
        try:
            rd.template, rd.template_bg = tpl, bg
            for i, L in enumerate(lecs):
                f = tmpd / f"{i:03d}.pdf"
                rd.cover(L, f)
                made.append((L, f))
            tfail = rd.template_error
        finally:
            rd.close()
    stamp = datetime.now().strftime("%m%d-%H%M%S")
    files = []
    if body.get("merge") and len(made) > 1:
        w = PdfWriter()
        for _, f in made:
            for pg in PdfReader(str(f)).pages:
                w.add_page(pg)
        dst = out / f"표지 모음 {stamp} ({len(made)}장).pdf"
        with open(dst, "wb") as fh:
            w.write(fh)
        files.append(dst)
    else:
        for L, f in made:
            name = M.safe(f"{L.mmdd}-{L.start}. {L.title}" + (f"_{'·'.join(p + 'T' for p in L.profs)}" if L.profs else "")) + " (표지).pdf"
            dst = out / name
            if dst.exists():
                dst = out / (dst.stem + f" {stamp}.pdf")
            shutil.copyfile(f, dst)
            files.append(dst)
    for _, f in made:
        try:
            f.unlink()
        except OSError:
            pass
    return {"ok": True, "files": [_rel(f) for f in files], "folder": _rel(out),
            "msg": (f"표지 {len(made)}장을 PDF 한 파일로 만들었어요." if len(made) > 1 and len(files) == 1
                    else f"표지 PDF {len(files)}개를 「표지 만들기」 폴더에 만들었어요." if len(files) > 1 else "표지 PDF를 만들었어요.")
                   + (" (고른 표지로 못 만든 것은 기본 표지로 만들었어요)" if tfail else "")}


def cover_builder(body: dict) -> dict:
    from . import covers as C
    st = C.builder_state(M.APP, str(body.get("id") or ""))
    return {"ok": bool(st), "state": st, "msg": "" if st else "앱에서 만든 표지가 아니에요."}


def cover_rename(body: dict) -> dict:
    from . import covers as C
    bad = C.rename_cover(M.APP, str(body.get("id") or ""), str(body.get("name") or ""))
    return {"ok": not bad, "msg": bad or "이름을 바꿨어요."}


def cover_select(body: dict) -> dict:
    from . import covers as C
    cid = str(body.get("id") or "")
    cfg = _read_cfg()
    if body.get("none"):                       # 표지 없음
        cfg["cover"] = False
        _write_cfg(cfg)
        return {"ok": True, "msg": "표지 없이 만들어요. 앞으로 만드는 강의록부터 (이미 만든 것은 「새 표지로 바꾸기」)."}
    if cid and not any(x["id"] == cid for x in C.list_covers(M.APP)):
        return {"ok": False, "msg": "없는 표지예요. 새로고침해 주세요."}
    if cfg.get("cover_template", "") == cid and cfg.get("cover", True) is not False:
        return {"ok": True, "msg": "이미 고른 표지예요."}
    cfg["cover"] = True
    cfg["cover_template"] = cid
    _write_cfg(cfg)
    _xrec.clear()
    return {"ok": True, "msg": "표지 모양을 바꿨어요. 앞으로 만드는 강의록부터 써요 (이미 만든 것은 「새 표지로 바꾸기」)."}


def cover_delete(body: dict) -> dict:
    from . import covers as C
    cid = str(body.get("id") or "")
    if not cid or cid.startswith("@") or not C.read_cover(M.APP, cid):
        return {"ok": False, "msg": "지울 수 없는 표지예요."}
    f = C.covers_dir(M.APP) / cid
    trash = C.covers_dir(M.APP) / "_지운표지"
    trash.mkdir(exist_ok=True)
    safe_replace(f, trash / cid) if not (trash / cid).exists() else f.unlink()
    bgf = C.bg_path(M.APP, cid)
    if bgf and bgf.exists():
        safe_replace(bgf, trash / bgf.name) if not (trash / bgf.name).exists() else bgf.unlink()
    try:
        nm = C._names(M.APP)
        if cid in nm:
            nm.pop(cid)
            (C.covers_dir(M.APP) / "_이름.json").write_text(json.dumps(nm, ensure_ascii=False, indent=1), "utf-8")
    except Exception:
        pass
    cfg = _read_cfg()
    if cfg.get("cover_template") == cid:
        cfg["cover_template"] = ""
        _write_cfg(cfg)
    return {"ok": True, "msg": "표지를 목록에서 뺐어요."}


def font_set(body: dict) -> dict:
    """설정에서 글꼴 파일 넣기·되돌리기. 표지와 PPT 변환에 이 글꼴을 써요."""
    import base64
    from . import render
    cfg = _read_cfg()
    later = " 앞으로 만드는 강의록부터 써요 (이미 만든 것은 「새 표지로 바꾸기」)."
    if body.get("clear"):
        cfg.pop("font", None)
        _write_cfg(cfg)
        return {"ok": True, "msg": "기본 글꼴로 바꿨어요." + later}
    if "select" in body or "delete" in body:            # 넣어 둔 글꼴 중에서 고르기 / 빼기
        fn = Path(str(body.get("select") or body.get("delete") or "")).name
        f = render.USER_FONT_DIR / fn
        if not fn or not f.is_file() or f.suffix.lower() not in FONT_EXT:
            return {"ok": False, "msg": "없는 글꼴이에요. 새로고침해 주세요."}
        if body.get("delete"):
            if (cfg.get("font") or {}).get("file") == fn:
                cfg.pop("font", None)
                _write_cfg(cfg)
            f.unlink()
            return {"ok": True, "msg": "글꼴을 목록에서 뺐어요."}
        cfg["font"] = {"file": fn}
        _write_cfg(cfg)
        return {"ok": True, "msg": f"「{render.font_family(f) or f.stem}」 글꼴로 바꿨어요." + later}
    name = Path(str(body.get("name") or "")).name
    if not name.lower().endswith(FONT_EXT):
        return {"ok": False, "msg": "TTF·OTF·TTC 글꼴 파일만 넣을 수 있어요."}
    try:
        data = base64.b64decode(body.get("data") or "", validate=True)
    except Exception:
        return {"ok": False, "msg": "파일을 읽지 못했어요."}
    if not data or len(data) > 60 * 1024 * 1024:
        return {"ok": False, "msg": "글꼴 파일이 비었거나 너무 커요 (60MB까지)."}
    if data[:4] not in (b"\x00\x01\x00\x00", b"OTTO", b"true", b"ttcf"):
        return {"ok": False, "msg": "글꼴 파일이 아닌 것 같아요."}
    render.USER_FONT_DIR.mkdir(parents=True, exist_ok=True)
    safe_name = re.sub(r"[^\w.\- ]", "_", name)
    (render.USER_FONT_DIR / safe_name).write_bytes(data)
    conv = _font_to_ttf(render.USER_FONT_DIR / safe_name)        # CFF OTF → TTF (크롬이 못 읽는 경우가 있어서)
    if conv:
        safe_name = conv.name
        cfg = _read_cfg()
    cfg["font"] = {"file": safe_name}
    _write_cfg(cfg)
    fam = render.font_family(render.USER_FONT_DIR / safe_name)
    return {"ok": True, "msg": f"「{fam}」 글꼴을 넣고 골랐어요." + later}


def _font_to_ttf(f: Path) -> Optional[Path]:
    """CFF OTF 를 TTF 로 바꾸고 원본은 지움 (고른 글꼴이 그 파일이면 설정도 새 이름으로). 바꾼 파일 또는 None"""
    from . import render
    if not render.needs_ttf(f):
        return None
    t = render.otf_to_ttf(f)
    if not t:
        return None
    with M.CFG_LOCK:
        cfg = _read_cfg()
        if (cfg.get("font") or {}).get("file") == f.name:
            cfg["font"] = {"file": t.name}
            _write_cfg(cfg)
    try:
        f.unlink()
    except Exception:
        pass
    return t


def _fix_user_fonts():
    """예전에 넣은 CFF OTF 글꼴도 TTF 로 (앱 켤 때 한 번, 뒤에서)"""
    from . import render
    try:
        for f in list(render.USER_FONT_DIR.glob("*.otf")) + list(render.USER_FONT_DIR.glob("*.OTF")):
            _font_to_ttf(f)
    except Exception:
        pass


def font_file(default: bool = False, name: str = ""):
    from . import render
    if name:
        f = render.USER_FONT_DIR / Path(name).name
        return f if f.is_file() and f.suffix.lower() in FONT_EXT else None
    if default:
        f = render.FONT_DIR / "Pretendard-Bold.ttf"
        return f if f.is_file() else None
    return render.user_font()


def secret_set(body: dict) -> dict:
    """비밀번호·토큰은 이 컴퓨터의 키체인(자격 증명 관리자)에만. 응답·로그에 값은 절대 안 남김."""
    from . import secrets_store, notion_sync
    from .lms import KEYCHAIN_SERVICE
    kind = body.get("kind")
    if kind == "lms":
        if body.get("clear"):
            secrets_store.delete(KEYCHAIN_SERVICE)
            return {"ok": True, "msg": "LMS 로그인 정보를 지웠어요."}
        uid, pw = str(body.get("id") or "").strip(), str(body.get("pw") or "")
        if not uid:
            return {"ok": False, "msg": "아이디(학번)를 적어 주세요."}
        if not pw:
            cur = secrets_store.get(KEYCHAIN_SERVICE)
            if not cur:
                return {"ok": False, "msg": "비밀번호를 적어 주세요."}
            pw = cur[1]                       # 아이디만 바꿈
        ok, msg = secrets_store.put(KEYCHAIN_SERVICE, uid, pw)
        return {"ok": ok, "msg": "저장했어요. 다음 받기부터 이 계정으로 자동 로그인해요." if ok else msg}
    if kind == "notion":
        if body.get("clear"):
            secrets_store.delete(notion_sync.KEYCHAIN)
            return {"ok": True, "msg": "노션 연결을 지웠어요."}
        tok = str(body.get("token") or "").strip().strip('"').strip("'")
        if not tok.startswith(("ntn_", "secret_")):
            return {"ok": False, "msg": "ntn_ 또는 secret_ 로 시작하는 '내부 통합 시크릿'을 붙여 넣어 주세요."}
        res = notion_sync.check(tok)
        if not res.startswith("ok:"):
            return {"ok": False, "msg": res}
        ok, msg = secrets_store.put(notion_sync.KEYCHAIN, "notion", tok)
        return {"ok": ok, "msg": f"연결했어요 ({res[3:]}). 노션 페이지 ··· → 연결 에 이 통합을 추가했는지도 확인해 주세요." if ok else msg}
    return {"ok": False, "msg": "알 수 없는 요청"}


# ---------------------------------------------------------------- 예약
def manual_set(body: dict) -> dict:
    """강의에 자료 직접 넣기·빼기 (LMS·드라이브에 없는 강의록도 정리). 넣은 자료가 있으면 그것으로 만들어요."""
    import base64
    key = str(body.get("key") or "")
    L = next((x for x in load(M.DATA / "시간표.json") if x.key == key), None)
    if not L:
        return {"ok": False, "msg": "시간표에 없는 강의예요. 새로고침해 주세요."}
    d = M.manual_dir(L)
    if body.get("delete"):
        f = d / Path(str(body["delete"])).name
        if f.is_file():
            f.unlink()
        return {"ok": True, "msg": "뺐어요. 다시 만들면 LMS·드라이브 자료로 돌아가요."}
    name = Path(str(body.get("name") or "")).name
    if name.startswith("."):          # 「.pdf」처럼 이름 없는 파일 → 이름을 붙여 줌
        name = "내 파일" + name
    if not name.lower().endswith(M.MANUAL_EXT):
        return {"ok": False, "msg": "PDF·PPT·워드·한글 파일만 넣을 수 있어요."}
    try:
        data = base64.b64decode(body.get("data") or "", validate=True)
    except Exception:
        return {"ok": False, "msg": "파일을 읽지 못했어요."}
    if not data or len(data) > 300 * 1024 * 1024:
        return {"ok": False, "msg": "파일이 비었거나 너무 커요 (300MB까지)."}
    d.mkdir(parents=True, exist_ok=True)
    (d / re.sub(r'[\\/:*?"<>|]', "_", name)).write_bytes(data)
    return {"ok": True, "msg": f"「{name}」을 넣었어요."}


def grade_set(body: dict) -> dict:
    """학년 나누기: start(지금 학년 이름) / add / remove / select. 고르면 앱을 다시 켜서 그 학년으로 열어요."""
    if _job["proc"] and _job["proc"].poll() is None or _external_running():
        return {"ok": False, "msg": "받는 중에는 학년을 바꿀 수 없어요. 끝난 뒤에 해 주세요."}
    with M.CFG_LOCK:
        raw = _grades.raw_cfg()
        gs = _grades.grades(raw)
        hidden = [g for g in (raw.get("grades_hidden") or []) if isinstance(g, dict) and g.get("name")]
        name = _grades.safe_name(body.get("name") or body.get("add") or body.get("remove") or body.get("select") or "")
        if "start" in body:                       # 처음 나누기: 지금 쓰는 데이터를 이 이름의 학년으로
            if gs:
                return {"ok": False, "msg": "이미 학년을 나눠 쓰고 있어요."}
            first = _grades.safe_name(body.get("start"))
            if not first:
                return {"ok": False, "msg": "지금 학년 이름을 적어 주세요 (예: 본과 2학년)."}
            raw["grades"], raw["grade"] = [{"name": first, "dir": ""}], first
            M._write_raw_cfg(raw)
            return {"ok": True, "msg": f"지금 쓰던 시간표·기록을 「{first}」 학년으로 묶었어요."}
        if not name:
            return {"ok": False, "msg": "학년 이름을 적어 주세요."}
        if "add" in body:
            if not gs:
                return {"ok": False, "msg": "먼저 지금 학년 이름을 정해 주세요."}
            if any(g["name"] == name for g in gs):
                return {"ok": False, "msg": "이미 있는 학년이에요."}
            old = next((g for g in hidden if g["name"] == name), None)
            if old:                               # 예전에 뺀 학년: 기록 그대로 다시
                hidden = [g for g in hidden if g["name"] != name]
                gs.append(old)
                msg = f"「{name}」 학년을 예전 기록 그대로 다시 넣었어요."
            else:
                d = f"학년/{name}"
                p = M.APP / d
                p.mkdir(parents=True, exist_ok=True)
                if not (p / _grades.GRADE_FILE).exists():
                    (p / _grades.GRADE_FILE).write_text(json.dumps(_grades.new_grade_cfg(name), ensure_ascii=False, indent=2), "utf-8")
                if not (p / "시간표.json").exists():
                    (p / "시간표.json").write_text("[]", "utf-8")
                gs.append({"name": name, "dir": d})
                msg = f"「{name}」 학년을 넣었어요. 고르면 그 학년 처음 설정이 열려요."
            raw["grades"], raw["grades_hidden"] = gs, hidden
            M._write_raw_cfg(raw)
            return {"ok": True, "msg": msg}
        if "remove" in body:
            if name == _grades.current(raw)[0]:
                return {"ok": False, "msg": "지금 쓰는 학년은 뺄 수 없어요. 다른 학년을 고른 뒤에 빼 주세요."}
            g = next((g for g in gs if g["name"] == name), None)
            if not g:
                return {"ok": False, "msg": "없는 학년이에요."}
            raw["grades"] = [x for x in gs if x["name"] != name]
            raw["grades_hidden"] = [x for x in hidden if x["name"] != name] + [g]
            M._write_raw_cfg(raw)
            return {"ok": True, "msg": f"「{name}」 학년을 목록에서 뺐어요. 받아 둔 강의록과 기록은 그대로 있어요 (같은 이름으로 다시 넣으면 돌아와요)."}
        if "select" in body:
            if not any(g["name"] == name for g in gs):
                return {"ok": False, "msg": "없는 학년이에요."}
            if not _SRV[0]:          # 다시 켤 수 없으면 바꾸지 않음 (설정만 바뀌고 화면은 예전 학년인 채로 남지 않게)
                return {"ok": False, "msg": "지금은 학년을 바꿀 수 없어요. 앱을 닫았다가 다시 열어 주세요."}
            raw["grade"] = name
            M._write_raw_cfg(raw)
    # 예약도 그 학년 것으로 다시 등록 (따로 돌려서 설정 잠금을 오래 잡지 않게 · 앱이 다시 켜져도 계속 돌아요)
    try:
        cfg = _grades.merge(_grades.raw_cfg())
        times = M._sched_times(cfg)
        subprocess.Popen([sys.executable, "-m", "lecture_app", "예약", *(times or ["끄기"])], cwd=str(M.APP),
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL,
                         **({"creationflags": 0x08000000} if os.name == "nt" else {"start_new_session": True}))
    except Exception:
        pass
    return {"ok": True, "restart": True, "msg": f"「{name}」 학년으로 바꿨어요. 앱을 다시 켜요."}


def schedule_set(body: dict) -> dict:
    slots = []
    for s in body.get("slots") or []:
        m = re.fullmatch(r"(\d{1,2}):(\d{2})", (s.get("time") or "").strip())
        if not m or int(m.group(1)) > 23 or int(m.group(2)) > 59:
            return {"ok": False, "msg": f"시간 형식을 확인해 주세요: {s.get('time')}"}
        slots.append((int(m.group(1)), int(m.group(2)), "오늘" if s.get("mode") == "오늘" else "전체",
                      s.get("target") if s.get("target") in ("강의록", "필야") else "둘다",
                      ",".join(re.sub(r"\D", "", str(y)) for y in (s.get("years") or []) if re.sub(r"\D", "", str(y)))))
    import contextlib
    import io
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        rc = M._apply_schedule(slots)
    return {"ok": rc == 0, "msg": buf.getvalue().strip()}


# ---------------------------------------------------------------- 실행 기록
def runs_list() -> List[dict]:
    d = M.SAVE_ROOT / "_실행기록"
    if not d.exists():
        return []
    fs = sorted(d.glob("*.txt"), key=lambda p: p.stat().st_mtime, reverse=True)[:40]
    out = []
    for f in fs:
        head = ""
        try:
            txt = f.read_text("utf-8", errors="replace")
            m = re.search(r"== 요약: (.+)", txt)
            head = m.group(1) if m else ("오류" if "오류" in f.name else ("진행 중" if "진행중" in f.name else ""))
        except Exception:
            pass
        out.append({"name": f.name, "mtime": datetime.fromtimestamp(f.stat().st_mtime).strftime("%m/%d %H:%M"),
                    "summary": head})
    return out


def sched_runs() -> List[dict]:
    """예약 받기 실행 기록 (최근 순 30개): 시작·끝을 하나로 합침"""
    rows, byid = [], {}
    try:
        lines = M.SCHED_LOG.read_text("utf-8").splitlines() if M.SCHED_LOG.exists() else []
    except Exception:
        lines = []
    for ln in lines:
        try:
            e = json.loads(ln)
        except Exception:
            continue
        if e.get("ev") == "skip":
            rows.append({"t": e.get("t", ""), "status": "skip", "msg": e.get("msg", "")})
        elif e.get("ev") == "start":
            r = {"t": e.get("t", ""), "status": "run", "mode": e.get("mode", ""), "target": e.get("target", ""),
                 "id": e.get("id", ""), "msg": ""}
            byid[r["id"]] = r
            rows.append(r)
        elif e.get("ev") == "end" and e.get("id") in byid:
            r = byid[e["id"]]
            r.update(status="err" if e.get("error") else "ok", msg=e.get("error") or e.get("msg", ""), end=e.get("t", ""))
    try:
        running = bool(M._other_run())          # 지금 받는 중이면 마지막 '시작'은 진행 중
    except Exception:
        running = False
    d = M.SAVE_ROOT / "_실행기록"
    for i, r in enumerate(rows):
        if r["status"] == "run" and not (running and i == len(rows) - 1):
            r["status"] = "stop"; r["msg"] = "끝나기 전에 멈췄어요 (컴퓨터가 잠들었거나 꺼졌을 수 있어요)"
        if r.get("id") and d.exists():
            f = next(iter(sorted(d.glob(f"{r['id']}*.txt"))), None)
            if f:
                r["file"] = f.name
    return rows[::-1][:30]


def run_text(name: str) -> str:
    if not re.fullmatch(r"[\w\-.가-힣 ]+\.txt", name or ""):
        return ""
    f = M.SAVE_ROOT / "_실행기록" / name
    return f.read_text("utf-8", errors="replace") if f.exists() else ""


# ---------------------------------------------------------------- 파일 열기
def _os_open(p: Path, reveal: bool = False):
    """파일·폴더 열기 (맥: open / Windows: 탐색기 / 리눅스: xdg-open). 셸을 거치지 않아 파일 이름에 &·^ 가 있어도 안전."""
    if sys.platform == "darwin":
        subprocess.run(["open", "-R", str(p)] if reveal else ["open", str(p)], capture_output=True)
    elif os.name == "nt":
        if reveal:
            # explorer 는 '/select,"경로"' 를 한 덩어리로 받아야 공백·한글 경로에서도 그 파일이 선택된 채 열림
            subprocess.run(f'explorer /select,"{p}"', capture_output=True)
        else:
            os.startfile(str(p))   # noqa
    else:
        subprocess.run(["xdg-open", str(p.parent if reveal else p)], capture_output=True)


def open_path(body: dict) -> dict:
    rel = body.get("rel") or ""
    p = (M.SAVE_ROOT / rel).resolve()
    root = M.SAVE_ROOT.resolve()
    if p != root and root not in p.parents:
        return {"ok": False, "msg": "열 수 없는 위치예요."}
    if not p.exists():
        return {"ok": False, "msg": "파일이 없어요."}
    _os_open(p, bool(body.get("reveal")))
    return {"ok": True}


# ---------------------------------------------------------------- HTTP
class H(BaseHTTPRequestHandler):
    server_version = "LectureApp/1"

    def log_message(self, *a):
        pass

    def _send(self, code: int, body, ctype="application/json; charset=utf-8"):
        data = body if isinstance(body, bytes) else json.dumps(body, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def _host_ok(self) -> bool:
        """다른 사이트가 주소를 바꿔치기(DNS rebinding)해서 접근하지 못하게: 이 컴퓨터 주소로 온 요청만"""
        h = (self.headers.get("Host") or "").lower()
        return h in (f"127.0.0.1:{PORT}", f"localhost:{PORT}")

    def do_GET(self):
        global _last_hit
        if not self._host_ok():
            return self._send(403, {"ok": False, "msg": "forbidden"})
        _last_hit = time.time()
        u = urlparse(self.path)
        q = parse_qs(u.query)
        try:
            if u.path == "/":
                return self._send(200, HTML.read_bytes(), "text/html; charset=utf-8")
            # ---- 앱으로 설치(PWA): 크롬 창 대신 강의록앱 아이콘으로 뜨게
            if u.path == "/manifest.webmanifest":
                return self._send(200, json.dumps(MANIFEST, ensure_ascii=False).encode("utf-8"), "application/manifest+json")
            if u.path == "/sw.js":
                return self._send(200, SW_JS.encode("utf-8"), "text/javascript; charset=utf-8")
            m = re.fullmatch(r"/help-img/([a-z0-9_]+)\.webp", u.path)      # 도움말 탭 사진 (앱에 같이 들어 있는 예시 화면)
            if m:
                f = Path(__file__).parent / "assets" / "help" / f"{m.group(1)}.webp"
                if f.is_file():
                    return self._send(200, f.read_bytes(), "image/webp")
                return self._send(404, {"ok": False})
            m = re.fullmatch(r"/icon-(32|64|192|512)\.png", u.path)
            if m:
                return self._send(200, (Path(__file__).parent / "assets" / f"icon-{m.group(1)}.png").read_bytes(), "image/png")
            if u.path == "/api/ping":
                return self._send(200, {"ok": True, "app": "강의록앱"})
            if u.path == "/api/state":
                L = load(M.DATA / "시간표.json")
                return self._send(200, {
                    "now": f"{datetime.now():%Y-%m-%d %H:%M}", "today": f"{datetime.now():%m%d}",
                    "courses": [{"name": c, "folder": next(x.course_folder for x in L if x.course == c),
                                 "terms": sorted({x.term for x in L if x.course == c and x.term})} for c in tt_courses(L)],
                    "lectures": lectures_state(), "pending": len(_pending()), "pend_courses": _pend_courses(L),
                    "xlabels": [str(M.CFG.get("extras_label") or "").strip() or "올해"] + _old_labels(),
                    "app_updated": _app_updated(),
                    "version": _app_version(),
                    "ui_ver": str(HTML.stat().st_mtime_ns),     # 화면 파일이 바뀌면 새로고침 때 화면도 새로 불러옴
                    "setup_done": bool(M.CFG.get("setup_done", True)), "pwa_installed": _pwa_shim() is not None, "chrome": _has_chrome(), "platform": "mac" if sys.platform == "darwin" else ("win" if os.name == "nt" else "linux"),
                    "schedule": schedule_state(), "job": job_state(),
                    "lo": bool(render.soffice_bin()),
                    "grade": _grades.current()[0], "grades": [g["name"] for g in _grades.grades()],          # LibreOffice 있음 (없으면 PPT 강의록이 실패)
                    "save_root": str(M.SAVE_ROOT), "update": _upd_status()})
            if u.path == "/api/progress":
                return self._send(200, progress_state())
            if u.path == "/api/job":
                return self._send(200, job_state())
            if u.path == "/api/log":
                return self._send(200, read_log(int((q.get("offset") or ["0"])[0] or 0)))
            if u.path == "/api/events":
                return self._send(200, read_events(int((q.get("offset") or ["0"])[0] or 0)))
            if u.path == "/api/pending":
                return self._send(200, pending_state())
            if u.path == "/api/decided":
                return self._send(200, decided_state())
            if u.path == "/api/settings":
                return self._send(200, settings_state())
            if u.path == "/api/covers":
                return self._send(200, covers_state())
            if u.path == "/api/cover/preview":
                png = cover_preview((q.get("id") or [""])[0])
                return self._send(200, png, "image/png") if png else self._send(404, {"ok": False})
            if u.path == "/api/font/file":          # 설정 화면 글꼴 미리보기용 (넣은 글꼴 파일만)
                f = font_file(bool(q.get("default")), (q.get("f") or [""])[0])
                if not f:
                    return self._send(404, {"ok": False})
                ct = {".otf": "font/otf", ".ttc": "font/collection"}.get(f.suffix.lower(), "font/ttf")
                return self._send(200, f.read_bytes(), ct)
            if u.path == "/api/profs":
                return self._send(200, profs_state())
            if u.path == "/api/tt":
                return self._send(200, tt_state())
            if u.path == "/api/runs":
                return self._send(200, runs_list())
            if u.path == "/api/sched_runs":
                return self._send(200, sched_runs())
            if u.path == "/api/remote":                 # 휴대폰·아이패드에서 열기 (설정 화면)
                from . import remote
                return self._send(200, remote.state(bool(q.get("lite"))))
            if u.path == "/api/run":
                return self._send(200, {"text": run_text((q.get("name") or [""])[0])})
            if u.path == "/api/update":
                return self._send(200, _upd_status())
            return self._send(404, {"ok": False})
        except Exception as e:
            return self._fail(e)

    def _fail(self, e):
        import traceback
        sys.stderr.write(f"[{datetime.now():%H:%M:%S}] {self.path}\n{traceback.format_exc()}\n")
        sys.stderr.flush()
        perm = isinstance(e, PermissionError) or "Operation not permitted" in str(e)
        msg = ("데스크탑 폴더(매뉴얼 정리)에 접근할 권한이 없어요. 시스템 설정 → 개인정보 보호 및 보안 → "
               "파일 및 폴더 에서 ‘강의록앱’(또는 python)의 ‘데스크탑 폴더’를 켜 주세요.") if perm else M.err(e)
        return self._send(500, {"ok": False, "perm": perm, "msg": msg})

    def do_POST(self):
        global _last_hit
        if not self._host_ok():
            return self._send(403, {"ok": False, "msg": "forbidden"})
        _last_hit = time.time()
        # 다른 웹사이트가 이 주소로 몰래 요청하지 못하게: 화면이 붙이는 머리글이 있어야만 받음
        if self.headers.get("X-Lecture-App") != "1":
            return self._send(403, {"ok": False})
        n = int(self.headers.get("Content-Length") or 0)
        cap = 420 * 1024 * 1024 if self.path.split("?")[0] == "/api/manual" else 100 * 1024 * 1024   # 직접 올리기: 300MB 파일(base64)까지
        if n > cap:
            try:                    # 본문을 버리고 답해야 브라우저가 '연결 끊김' 대신 메시지를 받음
                left = n
                while left > 0:
                    chunk = self.rfile.read(min(left, 1 << 20))
                    if not chunk:
                        break
                    left -= len(chunk)
            except Exception:
                pass
            return self._send(413, {"ok": False, "msg": "파일이 너무 커요 (300MB까지)."})
        try:
            body = json.loads(self.rfile.read(n) or b"{}")
        except Exception:
            body = {}
        u = urlparse(self.path)
        try:
            fn = {"/api/start": start_job, "/api/stop": lambda b: stop_job(), "/api/pending": pending_set,
                  "/api/schedule": schedule_set, "/api/grade": grade_set, "/api/manual": manual_set, "/api/drive_list": drive_list, "/api/drive_check": drive_check, "/api/drive_check_old": drive_check_old, "/api/open": open_path,
                  "/api/tt/preview": tt_preview, "/api/tt/apply": tt_apply,
                  "/api/tt/past_preview": tt_past_preview, "/api/tt/past_apply": tt_past_apply, "/api/profs/set": profs_set,
                  "/api/cover/add": cover_add, "/api/cover/bg": cover_bg, "/api/cover/rename": cover_rename, "/api/cover/builder": cover_builder, "/api/cover/make": cover_make, "/api/cover/select": cover_select, "/api/cover/delete": cover_delete,
                  "/api/pending/open": pending_open, "/api/decided": decided_set, "/api/decided/open": decided_open,
                  "/api/settings": settings_set, "/api/secret": secret_set, "/api/setup_done": setup_done, "/api/font": font_set, "/api/pick_folder": pick_folder, "/api/open_browser": open_in_browser, "/api/restart": restart_app,
                  "/api/remote/set": _remote_set, "/api/remote/newcode": _remote_code, "/api/remote/forget": _remote_forget,
                  "/api/update/check": update_check, "/api/update/apply": update_apply, "/api/update/later": update_later,
                  "/api/update/schedule": update_schedule, "/api/update/rollback": update_rollback, "/api/update/auto": update_auto, "/api/noretry": noretry_api}.get(u.path)
            if u.path in ("/api/settings", "/api/secret", "/api/setup_done", "/api/font", "/api/schedule", "/api/grade", "/api/tt/apply",
                          "/api/tt/past_apply", "/api/profs/set", "/api/cover/select", "/api/cover/delete", "/api/cover/bg", "/api/cover/rename"):
                with M.CFG_LOCK:         # 설정 읽고-고치고-쓰기가 겹치지 않게
                    return self._send(200, fn(body)) if fn else self._send(404, {"ok": False})
            if not fn:
                return self._send(404, {"ok": False})
            return self._send(200, fn(body))
        except Exception as e:
            return self._fail(e)


def _remote_set(body: dict) -> dict:
    from . import remote
    return remote.set_enabled(bool(body.get("enabled")))


def _remote_code(body: dict) -> dict:
    from . import remote
    return {"ok": True, "code": remote.new_code()}


def _remote_forget(body: dict) -> dict:
    from . import remote
    ok = remote.forget(str(body.get("id") or ""))
    return {"ok": ok, "msg": "그 기기 연결을 끊었어요." if ok else "없는 기기예요."}


def _open_window(url: str):
    """앱 창 열기: 크롬에서 '앱 설치'를 했으면 그 앱(강의록앱 아이콘)으로, 아니면 주소창 없는 크롬·엣지 창, 없으면 기본 브라우저"""
    shim = _pwa_shim()
    if shim:
        try:
            if sys.platform == "darwin":
                if subprocess.run(["open", "-a", str(shim)], capture_output=True).returncode == 0:
                    return
            elif os.name == "nt":
                os.startfile(str(shim))   # noqa
                return
        except Exception:
            pass
    if sys.platform == "darwin":
        for app in ("Google Chrome", "Chromium", "Microsoft Edge", "Brave Browser"):
            r = subprocess.run(["open", "-na", app, "--args", f"--app={url}", "--window-size=1440,920"],
                               capture_output=True)
            if r.returncode == 0:
                return
        subprocess.run(["open", url])
        return
    if os.name == "nt":
        cands = [Path(os.environ.get(v, "")) / sub for v in ("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA")
                 for sub in ("Google/Chrome/Application/chrome.exe", "Microsoft/Edge/Application/msedge.exe")]
        for exe in cands:
            if exe.is_file():
                subprocess.Popen([str(exe), f"--app={url}", "--window-size=1440,920"])
                return
    import webbrowser
    webbrowser.open(url)


def _already_running(url: str) -> bool:
    try:
        with urllib.request.urlopen(url + "api/ping", timeout=1.5) as r:
            return b"ok" in r.read()
    except Exception:
        return False


def open_only() -> int:
    """앱 창만 열기 (화면 서버가 켜질 때까지 잠깐 기다림). 앱 아이콘을 눌렀을 때 씀."""
    url = f"http://127.0.0.1:{PORT}/"
    for _ in range(40):
        if _already_running(url):
            break
        time.sleep(0.25)
    _open_window(url)
    return 0


_SRV = [None]


_REEXEC = [False]


def _reexec(srv):
    """새 코드로 다시 켜기 요청: 서버를 깔끔히 멈추게 하고(serve 가 끝난 뒤 _do_reexec 가 실제로 다시 켬).
    다른 스레드에서 소켓을 바로 닫으면 윈도우에서 serve_forever 가 오류로 끝나 '오류가 났어요' 알림이 뜸"""
    _REEXEC[0] = True
    srv.shutdown()


def _do_reexec():
    """같은 방식(상주 등)으로 새 프로세스로 다시 켬. 창은 이미 떠 있으니 새로 열지 않음."""
    argv = list(getattr(sys, "orig_argv", []) or []) or [sys.executable, "-m", "lecture_app"] + sys.argv[1:]
    argv[0] = sys.executable
    if "--창없이" not in argv:
        argv.append("--창없이")
    if os.name == "nt":      # 윈도우 execv 는 공백·한글 경로 인자가 깨져서 새로 띄우고 끝냄
        subprocess.Popen(argv, creationflags=0x00000008 | 0x00000200, close_fds=True)
        os._exit(0)
    os.execv(sys.executable, argv)


# ---------------------------------------------------------------- 앱 업데이트 (GitHub 릴리스 · 서명 확인)
def _upd_status() -> dict:
    try:
        from . import updater
        return updater.status()
    except Exception as e:
        return {"enabled": False, "err": str(e)[:200]}


def update_check(body: dict) -> dict:
    from . import updater
    return updater.check(force=bool(body.get("force")), opening=bool(body.get("opening")))


def _busy_locked() -> bool:
    """업데이트가 받기 시작과 겹치지 않게: 받기 시작(start_job)과 같은 잠금 안에서 확인"""
    with _lock:
        return _busy()


def _reexec_later():
    srv = _SRV[0]
    if not srv:
        return

    def later():
        time.sleep(1.2)          # 응답을 먼저 보내고
        for _ in range(3600):    # 그 사이 받기가 시작됐으면 끝날 때까지 기다렸다가 (받기는 따로 도는 프로그램이라 새 코드와 상관없음)
            if not _busy():
                break
            time.sleep(2)
        try:
            _reexec(srv)
        except Exception as e:
            sys.stderr.write(f"다시 켜기 실패: {e}\n")
    threading.Thread(target=later, daemon=True).start()


def update_apply(body: dict) -> dict:
    from . import updater
    r = updater.apply(busy=_busy_locked)
    if r.get("ok"):
        _reexec_later()
    return r


def noretry_api(body: dict) -> dict:
    key, side = str(body.get("key") or ""), str(body.get("side") or "")
    if side not in ("LMS", "드라이브") or not key:
        return {"ok": False, "msg": "잘못된 요청이에요."}
    if key not in {L.key for L in load(M.DATA / "시간표.json")}:
        return {"ok": False, "msg": "시간표에 없는 강의예요."}
    on = bool(body.get("on"))
    M.noretry_set(key, side, on, str(body.get("why") or ""))
    return {"ok": True, "msg": f"이 강의의 {side} 자료는 다음 받기부터 다시 시도하지 않아요" if on
            else f"이 강의의 {side} 자료를 다음 받기 때 다시 시도해요"}


def update_later(body: dict) -> dict:
    from . import updater
    return updater.later()


def update_schedule(body: dict) -> dict:
    from . import updater
    at = str(body.get("at") or "").strip()
    return updater.set_schedule(at or None)


def update_auto(body: dict) -> dict:
    from . import updater
    return updater.set_auto(bool(body.get("on")))


def update_rollback(body: dict) -> dict:
    from . import updater
    r = updater.rollback(busy=_busy_locked)
    if r.get("ok"):
        _reexec_later()
    return r


def _update_loop():
    """상주 중: 3시간마다 새 버전 확인, 예약 시각이 지났고 받기가 없으면 업데이트"""
    time.sleep(30)
    fail_at = 0.0
    while True:
        try:
            from . import updater
            updater.check()
            if updater.due() and not _busy() and time.time() - fail_at > 6 * 3600:     # 실패하면 6시간 뒤에 다시
                r = updater.apply(busy=_busy_locked)
                if r.get("ok"):
                    _reexec_later()
                    return
                fail_at = time.time()
        except Exception as e:
            sys.stderr.write(f"업데이트 확인 실패: {e}\n")
        time.sleep(600)


def restart_app(body: dict) -> dict:
    """설정 → 앱 다시 켜기 (업데이트가 바로 안 보이거나 화면이 이상할 때)"""
    if _busy():
        return {"ok": False, "msg": "받기가 진행 중이에요. 끝난 뒤에 다시 켜 주세요."}
    srv = _SRV[0]
    if not srv:
        return {"ok": False, "msg": "다시 켤 수 없어요. 앱을 닫았다가 다시 열어 주세요."}

    def later():
        time.sleep(0.6)          # 응답을 먼저 보내고
        try:
            _reexec(srv)
        except Exception as e:
            sys.stderr.write(f"다시 켜기 실패: {e}\n")
    threading.Thread(target=later, daemon=True).start()
    return {"ok": True, "msg": "다시 켜는 중이에요…"}


def serve(open_window: bool = True, stay: bool = False) -> int:
    url = f"http://127.0.0.1:{PORT}/"
    try:
        if not _external_running():     # 예약 받기가 기록을 쓰는 중이면 그때는 건너뜀 (받기가 시작할 때 함)
            M.migrate_layout()          # 예전 폴더 배치 → 1. 매뉴얼 / 2. 추가자료 · 예전 추가자료 파일 이름
    except Exception as e:
        sys.stderr.write(f"폴더 옮기기 실패: {e}\n")
    if _already_running(url):
        if open_window:
            _open_window(url)
        return 0
    srv = ThreadingHTTPServer(("127.0.0.1", PORT), H)
    srv.daemon_threads = True
    _SRV[0] = srv
    threading.Thread(target=_fix_user_fonts, daemon=True).start()      # 예전에 넣은 CFF 글꼴 → TTF

    def idle():
        while True:
            time.sleep(60)
            busy = _job["proc"] is not None and _job["proc"].poll() is None
            if not busy and time.time() - _last_hit > IDLE_LIMIT:
                srv.shutdown()
                return
    def code_mtime():
        try:
            return max(f.stat().st_mtime for f in Path(__file__).parent.glob("*.py"))
        except Exception:
            return 0

    def reload_on_update():
        """상주 중에 앱 코드가 바뀌면(업데이트) 받기가 없을 때 새 코드로 다시 켬 → 껐다 켤 필요 없음"""
        base = code_mtime()
        while True:
            time.sleep(10)
            m = code_mtime()
            if m == base or _busy():
                continue
            time.sleep(3)            # 파일 여러 개가 바뀌는 중일 수 있어 잠깐 기다림
            if code_mtime() != m:
                continue
            try:
                _reexec(srv)
            except Exception as e:
                sys.stderr.write(f"새 코드로 다시 켜기 실패: {e}\n")
                base = m
    threading.Thread(target=_update_loop, daemon=True).start()      # 새 버전 확인 (3시간마다) · 예약 업데이트
    if not stay:                 # --상주: 로그인할 때부터 켜 두면 Dock의 강의록앱 아이콘이 언제 눌러도 바로 열림
        threading.Thread(target=idle, daemon=True).start()
    else:
        threading.Thread(target=reload_on_update, daemon=True).start()
        if sys.platform == "darwin" or os.name == "nt":     # 맥 메뉴 막대 / 윈도우 알림 영역 현황 아이콘 (설정에서 끌 수 있음)
            def _mb():
                time.sleep(2)
                try:
                    from . import menubar
                    if menubar.running_pid():        # 앱이 새로 켜졌으면(업데이트 등) 메뉴 막대도 새 코드로
                        menubar.stop()
                        time.sleep(1.5)
                    menubar.launch()
                except Exception as e:
                    sys.stderr.write(f"메뉴 막대 띄우기 실패: {e}\n")
            threading.Thread(target=_mb, daemon=True).start()
    try:                                     # 휴대폰·아이패드에서 열기를 켜 뒀으면 그 문도 엶
        from . import remote
        if remote.enabled():
            threading.Thread(target=remote.start, daemon=True).start()
    except Exception as e:
        sys.stderr.write(f"다른 기기용 화면 켜기 실패: {e}\n")
    if open_window:
        threading.Timer(0.4, _open_window, args=(url,)).start()
    print(f"강의록앱 화면: {url}" + ("" if stay else "  (창을 닫고 15분 지나면 저절로 꺼져요)"), flush=True)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    try:
        from . import remote
        remote.stop()
    except Exception:
        pass
    if _REEXEC[0]:
        try:
            srv.server_close()
        except Exception:
            pass
        _do_reexec()
    return 0
