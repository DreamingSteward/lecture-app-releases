"""강의록앱 화면: 이 맥에서만 열리는 작은 웹 화면 (현황판 + 받기 + 애매한 자료 + 예약 + 실행 기록).

`강의록앱 화면` → http://127.0.0.1:8765 를 열고 Chrome 앱 창(없으면 기본 브라우저)으로 띄운다.
창을 닫고 15분 동안 아무 요청이 없고 받는 중도 아니면 스스로 꺼진다.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import re
import signal
import subprocess
import sys
import threading
import time
import urllib.request
from datetime import date, datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Dict, List, Optional
from urllib.parse import parse_qs, quote, urlparse

from . import main as M
from . import grades as _grades
from . import render
from .matching import Item, Memory, safe_replace
from .timetable import YEAR_KEY, courses as tt_courses, load, norm_course

PORT = 8765
WEB_ORIGIN = "https://lecture-app-knu.pages.dev"   # 웹앱 주소 (컴퓨터 앱이 켜져 있는지만 물어봄)
HTML = Path(__file__).with_name("gui.html")
JOB_LOG = M.APP / "logs" / "화면실행.log"
IDLE_LIMIT = 15 * 60
WEEK = "월화수목금토일"

_job: Dict = {"proc": None, "started": None, "args": [], "label": ""}
_last_hit = time.time()
_lock = threading.Lock()


# ---------------------------------------------------------------- 현황
def _year_for(L) -> int:
    from .timetable import cal_year
    return cal_year(L.month)       # 학기 이름표 기준 (오늘 날짜와 상관없이)


def _rel(p: Path) -> str:
    return M.rel_of(p)          # 저장 위치를 바꾼 과목은 원래 자리 경로로


def _app_version() -> str:
    try:
        return (M.APP / "VERSION").read_text("utf-8").strip()[:40]
    except Exception:
        return ""


XSKIP_F = "시험제외.json"         # 시험에 안 나오는 강의 (강좌별 교수 표의 ✕ · 홈 카드 ✕ · 휴대폰에서도): [강의 key]
_XSKIP_LOCK = threading.Lock()
_VIEW = {"iso": "", "n": 0, "by": "", "at": 0.0}     # 홈 시간표에서 지금 맨 위에 둔 날짜 (컴퓨터·폰이 서로 따라감 · 메모리에만)
_VIEW_LOCK = threading.Lock()


def view_set(body: dict) -> dict:
    iso = str(body.get("iso") or "")
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", iso):
        return {"ok": False}
    with _VIEW_LOCK:
        if iso != _VIEW["iso"]:
            _VIEW.update(iso=iso, n=_VIEW["n"] + 1, by=str(body.get("by") or "")[:40], at=time.time())
        return {"ok": True, "n": _VIEW["n"]}


def _xskips() -> set:
    try:
        v = json.loads((M.DATA / XSKIP_F).read_text("utf-8"))
        return {str(x) for x in v} if isinstance(v, list) else set()
    except Exception:
        return set()


def xskip_set(body: dict) -> dict:
    """시험에 안 나옴 표시 켜기·끄기 {keys: [...], on: bool}"""
    keys = [k for k in (body.get("keys") or []) if isinstance(k, str) and 0 < len(k) <= 300][:400]
    if not keys:
        return {"ok": False, "msg": "강의를 고르지 않았어요"}
    on = bool(body.get("on"))
    with _XSKIP_LOCK:
        cur = _xskips()
        cur = (cur | set(keys)) if on else (cur - set(keys))
        if on and len(cur) > 5000:                     # 휴대폰에서 끝없이 쌓이지 않게: 지금 시간표에 있는 강의만 남김
            have = {L.key for L in load(M.DATA / "시간표.json")}
            cur = {k for k in cur if k in have}
        f = M.DATA / XSKIP_F
        try:
            tmp = f.with_name(f.stem + ".tmp")
            tmp.write_text(json.dumps(sorted(cur), ensure_ascii=False, indent=1), "utf-8")
            safe_replace(tmp, f)
        except Exception as e:
            return {"ok": False, "msg": f"저장하지 못했어요: {M.err(e)}"}
    return {"ok": True, "keys": sorted(cur)}


def rev_get() -> dict:
    """바뀜 확인용 작은 신호: 시험 제외 · 화면 설정 · 시간표 · 옮긴 강의 · 현황 파일의 수정 시각 (휴대폰·컴퓨터가 3초마다 물어봄)"""
    parts = []
    for f in (M.DATA / XSKIP_F, _prefs_path(), M.DATA / "시간표.json", M.DATA / MOVED_F, M.STATUS):
        try:
            st = f.stat()
            parts.append(f"{st.st_mtime_ns}:{st.st_size}")
        except Exception:
            parts.append("-")
    with _VIEW_LOCK:
        v = {"iso": _VIEW["iso"], "n": _VIEW["n"], "by": _VIEW["by"], "age": round(time.time() - _VIEW["at"]) if _VIEW["at"] else None}
    return {"ok": True, "r": hashlib.md5("|".join(parts).encode()).hexdigest()[:12], "v": v}


def lectures_state() -> List[dict]:
    _xrec.clear()
    xs_ = _xskips()
    lectures = load(M.DATA / "시간표.json")
    try:
        status = json.loads(M.STATUS.read_text("utf-8")) if M.STATUS.exists() else {}
    except Exception:
        status = {}
    recs_cache: Dict[Path, Dict[str, dict]] = {}
    now = datetime.now()
    try:                                  # 설정을 바꿨으면 바로 반영 (표지·용지·글꼴이 예전 설정인 강의록 표시용)
        M.CFG.update(M.read_cfg())
        M.reload_roots()
    except Exception:
        pass
    try:
        tag = M.fmt_tag()
    except Exception:
        tag = ""
    out = []
    pend_all = _pending()
    pend_keys = {k for e in pend_all for k in (e.get("candidates") or [])}   # 아직 골라 줘야 하는 애매한 자료의 후보 강의
    pend_lk = {k for e in pend_all if not str(e.get("source", "")).startswith("필야") for k in (e.get("candidates") or [])}   # 받기 칸 보라 칸 (강의록)
    pend_xk = {k for e in pend_all if str(e.get("source", "")) == "필야" for k in (e.get("candidates") or [])}                 # (올해 추가자료 · 선배 학번 자료는 빼고)
    picked: Dict[str, set] = {}        # 내가 골라 준 자료: 강의 key → {"LMS", "드라이브"}
    skipped: set = set()               # 다시 받지 않기로 한 파일 (출처:uid)
    nr_all = M.noretry_load()          # 다시 시도하지 않기로 한 강의·출처
    try:
        mem = json.loads((M.DATA / "매칭기억.json").read_text("utf-8-sig"))
        for uk, v in (mem.items() if isinstance(mem, dict) else []):
            if v == "제외":
                skipped.add(uk)
            side = {"강의실": "LMS", "게시판": "LMS", "드라이브": "드라이브"}.get(str(uk).split(":", 1)[0])
            if side and isinstance(v, str):
                for k in v.split("||"):
                    picked.setdefault(k, set()).add(side)
    except Exception:
        pass
    moved = _moved()
    for L in lectures:
        y = _year_for(L)
        try:
            day = date(y, L.month, L.day)
        except ValueError:
            continue
        d, name = M.out_dir(L), M.out_name(L)
        if d not in recs_cache:
            recs_cache[d] = _safe_records(d) or {}
        rec = recs_cache[d].get(name) or {}
        f = d / name
        refs = d / (name[:-4] + "_참고자료")
        fd = d / name[:-4]                       # 강의록 여러 개를 따로 만든 폴더
        sp = M.split_parts(rec)
        pfiles = [(i + 1, fd / x["f"], x) for i, x in enumerate(sp) if (fd / x["f"]).is_file()] if fd.is_dir() else []
        st = status.get(L.key) or {}
        exists = f.exists() or bool(pfiles)
        note = rec.get("비고") or st.get("비고") or ""
        updated = False
        if exists:
            s = rec.get("상태") or "완료"
            updated = (s == "갱신" or "재업로드 반영" in note) and "직접 넣은 자료" not in note
            s = "완료"   # 드라이브 자료로 만든 것·재업로드로 갱신된 것도 '완료' (비고에 따로 적힘. LMS 확인은 계속)
        elif st.get("처리 여부"):
            s = st["처리 여부"]
            if s == "자료 없음" and "학습 기간 종료" in note:     # 예전 버전이 저장한 것도 실패로
                s = "실패"
        else:
            s = "미확인" if day <= now.date() else "예정"
        if s == "완료" and not exists:
            s = "미확인"
        parts = [x for x in (rec.get("출처") or "").split("+") if x]
        src = " + ".join(dict.fromkeys(parts)) + (f" · {len(parts)}개" if len(parts) > 1 else "")
        merged = 0
        if f.exists():                  # 자료 여러 개를 합친 강의록 (예전에 만든 것도 기록의 원본 파일 이름으로)
            names = [x.strip() for x in (rec.get("원본파일명") or "").split(" + ") if x.strip()]
            try:
                ref_names = {x.name for x in refs.iterdir()} if refs.is_dir() else set()
            except OSError:
                ref_names = set()
            mains = [n for n in names if M.safe(Path(n).name) not in ref_names and Path(n).name not in ref_names]
            merged = len(mains) if len(mains) > 1 else 0
            if merged and "개 합침" not in note:
                nm = [Path(n).stem if len(Path(n).stem) <= 24 else Path(n).stem[:23] + "…" for n in mains]
                note = "; ".join(x for x in (note, f"강의록 {merged}개 합침: " + " + ".join(nm)) if x)
        srcs = {k: dict(v) for k, v in _src_state(st, parts).items()}
        for v in srcs.values():          # 예전 버전이 노란 주의로 저장한 실패(학습 기간 종료·다운로드/변환 실패) → 실패(빨강)
            w = v.get("이유") or ""
            if v.get("상태") == "주의" and ("학습 기간 종료" in w or w.startswith("다운로드 실패") or "대신 만듦" in w):
                v["상태"] = "실패"
        for side, v in srcs.items():     # 애매한 자료를 이미 골라 줬으면 경고를 내림 (다음 받기 때 다시 확인)
            used = exists and any(("LMS" if p_ in ("강의실", "게시판") else p_) == side for p_ in parts)
            if side in picked.get(L.key, set()) and v.get("상태") != "존재" and used:
                v.update({"상태": "존재", "이유": "애매한 자료를 이 강의로 골라 줬어요"})      # 골라 준 자료로 만들었으면 ○
            elif "애매한 자료" in (v.get("이유") or "") and L.key not in pend_keys:
                if side in picked.get(L.key, set()):
                    v.update({"상태": "", "이유": "애매한 자료를 이 강의로 골라 줬어요 · 다음 받기 때 받아요"})
                else:
                    v.update({"상태": "비존재", "이유": "애매한 자료를 다른 강의로 골라 줬어요"})
        for side, v in srcs.items():     # 다시 시도하지 않기로 한 출처
            if side in nr_all.get(L.key, {}):
                v["다시안함"] = True
                if v.get("상태") != "실패":
                    v.update({"상태": "실패", "이유": "다시 시도하지 않기로 했어요 (다음 받기부터 건너뜀)"})
        out.append({
            "key": L.key, "course": L.course, "folder": L.course_folder, "term": L.term, "xs": 1 if L.key in xs_ else 0,
            "mmdd": L.mmdd, "date": day.isoformat(), "wd": WEEK[day.weekday()],
            "start": L.start, "hours": L.hours,
            "period": L.period_label, "h0": L.halves()[0], "h1": L.halves()[1], "moved": _mv_show(moved.get(L.key), L),
            "title": L.title, "profs": L.profs,
            "hist": [[yy, ps] for yy, ps in L.history() if yy != YEAR_KEY],
            "status": s, "updated": updated, "note": note, "source": src,
            "pend": 1 if L.key in pend_lk else 0, "pendx": 1 if L.key in pend_xk else 0,
            "file": _rel(f) if f.exists() else (_rel(fd) if pfiles else ""), "refs": _rel(refs) if refs.exists() else "",
            "merged_file": _rel(f) if f.exists() else "",
            "parts": [{"n": n, "rel": _rel(pf), "src": x.get("src") or "", "up": x.get("up") or ""} for n, pf, x in pfiles],
            "pdir": _rel(fd) if fd.is_dir() else "",
            "srcfiles": [{**x, "skip": x["id"] in skipped} for x in _src_files(rec, sp)] if exists else [],
            "manual": [x.name for x in M.manual_files(L)],
            "lms": st.get("LMS 업로드") or "", "drive": st.get("드라이브 업로드") or "",
            "srcs": srcs, "merged": merged,
            "web": [w for w in (st.get("web") or []) if isinstance(w, dict) and str(w.get("u", "")).startswith("https://drive.google.com/")] if not exists else [],
            "extra": _extra_state(L, st),
            "xold": {lab: _extra_state(L, st, lab) for lab in _old_labels()},
            "latest": st.get("최신 강의록") or "", "checked": st.get("확인시각") or "",
            "processed": rec.get("처리일시") or "",
            "stale": bool(exists and tag and rec.get("서명") and rec["서명"].split(" || ")[0] != tag),
        })
    return out



def _exams_state(L) -> list:
    """시험 일정: 시간표를 넣을 때 저장한 시험일정.json > 앱에 넣어 둔 assets/exams.json (과목마다) · 홈 시간표에만 보임 · 현황·받기에는 안 섞임"""
    try:
        from .timetable import cal_year
        data = json.loads((Path(__file__).parent / "assets" / "exams.json").read_text(encoding="utf-8")).get(str(YEAR_KEY)) or {}
        try:
            mine = json.loads(_exams_path().read_text("utf-8")).get(str(YEAR_KEY)) or {}
            if isinstance(mine, dict):
                data = {**data, **{k: v for k, v in mine.items() if isinstance(v, list)}}
        except Exception:
            pass
        names = set(tt_courses(L))
        p1 = _period1()
        try:
            _h, _m = (int(v) for v in p1.split(":")[:2])
        except Exception:
            _h, _m = 8, 30
        p1m = _h * 60 + _m
        out = []
        for c, xs in data.items():
            if (c not in names and c != "공통") or not isinstance(xs, list):     # 공통 = 과목 없는 학년 전체 시험
                continue
            for x in xs:
                try:            # 한 줄이 잘못돼도 나머지 시험은 보이게
                    mo, dd = (int(v) for v in str(x["d"]).split("/")[:2])
                    tt_ = [int(h) * 60 + int(mi) for h, mi in re.findall(r"(\d{1,2}):(\d{2})", str(x.get("t") or ""))]
                    h0 = h1 = 0
                    if len(tt_) > 1 and tt_[1] <= tt_[0]:
                        tt_ = tt_[:1]            # 끝이 시작보다 빠르면 끝은 버림
                    shown = list(tt_)            # 카드에 보일 시각은 적힌 그대로
                    if tt_ and tt_[0] < p1m:     # 1교시 전에 시작: 칸은 1교시부터 (끝이 1교시 전이면 1시간)
                        tt_ = [p1m] + ([tt_[1]] if len(tt_) > 1 and tt_[1] > p1m else [])
                    if tt_:                      # 시각 → 30분 칸 (1교시 시작 기준 · 끝이 없으면 1시간)
                        s_, e_ = tt_[0], (tt_[1] if len(tt_) > 1 else tt_[0] + 60)
                        h0 = max(1, (s_ - p1m) // 30 + 1)
                        h1 = max(h0, -(-(e_ - p1m) // 30))
                    gs = [int(v) for v in re.findall(r"\d+", str(x.get("g") or ""))]
                    if gs:
                        st, en = gs[0], (gs[-1] if len(gs) > 1 else gs[0])
                    else:
                        st, en = (h0 + 1) // 2 or 1, (h1 + 1) // 2 or 1
                    day = date(cal_year(mo), mo, dd)
                    lab = str(x.get("l") or "시험")
                    e = {"id": f"{c}|{lab}|{mo:02d}{dd:02d}", "course": c, "label": lab,      # 시험 시간 기록 키: 순서가 바뀌어도 그대로
                         "mmdd": f"{mo:02d}{dd:02d}", "date": day.isoformat(), "start": st, "hours": max(1, en - st + 1)}
                    if tt_:
                        e.update({"h0": h0, "h1": h1, "ts": f"{shown[0] // 60:02d}:{shown[0] % 60:02d}",
                                  "te": f"{shown[1] // 60:02d}:{shown[1] % 60:02d}" if len(shown) > 1 else ""})
                    out.append(e)
                except Exception:
                    continue
        return out
    except Exception:
        return []

def _src_files(rec: dict, sp: list) -> list:
    """이 강의록을 만든 원본 파일들: [{"id": "출처:uid", "name": 원본 이름, "side": LMS|드라이브|직접, "n": 따로 만든 번호}]"""
    names = [x.strip() for x in (rec.get("원본파일명") or "").split(" + ")]
    sig = M._sig_items(rec.get("서명") or "") if rec.get("서명") else []
    ids = [":".join(x.split(":", 2)[:2]) for x in sig]
    ups = [re.sub(r"~(본|보조)$", "", x.split(":", 2)[2]) if x.count(":") >= 2 else "" for x in sig]
    num = {x.get("id"): i + 1 for i, x in enumerate(sp)}
    out = []
    for i, nm in enumerate(names):
        if not nm:
            continue
        sid = ids[i] if i < len(ids) and len(ids) == len(names) else ""
        src = sid.split(":", 1)[0] if sid else ""
        side = "LMS" if src in ("강의실", "게시판") else "드라이브" if src == "드라이브" else "직접" if src == "직접" else ""
        out.append({"id": sid, "name": nm, "side": side, "n": num.get(sid, 0),
                    "up": ups[i] if i < len(ups) and len(ids) == len(names) and ups[i] != "*" else ""})
    return out


def _src_state(st: dict, parts: List[str]) -> dict:
    """출처별 상태. 받기를 한 번 돌린 뒤엔 저장된 값, 그 전엔 만든 파일의 출처·업로드 날짜로 짐작."""
    cs = st.get("출처상태")
    if cs:
        return cs
    out = {}
    for side, has, date in (("LMS", any(x in ("강의실", "게시판") for x in parts), st.get("LMS 업로드")),
                            ("드라이브", "드라이브" in parts, st.get("드라이브 업로드"))):
        if has or date:
            out[side] = {"상태": "존재", "이유": "", "날짜": date or "", "개수": 0}
        elif st:
            out[side] = {"상태": "비존재", "이유": "", "날짜": "", "개수": 0}
        else:
            out[side] = {"상태": "", "이유": "아직 확인 안 함", "날짜": "", "개수": 0}
    return out


_xrec: Dict[Path, Dict[str, dict]] = {}


MANIFEST = {
    "name": "강의록앱", "short_name": "강의록앱", "id": "/", "start_url": "/", "scope": "/",
    "display": "standalone", "background_color": "#EEF1F0", "theme_color": "#0E6B63",
    "description": "LMS·드라이브 강의록·추가자료를 받아 정리하는 앱",
    "icons": [{"src": "/icon-192.png", "sizes": "192x192", "type": "image/png"},
              {"src": "/icon-512.png", "sizes": "512x512", "type": "image/png"},
              {"src": "/icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "maskable"}],
}
# 설치 조건용 아주 작은 서비스 워커 (아무것도 저장하지 않고 그대로 통과)
SW_JS = "self.addEventListener('install',e=>self.skipWaiting());self.addEventListener('activate',e=>self.clients.claim());" \
        "self.addEventListener('fetch',e=>{});"


def _pwa_shim() -> Optional[Path]:
    """크롬에서 '앱 설치'를 했으면 생기는 강의록앱 실행 파일 (맥: ~/Applications/Chrome Apps / Windows: 시작 메뉴 바로가기)"""
    cands = []
    if sys.platform == "darwin":
        for d in ("Chrome Apps.localized", "Chrome Apps", "Edge Apps.localized", "Edge Apps"):
            cands.append(Path.home() / "Applications" / d / "강의록앱.app")
    elif os.name == "nt":
        sm = Path(os.environ.get("APPDATA", "")) / "Microsoft" / "Windows" / "Start Menu" / "Programs"
        cands += [sm / "Chrome Apps" / "강의록앱.lnk", sm / "강의록앱 (Chrome).lnk", sm / "Edge Apps" / "강의록앱.lnk"]
    hit = next((c for c in cands if c.exists()), None)
    if hit or sys.platform != "darwin":
        return hit
    return _safari_webapp()


def _safari_webapp() -> Optional[Path]:
    """맥 사파리 '파일 → Dock에 추가'로 만든 웹 앱 (~/Applications/*.app 중 이 앱 주소를 연 것)"""
    d = Path.home() / "Applications"
    try:
        for a in d.glob("*.app"):
            for f in list((a / "Contents").glob("*.plist")) + list((a / "Contents").glob("*/*.plist"))[:20]:
                try:
                    b = f.read_bytes()
                except Exception:
                    continue
                if b"127.0.0.1:8765" in b or b"localhost:8765" in b:
                    return a
    except Exception:
        pass
    return None


def _has_chrome() -> bool:
    """주소창 없는 앱 창을 띄울 크롬 계열 브라우저가 있는지 (없으면 맥은 사파리로 열림)"""
    if sys.platform == "darwin":
        names = ("Google Chrome", "Microsoft Edge", "Chromium", "Brave Browser")
        return any((r / f"{n}.app").exists() for r in (Path("/Applications"), Path.home() / "Applications") for n in names)
    if os.name == "nt":
        return any((Path(os.environ.get(v, "")) / sub).is_file() for v in ("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA")
                   for sub in ("Google/Chrome/Application/chrome.exe", "Microsoft/Edge/Application/msedge.exe"))
    return True


def _app_updated() -> str:
    """앱 파일이 마지막으로 바뀐 날짜·시각 (하단 '최종 수정' 표시용)"""
    try:
        t = max(f.stat().st_mtime for f in Path(__file__).parent.glob("*.*") if f.suffix in (".py", ".html"))
        return datetime.fromtimestamp(t).strftime("%Y-%m-%d %H:%M")
    except Exception:
        return ""


def _old_labels() -> List[str]:
    return [str(s["label"]).strip() for s in M.old_sources()]


def _xord(labs: List[str]) -> List[int]:
    """추가자료 칸 순서 (설정에서 위에 둘수록 왼쪽): xlabels 의 번호 목록 · 0 = 우리 학번"""
    od = list(M.CFG.get("extras_order") or [])
    if od and "@own" not in od:
        od.insert(0, "@own")             # 우리 학번이 순서에 없으면 맨 앞
    out = []
    for k in od:
        i = 0 if k == "@own" else (labs.index(k, 1) if k in labs[1:] else -1)
        if i >= 0 and i not in out:
            out.append(i)
    return out + [i for i in range(len(labs)) if i not in out]


def _safe_records(d):
    """화면 표시용: 기록을 못 읽으면(iCloud 동기화 중 등) 빈 것으로 보여 주고 화면은 계속 (다음 새로고침 때 다시 읽음)"""
    try:
        return M.read_records(d, tries=2)
    except Exception:
        return None


def _extra_state(L, st: dict, label: str = "") -> dict:
    """필야(추가자료) 상태: 파일이 있으면 기록의 상태(완료/검수 전), 없으면 지난 받기 결과"""
    d, name = M.extra_dir(L, label), M.extra_name(L, label)
    recs = _xrec.get(d)
    if recs is None:
        recs = _safe_records(d)
        if recs is not None:
            _xrec[d] = recs
        else:
            recs = {}
    rec = recs.get(name) or {}
    x = dict((st.get("선배필야") or {}).get(label) or {}) if label else dict(st.get("필야") or {})
    if x.get("links"):                 # 내 컴퓨터 폴더로 연결한 선배 자료: 이름과 연결한 폴더 기준 위치만 보냄 (열기는 /api/open_linked)
        root = next((s_.get("local") for s_ in M.old_sources() if str(s_.get("label", "")).strip() == label and s_.get("local")), "")
        rp = Path(os.path.expanduser(root)) if root else None

        roots_ = M.local_roots(label)

        def _loc(p_):                  # 고른 폴더 이름부터 보이게 (내 폴더 밖에서 직접 고른 폴더도)
            for r_ in roots_:
                try:
                    return str(Path(r_.name) / Path(p_).relative_to(r_))
                except ValueError:
                    continue
            return Path(p_).name
        links = x.pop("links")
        x["local"] = [{"n": Path(p_).name, "p": _loc(p_)} for p_ in links]
        x["icloud"] = bool(rp and "Mobile Documents" in str(rp))     # 아이클라우드 드라이브 안 → 폰 「파일」 앱에서도 같은 위치
        try:                                   # 클라우드 복사에 선배 추가자료를 켜 뒀으면: 드라이브에 올라간 자리
            from . import cloud as _c
            cds = [(k, d) for k, d in _c.copy_dirs().items() if _c.scope(k).get("xold")]
            if cds:
                k0, d0 = cds[0]
                xd = M.extra_dir(L, label)
                x["cloud"] = {"kind": k0, "dir": Path(d0).name, "files": [M.rel_of(xd / Path(p_).name) for p_ in links]}
        except Exception:
            pass
        return x
    f = d / name
    if x.get("web"):                   # 인터넷으로만 보기: 받지 않은 드라이브 자료 링크 (드라이브 주소만)
        x["web"] = [w for w in x["web"] if isinstance(w, dict) and str(w.get("u", "")).startswith("https://drive.google.com/")]
    if f.exists():
        x.pop("web", None)
        x["상태"] = rec.get("상태") or x.get("상태") or "완료"
        x["file"] = _rel(f)
        x["비고"] = rec.get("비고") or ""
        x["처리"] = rec.get("처리일시") or ""
        # 이 필야를 만든 자료 (애매한 자료의 '고치기'로 다른 강의로 옮길 수 있게)
        x["mkeys"] = [":".join(k.split(":")[:2]) for k in M._sig_items(rec.get("서명") or "")
                      if k.count(":") >= 2 and k.split(":")[0] and k.split(":")[1]]
        # 드라이브 원본 (휴대폰에서 컴퓨터·클라우드 복사본 없이도 원래 공유 폴더의 파일로 열기)
        nms = [n.strip() for n in (rec.get("원본파일명") or "").split(" + ")]
        x["orig"] = [{"id": k.split(":")[1], "name": nms[i] if i < len(nms) and len(nms) == len(x["mkeys"]) else ""}
                     for i, k in enumerate(x["mkeys"]) if k.startswith("필야") and re.fullmatch(r"[\w-]{10,}", k.split(":")[1])]
    return x


def _pending() -> list:
    """확인필요.json → [항목 dict] (모양이 이상해도 화면이 멈추지 않게: 리스트·dict 항목만, candidates 는 문자열 목록으로)"""
    try:
        d = json.loads(M.PENDING.read_text("utf-8")) if M.PENDING.exists() else []
    except Exception:
        return []
    out = []
    for e in d if isinstance(d, list) else []:
        if not isinstance(e, dict):
            continue
        c = e.get("candidates")
        e["candidates"] = [k for k in c if isinstance(k, str)] if isinstance(c, list) else []
        out.append(e)
    return out


def _pend_courses(L) -> dict:
    """과목별 애매한 자료(확인 필요) 수: {과목: {"lec": n, "x": n, "xt": {차수: n}}} (필야는 후보 강의의 차수별로도)"""
    from .matching import same_course
    names = tt_courses(L)
    term = {x.key: x.term for x in L}
    out: dict = {}
    for e in _pending():
        c = str(e.get("course") or "").split("|")[0].strip()
        n = next((x for x in names if same_course(x, c) or M.norm_course(x) == M.norm_course(c)), None)
        if not n:
            continue
        o = out.setdefault(n, {"lec": 0, "x": 0, "xt": {}})
        if str(e.get("source", "")).startswith("필야"):
            o["x"] += 1
            ts = {term.get(k) for k in e.get("candidates") or [] if term.get(k)}
            if len(ts) == 1:
                t = str(ts.pop())
                o["xt"][t] = o["xt"].get(t, 0) + 1
        else:
            o["lec"] += 1
    return out


def schedule_state() -> List[dict]:
    cfg = M.read_cfg()
    on = M.schedule_on()
    out = []
    for t in (M._sched_times(cfg) if on else []):
        e = re.match(r"매\s*(\d+)\s*(분|시간)\s*(오늘|전체)?\s*(둘다|강의록|필야)?\s*(?:학번\s*([\d,]+))?", t)
        if e:
            out.append({"time": "", "every": int(e.group(1)) * (60 if e.group(2) == "시간" else 1), "mode": e.group(3) or "전체",
                        "target": e.group(4) or "둘다", "years": re.findall(r"\d+", e.group(5) or "")})
            continue
        m = re.match(r"(\d{1,2}):(\d{2})\s*(오늘|전체)?\s*(둘다|강의록|필야)?\s*(?:학번\s*([\d,]+))?", t)
        if m:
            out.append({"time": f"{int(m.group(1)):02d}:{m.group(2)}", "mode": m.group(3) or "전체", "target": m.group(4) or "둘다",
                        "years": re.findall(r"\d+", m.group(5) or "")})
    return out


# ---------------------------------------------------------------- 실행 상태
def _external_info() -> Optional[dict]:
    """화면 밖에서(예약 실행·앱을 다시 열기 전에 시작한 받기) 돌고 있는 받기 정보"""
    info = M.run_lock()
    mine = _job["proc"].pid if _job["proc"] and _job["proc"].poll() is None else None
    if info and int(info.get("pid") or 0) not in (mine, os.getpid()):
        return info
    return None


def _external_running() -> bool:
    return _external_info() is not None


def _live_file() -> Optional[Path]:
    d = M.SAVE_ROOT / "_실행기록"
    files = sorted(d.glob("*_진행중.txt"), key=lambda p: p.stat().st_mtime, reverse=True) if d.exists() else []
    return files[0] if files else None


def job_state() -> dict:
    p = _job["proc"]
    running = bool(p and p.poll() is None)
    xi = None if running else _external_info()
    ext = xi is not None
    prog = {}
    if running and JOB_LOG.exists():
        try:
            tail = JOB_LOG.read_text("utf-8", errors="replace")[-20000:]
            ms = re.findall(r"\((\d+)/(\d+)\)\s+(.+)", tail)
            if ms:
                i, n, cur = ms[-1]
                rnd = len(re.findall(r"미룬 강의 \d+개", tail))
                prog = {"i": int(i), "n": int(n), "cur": cur.strip(), "round": rnd}
        except Exception:
            pass
    return {"running": running, "external": ext, "external_auto": bool(xi and xi.get("auto")), "started": _job["started"], "label": _job["label"],
            "exit": (p.returncode if p and not running else None), "progress": prog}


def shared_pc() -> bool:
    try:
        return _read_cfg().get("shared_pc") is True
    except Exception:
        return False


def _shared_close():
    """여러 사람이 쓰는 컴퓨터: 앱을 닫을 때 로그인 흔적 지우기 (구글 로그아웃 · LMS 비밀번호 · 노션 · LMS 브라우저 세션)
    기기 목록에서 빼기(네트워크)는 5초만 기다리고, 이 컴퓨터에 남는 것부터 지움 (끄기 · 로그아웃 시간 안에 끝나게)"""
    from . import lms as _lms
    _lms.SESSION_CRED = None
    t = threading.Thread(target=lambda: state_sync().leave(), daemon=True)
    try:
        if acct()._st().get("email"):
            t.start()
            t.join(5)
    except Exception:
        pass
    try:
        from . import secrets_store, notion_sync
        secrets_store.delete(notion_sync.KEYCHAIN)
    except Exception:
        pass
    try:
        acct().logout()
    except Exception:
        pass
    shutil.rmtree(M.APP / ".browser", ignore_errors=True)


def wipe_me(body: dict) -> dict:
    """설정 › 계정 › 「이 PC에서 내 정보 지우기」: 로그인 · 비밀번호 · 설정 · 기록을 이 컴퓨터에서 지움
    남기는 것: 받은 강의록(저장 폴더) · 직접 넣은 자료(모든 학년) · 글꼴 · 표지 · 앱 파일(google_client.json 등)
    지우는 것은 앱 폴더 안의 정해진 것만"""
    if body.get("confirm") is not True:
        return {"ok": False, "msg": "확인이 필요해요."}
    with _lock:
        if _job["proc"] and _job["proc"].poll() is None:
            return {"ok": False, "msg": "받는 중이에요. 끝난 뒤에 다시 해 주세요."}
    if _external_running():
        return {"ok": False, "msg": "예약 받기가 도는 중이에요. 끝난 뒤에 다시 해 주세요."}
    from . import secrets_store, notion_sync
    from .lms import KEYCHAIN_SERVICE
    _shared_close()
    for svc in (KEYCHAIN_SERVICE, notion_sync.KEYCHAIN):
        try:
            secrets_store.delete(svc)
        except Exception:
            pass
    try:                                        # 예약(자동 받기)도 끔
        subprocess.run([sys.executable, "-m", "lecture_app", "예약", "끄기"], cwd=str(M.APP), timeout=60,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL)
    except Exception:
        pass
    app = M.APP.resolve()
    KEEP = {"google_client.json"}
    gone = []

    def rm_data(d: Path):                       # 그 폴더의 기록 파일만 (직접넣은자료 등 사용자 파일은 둠)
        for p in list(d.glob("*.json")) + list(d.glob(".*.json")) + [d / ".device_id"]:
            try:
                if p.name not in KEEP and p.is_file() and not p.is_symlink() and p.resolve().parent == d.resolve():
                    p.unlink()
                    gone.append(p.name)
            except Exception:
                pass
        for sub in ("시간표_백업", "logs", ".browser", ".cache"):
            q = d / sub
            if q.is_dir() and not q.is_symlink() and q.resolve().parent == d.resolve():
                shutil.rmtree(q, ignore_errors=True)
                gone.append(sub)

    try:                                        # 예전에 남은 LMS 로그인 화면 캡처(학번이 보임)
        for d in {M.SAVE_ROOT / "_실행기록", Path.home() / "Desktop" / "매뉴얼 정리" / "_실행기록"}:
            for f in d.glob("*로그인*.png"):
                f.unlink()
    except Exception:
        pass
    from . import sync as _sync
    got = _sync._LOCK.acquire(timeout=30)       # 동기화가 도는 중이면 끝날 때까지
    try:
        rm_data(app)
    finally:
        if got:
            _sync._LOCK.release()
    gdir = app / "학년"
    if gdir.is_dir() and not gdir.is_symlink():
        for g in gdir.iterdir():
            if g.is_dir() and not g.is_symlink():
                rm_data(g)
    try:
        (app / "config.json").write_text(json.dumps({"shared_pc": True}, ensure_ascii=False, indent=1), "utf-8")
    except Exception:
        pass
    return {"ok": True, "gone": len(gone)}


def _needs_lms(body: dict) -> bool:
    return (body.get("target") or "둘다") != "필야" and body.get("src") != "드라이브"


def start_job(body: dict) -> dict:
    with _lock:
        if _job["proc"] and _job["proc"].poll() is None:
            return {"ok": False, "msg": "이미 받는 중이에요."}
        if _external_running():
            return {"ok": False, "msg": "예약 실행이 지금 받는 중이에요. 끝난 뒤에 다시 눌러 주세요."}
        try:
            from . import updater
            if updater._locked():
                return {"ok": False, "msg": "앱을 업데이트하는 중이에요. 끝나면 앱이 다시 켜져요. 그 뒤에 눌러 주세요."}
        except Exception:
            pass
        args = ["받기"]
        label = []
        cl = body.get("courses") or []
        cs = [str(c).strip() for c in (cl if isinstance(cl, list) else []) if str(c).strip() and not str(c).strip().startswith("-")][:50]
        if cs:
            args += ["--과목", *cs]
            label.append(", ".join(cs))
        else:
            label.append("전체 과목")
        mode = body.get("mode") or "all"
        kl = body.get("keys") or []
        keys = [str(k) for k in (kl if isinstance(kl, list) else []) if str(k).strip() and not str(k).startswith("-")][:400]
        if mode == "keys":
            if not keys:
                return {"ok": False, "msg": "다시 만들 강의를 골라 주세요."}
            args += ["--강의", *keys]
            label.append(f"고른 강의 {len(keys)}개")
        elif mode == "today":
            args.append("--오늘")
            label.append("오늘 강의")
        elif mode == "dates":
            ds = [d for d in re.split(r"[\s,]+", str(body.get("dates") or "")) if re.fullmatch(r"\d{1,2}/?\d{1,2}", d)]
            if not ds:
                return {"ok": False, "msg": "날짜를 적어 주세요 (예: 1024 10/27)."}
            args += ["--날짜", *ds]
            label.append("날짜 " + " ".join(ds))
        elif mode == "term":
            t = str(body.get("term") or "").strip()
            if not t.isdigit():
                return {"ok": False, "msg": "차수를 골라 주세요."}
            args += ["--차수", t]
            label.append(f"{t}차")
        else:
            label.append("전체 강의")
        if body.get("force"):
            args.append("--처음부터")
            label.append("다시 만들기" if mode == "keys" else "처음부터")
        elif body.get("remake"):
            args.append("--새표지")
            label.append("새 설정으로 다시 만들기")
        tgt = body.get("target") or "둘다"
        if tgt in ("강의록", "필야"):
            args += ["--대상", tgt]
            label.append(("추가자료" if tgt == "필야" else tgt) + "만")
        if body.get("src") == "드라이브" and tgt != "필야":
            args += ["--출처", "드라이브"]
            label.append("강의록은 드라이브만")
        ys = [re.sub(r"[^\w]", "", str(y)) for y in body.get("years") or [] if str(y).strip()]
        if ys and tgt != "강의록":
            args += ["--학번", *ys]
            label.append("추가자료 " + "·".join(ys))
        JOB_LOG.parent.mkdir(parents=True, exist_ok=True)
        try:        # 지난 받기의 진행 기록을 먼저 비움 → 새 받기가 시작되기 전 화면이 지난 결과(「끝났어요」·100%)를 잠깐 보여 주지 않게
            M.Events.PATH.write_text("", "utf-8")
        except Exception:
            pass
        from . import lms as _lms
        sess = _lms.SESSION_CRED if shared_pc() else None
        if shared_pc() and not sess and _needs_lms(body):
            return {"ok": False, "need_pw": True, "msg": "LMS 비밀번호를 넣어 주세요 · 여러 사람이 쓰는 컴퓨터라 저장하지 않아요"}
        f = open(JOB_LOG, "w", encoding="utf-8")
        env = dict(os.environ, PYTHONUNBUFFERED="1", PYTHONIOENCODING="utf-8")
        if sess:
            env["LA_LMS_STDIN"] = "1"
        grp = {"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP} if os.name == "nt" else {"start_new_session": True}
        _job["proc"] = subprocess.Popen([sys.executable, "-u", "-m", "lecture_app", *args], cwd=str(M.APP),
                                        stdout=f, stderr=subprocess.STDOUT, stdin=subprocess.PIPE if sess else subprocess.DEVNULL,
                                        env=env, **grp)
        if sess:                                # 비밀번호는 파일 · 명령줄 · 환경 변수가 아니라 표준 입력으로 한 번만
            try:
                _job["proc"].stdin.write(f"{sess[0]}\n{sess[1]}\n".encode("utf-8"))
                _job["proc"].stdin.close()
            except Exception:
                pass
        _job["started"] = f"{datetime.now():%H:%M}"
        _job["args"] = args
        _job["label"] = " · ".join(label)
        return {"ok": True}


def _kill_tree(pid: int):
    if os.name == "nt":
        subprocess.run(["taskkill", "/T", "/F", "/PID", str(pid)], capture_output=True)
        return
    try:
        os.killpg(os.getpgid(pid), signal.SIGTERM)
    except Exception:
        try:
            os.kill(pid, signal.SIGTERM)
        except Exception:
            pass


def stop_job() -> dict:
    p = _job["proc"]
    if not p or p.poll() is not None:
        xi = _external_info()
        if xi:                       # 앱을 다시 열기 전에 시작했거나 예약으로 시작한 받기도 멈출 수 있게
            _kill_tree(int(xi["pid"]))
            for _ in range(50):
                if not M.pid_alive(int(xi["pid"])):
                    break
                time.sleep(0.1)
            try:
                M.RUN_LOCK.unlink()
            except Exception:
                pass
            return {"ok": True}
        return {"ok": False, "msg": "받는 중이 아니에요."}
    if os.name == "nt":
        _kill_tree(p.pid)            # 브라우저·LibreOffice 같은 하위 프로그램까지
    else:
        try:
            os.killpg(p.pid, signal.SIGTERM)
        except Exception:
            p.terminate()
    for _ in range(50):
        if p.poll() is not None:
            break
        time.sleep(0.1)
    if p.poll() is None:
        try:
            os.killpg(p.pid, signal.SIGKILL)
        except Exception:
            p.kill()
    try:                         # 강제로 끄면 받기 쪽 정리(잠금 파일 지우기)가 안 돌아서 여기서 지움
        if int(json.loads(M.RUN_LOCK.read_text("utf-8")).get("pid") or 0) == p.pid:
            M.RUN_LOCK.unlink()
    except Exception:
        pass
    try:
        with open(JOB_LOG, "a", encoding="utf-8") as f:
            f.write("\n■ 화면에서 중지했어요. 받다 만 강의는 다음 실행 때 이어서 받아요.\n")
    except Exception:
        pass
    return {"ok": True}


def read_log(offset: int) -> dict:
    """화면에서 시작한 실행이면 그 출력, 아니면 예약 실행의 진행 기록"""
    p = _job["proc"]
    src = None
    if p is not None and JOB_LOG.exists():
        src = JOB_LOG
    elif _external_running():
        src = _live_file()
    if not src or not src.exists():
        return {"text": "", "offset": 0, "source": ""}
    data = src.read_bytes()
    if offset > len(data):
        offset = 0
    chunk = data[offset:offset + 200000].decode("utf-8", errors="replace")
    return {"text": chunk, "offset": offset + len(chunk.encode("utf-8")), "source": src.name}


def read_events(offset: int) -> dict:
    """받기 진행 기록(진행.jsonl): offset 이후 새 줄만"""
    f = M.Events.PATH
    if not f.exists():
        return {"text": "", "offset": 0, "reset": offset > 0}
    data = f.read_bytes()
    reset = offset > len(data)
    if reset:
        offset = 0
    chunk = data[offset:]
    cut = chunk.rfind(b"\n") + 1          # 쓰는 중인 마지막 줄은 다음에
    return {"text": chunk[:cut].decode("utf-8", errors="replace"), "offset": offset + cut, "reset": reset}


def progress_state() -> dict:
    """메뉴 막대용 짧은 현황: 받는 중/대기 중 + 진행 막대(전체·강의록·필야 학번별) + 마지막 결과"""
    js = job_state()
    running = bool(js["running"] or js["external"])
    plan, skipped, res = None, 0, set()
    xplan, xres, oplan, ores = None, set(), {}, {}
    end, target, started, phase = None, "둘다", "", ""
    f = M.Events.PATH
    try:
        lines = f.read_text("utf-8", errors="replace").splitlines() if f.exists() else []
    except OSError:
        lines = []
    for ln in lines:
        try:
            e = json.loads(ln)
        except ValueError:
            continue
        t = e.get("type")
        if t == "start":
            plan, skipped, res, xplan, xres, oplan, ores, end = None, 0, set(), None, set(), {}, {}, None
            target, started, phase = e.get("target") or "둘다", e.get("t") or e.get("time") or "", ""
        elif t == "plan":
            plan = set(e.get("keys") or [])
        elif t == "skip":
            skipped = int(e.get("n") or 0)
        elif t == "done" and not e.get("quiet"):
            res.add(e.get("key"))
        elif t == "xplan":
            if e.get("lab"):
                oplan[str(e["lab"])] = set(e.get("keys") or [])
            else:
                xplan = set(e.get("keys") or [])
        elif t == "xdone":
            if e.get("lab"):
                ores.setdefault(str(e["lab"]), set()).add(e.get("key"))
            else:
                xres.add(e.get("key"))
        elif t == "phase":
            phase = e.get("text") or ""
        elif t == "end":
            end = e
    lab0 = str(M.CFG.get("extras_label") or "").strip() or "올해"
    rows = []
    fin = end is not None or not running
    def row(name, d, n):
        return {"name": name, "done": min(d, n), "total": n, "pct": 100 if (fin or not n) else min(100, round(d * 100 / n))}
    if target != "필야" and plan is not None:
        rows.append(row("강의록", len(res), max(0, len(plan) - skipped)))
    if target != "강의록":
        if xplan is not None:
            rows.append(row(f"추가자료 {lab0}", len(xres), len(xplan)))
        for y in sorted(oplan, reverse=True):
            rows.append(row(f"추가자료 {y}", len(ores.get(y, set())), len(oplan[y])))
    d = sum(r["done"] for r in rows)
    n = sum(r["total"] for r in rows)
    allr = row("전체", d, n)
    summ = (end or {}).get("summary") or {}
    last = ""
    if end and not end.get("error"):
        last = f"새로 {summ.get('new', 0)} · 바뀜 {summ.get('updated', 0)} · 실패 {summ.get('fail', 0)} · 추가자료 {summ.get('extras', 0)}"
    elif end and end.get("error"):
        last = "오류로 멈췄어요"
    return {"running": running, "status": "받는 중…" if running else ("오류" if end and end.get("error") else "대기 중"),
            "label": js.get("label") or "", "started": js.get("started") or started, "phase": phase if running else "",
            "all": allr, "rows": rows, "last": last, "pending": len(_pending())}


# ---------------------------------------------------------------- 시간표
def profs_state() -> dict:
    """강좌별 교수 (연도 비교) 표: 시간표.json 그대로 + 행마다 이 앱의 강의 key (애매한 자료 고를 때 씀)"""
    from .timetable import _parse_dates, _parse_period, YEAR_KEY, SKIP_TITLE
    data = json.loads((M.DATA / "시간표.json").read_text("utf-8-sig"))
    lectures = load(M.DATA / "시간표.json")
    idx = {}
    for L in lectures:
        for t in L.titles:
            idx.setdefault((L.course, L.mmdd, L.start, t.strip()), L.key)
    out = []
    for c in data:
        rows = []
        for r in c.get("rows") or []:
            t = (r.get("t") or "").strip()
            keys = []
            if t and not SKIP_TITLE.search(t):
                gparts = (r.get("g") or "").split("·")
                for i, dd in enumerate(_parse_dates(r.get("d", ""))):
                    g = gparts[i] if i < len(gparts) else (gparts[-1] if gparts else "")
                    pp = _parse_period(g)
                    k = idx.get((c["name"], dd, pp[0], t)) if pp else None
                    if k and k not in keys:
                        keys.append(k)
            rows.append({"t": t, "d": r.get("d", ""), "g": r.get("g", ""), "y": r.get("y") or {},
                         "term": r.get("term") or 0, "tm": r.get("tm") or {}, "keys": keys})
        if any(r["keys"] for r in rows):            # 올해 수업이 있는 과목만
            out.append({"name": c["name"], "years": [str(y) for y in c.get("years") or []] or [YEAR_KEY], "rows": rows})
    lab = str(M.CFG.get("extras_label") or "").strip()
    return {"courses": out, "year": YEAR_KEY, "label": lab if lab.isdigit() else ""}


def _tt_write(new_data, backup=True) -> Optional[str]:
    from . import tt_edit as T
    path = M.DATA / "시간표.json"
    bk = T.backup(path) if backup else None
    tmp = path.with_name("시간표.gui.tmp")
    tmp.write_text(json.dumps(new_data, ensure_ascii=False, indent=1), "utf-8")
    safe_replace(tmp, path)
    return bk.name if bk else None


def tt_past_preview(body: dict) -> dict:
    """지난 연도 시간표(AI 결과) → 역대 교수 칸에 무엇이 바뀌는지"""
    from . import tt_edit as T
    data = json.loads((M.DATA / "시간표.json").read_text("utf-8-sig"))
    try:
        year, changes, warn = T.plan_past(data, body.get("data"), body.get("year"))
    except json.JSONDecodeError:
        return {"ok": False, "msg": "붙여넣은 내용이 형식에 맞지 않아요. AI가 준 JSON을 그대로 붙여넣어 주세요."}
    except ValueError as e:
        return {"ok": False, "msg": str(e)}
    return {"ok": True, "year": year, "changes": changes, "warn": warn}


def tt_past_apply(body: dict) -> dict:
    from . import tt_edit as T
    data = json.loads((M.DATA / "시간표.json").read_text("utf-8-sig"))
    try:
        year, changes, warn = T.plan_past(data, body.get("data"), body.get("year"))
    except (json.JSONDecodeError, ValueError) as e:
        return {"ok": False, "msg": str(e) if isinstance(e, ValueError) else "형식이 맞지 않아요."}
    acc = body.get("accept")
    n = len(changes) if acc is None else len(set(acc) & {c["id"] for c in changes})
    if not n:
        return {"ok": True, "msg": "바뀐 게 없어요."}
    _tt_write(T.apply_past(data, year, changes, acc))
    return {"ok": True, "msg": f"{_ylab(year)} 담당 교수 {n}건을 넣었어요. 표지의 「역대 담당 교수」는 강의록을 다시 만들 때 반영돼요."}


def profs_set(body: dict) -> dict:
    """강좌별 교수 표에서 지난 연도 칸 하나 고치기"""
    from . import tt_edit as T
    year = str(body.get("year") or "")
    if not re.fullmatch(r"20\d\d( 계절)?", year):
        return {"ok": False, "msg": "연도를 확인해 주세요."}
    if year == T.YEAR_KEY:
        return {"ok": False, "msg": "이번 학기 교수님은 시간표 탭에서 고쳐 주세요 (강의록 이름·표지와 같이 바뀌어서요)."}
    data = json.loads((M.DATA / "시간표.json").read_text("utf-8-sig"))
    try:
        ri = int(body.get("ri"))
        c = next(c for c in data if c["name"] == body.get("course"))
        if not (0 <= ri < len(c.get("rows") or [])) or (c["rows"][ri].get("t") or "").strip() != str(body.get("t") or "").strip():
            return {"ok": False, "msg": "시간표가 바뀌었어요. 새로고침해 주세요."}
    except (StopIteration, TypeError, ValueError):
        return {"ok": False, "msg": "시간표가 바뀌었어요. 새로고침해 주세요."}
    _tt_write(T.set_prof(data, c["name"], ri, year, str(body.get("value") or "")[:100]), backup=False)
    return {"ok": True}


def tt_state() -> dict:
    from . import tt_edit as T
    data = json.loads((M.DATA / "시간표.json").read_text("utf-8"))
    items = T.expand(data)
    for x in items:
        x["wd"] = T.wd(x["mmdd"])
        x.pop("row", None)
    return {"courses": [c["name"] for c in data], "items": items, "prompt": T.prompt_for(), "prompt_past": T.prompt_for(),
            "prompt_tpl": T.PROMPT, "year": T.YEAR_KEY, "picks": pick_state(data)}


def pick_state(data=None) -> dict:
    """내 분반 · 선택교과목 고르기 (실험실): 분반이 있는 과목 · 선택교과목 칸과 고른 것"""
    from .timetable import elect_slot, read_pick
    if data is None:
        data = json.loads((M.DATA / "시간표.json").read_text("utf-8-sig"))
    secs, el = {}, {}
    for c in data:
        for r in c.get("rows") or []:
            if not (r.get("d") or "").strip():
                continue                       # 지난 연도 기록 줄
            if str(r.get("sec") or "").isdigit():
                secs.setdefault(c["name"], set()).add(int(r["sec"]))
            es = elect_slot(r.get("t") or "")
            if es:
                el.setdefault(es[0], [])
                el[es[0]] += [x for x in es[1] if x not in el[es[0]]]
    return {"sections": {k: sorted(v) for k, v in secs.items() if len(v) > 1},   # 분반이 둘 이상인 과목만
            "electives": [{"slot": k, "options": v} for k, v in sorted(el.items())], "pick": read_pick(M.DATA)}


def pick_set(body: dict) -> dict:
    """고른 분반 · 선택 과목 저장 → 홈 · 강의록 · 표지에 바로 (시간표.json 은 그대로)"""
    from .timetable import PICK_F
    st = pick_state()
    sec = {}
    for k, n in (body.get("sec") or {}).items():
        if k in st["sections"] and isinstance(n, int) and n in st["sections"][k]:
            sec[k] = n
    slots = {e["slot"]: e["options"] for e in st["electives"]}
    el = {}
    for k, x in (body.get("elect") or {}).items():
        if k in slots and isinstance(x, str) and (x in slots[k] or x == "안 들음"):
            el[k] = x
    p = M.DATA / PICK_F
    tmp = p.with_name(PICK_F + ".tmp")
    tmp.write_text(json.dumps({"sec": sec, "elect": el}, ensure_ascii=False, indent=1), "utf-8")
    safe_replace(tmp, p)
    return {"ok": True, "pick": {"sec": sec, "elect": el}}


def _tt_plan(body: dict):
    """AI 결과(올해 + 지난 연도 함께) → 올해 시간표 변경 + 지난 연도 역대 교수 변경"""
    from . import tt_edit as T
    data = json.loads((M.DATA / "시간표.json").read_text("utf-8-sig"))
    cur = T.expand(data)
    if "_items" in body:            # 홈에서 옮기기: 옮긴 강의만 바꾼 목록 (자습·시험 같은 항목도 그대로 두게 normalize 를 거치지 않음)
        new = body["_items"]
        return T, data, cur, new, [], T.diff(cur, new, "partial", days=set(body.get("_days") or ())), {}
    names = [c["name"] for c in data]
    raw = T.load_raw(body.get("data"))          # 여러 번 나눠 받은 답(「"more": true」 → 「이어서」)도 하나로
    lab = T.cur_label(raw)
    if lab:       # 붙여넣은 시간표의 '이번 학기'(날짜가 적힌 해)·수업 달로 맞춤 (요일 계산) · 미리보기 뒤엔 저장된 시간표 기준으로 돌림
        from . import timetable as _tt
        ms = T.cur_months(raw)
        if body.get("mode") != "all":
            ms |= _tt._MONTHS
        _tt._MONTHS = ms
        if lab != T.YEAR_KEY:
            _tt.set_year_key(lab)
            cur = T.expand(data)
    cur_items, past_items, future = T.split_years(raw)
    new, warn = T.normalize(cur_items, cur, names) if cur_items else ([], [])
    mode = body.get("mode") or "partial"
    changes = T.diff(cur, new, mode, body.get("courses")) if (new or mode == "all") and (cur_items or mode != "all") else []
    return T, data, cur, new, warn, changes, past_items


def _ylab(y) -> str:
    """'2025' → '2025년', '2025 계절' → '2025 계절' (계절년 X)"""
    y = str(y)
    return y if "계절" in y else y + "년"


def _past_plan(T, data, past_items, keys=None):
    """지난 연도들 → ([변경(연도·key 포함)], [경고], 적용한 데이터).
    최근 해부터 차례로 맞추고 적용해 가며 봄 (여러 해에 같은 '올해 없는 강의'가 있어도 비교용 줄은 하나만)"""
    out, warn = [], []
    for y in sorted(past_items, reverse=True):
        try:
            _y, ch, w = T.plan_past(data, past_items[y], y)
        except ValueError as e:
            warn.append(str(e))
            continue
        out += [{**c, "year": y} for c in ch]
        warn += [f"{_ylab(y)}: {x}" for x in w]
        acc = [c["id"] for c in ch] if keys is None else [c["id"] for c in ch if c["key"] in keys]
        if acc:
            data = T.apply_past(data, y, ch, acc)
    return out, warn, data


_P1 = [0.0, ""]


def _period1() -> str:
    if time.time() - _P1[0] < 30 and _P1[1]:
        return _P1[1]
    _P1[1] = _period1_calc()
    _P1[0] = time.time()
    return _P1[1]


def _period1_calc() -> str:
    """1교시 시작 시각 (교시는 모두 60분 · A=앞 30분, B=뒤 30분).
    이 학기 설정 「1교시」(시간표 JSON 의 "1교시" 를 넣을 때 저장) > 학기 이름으로 (예과 1학년 09:00 · 나머지 08:30 · knu-med.json 의 timing 과 같음)"""
    try:
        v = str(_read_cfg().get("1교시") or "")
        if re.fullmatch(r"\d{1,2}:\d{2}", v):
            return v
    except Exception:
        pass
    g = _grades.current()[0] or ""
    return "09:00" if re.search(r"예과\s*1|예\s*1(?!\d)", g) else "08:30"


def _exams_path() -> Path:
    return M.DATA / "시험일정.json"          # 이 학기 시험 일정 {학년도: {과목: [{"l","d","g"?,"t"?}]}} · 홈 시간표에만


def _save_exams(body: dict):
    """붙여넣은 시간표 JSON 의 과목별 "exams" → 시험일정.json (exams 가 있는 과목만 바꿈 · 나머지 과목은 그대로)"""
    try:
        from . import tt_edit as T
        from .timetable import YEAR_KEY
        from .matching import same_course
        new = T.exams_of(body.get("data"))
        if not new:                       # 시험 칸이 아예 없으면 그대로 둠
            return
        names = tt_courses(load(M.DATA / "시간표.json")) if (M.DATA / "시간표.json").exists() else []
        p = _exams_path()
        try:
            allx = json.loads(p.read_text("utf-8"))
            allx = allx if isinstance(allx, dict) else {}
        except Exception:
            allx = {}
        yk = str(YEAR_KEY)
        cur = allx.get(yk) if isinstance(allx.get(yk), dict) else {}
        for c, xs in new.items():
            cn = next((n for n in names if n == c), None) or next((n for n in names if same_course(n, c)), None) or c
            cur[cn] = xs
        allx[yk] = cur
        tmp = p.with_name("시험일정.tmp")
        tmp.write_text(json.dumps(allx, ensure_ascii=False, indent=1), "utf-8")
        safe_replace(tmp, p)
    except Exception as e:
        _log_err("시험 일정 저장", e)


def _hol_state() -> dict:
    try:
        from . import holidays
        return holidays.state()
    except Exception:
        return {"years": [], "days": {}}


def _events_path() -> Path:
    return M.DATA / "행사.json"            # 학교 행사 · 시험 기간 {학년도: [{"l","d","e"?,"g"?,"t"?}]} · 홈 달력에만


def _save_events(body: dict):
    """붙여넣은 시간표 JSON 의 "events" → 행사.json (events 칸이 있을 때만 이 학기 것을 통째로 바꿈 · 없으면 그대로)"""
    try:
        from . import tt_edit as T
        from .timetable import YEAR_KEY
        raw = T.load_raw(body.get("data"))
        if not isinstance(raw, dict) or not isinstance(raw.get("events"), list):
            return
        new = T.events_of(raw)
        p = _events_path()
        try:
            allx = json.loads(p.read_text("utf-8"))
            allx = allx if isinstance(allx, dict) else {}
        except Exception:
            allx = {}
        allx[str(YEAR_KEY)] = new
        tmp = p.with_name("행사.tmp")
        tmp.write_text(json.dumps(allx, ensure_ascii=False, indent=1), "utf-8")
        safe_replace(tmp, p)
    except Exception as e:
        _log_err("행사 저장", e)


def _events_state() -> list:
    """홈 달력용 행사: [{"d": "YYYY-MM-DD", "l": 이름, "g"?, "t"?, "n": 며칠째/모두}] (여러 날이면 날마다 한 줄 · 최대 60일)"""
    from datetime import timedelta
    from .timetable import cal_year
    try:
        xs = json.loads(_events_path().read_text("utf-8")).get(str(YEAR_KEY)) or []
    except Exception:
        return []
    out = []
    for x in xs if isinstance(xs, list) else []:
        try:
            mo, dd = (int(v) for v in str(x["d"]).split("/")[:2])
            a = date(cal_year(mo), mo, dd)
            b = a
            if x.get("e"):
                m2, d2 = (int(v) for v in str(x["e"]).split("/")[:2])
                b = date(cal_year(m2), m2, d2)
                if b < a or (b - a).days > 60:
                    b = a
            n = (b - a).days + 1
            for i in range(n):
                o = {"d": (a + timedelta(days=i)).isoformat(), "l": str(x.get("l") or "")[:60]}
                if n > 1:
                    o["n"] = f"{i + 1}/{n}"
                for k in ("g", "t"):
                    if x.get(k):
                        o[k] = str(x[k])[:20]
                out.append(o)
        except Exception:
            continue                         # 한 줄이 잘못돼도 나머지는 보이게
    return out


def _save_p1(body: dict):
    """붙여넣은 시간표 JSON 의 "1교시": "08:30" → 이 학기 설정에 저장 (홈 시간표 시각)"""
    raw = body.get("data")
    try:
        from . import tt_edit as T
        raw = T.load_raw(raw)
        v = str(raw.get("1교시") or "").strip() if isinstance(raw, dict) else ""
        m = re.fullmatch(r"(\d{1,2}):(\d{2})", v)
        if not m or not (5 <= int(m.group(1)) <= 12 and int(m.group(2)) < 60):
            return
        v = f"{int(m.group(1)):02d}:{m.group(2)}"
        cfg = _read_cfg()
        if cfg.get("1교시") != v:
            cfg["1교시"] = v
            _write_cfg(cfg)
        _P1[0] = 0
    except Exception as e:
        _log_err("1교시 저장", e)


# ---------------------------------------------------------------- 화면 설정 (컴퓨터 → 휴대폰 보기에 그대로)
_PREFS_LOCK = threading.Lock()


def _prefs_path() -> Path:
    return M.APP / "화면설정.json"          # 학년과 상관없이 앱 폴더 (키 안에 학년이 들어 있음: 과목 카드 핀·순서)


def prefs_get(_b=None) -> dict:
    try:
        d = json.loads(_prefs_path().read_text("utf-8"))
        return {"ok": True, "p": d if isinstance(d, dict) else {}}
    except Exception:
        return {"ok": True, "p": {}}


def prefs_set(body: dict) -> dict:
    """컴퓨터 화면이 바뀐 설정을 보냄 ({키: 값 또는 None(지움)}) · 휴대폰은 remote 쪽에서 막힘"""
    ch = body.get("p")
    if not isinstance(ch, dict):
        return {"ok": False}
    with _PREFS_LOCK:
        d = prefs_get()["p"]
        for k, v in ch.items():
            if not isinstance(k, str) or len(k) > 200:
                continue
            if v is None:
                d.pop(k, None)
            elif isinstance(v, str) and len(v) < 2_000_000:
                d[k] = v
        try:
            f = _prefs_path()
            tmp = f.with_name(f.stem + ".tmp")
            tmp.write_text(json.dumps(d, ensure_ascii=False), "utf-8")
            safe_replace(tmp, f)
        except Exception as e:
            _log_err("화면 설정", e)
            return {"ok": False}
    return {"ok": True}


def _log_err(what: str, e: Exception):
    try:
        print(f"[{what}] {M.err(e)}", file=sys.stderr, flush=True)
    except Exception:
        pass


MOVED_F = "옮긴강의.json"        # 홈 편집 모드로 옮긴 강의: {지금 key: {"mmdd": 원래 날짜, "period": 원래 교시}}


def _moved() -> dict:
    try:
        d = json.loads((M.DATA / MOVED_F).read_text("utf-8"))
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _moved_save(d: dict):
    try:
        f = M.DATA / MOVED_F
        if d:
            tmp = f.with_name(f.stem + ".tmp")
            tmp.write_text(json.dumps(d, ensure_ascii=False, indent=1), "utf-8")
            safe_replace(tmp, f)
        elif f.exists():
            f.unlink()
    except Exception as e:
        _log_err("옮긴 강의 기록", e)


def _at(x, course, mmdd, start, hours, g, profs=None, term=None) -> bool:
    """강의 x 가 그 자리(과목·날짜·교시·반 교시)에 있는지 · profs·term 을 주면 교수·차수까지 (같은 제목 다른 교수 회차를 헷갈리지 않게)"""
    return (x.course == course and x.mmdd == mmdd and x.start == start and x.hours == hours
            and ((x.extra or {}).get("g") or "") == (g or "")
            and (profs is None or list(x.profs) == list(profs)) and (term is None or int(x.term or 0) == int(term or 0)))


def _mv_orig(v: dict, titles=None) -> dict:
    """기록 → {제목: {mmdd, period}} (예전 모양 {mmdd, period, titles} 도 읽음)"""
    if not v:
        return {}
    if isinstance(v.get("o"), dict):
        return dict(v["o"])
    if not v.get("mmdd"):
        return {}
    ts = v.get("titles") or titles or []
    return {t: {"mmdd": v.get("mmdd"), "period": v.get("period")} for t in ts}


def _mv_show(v, L):
    """화면에 보일 기존 자리 (제목이 여러 자리에서 왔으면 첫 자리 + 개수)"""
    if not v:
        return None
    o = _mv_orig(v, L.titles)
    if not o:
        return None
    xs = sorted({(x.get("mmdd") or "", x.get("period") or "") for x in o.values()})
    return {"mmdd": xs[0][0], "period": xs[0][1], "n": len(xs)}


def _mv_clean(L, o: dict) -> dict:
    """지금 자리와 같은 제목(원래 자리로 돌아온 것)·이 강의에 없는 제목은 뺌"""
    from . import tt_edit as T
    here = (L.mmdd, T._gtxt(L.start, L.hours, (L.extra or {}).get("g") or ""))
    return {t: v for t, v in o.items() if t in L.titles and (v.get("mmdd"), v.get("period")) != here}


def _moved_tidy(remap: dict, now, skip=()):
    """시간표가 바뀐 뒤: 옮긴 강의 기록의 key 를 새 key 로 · 지금 시간표에 없거나 원래 자리로 돌아온 강의는 지움
    (이름을 고친 강의는 제목 하나뿐이면 새 제목으로 이어 줌)"""
    d = _moved()
    if not d:
        return
    by = {L.key: L for L in now}
    out = {}
    for k, v in d.items():
        if k in skip:
            continue
        k2 = remap.get(k, k)
        L = by.get(k2)
        if L is None:
            continue
        o = _mv_orig(v, L.titles)
        same_slot = k2 == k or (k.split("|")[1:2] or [""])[0].split("-")[0] == L.mmdd and \
            (k.split("|")[1:2] or [""])[0].split("-", 1)[-1] in (str(L.start), (L.extra or {}).get("kg") or "")
        if len(o) == 1 and not (set(o) & set(L.titles)) and len(L.titles) == 1 and same_slot:   # 제목만 고친 강의 (같은 자리) → 새 제목으로
            o = {L.titles[0]: list(o.values())[0]}
        o = _mv_clean(L, {**_mv_orig(out[k2], L.titles), **o} if k2 in out else o)
        if o:
            out[k2] = {"o": o}
    if out != d:
        _moved_save(out)


def tt_revert(body: dict) -> dict:
    """옮긴 강의를 원래 날짜·교시로 되돌리기"""
    k = str(body.get("key") or "")
    v = _moved().get(k)
    if not v:
        return {"ok": False, "msg": "기존 교시 기록이 없어요"}
    L = next((x for x in load(M.DATA / "시간표.json") if x.key == k), None)
    o = _mv_orig(v, L.titles if L else None)
    if L is not None and not (set(o) & set(L.titles)):          # 이름을 고쳤으면 이 강의 전체를
        o = {t: list(o.values())[0] for t in L.titles}
    groups = {}
    for t, x in o.items():
        groups.setdefault((x.get("mmdd"), x.get("period")), []).append(t)
    r = tt_move({"moves": [{"key": k, "mmdd": md, "period": per, "titles": ts} for (md, per), ts in groups.items()], "_revert": True})
    if r.get("ok"):
        r["msg"] = "기존 교시로 되돌렸어요"
    return r


def tt_move(body: dict) -> dict:
    """홈 편집 모드: 강의를 다른 날·시간으로 옮기기 → 시간표 수정과 같은 길로 (미리보기 / 저장)
    옮긴 강의만 바꾸고 그날의 다른 항목(자습·시험·오리엔테이션 등)은 그대로 둔다.
    옮긴 강의는 제목마다 처음 자리를 기억 (옮긴강의.json · 「기존 교시로」)."""
    from . import tt_edit as T
    from .timetable import period_label
    try:
        data = json.loads((M.DATA / "시간표.json").read_text("utf-8-sig"))
        cur = T.expand(data)
        lecs = {L.key: L for L in load(M.DATA / "시간표.json")}
        days, mod, warn, pend, hints = set(), {}, [], [], []
        mvr = _moved()
        home = set()          # 옮긴 기록상 원래 자리로 돌아가는 수업 (나눴던 카드를 다시 합치는 건 허용)
        for mv in body.get("moves") or []:
            L = lecs.get(str(mv.get("key") or ""))
            nd = re.sub(r"\D", "", str(mv.get("mmdd") or ""))
            per = str(mv.get("period") or "").strip()
            p = T.parse_period(per)
            if L is None or len(nd) != 4 or not p:
                continue
            only = set(mv.get("titles") or []) or set(L.titles)      # 되돌리기: 그 자리에서 온 제목만
            lg = (L.extra or {}).get("g") or ""
            lp = "·".join(L.profs)
            hit = [x for x in cur if x["course"] == L.course and x["mmdd"] == L.mmdd and x["start"] == L.start and x["hours"] == L.hours
                   and (x.get("g") or "") == lg and x["prof"] == lp and x["title"] in only and id(x) not in mod]
            if not hit:
                continue
            days |= {L.mmdd, nd}
            g = period_label(per)
            rec = _mv_orig(mvr.get(L.key) or {}, L.titles)
            for x in hit:
                mod[id(x)] = (nd, p[0], p[1], g)
                o_ = rec.get(x["title"]) or {}
                if body.get("_revert") or (o_.get("mmdd") == nd and str(o_.get("period") or "") in (per, T._gtxt(p[0], p[1], g))):
                    home.add(id(x))
            ts = sorted({x["title"] for x in hit})
            pend.append((L, nd, p, g, ts))
            hints.append({"key": L.key, "course": L.course, "mmdd": nd, "start": p[0], "hours": p[1], "g": g, "titles": ts,
                          "profs": list(L.profs), "term": int(L.term or 0),
                          "from": {"mmdd": L.mmdd, "start": L.start, "hours": L.hours, "g": lg},
                          "rest": [t for t in L.titles if t not in ts]})
        if not mod:
            return {"ok": False, "msg": "옮길 강의를 찾지 못했어요. 새로고침한 뒤 다시 해 주세요."}
        # 같은 강의(같은 제목·교수)가 이미 있는 자리로 옮기면 두 회차가 한 카드로 합쳐져 되돌릴 수 없음 → 막음
        for x in cur:
            if id(x) in mod:
                nd, st, hr, g = mod[id(x)]
                dup = next((y for y in cur if id(y) not in mod and y["course"] == x["course"] and y["mmdd"] == nd and y["start"] == st
                            and y["hours"] == hr and (y.get("g") or "") == g and y["prof"] == x["prof"] and y["term"] == x["term"]
                            and T.nt(y["title"]) == T.nt(x["title"])), None)
                if dup is not None:
                    return {"ok": False, "msg": f"{int(nd[:2])}/{int(nd[2:])} 그 자리에 이미 같은 강의 「{x['title']}」가 있어요. 다른 칸으로 옮겨 주세요."}
        items, owner = [], {}
        for x in cur:
            if x["mmdd"] in days:
                org = (x["mmdd"], x["start"], x["hours"], x.get("g") or "", x["prof"], x["term"])
                hm = id(x) in home
                if id(x) in mod:
                    nd, st, hr, g = mod[id(x)]
                    same = (x["mmdd"], x["start"], x["hours"], x.get("g") or "") == (nd, st, hr, g or "")
                    x = {**x, "mmdd": nd, "start": st, "hours": hr, "g": g}
                    if not same:
                        x.pop("sep", None)              # 옮기면 일단 보통 강의로 (아래에서 다른 강의와 모이면 다시 따로 표시)
                items.append({k: v for k, v in x.items() if k != "row"})
                owner[id(items[-1])] = (org, True, hm)
        # 옮긴 뒤 같은 과목·차수·시간·교수 자리에 다른 강의가 모이면: 한 카드로 합치지 않고 따로 둠 (홈에선 그 칸에 위아래로)
        #   예외: 원래 한 카드였다가 나눴던 것이 그 자리로 돌아오면 다시 합침
        def _orig_of(it):
            o_ = owner[id(it)][0]
            L_ = next((L for L in lecs.values() if L.course == it["course"] and L.mmdd == o_[0] and L.start == o_[1] and it["title"] in L.titles), None)
            return (_mv_orig(mvr.get(L_.key) or {}, L_.titles).get(it["title"]) or {}) if L_ else {}
        grp = {}
        for it in items:
            grp.setdefault((it["course"], it["term"], it["mmdd"], it["start"], it["hours"], it.get("g") or "", it["prof"]), []).append(it)
        for gk, xs in grp.items():
            movers = [it for it in xs if it.get("mmdd") != owner[id(it)][0][0] or it["start"] != owner[id(it)][0][1]]
            stay = [it for it in xs if it not in movers]
            if not movers or len(xs) < 2:
                continue
            here = (gk[2], T._gtxt(gk[3], gk[4], gk[5]))

            def _home_here(o_, here=here):      # 옮긴 기록상 원래 자리가 바로 여기
                return o_.get("mmdd") == here[0] and str(o_.get("period") or "") == here[1]
            sib = all(not _orig_of(it) or _home_here(_orig_of(it)) for it in stay)     # 여기 있던 강의도 원래 여기 것
            used = {it.get("sep") or "" for it in stay}
            by_org = {}                          # 같은 카드에서 함께 온 제목들은 한 카드로 (같은 표시)
            if not stay:                         # 빈 자리에 여러 강의가 함께 옮겨 옴: 첫 카드는 보통대로
                by_org[owner[id(movers[0])][0]] = ""
                used = {""}
            for it in movers:
                if owner[id(it)][2] and sib and _home_here(_orig_of(it) or {"mmdd": here[0], "period": here[1]}):
                    base = next((x.get("sep") or "" for x in stay), "")
                    if base:
                        it["sep"] = base
                    continue
                o_ = owner[id(it)][0]
                if o_ not in by_org:
                    k_ = 1
                    while str(k_) in used:
                        k_ += 1
                    by_org[o_] = str(k_); used.add(str(k_))
                if by_org[o_]:
                    it["sep"] = by_org[o_]
        b2 = {"_items": items, "_days": sorted(days), "_moves": hints, "mode": "partial"}
        mv0 = _moved()
    except Exception as e:
        return {"ok": False, "msg": f"시간표를 읽지 못했어요: {M.err(e)}"}
    if body.get("preview"):
        r = tt_preview(b2)
        if r.get("ok") and warn:
            r["warn"] = (r.get("warn") or []) + warn
        return r
    r = tt_apply(b2)
    if r.get("ok") and r.get("backup"):
        base = "시간표를 바꿨어요."
        if r.get("moved"):
            base += f" 이미 만든 강의록 {len(r['moved'])}개는 표지가 바뀌어 _이전버전 으로 옮겼고, 다음 받기 때 새 날짜·교시로 다시 만들어요."
        r["msg"] = base
        try:
            now = load(M.DATA / "시간표.json")
            d = _moved()
            undo = []                      # 방금 저장 되돌리기: 옮긴 제목을 저장 전 자리로
            for L, nd, p, g, ts in pend:
                n_ = next((x for x in now if _at(x, L.course, nd, p[0], p[1], g, L.profs, L.term) and set(ts) & set(x.titles)), None)
                if n_ is not None:
                    undo.append({"key": n_.key, "titles": ts, "mmdd": L.mmdd, "period": T._gtxt(L.start, L.hours, (L.extra or {}).get("g") or ""),
                                 "title": L.title, "to": f"{int(nd[:2])}/{int(nd[2:])} {T._gtxt(p[0], p[1], g)}교시"})
            r["undo"] = undo
            for L, nd, p, g, ts in pend:
                prev = _mv_orig(mv0.get(L.key) or {}, L.titles)
                here = {"mmdd": L.mmdd, "period": T._gtxt(L.start, L.hours, (L.extra or {}).get("g") or "")}
                n = next((x for x in now if _at(x, L.course, nd, p[0], p[1], g, L.profs, L.term) and set(ts) & set(x.titles)), None)
                if n is not None:
                    o = {**_mv_orig(d.get(n.key) or {}, n.titles), **{t: prev.get(t) or here for t in ts}}
                    o = _mv_clean(n, o)
                    if o:
                        d[n.key] = {"o": o}
                    else:
                        d.pop(n.key, None)
                rest = [t for t in L.titles if t not in ts]          # 같은 카드에서 안 옮긴 제목은 원래 기록 그대로
                if rest and any(t in prev for t in rest):
                    m = next((x for x in now if _at(x, L.course, L.mmdd, L.start, L.hours, (L.extra or {}).get("g") or "", L.profs, L.term)
                              and set(rest) & set(x.titles)), None)
                    if m is not None:
                        o = _mv_clean(m, {**_mv_orig(d.get(m.key) or {}, m.titles), **{t: prev[t] for t in rest if t in prev}})
                        if o:
                            d[m.key] = {"o": o}
            keys = {x.key for x in now}
            _moved_save({k: v for k, v in d.items() if k in keys})
        except Exception as e:
            _log_err("옮긴 강의 기록", e)
    return r


def _remap_keys(remap: dict):
    remap = {k: v for k, v in (remap or {}).items() if k != v}
    if not remap:
        return
    def rw(path, fn):
        try:
            if not path.exists():
                return
            v = json.loads(path.read_text("utf-8"))
            v2 = fn(v)
            tmp = path.with_name(path.stem + ".remap.tmp")
            tmp.write_text(json.dumps(v2, ensure_ascii=False, indent=1), "utf-8")
            safe_replace(tmp, path)
        except Exception as e:
            _log_err(path.name, e)
    def nr(v):
        if not isinstance(v, dict):
            return v
        out = {}
        for k, e in v.items():                 # 두 key 가 하나로 합쳐지면 LMS·드라이브 기록을 합침
            k2 = remap.get(k, k)
            out[k2] = {**(out.get(k2) or {}), **e} if isinstance(e, dict) and isinstance(out.get(k2), dict) else e
        return out
    rw(M.NORETRY_FILE, nr)
    rw(M.DATA / "다시만들기.json", lambda v: list(dict.fromkeys(remap.get(k, k) for k in v)) if isinstance(v, list) else v)
    def pend(v):
        for e in v if isinstance(v, list) else []:
            if isinstance(e, dict) and isinstance(e.get("candidates"), list):
                e["candidates"] = list(dict.fromkeys(remap.get(k, k) if isinstance(k, str) else k for k in e["candidates"]))
        return v
    rw(M.PENDING, pend)
    with _XSKIP_LOCK:                   # 휴대폰에서 ✕ 누르는 것과 겹쳐도 하나가 사라지지 않게
        rw(M.DATA / XSKIP_F, lambda v: sorted({remap.get(k, k) for k in v}) if isinstance(v, list) else v)    # 시험에 안 나옴 표시도 새 key 로


def _copy_marks(pairs):
    """나눈 카드: 원래 카드의 ✕(시험에 안 나옴)·다시 안 함 표시를 떨어져 나간 강의에도"""
    pairs = [(a, b) for a, b in pairs if a and b and a != b]
    if not pairs:
        return
    with _XSKIP_LOCK:
        cur = _xskips()
        add = {b for a, b in pairs if a in cur}
        if add - cur:
            f = M.DATA / XSKIP_F
            tmp = f.with_name(f.stem + ".tmp")
            tmp.write_text(json.dumps(sorted(cur | add), ensure_ascii=False, indent=1), "utf-8")
            safe_replace(tmp, f)
    try:
        p = M.NORETRY_FILE
        if p.exists():
            v = json.loads(p.read_text("utf-8"))
            ch = False
            for a, b in pairs:
                if isinstance(v, dict) and a in v and b not in v:
                    v[b] = v[a]
                    ch = True
            if ch:
                tmp = p.with_name(p.stem + ".copy.tmp")
                tmp.write_text(json.dumps(v, ensure_ascii=False, indent=1), "utf-8")
                safe_replace(tmp, p)
    except Exception as e:
        _log_err("다시 안 함 복사", e)


def tt_preview(body: dict) -> dict:
    from .timetable import refresh_year_key
    try:
        return _tt_preview(body)
    finally:
        refresh_year_key()          # 저장한 시간표 기준으로 (미리보기만 했으면 원래대로)


def _tt_preview(body: dict) -> dict:
    try:
        T, data, cur, new, warn, changes, past_items = _tt_plan(body)
    except json.JSONDecodeError:
        return {"ok": False, "msg": "붙여넣은 내용이 형식에 맞지 않아요. AI가 준 JSON을 그대로 붙여넣어 주세요."}
    except ValueError as e:                 # 끊긴 JSON 등 (tt_edit.load_raw 가 이유를 적어 줌)
        return {"ok": False, "msg": str(e)}
    if not new and not past_items:
        return {"ok": False, "msg": "시간표에서 수업을 하나도 읽지 못했어요. AI 결과를 다시 확인해 주세요."}
    # 지난 연도는 올해 변경을 모두 적용했다고 치고 그 위에 맞춰 봄 (새 과목·새 강의도 짝을 찾게)
    sim = T.collapse(T.apply_changes(cur, changes), data) if changes else data
    past, pwarn, _d = _past_plan(T, sim, past_items)
    for c in changes:
        for side in ("before", "after"):
            if c[side]:
                c[side] = {**c[side], "wd": T.wd(c[side]["mmdd"])}
                c[side].pop("row", None)
    other = _other_term(cur, new)
    if other:
        warn = [other] + warn
    return {"ok": True, "changes": changes, "warn": warn + pwarn, "count": len(new), "year": T.YEAR_KEY,
            "days": sorted({x["mmdd"] for x in new}), "past": past, "past_years": sorted(past_items, reverse=True),
            "other_term": bool(other)}


def _other_term(cur: list, new: list) -> str:
    """붙여 넣은 수업이 지금 시간표 학기 달과 거의 안 겹치면 경고 문구 (다른 학기 시간표를 넣는 실수 막기)"""
    if not cur or not new:
        return ""
    cm = {int(x["mmdd"][:2]) for x in cur}
    ins = sum(1 for x in new if int(x["mmdd"][:2]) in cm)
    if ins * 10 >= len(new) * 3:                 # 30% 이상 겹치면 같은 학기로 봄
        return ""
    def rng(ms):
        ms = sorted(ms, key=lambda m: (m - 3) % 12)          # 3월부터 세서 해를 넘기는 학기도 이어지게 (9월~2월)
        return f"{ms[0]}월~{ms[-1]}월" if len(ms) > 1 else f"{ms[0]}월"
    return (f"지금 시간표는 {rng(cm)} 수업인데, 붙여 넣은 시간표는 {rng({int(x['mmdd'][:2]) for x in new})} 수업이에요. "
            "다른 학기 시간표 같아요 — 맞는 학기 시간표인지, 앱에서 고른 학기가 맞는지 확인해 주세요.")


def tt_apply(body: dict) -> dict:
    from .timetable import refresh_year_key
    try:
        r = _with_run_lock(lambda: _tt_apply(body), "받기가 진행 중이에요. 끝난 뒤에 적용해 주세요.")   # 강의록을 옮기는 동안 예약 받기가 끼어들지 않게
        if isinstance(r, dict) and r.get("ok") and body.get("data"):
            _save_p1(body)
            _save_exams(body)
            _save_events(body)
        return r
    finally:
        refresh_year_key()          # 새로 넣은 시간표의 '이번 학기' 칸으로


def _tt_apply(body: dict) -> dict:
    if (_job["proc"] and _job["proc"].poll() is None) or _external_running():
        return {"ok": False, "msg": "받기가 진행 중이에요. 끝난 뒤에 적용해 주세요."}
    try:
        T, data, cur, new, warn, changes, past_items = _tt_plan(body)
    except json.JSONDecodeError:
        return {"ok": False, "msg": "붙여넣은 내용이 형식에 맞지 않아요."}
    except ValueError as e:                 # 끊긴 JSON 등 (tt_edit.load_raw 가 이유를 적어 줌)
        return {"ok": False, "msg": str(e)}
    msgs, moved, bk, res = [], [], None, None
    acc = body.get("accept")
    n = len(changes) if acc is None else len(set(acc) & {c["id"] for c in changes})
    path = M.DATA / "시간표.json"
    if n:
        final = T.apply_changes(cur, changes, acc)
        old_lectures = load(path)
        bk = T.backup(path)
        new_data = T.collapse(final, data)
        tmp = path.with_name("시간표.gui.tmp")
        tmp.write_text(json.dumps(new_data, ensure_ascii=False, indent=1), "utf-8")
        safe_replace(tmp, path)
        new_lectures = load(path)
        hint, splits = {}, []
        for mv in body.get("_moves") or []:      # 홈에서 옮긴 강의 → 새 강의 key (제목·날짜·교시·교수로 정확히)
            fr = mv.get("from") or {}
            if mv.get("rest") and fr:            # 카드의 일부 제목만 옮김(합쳐진 카드 나누기) → 기록은 제자리에 남는 강의가 가짐
                n_ = next((x for x in new_lectures if _at(x, mv["course"], fr["mmdd"], fr["start"], fr["hours"], fr.get("g"), mv.get("profs"), mv.get("term"))
                           and set(mv["rest"]) & set(x.titles)), None)
                n2 = next((x for x in new_lectures if _at(x, mv["course"], mv["mmdd"], mv["start"], mv["hours"], mv["g"], mv.get("profs"), mv.get("term"))
                           and set(mv["titles"]) & set(x.titles)), None)
                if n2 is not None:
                    splits.append((mv["key"], n2.key))     # 떨어져 나간 쪽에도 ✕(시험에 안 나옴)·다시 안 함 표시를 복사
            else:
                n_ = next((x for x in new_lectures if _at(x, mv["course"], mv["mmdd"], mv["start"], mv["hours"], mv["g"], mv.get("profs"), mv.get("term"))
                           and set(mv["titles"]) & set(x.titles)), None)
            if n_ is not None:
                hint[mv["key"]] = n_.key
        if not body.get("_moves"):               # AI 붙여넣기·시간표 수정: 미리보기의 「바뀌기 전 → 바뀐 뒤」 짝으로 정확히 (같은 제목 다른 주로 잘못 잇지 않게)
            okc = None if acc is None else set(acc)
            ot = {(x.course, T.nt(t)) for x in old_lectures for t in x.titles}
            nt_ = {(x.course, T.nt(t)) for x in new_lectures for t in x.titles}
            for c in changes:
                if c["type"] != "change" or (okc is not None and c["id"] not in okc):
                    continue
                b_, a_ = c["before"], c["after"]
                if T.nt(b_["title"]) != T.nt(a_["title"]) and ((a_["course"], T.nt(a_["title"])) in ot or (b_["course"], T.nt(b_["title"])) in nt_):
                    continue                     # 제목이 바뀐 짝인데 두 제목이 다 다른 자리에 살아 있음 (서로 자리 바꿈 등) → 이름 고침이 아니라서 잇지 않음
                pb = [p_ for p_ in str(b_.get("prof") or "").split("·") if p_]
                pa = [p_ for p_ in str(a_.get("prof") or "").split("·") if p_]
                O = next((x for x in old_lectures if _at(x, b_["course"], b_["mmdd"], b_["start"], b_["hours"], b_.get("g"), pb) and b_["title"] in x.titles), None)
                N = next((x for x in new_lectures if _at(x, a_["course"], a_["mmdd"], a_["start"], a_["hours"], a_.get("g"), pa) and a_["title"] in x.titles), None)
                if O is not None and N is not None and O.key != N.key and O.key not in hint:
                    hint[O.key] = N.key
        if hint:
            moved_keys = set(hint)
            for O in old_lectures:
                if O.key in moved_keys:
                    continue
                tgt = None                                       # (다른 강의와 합치기는 tt_move 에서 막음)
                if tgt is None:                                  # 옆 강의 때문에 key 만 바뀐 강의 (같은 날 같은 제목 회차·반 교시 등)
                    tgt = next((N for N in new_lectures if N.course == O.course and (N.mmdd, N.start, N.hours, N.period_label, N.profs, N.titles)
                                == (O.mmdd, O.start, O.hours, O.period_label, O.profs, O.titles)), None)
                if tgt is not None and tgt.key != O.key:
                    hint[O.key] = tgt.key
        tlog = []
        try:                                     # 정리하다 실패해도 (윈도우에서 파일이 열려 있는 등) 나머지 key 정리는 계속
            res = T.tidy_outputs(M.DATA, old_lectures, new_lectures, M.out_dir, M.out_name, M.read_records, M.write_records,
                                 log=tlog.append, hint=hint)
        except Exception as e:
            _log_err("tidy_outputs", e)
            res = {"moved": [], "remap": {k: v for k, v in hint.items()}}
            msgs.append(f"강의록 파일 정리 중 오류가 있었어요: {M.err(e)}")
        if any("옮기기 실패" in x for x in tlog):
            msgs.append("열려 있는 강의록 파일이 있어 일부는 옮기지 못했어요 · 파일을 닫고 다음 받기 때 다시 정리돼요")
        moved = res["moved"]
        # 확실한 연결만: 홈에서 옮긴 강의·붙여넣기 짝(hint) · 새로 생긴 key 로 간 것 (이미 있던 다른 강의로 덮어 잇지 않게)
        old_keys = {x.key for x in old_lectures}
        safe = {k: v for k, v in (res.get("remap") or {}).items() if k in hint or v not in old_keys}
        res["remap"] = safe
        try:                                     # 추가자료·{원본} 이름 기억도 새 강의 이름·key로 (안 하면 다음 받기 때 추가자료가 하나 더 생김)
            M.tidy_extras(old_lectures, new_lectures, safe)
        except Exception as e:
            msgs.append(f"추가자료 이름을 정리하지 못했어요: {M.err(e)}")
        mroot = M.DATA / "직접넣은자료"          # 내가 직접 넣은 자료 폴더도 새 강의 key로 옮김
        for ok_, nk_ in (res.get("remap") or {}).items():
            src_, dst_ = mroot / M.safe(ok_), mroot / M.safe(nk_)
            try:
                if ok_ != nk_ and src_.is_dir():
                    if not dst_.exists():
                        shutil.move(str(src_), str(dst_))
                    else:
                        for f_ in src_.iterdir():
                            if not (dst_ / f_.name).exists():
                                shutil.move(str(f_), str(dst_ / f_.name))
            except OSError:
                pass
        try:                                     # 바뀐 key: 다시 안 함 · 다시 만들기 · 애매한 자료 후보 · 옮긴 강의 기록도 새 key 로
            _remap_keys(safe)
            if splits:
                _copy_marks([(safe.get(o, hint.get(o, o)), n2) for o, n2 in splits])
            _moved_tidy(safe, new_lectures, skip={m["key"] for m in body.get("_moves") or []})      # 지금 옮긴 강의 기록만 tt_move 가 직접
        except Exception as e:
            _log_err("key 정리", e)
        msgs.append(f"이번 학기 시간표에 {n}건 적용했어요.")
        try:                     # 내 시간표로 바뀌었으니 배포판 시간표 이름은 지움
            cfg = _read_cfg()
            if cfg.pop("tt_label", None) is not None:
                _write_cfg(cfg)
        except Exception:
            pass
    if past_items:
        data2 = json.loads(path.read_text("utf-8-sig"))
        keys = body.get("accept_past")
        past, _w, data2 = _past_plan(T, data2, past_items, None if keys is None else set(keys))
        pick = past if keys is None else [c for c in past if c["key"] in set(keys)]
        if pick:
            if bk is None:
                bk = T.backup(path)
            _tt_write(data2, backup=False)
            ys = sorted({c["year"] for c in pick}, reverse=True)
            msgs.append(f"지난 연도({', '.join(ys)}) 담당 교수 {len(pick)}건을 넣었어요.")
    if not msgs:
        return {"ok": True, "msg": "바뀐 게 없어요."}
    msg = " ".join(msgs)
    if moved:
        msg += f" 이미 만든 강의록 {len(moved)}개는 _이전버전 으로 옮겼고, 다음 받기 때 새 시간표대로 다시 만들어요."
    return {"ok": True, "msg": msg, "backup": bk.name if bk else None, "moved": moved, "remap": (res or {}).get("remap") or {}}


# ---------------------------------------------------------------- 애매한 자료
def pending_state() -> List[dict]:
    from .matching import same_course
    lectures = {L.key: L for L in load(M.DATA / "시간표.json")}
    sem = lambda L: ((int(L.mmdd[:2]) + (12 if int(L.mmdd[:2]) <= 2 else 0)) * 100 + int(L.mmdd[2:]), L.start)
    lab = lambda L: {"key": L.key, "label": _lec_label(L)}
    out = []
    for e in _pending():
        cands = [lectures[k] for k in e.get("candidates", []) if k in lectures]
        course_all = sorted([L for L in lectures.values() if same_course(L.course, e.get("course", ""))], key=sem)
        if not cands:
            cands = course_all
        tt_course = (course_all[0].course if course_all else (cands[0].course if cands else e.get("course", "").split("|")[0].strip()))
        out.append({**e, "course_name": e.get("course", "").split("|")[0].strip(), "course_tt": tt_course,
                    "has_file": bool(e.get("file")) and Path(e.get("file")).exists(),
                    "options": [lab(L) for L in cands[:20]],
                    "all": [lab(L) for L in course_all]})     # 후보에 없으면 과목 전체에서 고르기
    return out


# ---------------------------------------------------------------- 재업로드 확인 (이름이 비슷한 자료가 같이 올라와 있을 때)
def verq_state() -> List[dict]:
    lectures = {L.key: L for L in load(M.DATA / "시간표.json")}
    out = []
    for e in M.load_verq()["q"]:
        L = lectures.get(e.get("key"))
        if not L:
            continue
        fs = [{**f, "has_file": bool(f.get("file")) and Path(f["file"]).exists()} for f in e.get("files") or []]
        out.append({"id": e["id"], "key": L.key, "course": L.course, "label": _lec_label(L), "files": fs})
    return out


def verq_set(body: dict) -> dict:
    if _busy():
        return {"ok": False, "msg": "받기가 진행 중이에요. 끝난 뒤에 골라 주세요."}
    v = M.load_verq()
    e = next((x for x in v["q"] if x.get("id") == body.get("id")), None)
    ans = body.get("ans")
    if not e or ans not in ("re", "diff"):
        return {"ok": False, "msg": "목록에 없는 자료예요. 새로고침해 주세요."}
    v["ans"][e["id"]] = ans
    v["q"] = [x for x in v["q"] if x is not e]
    M.save_verq(v)
    if ans == "re":       # 최신 것만 남기고 다시 만듦
        try:
            M._redo_path().write_text(json.dumps(sorted(M.redo_keys() | {e["key"]}), ensure_ascii=False), "utf-8")
        except Exception:
            pass
        return {"ok": True, "key": e["key"], "msg": "재업로드로 기억했어요. 최신 자료로 다시 만들어요."}
    return {"ok": True, "key": e["key"], "msg": "서로 다른 자료로 기억했어요. 둘 다 써요."}


def verq_open(body: dict) -> dict:
    e = next((x for x in M.load_verq()["q"] if x.get("id") == body.get("id")), None)
    f = next((x for x in (e or {}).get("files") or [] if x.get("uid") == body.get("uid") and x.get("source") == body.get("source")), None)
    p = Path(f.get("file") or "") if f else None
    if not p or not p.exists():
        return {"ok": False, "msg": "받아 둔 파일이 없어요. 받기를 한 번 돌리면 받아 둬요."}
    return _open_copy(p, f.get("filename") or p.name)


# ---------------------------------------------------------------- 강의록 합치기 (강의록이 여러 개라 폴더에 따로 만든 강의)
def merge_state() -> dict:
    lectures = load(M.DATA / "시간표.json")
    prefs = M.load_merge()
    items, done, merged = [], [], []
    seen, rc = set(), {}
    for L in lectures:
        if L.key in seen:
            continue
        seen.add(L.key)
        d, name = M.out_dir(L), M.out_name(L)
        if d not in rc:
            try:
                rc[d] = _safe_records(d) or {}
            except Exception:
                rc[d] = {}
        rec = rc[d].get(name) or {}
        sp = M.split_parts(rec)
        fd = d / name[:-4]
        e = prefs.get(L.key)
        if not sp and e and e.get("do") == "merge" and (d / name).exists():     # 합본으로 만든 강의 → 다시 나누기
            merged.append({"key": L.key, "course": L.course, "label": _lec_label(L), "mmdd": L.mmdd, "start": L.start,
                           "parts": [{"n": i + 1, "src": x, "up": "", "rel": ""} for i, x in
                                     enumerate(x.strip() for x in (rec.get("원본파일명") or "").split(" + ") if x.strip())],
                           "folder": "", "file": _rel(d / name)})
            continue
        if not sp or not fd.is_dir():
            continue
        ids = [x.get("id", "") for x in sp]
        c = M.merge_choice(L.key, ids)
        row = {"key": L.key, "course": L.course, "label": _lec_label(L), "mmdd": L.mmdd, "start": L.start,
               "parts": [{"n": i + 1, "src": x.get("src") or "", "up": x.get("up") or "", "rel": _rel(fd / x["f"]) if (fd / x["f"]).is_file() else ""}
                         for i, x in enumerate(sp)], "folder": _rel(fd)}
        if c and c.get("do") == "split":
            done.append(row)
        elif not c:
            items.append(row)
    key = lambda r: ((int(r["mmdd"][:2]) + (12 if int(r["mmdd"][:2]) <= 2 else 0)) * 100 + int(r["mmdd"][2:]), r["start"])
    items.sort(key=key)
    done.sort(key=key)
    merged.sort(key=key)
    return {"items": items, "split": done, "merged": merged, "busy": _busy()}


def _merge_decided(lecs) -> set:
    """강의록 합치기에서 이미 고른 강의 (지금 자료 묶음 그대로)"""
    prefs = M.load_merge()
    out = set()
    for x in lecs:
        e = prefs.get(x["key"]) if x.get("parts") else None
        ids = sorted(f["id"] for f in x.get("srcfiles") or [] if f.get("n"))
        if e and sorted(e.get("files") or []) == ids:
            out.add(x["key"])
    return out


def merge_set(body: dict) -> dict:
    if _busy():
        return {"ok": False, "msg": "받기가 진행 중이에요. 끝난 뒤에 골라 주세요."}
    key, do = str(body.get("key") or ""), body.get("do")
    L = next((x for x in load(M.DATA / "시간표.json") if x.key == key), None)
    if not L or do not in ("merge", "split", "ask", "unmerge"):
        return {"ok": False, "msg": "목록에 없는 강의예요. 새로고침해 주세요."}
    prefs = M.load_merge()
    if do in ("ask", "unmerge"):          # 따로 두기로 한 것을 다시 묻기 / 합본을 다시 (1)·(2)로 나누기
        prefs.pop(key, None)
        M.save_merge(prefs)
        return {"ok": True}
    rec = (_safe_records(M.out_dir(L)) or {}).get(M.out_name(L)) or {}
    sp = M.split_parts(rec)
    if not sp:
        return {"ok": False, "msg": "따로 만든 강의록이 없어요. 새로고침해 주세요."}
    prefs[key] = {"files": [x.get("id", "") for x in sp], "do": do, "del": bool(body.get("del")),
                  "at": f"{datetime.now():%Y-%m-%d %H:%M}"}
    M.save_merge(prefs)
    return {"ok": True, "key": key}


def file_skip(body: dict) -> dict:
    """강의록을 만든 원본 파일 하나를 앞으로 쓰지 않기 (매칭 기억에 '제외') / 되돌리기"""
    if _busy():
        return {"ok": False, "msg": "받기가 진행 중이에요. 끝난 뒤에 바꿔 주세요."}
    sid, key = str(body.get("id") or ""), str(body.get("key") or "")
    src, _, uid = sid.partition(":")
    if not src or not uid or src == "직접":
        return {"ok": False, "msg": "이 파일은 여기서 바꿀 수 없어요."}
    mem = Memory(M.DATA / "매칭기억.json")
    if body.get("on"):
        it = Item(src, str(body.get("course") or ""), uid, "", str(body.get("name") or ""), "")
        prev = mem.data.get(sid)
        mem.set(it, "제외")
        if prev and prev != "제외":             # 직접 골라 둔 강의가 있었으면 되돌릴 때 쓰게 기억
            mem.info.setdefault(sid, {})["prev"] = prev
            mem.save()
        msg = f"「{body.get('name') or uid}」 파일은 다음 받기부터 쓰지 않아요 (이 파일이 들어간 모든 강의록에서) · 받기를 하면 빼고 다시 만들어요"
    else:
        if mem.data.get(sid) == "제외":
            prev = (mem.info.get(sid) or {}).pop("prev", None)
            if prev:
                mem.data[sid] = prev
            else:
                mem.data.pop(sid, None)
            mem.save()
        msg = "다음 받기 때 이 파일을 다시 써요"
    try:
        M._redo_path().write_text(json.dumps(sorted(M.redo_keys() | ({key} if key else set())), ensure_ascii=False), "utf-8")
    except Exception:
        pass
    return {"ok": True, "msg": msg}


def pending_open(body: dict) -> dict:
    """애매한 자료 미리 받아 둔 파일 열기 (앱 폴더의 .cache 안에 있는 것만)"""
    e = next((x for x in _pending() if x.get("uid") == body.get("uid") and x.get("source") == body.get("source")), None)
    f = Path(e.get("file") or "") if e else None
    cache = (M.APP / ".cache").resolve()
    if not f or not f.exists() or cache not in f.resolve().parents:
        return {"ok": False, "msg": "미리 받아 둔 파일이 없어요. 받기를 한 번 돌리면 받아 둬요."}
    return _open_copy(f, e.get("filename") or f.name)


def _open_copy(f: Path, fname: str) -> dict:
    cache = (M.APP / ".cache").resolve()
    if cache not in f.resolve().parents:
        return {"ok": False, "msg": "열 수 없는 위치예요."}
    # 원래 파일 이름으로 열리게 임시 사본 (미리보기 창 제목이 알아보기 쉽게)
    if Path(fname).suffix.lower() not in (".pdf", ".ppt", ".pptx", ".doc", ".docx", ".hwp", ".hwpx", ".key", ".odp",
                                          ".xls", ".xlsx", ".txt", ".png", ".jpg", ".jpeg", ".zip"):
        return {"ok": False, "msg": "문서 파일만 열 수 있어요 (실행 파일은 열지 않아요)."}
    import tempfile
    d = Path(tempfile.gettempdir()) / "강의록앱_미리보기"
    d.mkdir(exist_ok=True)
    dst = d / M.safe(Path(fname).name)
    shutil.copy(f, dst)
    try:
        _os_open(dst)
    except Exception as ex:
        return {"ok": False, "msg": f"파일을 열 프로그램을 못 찾았어요 ({type(ex).__name__})"}
    return {"ok": True}


def pending_set(body: dict) -> dict:
    data = _pending()
    e = next((x for x in data if x.get("uid") == body.get("uid") and x.get("source") == body.get("source")), None)
    if not e:
        return {"ok": False, "msg": "목록에 없는 자료예요. 새로고침해 주세요."}
    it = Item(e["source"], e["course"], e["uid"], e.get("title", ""), e.get("filename", ""), e.get("uploaded", ""))
    mem = Memory(M.DATA / "매칭기억.json")
    if body.get("exclude"):
        mem.set(it, "제외")
    elif body.get("outscope"):
        mem.set(it, "범위밖")
    elif body.get("unknown"):
        mem.set(it, "보류")
    else:
        valid = {L.key for L in load(M.DATA / "시간표.json")}
        picks = [k for k in body.get("picks") or [] if k in valid]       # 시간표에 있는 강의만
        if e.get("role_q") and not picks:
            picks = [k for k in e.get("candidates") or [] if k in valid]
        if not picks:
            return {"ok": False, "msg": "강의를 하나 이상 골라 주세요."}
        if not e.get("role_q"):          # 본/보조 질문은 이미 정해진 강의는 그대로 두고 역할만 저장
            mem.set(it, "||".join(picks))
        role = body.get("role")
        if role in ("본", "보조") or e.get("role_q"):
            roles = M.load_roles()
            roles[f"{it.source}:{it.uid}"] = role if role in ("본", "보조") else "본"
            tmp = M._roles_path().with_suffix(".tmp")
            tmp.write_text(json.dumps(roles, ensure_ascii=False, indent=1), "utf-8")
            safe_replace(tmp, M._roles_path())
        try:      # 지난 강의라도 다음 받기 때 다시 만들게
            M._redo_path().write_text(json.dumps(sorted(M.redo_keys() | set(picks)), ensure_ascii=False), "utf-8")
        except Exception:
            pass
    data = [x for x in data if x is not e]
    tmp = M.PENDING.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=1), "utf-8")
    safe_replace(tmp, M.PENDING)
    return {"ok": True}


# ---------------------------------------------------------------- 내가 정한 자료 (매칭 기억 다시 보기·고치기)
def _busy() -> bool:
    return bool((_job["proc"] and _job["proc"].poll() is None) or _external_running())


def _lec_label(L) -> str:
    return f"{L.mmdd[:2]}/{L.mmdd[2:]} {L.start}교시 · {L.title}" + (f" ({'·'.join(L.profs)})" if L.profs else "")


def _mem_cache_file(info: dict) -> Optional[Path]:
    try:
        it = Item(info["source"], info.get("course", ""), info["uid"], info.get("title", ""),
                  info.get("filename", ""), info.get("uploaded", ""))
        f = M._cache_path(M.APP / ".cache", it)
        return f if f.exists() else None
    except Exception:
        return None


def _auto_load() -> dict:
    """앱이 스스로 정한 분류 (main.save_auto 가 받을 때마다 기록)"""
    try:
        f = M.DATA / "자동분류.json"
        return json.loads(f.read_text("utf-8-sig")) if f.exists() else {}
    except Exception:
        return {}


def decided_state() -> dict:
    lectures = load(M.DATA / "시간표.json")
    by_key = {L.key: L for L in lectures}
    mem = Memory(M.DATA / "매칭기억.json")
    courses = tt_courses(lectures)
    sem = lambda mmdd: (int(mmdd[:2]) + (12 if int(mmdd[:2]) <= 2 else 0)) * 100 + int(mmdd[2:])   # 2학기: 1·2월은 뒤로
    out = []
    auto = _auto_load()
    rows = [(k, v, mem.info.get(k, {}), "") for k, v in mem.data.items()]
    rows += [(k, "||".join(e.get("keys") or []), e, e.get("how", "")) for k, e in auto.items() if k not in mem.data and e.get("keys")]
    roles = M.load_roles()
    for k, v, info, how in rows:
        src, _, uid = k.partition(":")
        cname = (info.get("course") or "").split("|")[0].strip()
        # 과목: 기억한 강의의 과목 → 출처 과목명
        picks = [] if v in ("제외", "범위밖", "보류") else [x for x in v.split("||") if x]
        course = next((by_key[x].course for x in picks if x in by_key), "")
        if not course and cname:
            course = next((c for c in courses if norm_course(c) == norm_course(cname)), cname)
        picks.sort(key=lambda x: (sem(by_key[x].mmdd), by_key[x].start) if x in by_key else (99999, 0))
        f = _mem_cache_file(info) if info else None
        out.append({"key": k, "source": info.get("source") or src, "uid": uid, "course": course or "(과목 모름)",
                    "filename": info.get("filename", ""), "title": info.get("title", ""),
                    "uploaded": info.get("uploaded", ""), "at": info.get("at", ""),
                    "exclude": v == "제외", "outscope": v == "범위밖", "unknown": v == "보류", "auto": bool(how), "how": how, "role": roles.get(k, ""),
                    "picks": [{"key": x, "label": _lec_label(by_key[x]) if x in by_key else f"(시간표에 없는 강의) {x}",
                               "missing": x not in by_key} for x in picks],
                    "has_file": bool(f), "size": f.stat().st_size if f else 0})
    first = lambda x: min([sem(by_key[p["key"]].mmdd) * 10 + by_key[p["key"]].start for p in x["picks"] if p["key"] in by_key] or [99999])
    out.sort(key=lambda x: (x["course"] == "(과목 모름)", x["course"], not x["unknown"], x["exclude"], first(x), x["filename"]))   # 잘 모르겠음은 위로
    opts = {}
    for L in sorted(lectures, key=lambda L: (L.course, sem(L.mmdd), L.start)):
        opts.setdefault(L.course, []).append({"key": L.key, "label": _lec_label(L)})
    return {"items": out, "options": opts, "busy": _busy()}


def _retire_outputs(keys, extra: bool, label: str = "") -> List[str]:
    """더 이상 이 자료를 안 쓰게 된 강의의 결과물을 _이전버전 으로 옮기고 기록을 지움 → 다음 받기 때 다시 만듦"""
    by_key = {L.key: L for L in load(M.DATA / "시간표.json")}
    moved = []
    stamp = f"{datetime.now():%m%d}"
    for k in keys:
        L = by_key.get(k)
        if not L:
            continue
        d, name = (M.extra_dir(L, label), M.extra_name(L, label)) if extra else (M.out_dir(L), M.out_name(L))
        fd = d / name[:-4]                     # 강의록 여러 개를 따로 만든 폴더
        if (d / name).exists() or (not extra and fd.is_dir()):
            prev = d / "_이전버전"
            prev.mkdir(exist_ok=True)
            if (d / name).exists():
                shutil.move(str(d / name), str(M._backup_name(prev, name, f"자료변경{stamp}")))
            for fd_ in ((fd, d / (name[:-4] + "_원본")) if not extra else ()):
                if fd_.is_dir():
                    shutil.move(str(fd_), str(M.unique_dir(prev / (fd_.name + f"_자료변경{stamp}"))))
            refs = d / (name[:-4] + "_참고자료")
            if not extra and refs.exists():
                shutil.move(str(refs), str(prev / (refs.name + f"_자료변경{stamp}")))
            moved.append(name)
        recs = M.read_records(d)
        if name in recs:
            recs.pop(name, None)
            M.write_records(d, recs)
    return moved


def decided_set(body: dict) -> dict:
    if _busy():
        return {"ok": False, "msg": "받기가 진행 중이에요. 끝난 뒤에 고쳐 주세요."}
    mem = Memory(M.DATA / "매칭기억.json")
    k = body.get("key") or ""
    auto = None
    if k not in mem.data:
        auto = _auto_load().get(k)
        if not auto or not auto.get("keys"):
            return {"ok": False, "msg": "목록에 없는 자료예요. 새로고침해 주세요."}
        if body.get("forget"):
            return {"ok": True, "msg": "앱이 정한 분류는 그대로 둬요."}
        # 앱이 정한 걸 고치면 → 내가 정한 자료로 기억 (다음 받기부터 이대로)
        mem.info[k] = {a: b for a, b in auto.items() if a not in ("how", "keys", "at")}
    old = mem.data[k] if auto is None else "||".join(auto["keys"])
    old_picks = set() if old in ("제외", "범위밖", "보류") else {x for x in old.split("||") if x}
    if body.get("forget"):
        mem.data.pop(k, None)
        mem.info.pop(k, None)
        new_picks, msg = set(), "기억을 지웠어요. 다음 받기 때 앱이 다시 판단하고, 애매하면 다시 물어봐요."
    elif body.get("exclude"):
        mem.data[k] = "제외"
        new_picks, msg = set(), "강의록 아님으로 바꿨어요."
    elif body.get("outscope"):
        mem.data[k] = "범위밖"
        new_picks, msg = set(), "현재 범위 아님으로 바꿨어요."
    elif body.get("unknown"):
        mem.data[k] = "보류"
        new_picks, msg = set(), "미정으로 두었어요. 강의록에는 안 넣고, 「미정」 칸에서 나중에 고를 수 있어요."
    else:
        valid = {L.key for L in load(M.DATA / "시간표.json")}
        picks = [x for x in body.get("picks") or [] if x in valid]
        if not picks:
            return {"ok": False, "msg": "강의를 하나 이상 골라 주세요."}
        mem.data[k] = "||".join(picks)
        new_picks, msg = set(picks), "저장했어요."
    if k in mem.info:
        mem.info[k]["at"] = datetime.now().strftime("%Y-%m-%d %H:%M")
    mem.save()
    src = k.partition(":")[0]
    extra = src.startswith("필야")
    moved = _retire_outputs(sorted(old_picks - new_picks), extra, src[2:]) if old_picks - new_picks else []
    if new_picks - old_picks or moved:
        msg += " 다음 받기 때 바뀐 강의의 " + ("추가자료를" if extra else "강의록을") + " 다시 만들어요."
    if moved:
        msg += f" (이전 파일 {len(moved)}개는 _이전버전 으로 옮김)"
    return {"ok": True, "msg": msg}


def preview_file(body: dict):
    """휴대폰 미리보기용: 애매한 자료(uid·source) 또는 정한 자료(key)의 받아 둔 파일 → (파일, 이름) 또는 None (.cache 안의 것만)"""
    cache = (M.APP / ".cache").resolve()
    if body.get("key"):
        mem = Memory(M.DATA / "매칭기억.json")
        info = mem.info.get(body.get("key") or "") or _auto_load().get(body.get("key") or "")
        f = _mem_cache_file(info) if info else None
        name = (info or {}).get("filename") or (f.name if f else "")
    else:
        e = next((x for x in _pending() if x.get("uid") == body.get("uid") and x.get("source") == body.get("source")), None)
        f = Path(e.get("file") or "") if e and e.get("file") else None
        name = (e or {}).get("filename") or (f.name if f else "")
    if not f or not f.exists() or cache not in f.resolve().parents:
        return None
    return f, name


def decided_open(body: dict) -> dict:
    mem = Memory(M.DATA / "매칭기억.json")
    info = mem.info.get(body.get("key") or "") or _auto_load().get(body.get("key") or "")
    f = _mem_cache_file(info) if info else None
    if not f:
        return {"ok": False, "msg": "받아 둔 파일이 없어요 (지난 받기에서 쓴 임시 파일이 지워졌어요)."}
    return _open_copy(f, info.get("filename") or f.name)


# ---------------------------------------------------------------- 설정 (계정·드라이브·노션)
def _cfg_path() -> Path:
    return M.APP / "config.json"


def _read_cfg() -> dict:
    return M.read_cfg()          # 못 읽으면 오류 (빈 설정으로 덮어쓰지 않게)


def _write_cfg(cfg: dict):
    M.write_cfg(cfg)             # 다음 받기부터 (받기는 새 프로세스라 파일을 다시 읽음)


def _icloud_synced() -> List[str]:
    """맥에서 「데스크탑 및 문서 폴더」 iCloud 동기화가 켜져 있으면 ['~/Desktop', '~/Documents']"""
    if sys.platform != "darwin":
        return []
    try:
        from . import cloud
        return [f"~/{n}" for n in cloud._mac_synced().values()]      # 실제로 동기화 중인 것만 (끈 뒤 남은 예전 폴더는 빼고)
    except Exception:
        return []


def _tt_courses_names() -> list:
    try:
        return sorted({L.course for L in load(M.DATA / "시간표.json")})
    except Exception:
        return []


def drive_list(body: dict) -> dict:
    """처음 설정·설정 탭의 「드라이브에서 고르기」: 폴더 하나의 안쪽 목록 + 시간표 과목과 맞는 폴더 표시"""
    from . import drive as D
    fid = D.folder_id_of(str(body.get("id") or body.get("url") or ""))
    if not fid or not re.fullmatch(r"[\w-]{10,}", fid):
        return {"ok": False, "msg": "구글 드라이브 폴더 링크를 넣어 주세요 (https://drive.google.com/drive/folders/…)."}
    try:
        es = D.list_folder(fid)
    except Exception as e:
        return {"ok": False, "msg": "드라이브 폴더를 열지 못했어요. 링크가 맞는지, 「링크가 있는 모든 사용자」로 공유된 폴더인지 확인해 주세요. (" + M.err(e) + ")"}
    courses = _tt_courses_names()
    cmap = _read_cfg().get("drive_course_map") or {}
    hit = {}
    for c in courses:
        f, _how = D.match_course_folder(c, es, cmap, courses)
        if f:
            hit.setdefault(f[0], c)
    out = []
    for i, n, isdir, mod in es:
        out.append({"id": i, "name": n, "dir": isdir, "mod": mod, "course": hit.get(i, "") if isdir else "",
                    "sem": bool(isdir and re.search(r"학기|semester", n, re.I))})
    out.sort(key=lambda e: (not e["dir"], e["name"]))
    return {"ok": True, "id": fid, "entries": out, "courses": courses,
            "matched": sorted({e["course"] for e in out if e["course"]})}


def drive_check(body: dict) -> dict:
    """고른 학기 폴더 확인: 과목 폴더·매뉴얼 폴더가 있는지 + 파일 날짜로 다른 학번(작년) 드라이브인지"""
    from . import drive as D
    from concurrent.futures import ThreadPoolExecutor
    sid = str(body.get("sem_id") or "").strip()
    if not re.fullmatch(r"[\w-]{10,}", sid):
        return {"ok": False, "msg": "학기 폴더를 먼저 골라 주세요."}
    try:
        es = D.list_folder(sid)
    except Exception:
        return {"ok": False, "msg": "학기 폴더를 열지 못했어요. 다시 골라 주세요."}
    courses = _tt_courses_names()
    from .timetable import year_num
    year = year_num(YEAR_KEY)

    cfg0 = _read_cfg()
    same = D.maps_apply(cfg0, str(body.get("root") or ""), sid)
    pick = lambda k: body[k] if isinstance(body.get(k), dict) else ((cfg0.get("drive_" + k) or {}) if same else {})
    cmap = body["map"] if isinstance(body.get("map"), dict) else ((cfg0.get("drive_course_map") or {}) if same else {})
    cmap = {str(k): str(v) for k, v in cmap.items() if v}
    mm = {str(k): str(v) for k, v in pick("manual_map").items() if v}          # 과목마다 직접 고른 매뉴얼 폴더
    xm = {str(k): str(v) for k, v in pick("extras_map").items() if v}          # 과목마다 직접 고른 추가자료 폴더
    lay = pick("extras")                                                      # 추가자료 위치
    cont = str(lay.get("container") or "")
    sub = str(lay.get("sub", "추가자료")) if "sub" in lay else "추가자료"
    x_warn = ""
    try:
        cont_es = D.list_folder(cont) if cont else None
    except Exception:
        cont_es, x_warn = None, "추가자료 폴더를 열지 못했어요. 「추가자료 위치」를 다시 골라 주세요."

    def count_files(fid, cap=300):
        n, stack = 0, [(fid, 0)]
        while stack and n < cap:
            x, dep = stack.pop()
            for e in D.list_folder(x):
                if e[2] and dep < 2:
                    stack.append((e[0], dep + 1))
                elif not e[2]:
                    n += 1
        return n

    def one(c):
        f, how = D.match_course_folder(c, es, cmap, courses)
        r = {"course": c, "folder": f[1] if f else "", "folder_id": f[0] if f else "", "how": how,
             "manual": False, "files": 0, "old": 0, "dates": [],
             "m_id": "", "m_name": "", "m_how": "", "m_opts": [],
             "x_id": "", "x_name": "", "x_how": "", "x_files": 0, "x_opts": []}
        try:
            ents = D.list_folder(f[0]) if f else []
        except Exception:
            ents = []
        dirs = [{"id": e[0], "name": e[1]} for e in ents if e[2]]
        # 매뉴얼 (강의록)
        r["m_opts"] = ([{"id": f[0], "name": f"(과목 폴더 「{f[1]}」 바로)"}] if f else []) + dirs
        mid = mm.get(c)
        man, direct = None, False
        if mid == "-":
            r["m_how"] = "고름"
        elif mid:
            man = (mid, next((o["name"] for o in r["m_opts"] if o["id"] == mid), "직접 고른 폴더"), True, "")
            direct, r["m_how"] = (bool(f) and mid == f[0]), "고름"
            if not any(o["id"] == mid for o in r["m_opts"]):
                r["m_opts"].append({"id": mid, "name": "직접 고른 폴더"})
        elif f:
            man, direct, _mh = D.manual_folder((f[0], f[1], True, ""), c, ents, use_map=False)   # 받기와 같은 규칙 (매뉴얼 폴더 · 날짜 폴더 · 과목 폴더에 바로 있는 강의록)
            r["m_how"] = "자동" if man else ""
        if man:
            r["manual"], r["m_id"], r["m_name"] = True, man[0], ("(과목 폴더 바로)" if direct or (f and man[0] == f[0]) else man[1])
            try:
                subs = [e for e in D.list_folder(man[0]) if not direct or (e[2] and re.fullmatch(r"\d{4}", e[1].strip()))]
                files = [e for e in subs if not e[2]]
                for e in [e for e in subs if e[2]][:4]:          # 날짜 폴더 몇 개만 (빠르게)
                    files += [x for x in D.list_folder(e[0]) if not x[2]]
                for e in files:
                    d = D._mod_sortable(e[3])
                    if re.match(r"\d{4}-", d or ""):
                        r["dates"].append(d)
                r["files"] = len(files)
                r["old"] = sum(1 for d in r["dates"] if int(d[:4]) < year)
            except Exception:
                pass
        # 추가자료
        xid = xm.get(c)
        x = None
        if cont_es is not None:
            cf2, _h = D.match_course_folder(c, cont_es, {}, courses)
            if sub:
                try:
                    in2 = D.list_folder(cf2[0]) if cf2 else []
                except Exception:
                    in2 = []
                r["x_opts"] = [{"id": e[0], "name": f"{cf2[1]} › {e[1]}"} for e in in2 if e[2]]
                auto = D.find_sub(in2, sub) if cf2 else None
            else:
                r["x_opts"] = [{"id": e[0], "name": e[1]} for e in cont_es if e[2]]
                auto = cf2
        else:
            r["x_opts"] = dirs
            auto = D.find_sub(ents, sub or "추가자료") if f else None
        if xid == "-":
            r["x_how"] = "고름"
        elif xid:
            x = (xid, next((o["name"] for o in r["x_opts"] if o["id"] == xid), "직접 고른 폴더"))
            r["x_how"] = "고름"
            if not any(o["id"] == xid for o in r["x_opts"]):
                r["x_opts"].append({"id": xid, "name": "직접 고른 폴더"})
        elif auto:
            x, r["x_how"] = (auto[0], auto[1]), "자동"
        if x:
            r["x_id"], r["x_name"] = x[0], x[1]
            try:
                r["x_files"] = count_files(x[0])
            except Exception:
                pass
        return r
    with ThreadPoolExecutor(6) as ex:
        res = list(ex.map(one, courses))
    n_dates = sum(len(r["dates"]) for r in res)
    n_old = sum(r["old"] for r in res)
    found = [r for r in res if r["folder"]]
    newest = max((d for r in res for d in r["dates"]), default="")
    old_drive = n_dates >= 5 and n_old / n_dates >= 0.6
    hint = ""
    m = re.search(r"(\d{2})\s*학번", " ".join(n for _, n, *_ in es) + " " + str(body.get("path") or ""))   # 연도(2025)는 학번이 아니라서 「NN학번」만
    if m and m.group(1) != str(_read_cfg().get("extras_label") or "").strip():
        hint = m.group(1)
    return {"ok": True, "year": year, "courses": res, "found": len(found), "total": len(courses),
            "dirs": [{"id": i, "name": n} for i, n, isdir, _ in es if isdir],
            "manual": sum(1 for r in found if r["manual"]), "old_ratio": round(n_old / n_dates, 2) if n_dates else 0,
            "old_drive": old_drive, "newest": newest, "label_hint": hint,
            "x_warn": x_warn, "extras_found": sum(1 for r in res if r["x_id"]), "extras_layout": {"container": cont, "sub": sub, "label": str(lay.get("label") or "")},
            "manual_map": mm, "extras_map": xm}


def drive_suggest(body: dict) -> dict:
    """드라이브 링크 안을 둘러보고 과목 폴더들이 든 곳·추가자료 위치를 추천 (want: extras / manual)"""
    from . import drive as D
    root = D.folder_id_of(str(body.get("root") or body.get("folder") or ""))
    if not re.fullmatch(r"[\w-]{10,}", root or ""):
        return {"ok": False, "msg": "드라이브 링크를 먼저 넣어 주세요."}
    sem = str(body.get("semester") or _read_cfg().get("drive_semester") or "2학기").strip()
    try:
        cands = D.suggest_layouts(root, sem, _tt_courses_names(), "manual" if body.get("want") == "manual" else "extras")
    except Exception as e:
        return {"ok": False, "msg": "드라이브를 둘러보지 못했어요: " + M.err(e)}
    if not cands:
        return {"ok": False, "msg": "시간표 과목 폴더가 들어 있는 폴더를 못 찾았어요. 직접 골라 주세요."}
    return {"ok": True, "semester": sem, "cands": cands[:4]}


def old_status(body: dict) -> dict:
    """설정 › 선배 추가자료 줄 옆 표시: 이번 학기 과목 폴더를 몇 개 찾았는지 (내 폴더는 더 깊이 자동으로 찾아봄)"""
    from . import drive as D
    o = body.get("row") if isinstance(body.get("row"), dict) else {}
    local, folder = str(o.get("local") or "").strip(), str(o.get("folder") or "").strip()
    if not (local or folder):
        return {"ok": False, "msg": ""}
    if local and not Path(os.path.expanduser(local)).is_dir():
        return {"ok": False, "msg": "내 폴더를 찾을 수 없어요"}
    if folder and not local and not re.fullmatch(r"[\w-]{10,}", D.folder_id_of(folder) or ""):
        return {"ok": False, "msg": "드라이브 링크를 확인해 주세요"}
    courses = _tt_courses_names()
    if not courses:
        return {"ok": False, "msg": "시간표가 없어요"}
    cmap = o.get("map") if isinstance(o.get("map"), dict) else {}
    src = {"local": local, "folder": "" if local else folder, "path": str(o.get("path") or ""),
           "map": {str(k): ([str(x) for x in v if isinstance(x, str)] if isinstance(v, list) else str(v)) for k, v in cmap.items() if v}}
    sem = str(o.get("semester") or _read_cfg().get("drive_semester") or "2학기").strip()
    try:
        r = D.old_check(src, sem, courses)
    except Exception as e:
        return {"ok": False, "msg": "확인하지 못했어요: " + M.err(e)}
    r["total"] = len(courses)
    return r


def local_check_old(body: dict) -> dict:
    """내 폴더 선배 자료: 과목마다 어느 폴더인지 보고 고치기 (드라이브의 「과목 폴더 연결」과 같은 창)"""
    from . import drive as D
    o = body.get("row") if isinstance(body.get("row"), dict) else {}
    local = str(o.get("local") or "").strip()
    if not local or not Path(os.path.expanduser(local)).is_dir():
        return {"ok": False, "msg": "내 폴더를 찾을 수 없어요."}
    courses = _tt_courses_names()
    if not courses:
        return {"ok": False, "msg": "시간표가 없어요."}
    cmap = o.get("map") if isinstance(o.get("map"), dict) else {}
    root = Path(os.path.expanduser(local)).resolve()
    cmap = {str(k): ([str(x) for x in v if isinstance(x, str) and Path(os.path.expanduser(x)).is_absolute()][:12] if isinstance(v, list) else str(v))
            for k, v in cmap.items() if v and (isinstance(v, list) or str(v) == "-" or M._within(Path(str(v)), root))}   # 고른 폴더 하나 = 그 내 폴더 안만 · 여러 개 = Finder로 고른 곳
    src = {"local": local, "path": str(o.get("path") or ""), "map": cmap,
           "only": str(o.get("only") or "")[:80], "skip": str(o.get("skip") or "")[:80], "sub": str(o.get("sub") or "")}
    sem = str(o.get("semester") or _read_cfg().get("drive_semester") or "2학기").strip()
    try:
        return D.old_local_check(src, sem, courses)
    except Exception as e:
        return {"ok": False, "msg": "확인하지 못했어요: " + M.err(e)}


def drive_check_old(body: dict) -> dict:
    """선배 필야 폴더 확인: 학기 폴더 안에서 시간표 과목마다 맞는 폴더 (직접 고른 것 포함) + 파일 수"""
    from . import drive as D
    from concurrent.futures import ThreadPoolExecutor
    src = {"folder": str(body.get("folder") or ""), "path": str(body.get("path") or "")}
    sub = str(body.get("sub") or "").strip()          # 학기 › 과목 › 추가자료 구조: 과목 폴더 안 폴더
    sem = str(body.get("semester") or "").strip() or "."
    try:
        sid = D.old_sem_folder(src, sem)
        es = D.list_folder(sid) if sid else []
    except Exception:
        return {"ok": False, "msg": "선배 드라이브 폴더를 열지 못했어요. 링크와 공유 설정을 확인해 주세요."}
    if not sid:
        return {"ok": False, "msg": f"「{' › '.join(D.old_parts(src, sem)) or '링크한 폴더'}」 경로를 못 찾았어요. 구조를 다시 골라 주세요."}
    cmap = body.get("map") if isinstance(body.get("map"), dict) else {}
    cmap = {str(k): str(v) for k, v in cmap.items() if v}
    courses = _tt_courses_names()

    def one(c):
        f, how = D.match_course_folder(c, es, cmap, courses)
        r = {"course": c, "folder": f[1] if f else "", "folder_id": f[0] if f else "", "how": how, "files": 0, "sub": ""}
        if f and sub:
            try:
                x = D.find_sub(D.list_folder(f[0]), sub)
            except Exception:
                x = None
            r["sub"] = x[1] if x else ""
            if not x:
                r["files"] = 0
                return r
            f = (x[0], x[1])
        if f:
            try:
                n, stack = 0, [(f[0], 0)]
                while stack and n < 300:
                    fid, dep = stack.pop()
                    for e in D.list_folder(fid):
                        if e[2] and dep < 2:
                            stack.append((e[0], dep + 1))
                        elif not e[2]:
                            n += 1
                r["files"] = n
            except Exception:
                pass
        return r
    with ThreadPoolExecutor(6) as ex:
        res = list(ex.map(one, courses))
    return {"ok": True, "courses": res, "found": sum(1 for r in res if r["folder"]), "total": len(res),
            "dirs": [{"id": i, "name": n} for i, n, isdir, _ in es if isdir]}


def settings_state() -> dict:
    from . import secrets_store, notion_sync
    from .lms import KEYCHAIN_SERVICE
    cfg = _read_cfg()
    from . import lms as _lms
    lms_acct = (_lms.SESSION_CRED or ("",))[0] if shared_pc() else secrets_store.account(KEYCHAIN_SERVICE)
    return {
        "save_root": cfg.get("save_root", ""),
        "tt_label": cfg.get("tt_label", ""),          # 배포판에 들어 있는 시간표 이름 (예: 2026 본과 2학년)
        "grades": [g["name"] for g in _grades.grades()], "grade": _grades.current()[0], "p1": _period1(),
        "icloud": _icloud_synced(), "home": str(Path.home()).replace("\\", "/"),                    # 맥: iCloud와 동기화되는 바탕 화면·문서
        "drive_root": cfg.get("drive_root", ""),
        "drive_semester": cfg.get("drive_semester", ""),
        "drive_sem_label": cfg.get("drive_sem_label", ""),
        "drive_sem_id": cfg.get("drive_sem_id", ""),
        "drive_course_map": cfg.get("drive_course_map") or {}, "drive_course_map_root": cfg.get("drive_course_map_root") or "",
        "drive_manual_map": cfg.get("drive_manual_map") or {}, "drive_extras_map": cfg.get("drive_extras_map") or {},
        "drive_extras": cfg.get("drive_extras") or {},
        "extras": cfg.get("extras", True),
        "drive_mode": "link" if cfg.get("drive_mode") == "link" else "save",
        "extras_label": cfg.get("extras_label", ""),
        "extras_old": cfg.get("extras_old") or [],
        "extras_order": cfg.get("extras_order") or [],
        "custom_dirs": {k: dict(v) for k, v in (cfg.get("custom_dirs") or {}).items() if isinstance(v, dict)},
        "default_dirs": {"lec": str(M.MANUAL_ROOT), "x": str(M.EXTRA_ROOT)},
        "board_include": cfg.get("board_include") or ["강의자료"],
        "cover": cfg.get("cover", True), "keep_orig": bool(cfg.get("keep_orig")), "split_name": cfg.get("split_name") or "tt", "paper": cfg.get("paper", "A4" if cfg.get("a4", True) else ""),
        "font": _font_info(cfg), "menubar": cfg.get("menubar", True) is not False,
        "notion_sources": (cfg.get("notion") or {}).get("sources") or {},
        "courses": tt_courses(load(M.DATA / "시간표.json")) if (M.DATA / "시간표.json").exists() else [],
        "lms": {"id": lms_acct, "saved": bool(_lms.SESSION_CRED) if shared_pc() else (bool(lms_acct) and secrets_store.has(KEYCHAIN_SERVICE))},
        "shared_pc": shared_pc(),
        "notion": {"saved": secrets_store.has(notion_sync.KEYCHAIN)},
        "keychain": "키체인" if sys.platform == "darwin" else "자격 증명 관리자",
        "notify": {"on": (cfg.get("notify") or {}).get("on", True) is not False,
                   "kinds": [{"k": k, "name": v, "on": (cfg.get("notify") or {}).get(k, True) is not False} for k, v in _notifier_kinds().items()]},
    }


def _notifier_kinds() -> dict:
    from . import notifier
    return notifier.KINDS


def _save_root_problem(v: str) -> str:
    """정리 폴더로 고른 곳이 위험하면 이유 ('' = 괜찮음): 홈·드라이브 맨 위, 과목별 저장 위치·클라우드 복사 폴더와 겹침"""
    try:
        p = Path(os.path.expanduser(v)).resolve()
    except Exception:
        return "폴더 경로가 이상해요."
    if len(p.parts) <= 1 or M._within(Path.home(), p):
        return "홈 폴더나 드라이브 맨 위는 고를 수 없어요. 그 안에 「매뉴얼 정리」 같은 폴더를 만들어 골라 주세요."
    if M._within(p, M.APP) or M._within(M.APP, p):
        return "앱 폴더(강의록앱) 안이나 그 위쪽은 고를 수 없어요 (앱을 업데이트·삭제할 때 같이 지워져요). 다른 폴더를 골라 주세요."
    for b, _ in M.custom_bases():
        if M._within(b, p) or M._within(p, b):
            return f"과목별 저장 위치로 정한 폴더({b})와 겹쳐요. 다른 폴더를 골라 주세요."
    try:
        from . import cloud as _c
        for d in _c.copy_dirs().values():
            if M._within(d, p) or M._within(p, d):
                return "클라우드 복사 폴더와 겹쳐요. 다른 폴더를 골라 주세요."
    except Exception:
        pass
    return ""


def settings_set(body: dict) -> dict:
    from .drive import folder_id_of
    cfg = _read_cfg()
    msgs = []
    if "save_root" in body:
        v = str(body["save_root"]).strip()
        if not v:
            return {"ok": False, "msg": "저장 폴더를 적어 주세요."}
        why = _save_root_problem(v)
        if why:
            return {"ok": False, "msg": why}
        if v != cfg.get("save_root"):
            cfg["save_root"] = v
            msgs.append("저장 폴더를 바꿨어요 (이미 받아 둔 강의록은 예전 폴더에 그대로 있어요)")
    if "drive_root" in body:
        fid = folder_id_of(str(body["drive_root"]))
        if fid and not re.fullmatch(r"[\w-]{10,}", fid):
            return {"ok": False, "msg": "드라이브 폴더 링크를 확인해 주세요."}
        if fid != cfg.get("drive_root") and "drive_sem_id" not in body:
            cfg["drive_sem_id"] = ""            # 드라이브를 바꾸면 예전에 고른 학기 폴더는 지움
            cfg["drive_sem_label"] = ""
        cfg["drive_root"] = fid
    if "drive_course_map" in body and isinstance(body["drive_course_map"], dict):
        cfg["drive_course_map"] = {str(k)[:80]: str(v) for k, v in body["drive_course_map"].items()
                                   if v and (str(v) == "-" or re.fullmatch(r"[\w-]{10,}", str(v)))}
        cfg["drive_course_map_root"] = folder_id_of(str(body.get("drive_course_map_root") or "")) or cfg.get("drive_root", "")
    _idmap = lambda m: {str(k)[:80]: str(v) for k, v in m.items() if v and (str(v) == "-" or re.fullmatch(r"[\w-]{10,}", str(v)))}
    for k in ("drive_manual_map", "drive_extras_map"):            # 과목마다 직접 고른 매뉴얼·추가자료 폴더
        if k in body and isinstance(body[k], dict):
            cfg[k] = _idmap(body[k])
    if "drive_extras" in body and isinstance(body["drive_extras"], dict):   # 추가자료 위치
        de = body["drive_extras"]
        cont = str(de.get("container") or "").strip()
        if cont and not re.fullmatch(r"[\w-]{10,}", cont):
            return {"ok": False, "msg": "추가자료 폴더를 다시 골라 주세요."}
        cfg["drive_extras"] = {"container": cont, "sub": str(de.get("sub", "추가자료"))[:40], "label": str(de.get("label") or "")[:120]}
    if "drive_maps_sem" in body:
        ms = str(body["drive_maps_sem"] or "").strip()
        cfg["drive_maps_sem"] = ms if re.fullmatch(r"[\w-]{10,}", ms) else ""
    if "drive_sem_id" in body:
        sid = str(body["drive_sem_id"] or "").strip()
        if sid and not re.fullmatch(r"[\w-]{10,}", sid):
            return {"ok": False, "msg": "학기 폴더를 다시 골라 주세요."}
        if sid != (cfg.get("drive_sem_id") or "") and "drive_maps_sem" not in body and not cfg.get("drive_maps_sem"):
            cfg["drive_maps_sem"] = cfg.get("drive_sem_id") or "-"     # 예전 설정: 지금까지 고른 폴더는 이전 학기 폴더 것으로 기록
        cfg["drive_sem_id"] = sid
    for k in ("drive_semester", "extras_label", "drive_sem_label"):
        if k in body:
            cfg[k] = str(body[k]).strip()
    if "shared_pc" in body:                     # 여러 사람이 쓰는 컴퓨터 (이 컴퓨터만 · 동기화 안 함)
        cfg["shared_pc"] = body["shared_pc"] is True
        if cfg["shared_pc"]:
            from . import secrets_store as _ss
            from .lms import KEYCHAIN_SERVICE as _K
            _ss.delete(_K)                       # 전에 저장한 비밀번호도 지움
    if "extras" in body:
        cfg["extras"] = bool(body["extras"])
    if body.get("drive_mode") in ("save", "link"):   # 학년 드라이브 자료: 이 컴퓨터에 받아 두기 / 받지 않고 인터넷으로만 보기
        cfg["drive_mode"] = body["drive_mode"]
    if "keep_orig" in body:                      # PPT·워드 등 원본 파일도 같이 저장 (기본: PDF만)
        cfg["keep_orig"] = bool(body["keep_orig"])
    if body.get("split_name") in ("tt", "orig"):   # 강의록 여러 개를 폴더에 따로 만들 때 안쪽 파일 이름
        cfg["split_name"] = body["split_name"]
    mb_on = None
    if "menubar" in body:                       # 맥 메뉴 막대 현황 켜기·끄기 (저장한 뒤에 켜고 끔)
        cfg["menubar"] = mb_on = bool(body["menubar"])
    changed = False
    if "cover" in body and bool(body["cover"]) != cfg.get("cover", True):
        cfg["cover"] = bool(body["cover"])
        changed = True
    if "paper" in body:
        pp = str(body["paper"] or "")
        if pp and pp not in ("A4", "B5", "A5", "Letter"):
            m = re.fullmatch(r"\s*(\d+(?:\.\d+)?)\s*[x×*]\s*(\d+(?:\.\d+)?)\s*", pp)
            if not m or not all(50 <= float(v) <= 1200 for v in m.groups()):
                return {"ok": False, "msg": "사용자 설정 용지는 가로·세로를 50~1200mm 사이로 적어 주세요."}
            pp = f"{float(m.group(1)):g}x{float(m.group(2)):g}"
        old_pp = cfg.get("paper", "A4" if cfg.get("a4", True) else "")
        if pp != old_pp:
            cfg["paper"] = pp
            cfg.pop("a4", None)
            changed = True
    if changed:
        msgs.append("앞으로 만드는 강의록부터 새 설정을 써요 (이미 만든 것은 「새 표지로 바꾸기」)")
    if "board_include" in body:
        cfg["board_include"] = [x.strip() for x in body["board_include"] if str(x).strip()] or ["강의자료"]
    if "extras_old" in body:
        raw_old = body["extras_old"]
        if not isinstance(raw_old, list):
            return {"ok": False, "msg": "선배 추가자료 목록을 읽지 못했어요. 화면을 새로고침한 뒤 다시 저장해 주세요."}
        prev_old = [x for x in (cfg.get("extras_old") or []) if isinstance(x, dict)]
        if not raw_old and prev_old and not body.get("extras_old_clear"):
            return {"ok": False, "msg": "선배 추가자료 목록이 비어서 왔어요. 화면을 새로고침한 뒤 다시 저장해 주세요."}
        prev_local = {(str(x.get("label", "")).strip(), str(x.get("local", "")).strip()) for x in prev_old if x.get("local")}
        olds = []
        for o in raw_old:
            if not isinstance(o, dict):
                continue
            lab, link = str(o.get("label", "")).strip(), str(o.get("folder", "")).strip()
            local = str(o.get("local", "")).strip()            # 드라이브 대신 내 컴퓨터 폴더
            if not lab and not link and not local:
                continue
            if not lab or not (link or local):
                return {"ok": False, "msg": "선배 추가자료는 이름(학번)과 드라이브 링크 또는 내 폴더를 둘 다 정해 주세요."}
            if local and (lab, local) not in prev_local and not Path(os.path.expanduser(local)).is_dir():   # 이미 저장된 폴더는 지금 안 보여도(외장 디스크 등) 통과
                return {"ok": False, "msg": f"「{lab}」 내 폴더를 찾을 수 없어요: {local}"}
            lab2 = re.sub(r"\s*학번$", "", lab).strip() if re.fullmatch(r"\d+\s*학번?", lab) else lab   # 「20학번」→ 20 · 그 밖의 이름은 적은 그대로 (폴더 이름)
            lab2 = re.sub(r'[\\/:*?"<>|]', "", lab2)[:30].strip()
            if not lab2:
                return {"ok": False, "msg": "선배 추가자료 이름에 쓸 수 없는 글자만 있어요."}
            mine_ = str(cfg.get("extras_label", "")).strip()
            if lab2.strip(". ") == "" or M.safe(lab2) in ("", "올해"):
                return {"ok": False, "msg": f"「{lab2}」는 폴더 이름으로 쓸 수 없어요. 학번이나 이름을 적어 주세요."}
            if lab2 in {o["label"] for o in olds} or lab2 == mine_ or M.xfolder(lab2) in {M.xfolder(o["label"]) for o in olds} | {M.xfolder(mine_)}:
                return {"ok": False, "msg": f"「{lab2}」가 두 번 들어가 있어요. 하나만 남겨 주세요."}
            olds.append({"label": lab2, **({"folder": folder_id_of(link)} if link else {"local": local}),
                         "path": str(o.get("path", "")).strip().strip("/"),
                         **({"sub": str(o["sub"]).strip()[:40]} if str(o.get("sub") or "").strip() else {}),
                         **({"only": str(o["only"]).strip()[:80]} if str(o.get("only") or "").strip() else {}),     # 이 이름의 폴더만 읽기 (예: PDF)
                         **({"skip": str(o["skip"]).strip()[:80]} if str(o.get("skip") or "").strip() else {}),     # 이 이름의 폴더는 빼기 (예: 한글)
                         **({"year": str(o["year"]).strip()} if re.fullmatch(r"20\d\d", str(o.get("year") or "").strip()) else {}),   # 자료 연도: 그해 시간표의 교수로 강의 찾기
                         **({"semester": str(o["semester"]).strip()} if str(o.get("semester", "")).strip() else {}),
                         **({"map": {str(k)[:80]: ([str(x)[:400] for x in v if isinstance(x, str) and x.strip() and Path(os.path.expanduser(x)).is_absolute()
                                                    and len(Path(os.path.expanduser(x)).parts) > 2 and Path(os.path.expanduser(x)) != Path.home()][:12]
                                                   if isinstance(v, list) else str(v))       # 내 폴더: 과목마다 Finder로 고른 폴더 여러 개
                                 for k, v in o["map"].items() if v and (isinstance(v, list) and not link or str(v) == "-" or (re.fullmatch(r"[\w-]{10,}", str(v)) if link else  # 드라이브 = 폴더 id · 내 폴더 = 그 폴더 안 경로
                                 M._within(Path(str(v)), Path(os.path.expanduser(local)))))}}
                            if isinstance(o.get("map"), dict) and o["map"] else {})})
        cfg["extras_old"] = olds
    if isinstance(body.get("extras_order"), list):      # 추가자료 칸 순서: "@own"(우리 학번) · 선배 이름
        od = []
        for k in body["extras_order"][:40]:
            k = str(k).strip()
            if k != "@own":
                k = re.sub(r"\s*학번$", "", k).strip() if re.fullmatch(r"\d+\s*학번?", k) else k
                k = re.sub(r'[\\/:*?"<>|]', "", k)[:30].strip()
            if k and k not in od:
                od.append(k)
        cfg["extras_order"] = od
    if "notion_sources" in body:
        src = {}
        for c, v in (body["notion_sources"] or {}).items():
            v = str(v or "").strip()
            if not v:
                continue
            m = re.search(r"[0-9a-f]{32}", v.split("?")[0].replace("-", "").lower())   # 링크면 ?v=(보기 id) 앞부분
            raw = m.group(0) if m else ""
            if len(raw) != 32:
                return {"ok": False, "msg": f"{c}: 노션 표 링크(또는 ID)를 확인해 주세요."}
            src[c] = f"{raw[:8]}-{raw[8:12]}-{raw[12:16]}-{raw[16:20]}-{raw[20:]}"
        cfg.setdefault("notion", {})["sources"] = src
    _write_cfg(cfg)
    _xrec.clear()
    if mb_on is not None:
        def _mb(on=mb_on):
            time.sleep(0.5)
            try:
                from . import menubar
                menubar.launch() if on else menubar.stop()
            except Exception:
                pass
        threading.Thread(target=_mb, daemon=True).start()
    return {"ok": True, "msg": "저장했어요." + (" " + " · ".join(msgs) if msgs else "")}


def open_in_browser(body: dict) -> dict:
    """앱 설치(강의록앱 아이콘)는 주소창이 있는 보통 크롬 창에서만 돼서, 보통 창으로 엶"""
    url = f"http://127.0.0.1:{PORT}/#install"
    try:
        if sys.platform == "darwin":
            for app in ("Google Chrome", "Microsoft Edge", "Chromium", "Brave Browser"):
                if subprocess.run(["open", "-a", app, url], capture_output=True).returncode == 0:
                    return {"ok": True}
        elif os.name == "nt":
            for exe in [Path(os.environ.get(v, "")) / sub for v in ("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA")
                        for sub in ("Google/Chrome/Application/chrome.exe", "Microsoft/Edge/Application/msedge.exe")]:
                if exe.is_file():
                    subprocess.Popen([str(exe), url])
                    return {"ok": True}
        import webbrowser
        webbrowser.open(url)
        return {"ok": True}
    except Exception as e:
        return {"ok": False, "msg": f"브라우저를 못 열었어요 ({type(e).__name__})"}


def custom_dir_set(body: dict) -> dict:
    """설정 › 저장 위치 › 과목별: 종류(lec 강의록 · x 추가자료)·과목마다 저장 폴더 바꾸기 · 이미 받은 파일도 새 폴더로 옮김"""
    kind, course = str(body.get("kind") or ""), str(body.get("course") or "").strip()
    raw = str(body.get("path") or "").strip()
    if kind not in M.CUSTOM_KINDS:
        return {"ok": False, "msg": "종류가 이상해요."}
    try:
        names = tt_courses(load(M.DATA / "시간표.json"))
    except Exception:
        names = []
    if course not in names:
        return {"ok": False, "msg": "시간표에 없는 과목이에요."}
    js = job_state()
    if js["running"] or js["external"]:
        return {"ok": False, "msg": "받는 중에는 바꿀 수 없어요. 끝난 뒤에 바꿔 주세요."}
    new = None
    if raw:
        try:
            newp = Path(os.path.expanduser(raw)).resolve()
        except Exception:
            return {"ok": False, "msg": "폴더 경로가 이상해요."}
        if not newp.is_absolute():
            return {"ok": False, "msg": "폴더를 「폴더 고르기」로 골라 주세요."}
        from .timetable import folder_course
        own_def = (M.MANUAL_ROOT if kind == "lec" else M.EXTRA_ROOT) / folder_course(course)
        if M._same_dir(newp, own_def):          # 원래 자리를 고름 = 기본으로 되돌리기
            newp = None
        else:
            why = M.custom_dir_problem(kind, course, newp, names)
            if why:
                return {"ok": False, "msg": why}
        new = str(newp) if newp else None
    return _with_run_lock(lambda: _custom_dir_apply(kind, course, new), "받는 중에는 바꿀 수 없어요. 끝난 뒤에 바꿔 주세요.")


def _take_run_lock() -> Optional[bool]:
    """받기 잠금 파일을 이 화면 프로세스 이름으로 잡음 (그동안 예약 받기가 시작되지 않게)
    · True 잡음 · False 다른 받기가 진행 중 · None 파일을 못 만듦(권한 등 — 그냥 진행)"""
    M.RUN_LOCK.parent.mkdir(parents=True, exist_ok=True)
    for _ in range(2):
        try:
            fd = os.open(str(M.RUN_LOCK), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write(json.dumps({"pid": os.getpid(), "auto": False, "started": "", "move": True}))
            return True
        except FileExistsError:
            if M.run_lock() is not None:          # 정말 받는 중
                return False
            try:
                M.RUN_LOCK.unlink()               # 꺼진 실행이 남긴 잠금 → 지우고 다시
            except OSError:
                return False
        except OSError:
            return None
    return False


def _with_run_lock(fn, busy_msg: str) -> dict:
    """파일을 옮기거나 이름을 바꾸는 동안: 화면 잠금(_lock) + 받기 잠금 파일"""
    if not _lock.acquire(timeout=5):
        return {"ok": False, "msg": "다른 작업 중이에요. 잠시 뒤에 다시 눌러 주세요."}
    held = False
    try:
        if (_job["proc"] and _job["proc"].poll() is None) or _external_running():
            return {"ok": False, "msg": busy_msg}
        t = _take_run_lock()
        if t is False:
            return {"ok": False, "msg": busy_msg}
        held = bool(t)
        return fn()
    finally:
        if held:
            try:
                M.RUN_LOCK.unlink()
            except OSError:
                pass
        _lock.release()


def _custom_dir_apply(kind: str, course: str, new: Optional[str]) -> dict:
    with M.CFG_LOCK:
        M.CFG.update(_read_cfg())
        try:
            res = M.move_course_dir(kind, course, new)
        except Exception as e:
            return {"ok": False, "msg": f"옮기지 못했어요: {M.err(e)}"}
        if res.get("err"):
            return {"ok": False, "msg": res["err"]}
        cfg = _read_cfg()
        cd = cfg.get("custom_dirs") if isinstance(cfg.get("custom_dirs"), dict) else {}
        cd.setdefault(kind, {})
        if new:
            cd[kind][course] = new
        else:
            cd[kind].pop(course, None)
        cd = {k: v for k, v in cd.items() if v}
        if cd:
            cfg["custom_dirs"] = cd
        else:
            cfg.pop("custom_dirs", None)
        _write_cfg(cfg)
        M.CFG.update(cfg)
        if not cd:
            M.CFG.pop("custom_dirs", None)
        else:
            M.CFG["custom_dirs"] = cd
    sk = res.get("skipped") or []
    msg = (f"바꿨어요 · 이미 받은 것 {res.get('moved', 0)}개를 옮겼어요" if res.get("moved") else "바꿨어요") + \
          (f" · 같은 이름이 있어 {len(sk)}개는 그대로 뒀어요" if sk else "")
    return {"ok": True, "msg": msg, "moved": res.get("moved", 0), "skipped": sk[:20]}


def pick_folder(body: dict) -> dict:
    """Finder(맥)·탐색기(Windows) 창으로 폴더 고르기 → 경로를 돌려줌 (경로를 직접 안 써도 되게)"""
    cur = Path(str(body.get("current") or "~")).expanduser()
    start = cur if cur.is_dir() else (cur.parent if cur.parent.is_dir() else Path.home())
    try:
        if sys.platform == "darwin":
            q = lambda t: t.replace("\\", "\\\\").replace('"', '\\"')
            script = (f'set f to choose folder with prompt "강의록을 정리할 폴더를 고르세요" '
                      f'default location (POSIX file "{q(str(start))}")\nreturn POSIX path of f')
            # 'activate' = osascript 자기 창을 맨 앞으로 (다른 앱 제어 권한이 필요 없음)
            r = subprocess.run(["osascript", "-e", "activate", "-e", script],
                               capture_output=True, text=True, timeout=600)
            path = (r.stdout or "").strip()
        elif os.name == "nt":
            ps = ("Add-Type -AssemblyName System.Windows.Forms;"
                  "$d=New-Object System.Windows.Forms.FolderBrowserDialog;"
                  "$d.Description='강의록을 정리할 폴더를 고르세요';$d.ShowNewFolderButton=$true;"
                  f"$d.SelectedPath='{str(start).replace(chr(39), chr(39) * 2)}';"
                  "$w=New-Object System.Windows.Forms.Form;$w.TopMost=$true;"
                  "if($d.ShowDialog($w) -eq 'OK'){[Console]::OutputEncoding=[Text.Encoding]::UTF8;Write-Output $d.SelectedPath}")
            r = subprocess.run(["powershell", "-NoProfile", "-STA", "-Command", ps], capture_output=True, timeout=600)
            path = (r.stdout or b"").decode("utf-8", "ignore").strip()
        else:
            r = subprocess.run(["zenity", "--file-selection", "--directory", f"--filename={start}/"],
                               capture_output=True, text=True, timeout=600)
            path = (r.stdout or "").strip()
    except Exception as e:
        return {"ok": False, "msg": f"폴더 고르기 창을 못 열었어요 ({type(e).__name__}). 경로를 직접 적어 주세요."}
    if not path:
        return {"ok": False, "cancel": True}
    p = Path(path).expanduser()
    home = Path.home()
    shown = "~/" + str(p.relative_to(home)).replace("\\", "/") if home in p.parents else str(p)
    return {"ok": True, "path": shown.rstrip("/") or str(p)}


def setup_done(body: dict) -> dict:
    """처음 설정 화면을 끝냈다고 표시 (다음부터 안 뜸). 설정 탭에서 언제든 다시 바꿀 수 있음."""
    cfg = _read_cfg()
    cfg["setup_done"] = bool(body.get("done", True))
    _write_cfg(cfg)
    return {"ok": True}


def _font_info(cfg: dict) -> dict:
    from . import render
    uf = render.user_font()
    lst = []
    if render.USER_FONT_DIR.is_dir():
        for f in sorted(render.USER_FONT_DIR.iterdir(), key=lambda p: p.stat().st_mtime):
            if f.is_file() and f.suffix.lower() in FONT_EXT:
                lst.append({"file": f.name, "name": render.font_family(f) or f.stem})
    base = "Apple SD 산돌고딕 Neo" if sys.platform == "darwin" else ("맑은 고딕" if os.name == "nt" and render.WIN_KO[0].exists() else "Pretendard (앱 기본)")
    if uf:
        return {"user": True, "name": render.font_family(uf), "file": uf.name, "list": lst, "default": base}
    return {"user": False, "name": base, "list": lst, "default": base}


FONT_EXT = (".ttf", ".otf", ".ttc")


# ---------------------------------------------------------------- 표지 모양 (기본 + 내가 넣은 HTML 표지)
_COVER_LOCK = threading.Lock()


def _sample_lecture():
    """미리보기용 강의: 내 시간표에서 역대 교수가 있고 올해와 다른 해가 있는 강의 (없으면 예시)"""
    from .timetable import Lecture
    try:
        ls = load(M.DATA / "시간표.json")
        ls = sorted(ls, key=lambda L: (-sum(1 for _y, ps in L.history() if ps and set(ps) != set(L.profs)),
                                       -len([1 for _y, ps in L.history() if ps]), len(L.title)))
        if ls:
            return ls[0]
    except Exception:
        pass
    sd = render.SAMPLE_LECTURE
    hist = [(sd["year"], sd["profs"])] + [(h["year"], h["profs"]) for h in sd["history"]]
    return Lecture(sd["course"], sd["term"], sd["mmdd"], sd["period_start"], sd["hours"], list(sd["titles"]),
                   list(sd["profs"]), extra={"hist": hist})


def covers_state() -> dict:
    from . import covers as C
    cfg = _read_cfg()
    cur = cfg.get("cover_template", "")
    items = C.list_covers(M.APP)
    if cur and not any(x["id"] == cur for x in items):
        cur = ""
    L = _sample_lecture()
    return {"items": items, "selected": cur, "cover": cfg.get("cover", True) is not False, "prompt": C.cover_prompt(render.cover_data(L), render.YEAR_KEY),
            "sample": render.cover_data(L)}


def cover_preview(cid: str) -> Optional[bytes]:
    """표지 미리보기 PNG (만든 것은 .cache 에 보관)"""
    from . import covers as C
    items = {x["id"]: x for x in C.list_covers(M.APP)}
    if cid not in items:
        return None
    tpl = C.read_cover(M.APP, cid) if cid else None
    L = _sample_lecture()
    sig = hashlib.md5(json.dumps([items[cid]["ver"], render.cover_data(L), str(render.user_font() or "")],
                                 ensure_ascii=False).encode("utf-8")).hexdigest()[:12]
    d = M.APP / ".cache" / "cover_prev"
    f = d / f"{(cid or 'builtin').replace('.html', '')}-{sig}.png"
    if f.exists():
        return f.read_bytes()
    with _COVER_LOCK:
        d.mkdir(parents=True, exist_ok=True)
        rd = render.Renderer()
        try:
            rd.cover_png(L, f, tpl, C.read_bg(M.APP, cid) if cid else None)
        finally:
            rd.close()
    return f.read_bytes() if f.exists() else None


def cover_add(body: dict) -> dict:
    from . import covers as C
    text = str(body.get("html") or "")
    m = re.search(r"```(?:html)?\s*(.*?)```", text, re.S | re.I)      # AI 답을 통째로 붙여 넣은 경우 코드만
    if m and "<" in m.group(1):
        text = m.group(1)
    bad = C.check_template(text)
    if bad:
        return {"ok": False, "msg": bad}
    # 미리 한 번 그려 봄 (오류면 알려 줌)
    try:
        with _COVER_LOCK:
            rd = render.Renderer()
            try:
                tmp = M.APP / ".cache" / "cover_test.pdf"
                tmp.parent.mkdir(parents=True, exist_ok=True)
                rd.render_template(text, render.cover_data(_sample_lecture()), tmp)
            finally:
                rd.close()
    except Exception as e:
        return {"ok": False, "msg": f"이 HTML로 표지를 만들지 못했어요 ({type(e).__name__}). AI에게 다시 만들어 달라고 해 주세요."}
    if body.get("id"):                     # 앱에서 만든 표지 고치기
        bad = C.update_cover(M.APP, str(body["id"]), text)
        if bad:
            return {"ok": False, "msg": bad}
        return {"ok": True, "id": body["id"], "msg": "표지를 고쳤어요. 앞으로 만드는 강의록부터 써요 (이미 만든 것은 「새 표지로 바꾸기」)."}
    cid = C.save_cover(M.APP, str(body.get("name") or ""), text)
    if body.get("select", True):
        with M.CFG_LOCK:
            cfg = _read_cfg()
            cfg["cover_template"] = cid
            cfg["cover"] = True
            _write_cfg(cfg)
    return {"ok": True, "id": cid, "msg": "표지를 넣고 골랐어요. 앞으로 만드는 강의록부터 이 표지를 써요 (이미 만든 것은 「새 표지로 바꾸기」)."}


def cover_bg(body: dict) -> dict:
    """표지 배경 사진 넣기·빼기 (화면이 사진을 줄여 JPEG data: 주소로 보냄)"""
    from . import covers as C
    import base64
    cid = str(body.get("id") or "")
    raw = None
    if not body.get("remove"):
        d = str(body.get("data") or "")
        m = re.fullmatch(r"data:image/jpeg;base64,([A-Za-z0-9+/=\s]+)", d)
        if not m:
            return {"ok": False, "msg": "사진을 읽지 못했어요. 다른 사진으로 해 주세요."}
        try:
            raw = base64.b64decode(m.group(1))
        except Exception:
            return {"ok": False, "msg": "사진을 읽지 못했어요."}
    bad = C.save_bg(M.APP, cid, raw)
    if bad:
        return {"ok": False, "msg": bad}
    return {"ok": True, "msg": "사진을 뺐어요." if raw is None else "사진을 넣었어요. 이미 만든 강의록도 바꾸려면 「새 표지로 바꾸기」를 눌러 주세요."}


def cover_make(body: dict) -> dict:
    """표지만 따로 PDF로: 시간표에서 고른 강의 또는 직접 입력한 강의 → <저장 폴더>/표지 만들기/"""
    from . import covers as C
    from .timetable import Lecture
    from pypdf import PdfReader, PdfWriter
    items = body.get("items") or []
    if not items:
        return {"ok": False, "msg": "표지를 만들 강의를 넣어 주세요."}
    if len(items) > 400:
        return {"ok": False, "msg": "한 번에 400개까지 만들 수 있어요."}
    by_key = {L.key: L for L in load(M.DATA / "시간표.json")}
    lecs = []
    for it in items:
        L = by_key.get(str(it.get("key") or ""))
        if L is None:
            md = re.sub(r"\D", "", str(it.get("mmdd") or ""))
            if len(md) == 3:
                md = "0" + md
            title = str(it.get("title") or "").strip()
            if len(md) != 4 or not title or not (1 <= int(md[:2]) <= 12 and 1 <= int(md[2:]) <= 31):
                return {"ok": False, "msg": "날짜(예: 1012)와 강의 제목을 확인해 주세요."}
            per = re.findall(r"\d+", str(it.get("period") or "1"))
            st = int(per[0]) if per else 1
            hrs = max(1, int(per[-1]) - st + 1) if len(per) > 1 else 1
            profs = [x for x in re.split(r"[,·/\s]+", str(it.get("prof") or "")) if x]
            try:
                term = int(str(it.get("term") or 0) or 0)
            except ValueError:
                term = 0
            L = Lecture(course=str(it.get("course") or "").strip(), term=term, mmdd=md, start=st, hours=hrs,
                        titles=[title], profs=profs, extra={"hist": []})
        lecs.append(L)
    design = str(body.get("design") if body.get("design") is not None else "")
    tpl = C.read_cover(M.APP, design) if design else None
    bg = C.read_bg(M.APP, design) if design else None
    out = M.SAVE_ROOT / "표지 만들기"
    out.mkdir(parents=True, exist_ok=True)
    tmpd = M.APP / ".cache" / "cover_make"
    tmpd.mkdir(parents=True, exist_ok=True)
    made = []
    with _COVER_LOCK:
        rd = render.Renderer()
        try:
            rd.template, rd.template_bg = tpl, bg
            for i, L in enumerate(lecs):
                f = tmpd / f"{i:03d}.pdf"
                rd.cover(L, f)
                made.append((L, f))
            tfail = rd.template_error
        finally:
            rd.close()
    stamp = datetime.now().strftime("%m%d-%H%M%S")
    files = []
    if body.get("merge") and len(made) > 1:
        w = PdfWriter()
        for _, f in made:
            for pg in PdfReader(str(f)).pages:
                w.add_page(pg)
        dst = out / f"표지 모음 {stamp} ({len(made)}장).pdf"
        with open(dst, "wb") as fh:
            w.write(fh)
        files.append(dst)
    else:
        for L, f in made:
            name = M.safe(f"{L.mmdd}-{L.start}. {L.title}" + (f"_{'·'.join(p + 'T' for p in L.profs)}" if L.profs else "")) + " (표지).pdf"
            dst = out / name
            if dst.exists():
                dst = out / (dst.stem + f" {stamp}.pdf")
            shutil.copyfile(f, dst)
            files.append(dst)
    for _, f in made:
        try:
            f.unlink()
        except OSError:
            pass
    return {"ok": True, "files": [_rel(f) for f in files], "folder": _rel(out),
            "msg": (f"표지 {len(made)}장을 PDF 한 파일로 만들었어요." if len(made) > 1 and len(files) == 1
                    else f"표지 PDF {len(files)}개를 「표지 만들기」 폴더에 만들었어요." if len(files) > 1 else "표지 PDF를 만들었어요.")
                   + (" (고른 표지로 못 만든 것은 기본 표지로 만들었어요)" if tfail else "")}


def cover_builder(body: dict) -> dict:
    from . import covers as C
    st = C.builder_state(M.APP, str(body.get("id") or ""))
    return {"ok": bool(st), "state": st, "msg": "" if st else "앱에서 만든 표지가 아니에요."}


def cover_rename(body: dict) -> dict:
    from . import covers as C
    bad = C.rename_cover(M.APP, str(body.get("id") or ""), str(body.get("name") or ""))
    return {"ok": not bad, "msg": bad or "이름을 바꿨어요."}


def cover_select(body: dict) -> dict:
    from . import covers as C
    cid = str(body.get("id") or "")
    cfg = _read_cfg()
    if body.get("none"):                       # 표지 없음
        cfg["cover"] = False
        _write_cfg(cfg)
        return {"ok": True, "msg": "표지 없이 만들어요. 앞으로 만드는 강의록부터 (이미 만든 것은 「새 표지로 바꾸기」)."}
    if cid and not any(x["id"] == cid for x in C.list_covers(M.APP)):
        return {"ok": False, "msg": "없는 표지예요. 새로고침해 주세요."}
    if cfg.get("cover_template", "") == cid and cfg.get("cover", True) is not False:
        return {"ok": True, "msg": "이미 고른 표지예요."}
    cfg["cover"] = True
    cfg["cover_template"] = cid
    _write_cfg(cfg)
    _xrec.clear()
    return {"ok": True, "msg": "표지 모양을 바꿨어요. 앞으로 만드는 강의록부터 써요 (이미 만든 것은 「새 표지로 바꾸기」)."}


def cover_delete(body: dict) -> dict:
    from . import covers as C
    cid = str(body.get("id") or "")
    if not cid or cid.startswith("@") or not C.read_cover(M.APP, cid):
        return {"ok": False, "msg": "지울 수 없는 표지예요."}
    f = C.covers_dir(M.APP) / cid
    trash = C.covers_dir(M.APP) / "_지운표지"
    trash.mkdir(exist_ok=True)
    safe_replace(f, trash / cid) if not (trash / cid).exists() else f.unlink()
    bgf = C.bg_path(M.APP, cid)
    if bgf and bgf.exists():
        safe_replace(bgf, trash / bgf.name) if not (trash / bgf.name).exists() else bgf.unlink()
    try:
        nm = C._names(M.APP)
        if cid in nm:
            nm.pop(cid)
            (C.covers_dir(M.APP) / "_이름.json").write_text(json.dumps(nm, ensure_ascii=False, indent=1), "utf-8")
    except Exception:
        pass
    cfg = _read_cfg()
    if cfg.get("cover_template") == cid:
        cfg["cover_template"] = ""
        _write_cfg(cfg)
    return {"ok": True, "msg": "표지를 목록에서 뺐어요."}


def font_set(body: dict) -> dict:
    """설정에서 글꼴 파일 넣기·되돌리기. 표지와 PPT 변환에 이 글꼴을 써요."""
    import base64
    from . import render
    cfg = _read_cfg()
    later = " 앞으로 만드는 강의록부터 써요 (이미 만든 것은 「새 표지로 바꾸기」)."
    if body.get("clear"):
        cfg.pop("font", None)
        _write_cfg(cfg)
        return {"ok": True, "msg": "기본 글꼴로 바꿨어요." + later}
    if "select" in body or "delete" in body:            # 넣어 둔 글꼴 중에서 고르기 / 빼기
        fn = Path(str(body.get("select") or body.get("delete") or "")).name
        f = render.USER_FONT_DIR / fn
        if not fn or not f.is_file() or f.suffix.lower() not in FONT_EXT:
            return {"ok": False, "msg": "없는 글꼴이에요. 새로고침해 주세요."}
        if body.get("delete"):
            if (cfg.get("font") or {}).get("file") == fn:
                cfg.pop("font", None)
                _write_cfg(cfg)
            f.unlink()
            return {"ok": True, "msg": "글꼴을 목록에서 뺐어요."}
        cfg["font"] = {"file": fn}
        _write_cfg(cfg)
        return {"ok": True, "msg": f"「{render.font_family(f) or f.stem}」 글꼴로 바꿨어요." + later}
    name = Path(str(body.get("name") or "")).name
    if not name.lower().endswith(FONT_EXT):
        return {"ok": False, "msg": "TTF·OTF·TTC 글꼴 파일만 넣을 수 있어요."}
    try:
        data = base64.b64decode(body.get("data") or "", validate=True)
    except Exception:
        return {"ok": False, "msg": "파일을 읽지 못했어요."}
    if not data or len(data) > 60 * 1024 * 1024:
        return {"ok": False, "msg": "글꼴 파일이 비었거나 너무 커요 (60MB까지)."}
    if data[:4] not in (b"\x00\x01\x00\x00", b"OTTO", b"true", b"ttcf"):
        return {"ok": False, "msg": "글꼴 파일이 아닌 것 같아요."}
    render.USER_FONT_DIR.mkdir(parents=True, exist_ok=True)
    safe_name = re.sub(r"[^\w.\- ]", "_", name)
    (render.USER_FONT_DIR / safe_name).write_bytes(data)
    conv = _font_to_ttf(render.USER_FONT_DIR / safe_name)        # CFF OTF → TTF (크롬이 못 읽는 경우가 있어서)
    if conv:
        safe_name = conv.name
        cfg = _read_cfg()
    cfg["font"] = {"file": safe_name}
    _write_cfg(cfg)
    fam = render.font_family(render.USER_FONT_DIR / safe_name)
    return {"ok": True, "msg": f"「{fam}」 글꼴을 넣고 골랐어요." + later}


def _font_to_ttf(f: Path) -> Optional[Path]:
    """CFF OTF 를 TTF 로 바꾸고 원본은 지움 (고른 글꼴이 그 파일이면 설정도 새 이름으로). 바꾼 파일 또는 None"""
    from . import render
    if not render.needs_ttf(f):
        return None
    t = render.otf_to_ttf(f)
    if not t:
        return None
    with M.CFG_LOCK:
        cfg = _read_cfg()
        if (cfg.get("font") or {}).get("file") == f.name:
            cfg["font"] = {"file": t.name}
            _write_cfg(cfg)
    try:
        f.unlink()
    except Exception:
        pass
    return t


def _fix_user_fonts():
    """예전에 넣은 CFF OTF 글꼴도 TTF 로 (앱 켤 때 한 번, 뒤에서)"""
    from . import render
    try:
        for f in list(render.USER_FONT_DIR.glob("*.otf")) + list(render.USER_FONT_DIR.glob("*.OTF")):
            _font_to_ttf(f)
    except Exception:
        pass


def font_file(default: bool = False, name: str = ""):
    from . import render
    if name:
        f = render.USER_FONT_DIR / Path(name).name
        return f if f.is_file() and f.suffix.lower() in FONT_EXT else None
    if default:
        f = render.FONT_DIR / "Pretendard-Bold.ttf"
        return f if f.is_file() else None
    return render.user_font()


def secret_set(body: dict) -> dict:
    """비밀번호·토큰은 이 컴퓨터의 키체인(자격 증명 관리자)에만. 응답·로그에 값은 절대 안 남김."""
    from . import secrets_store, notion_sync
    from .lms import KEYCHAIN_SERVICE
    kind = body.get("kind")
    if kind == "lms":
        from . import lms as _lms
        if body.get("clear"):
            secrets_store.delete(KEYCHAIN_SERVICE)
            _lms.SESSION_CRED = None
            return {"ok": True, "msg": "LMS 로그인 정보를 지웠어요."}
        uid, pw = str(body.get("id") or "").strip(), str(body.get("pw") or "")
        if shared_pc():                       # 여러 사람이 쓰는 컴퓨터: 키체인에 두지 않고 이번에 켠 동안만
            if not uid or not pw:
                return {"ok": False, "msg": "아이디와 비밀번호를 넣어 주세요."}
            secrets_store.delete(KEYCHAIN_SERVICE)
            _lms.SESSION_CRED = (uid, pw)
            return {"ok": True, "msg": "이번에 켠 동안만 기억해요. 앱을 닫으면 지워져요."}
        if not uid:
            return {"ok": False, "msg": "아이디(학번)를 적어 주세요."}
        if not pw:
            cur = secrets_store.get(KEYCHAIN_SERVICE)
            if not cur:
                return {"ok": False, "msg": "비밀번호를 적어 주세요."}
            pw = cur[1]                       # 아이디만 바꿈
        ok, msg = secrets_store.put(KEYCHAIN_SERVICE, uid, pw)
        return {"ok": ok, "msg": "저장했어요. 다음 받기부터 이 계정으로 자동 로그인해요." if ok else msg}
    if kind == "notion":
        if body.get("clear"):
            secrets_store.delete(notion_sync.KEYCHAIN)
            return {"ok": True, "msg": "노션 연결을 지웠어요."}
        tok = str(body.get("token") or "").strip().strip('"').strip("'")
        if not tok.startswith(("ntn_", "secret_")):
            return {"ok": False, "msg": "ntn_ 또는 secret_ 로 시작하는 '내부 통합 시크릿'을 붙여 넣어 주세요."}
        res = notion_sync.check(tok)
        if not res.startswith("ok:"):
            return {"ok": False, "msg": res}
        ok, msg = secrets_store.put(notion_sync.KEYCHAIN, "notion", tok)
        return {"ok": ok, "msg": f"연결했어요 ({res[3:]}). 노션 페이지 ··· → 연결 에 이 통합을 추가했는지도 확인해 주세요." if ok else msg}
    return {"ok": False, "msg": "알 수 없는 요청"}


# ---------------------------------------------------------------- 예약
def manual_set(body: dict) -> dict:
    """강의에 자료 직접 넣기·빼기 (LMS·드라이브에 없는 강의록도 정리). 넣은 자료가 있으면 그것으로 만들어요."""
    import base64
    key = str(body.get("key") or "")
    L = next((x for x in load(M.DATA / "시간표.json") if x.key == key), None)
    if not L:
        return {"ok": False, "msg": "시간표에 없는 강의예요. 새로고침해 주세요."}
    d = M.manual_dir(L)
    if body.get("delete"):
        f = d / Path(str(body["delete"])).name
        if f.is_file():
            f.unlink()
        return {"ok": True, "msg": "뺐어요. 다시 만들면 LMS·드라이브 자료로 돌아가요."}
    name = Path(str(body.get("name") or "")).name
    if name.startswith("."):          # 「.pdf」처럼 이름 없는 파일 → 이름을 붙여 줌
        name = "내 파일" + name
    if not name.lower().endswith(M.MANUAL_EXT):
        return {"ok": False, "msg": "PDF·PPT·워드·한글 파일만 넣을 수 있어요."}
    try:
        data = base64.b64decode(body.get("data") or "", validate=True)
    except Exception:
        return {"ok": False, "msg": "파일을 읽지 못했어요."}
    if not data or len(data) > 300 * 1024 * 1024:
        return {"ok": False, "msg": "파일이 비었거나 너무 커요 (300MB까지)."}
    d.mkdir(parents=True, exist_ok=True)
    (d / re.sub(r'[\\/:*?"<>|]', "_", name)).write_bytes(data)
    return {"ok": True, "msg": f"「{name}」을 넣었어요."}


def grade_set(body: dict) -> dict:
    """학기 나누기: start(지금 학기 이름) / add / rename(+to) / remove / select. 고르면 앱을 다시 켜서 그 학년으로 열어요."""
    if _job["proc"] and _job["proc"].poll() is None or _external_running():
        return {"ok": False, "msg": "받는 중에는 학기를 바꿀 수 없어요. 끝난 뒤에 해 주세요."}
    with M.CFG_LOCK:
        raw = _grades.raw_cfg()
        gs = _grades.grades(raw)
        hidden = [g for g in (raw.get("grades_hidden") or []) if isinstance(g, dict) and g.get("name")]
        name = _grades.safe_name(body.get("name") or body.get("rename") or body.get("add") or body.get("remove") or body.get("select") or "")
        if "start" in body:                       # 처음 나누기: 지금 쓰는 데이터를 이 이름의 학년으로
            if gs:
                return {"ok": False, "msg": "이미 학기를 나눠 쓰고 있어요."}
            first, err = _grades.new_name(body.get("start"))
            if err:
                return {"ok": False, "msg": "지금 " + err if not first and "적어" in err else err}
            raw["grades"], raw["grade"] = [{"name": first, "dir": ""}], first
            M._write_raw_cfg(raw)
            return {"ok": True, "msg": f"지금 쓰던 시간표·기록을 「{first}」 학기로 묶었어요."}
        if not name:
            return {"ok": False, "msg": "학기 이름을 적어 주세요."}
        if "rename" in body:                      # 이름만 바꾸기 (폴더·기록은 그대로)
            g = next((g for g in gs if g["name"] == name), None)
            if not g:
                return {"ok": False, "msg": "없는 학기예요."}
            to, err = _grades.new_name(body.get("to"))
            if err:
                return {"ok": False, "msg": err}
            if to == name:
                return {"ok": True, "msg": "이름이 그대로예요."}
            if any(x["name"].casefold() == to.casefold() for x in gs + hidden):
                return {"ok": False, "msg": "같은 이름의 학기가 이미 있어요 (목록에서 뺀 학기 포함)."}
            g["name"] = to
            if raw.get("grade") == name or (not raw.get("grade") and gs and gs[0] is g):
                raw["grade"] = to
            raw["grades"] = gs
            M._write_raw_cfg(raw)
            return {"ok": True, "renamed": [name, to], "msg": f"「{name}」 → 「{to}」로 이름을 바꿨어요."}
        if "add" in body:
            name, err = _grades.new_name(body.get("add"))
            if err:
                return {"ok": False, "msg": err}
            if not gs:
                return {"ok": False, "msg": "먼저 지금 학기 이름을 정해 주세요."}
            if any(g["name"].casefold() == name.casefold() for g in gs):
                return {"ok": False, "msg": "이미 있는 학기예요."}
            old = next((g for g in hidden if g["name"] == name), None)
            if old:                               # 예전에 뺀 학년: 기록 그대로 다시
                hidden = [g for g in hidden if g["name"] != name]
                gs.append(old)
                msg = f"「{name}」 학기를 예전 기록 그대로 다시 넣었어요."
            else:
                used = {str(x.get("dir") or "").casefold() for x in gs + hidden}
                d, i = f"학년/{name}", 2
                while d.casefold() in used:                  # 이름을 바꾼 학기가 이 폴더를 쓰고 있으면 다른 폴더로
                    d, i = f"학년/{name}_{i}", i + 1
                p = M.APP / d
                p.mkdir(parents=True, exist_ok=True)
                if not (p / _grades.GRADE_FILE).exists():
                    (p / _grades.GRADE_FILE).write_text(json.dumps(_grades.new_grade_cfg(name), ensure_ascii=False, indent=2), "utf-8")
                if not (p / "시간표.json").exists():
                    (p / "시간표.json").write_text("[]", "utf-8")
                gs.append({"name": name, "dir": d})
                msg = f"「{name}」 학기를 넣었어요. 고르면 그 학기 처음 설정이 열려요."
            raw["grades"], raw["grades_hidden"] = gs, hidden
            M._write_raw_cfg(raw)
            return {"ok": True, "msg": msg}
        if "remove" in body:
            if name == _grades.current(raw)[0]:
                return {"ok": False, "msg": "지금 쓰는 학기는 뺄 수 없어요. 다른 학기를 고른 뒤에 빼 주세요."}
            g = next((g for g in gs if g["name"] == name), None)
            if not g:
                return {"ok": False, "msg": "없는 학기예요."}
            raw["grades"] = [x for x in gs if x["name"] != name]
            raw["grades_hidden"] = [x for x in hidden if x["name"] != name] + [g]
            M._write_raw_cfg(raw)
            return {"ok": True, "msg": f"「{name}」 학기를 목록에서 뺐어요. 받아 둔 강의록과 기록은 그대로 있어요 (같은 이름으로 다시 넣으면 돌아와요)."}
        if "select" in body:
            if not any(g["name"] == name for g in gs):
                return {"ok": False, "msg": "없는 학기예요."}
            if not _SRV[0]:          # 다시 켤 수 없으면 바꾸지 않음 (설정만 바뀌고 화면은 예전 학년인 채로 남지 않게)
                return {"ok": False, "msg": "지금은 학기를 바꿀 수 없어요. 앱을 닫았다가 다시 열어 주세요."}
            raw["grade"] = name
            M._write_raw_cfg(raw)
    # 예약도 그 학년 것으로 다시 등록 (따로 돌려서 설정 잠금을 오래 잡지 않게 · 앱이 다시 켜져도 계속 돌아요)
    try:
        cfg = _grades.merge(_grades.raw_cfg())
        times = M._sched_times(cfg)
        subprocess.Popen([sys.executable, "-m", "lecture_app", "예약", *(times or ["끄기"])], cwd=str(M.APP),
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL,
                         **({"creationflags": 0x08000000} if os.name == "nt" else {"start_new_session": True}))
    except Exception:
        pass
    return {"ok": True, "restart": True, "msg": f"「{name}」 학기로 바꿨어요. 앱을 다시 켜요."}


def schedule_set(body: dict) -> dict:
    slots = []
    for s in body.get("slots") or []:
        try:
            ev = int(s.get("every") or 0)                # n분·n시간마다 (분)
        except (TypeError, ValueError):
            ev = -1
        if ev:
            if not M.EVERY_MIN <= ev <= M.EVERY_MAX:
                return {"ok": False, "msg": f"「마다」 예약은 {M.EVERY_MIN}분 ~ 24시간 사이로 정해 주세요."}
            h = mi = 0
        else:
            m = re.fullmatch(r"(\d{1,2}):(\d{2})", (s.get("time") or "").strip())
            if not m or int(m.group(1)) > 23 or int(m.group(2)) > 59:
                return {"ok": False, "msg": f"시간 형식을 확인해 주세요: {s.get('time')}"}
            h, mi = int(m.group(1)), int(m.group(2))
        slots.append((h, mi, "오늘" if s.get("mode") == "오늘" else "전체",
                      s.get("target") if s.get("target") in ("강의록", "필야") else "둘다",
                      ",".join(re.sub(r"\D", "", str(y)) for y in (s.get("years") or []) if re.sub(r"\D", "", str(y))), ev))
    import contextlib
    import io
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        rc = M._apply_schedule(slots)
    rules = body.get("rules")
    if rc == 0 and isinstance(rules, list):          # 예약 화면의 규칙(시간대 · 켜기/끄기) — 시스템에는 위 slots(정한 시각들)로 등록 · 등록이 실패하면 저장 안 함
        keep = []
        for r in rules[:40]:
            if not isinstance(r, dict):
                continue
            keep.append({k: (str(v)[:20] if isinstance(v, str) else v) for k, v in r.items()
                         if k in ("id", "kind", "time", "from", "to", "step", "every", "mode", "target", "years", "on", "delay", "gap")
                         and isinstance(v, (str, int, bool, list))})
        with M.CFG_LOCK:
            cfg = M.read_cfg()
            sc = dict(cfg.get("schedule") or {})
            sc["rules"] = keep
            cfg["schedule"] = sc
            M.write_cfg(cfg)
    return {"ok": rc == 0, "msg": buf.getvalue().strip()}


def schedule_rules():
    """예약 규칙 (예약 화면에서 저장한 것) · 없으면 None (화면이 지금 예약으로 만듦)"""
    try:
        r = (M.read_cfg().get("schedule") or {}).get("rules")
        return r if isinstance(r, list) else None
    except Exception:
        return None


# ---------------------------------------------------------------- 실행 기록
def runs_list() -> List[dict]:
    d = M.SAVE_ROOT / "_실행기록"
    if not d.exists():
        return []
    fs = sorted(d.glob("*.txt"), key=lambda p: p.stat().st_mtime, reverse=True)[:40]
    out = []
    for f in fs:
        head = ""
        try:
            txt = f.read_text("utf-8", errors="replace")
            m = re.search(r"== 요약: (.+)", txt)
            head = m.group(1).replace("갱신", "바뀜").replace("변경 없음", "그대로") if m else ("오류" if "오류" in f.name else ("진행 중" if "진행중" in f.name else ""))
        except Exception:
            pass
        out.append({"name": f.name, "mtime": datetime.fromtimestamp(f.stat().st_mtime).strftime("%m/%d %H:%M"),
                    "summary": head})
    return out


def sched_runs() -> List[dict]:
    """예약 받기 실행 기록 (최근 순 30개): 시작·끝을 하나로 합침"""
    rows, byid = [], {}
    try:
        lines = M.SCHED_LOG.read_text("utf-8").splitlines() if M.SCHED_LOG.exists() else []
    except Exception:
        lines = []
    for ln in lines:
        try:
            e = json.loads(ln)
        except Exception:
            continue
        if e.get("ev") == "skip":
            rows.append({"t": e.get("t", ""), "status": "skip", "msg": e.get("msg", "")})
        elif e.get("ev") == "start":
            r = {"t": e.get("t", ""), "status": "run", "mode": e.get("mode", ""), "target": e.get("target", ""),
                 "id": e.get("id", ""), "msg": ""}
            byid[r["id"]] = r
            rows.append(r)
        elif e.get("ev") == "end" and e.get("id") in byid:
            r = byid[e["id"]]
            r.update(status="err" if e.get("error") else "ok", msg=e.get("error") or e.get("msg", ""), end=e.get("t", ""))
    try:
        running = bool(M._other_run())          # 지금 받는 중이면 마지막 '시작'은 진행 중
    except Exception:
        running = False
    d = M.SAVE_ROOT / "_실행기록"
    for i, r in enumerate(rows):
        if r["status"] == "run" and not (running and i == len(rows) - 1):
            r["status"] = "stop"; r["msg"] = "끝나기 전에 멈췄어요 (컴퓨터가 잠들었거나 꺼졌을 수 있어요)"
        if r.get("id") and d.exists():
            f = next(iter(sorted(d.glob(f"{r['id']}*.txt"))), None)
            if f:
                r["file"] = f.name
    return rows[::-1][:30]


def run_text(name: str) -> str:
    if not re.fullmatch(r"[\w\-.가-힣 ]+\.txt", name or ""):
        return ""
    f = M.SAVE_ROOT / "_실행기록" / name
    return f.read_text("utf-8", errors="replace") if f.exists() else ""


# ---------------------------------------------------------------- 파일 열기
def _os_open(p: Path, reveal: bool = False):
    """파일·폴더 열기 (맥: open / Windows: 탐색기 / 리눅스: xdg-open). 셸을 거치지 않아 파일 이름에 &·^ 가 있어도 안전."""
    if sys.platform == "darwin":
        subprocess.run(["open", "-R", str(p)] if reveal else ["open", str(p)], capture_output=True)
    elif os.name == "nt":
        if reveal:
            # explorer 는 '/select,"경로"' 를 한 덩어리로 받아야 공백·한글 경로에서도 그 파일이 선택된 채 열림
            subprocess.run(f'explorer /select,"{p}"', capture_output=True)
        else:
            os.startfile(str(p))   # noqa
    else:
        subprocess.run(["xdg-open", str(p.parent if reveal else p)], capture_output=True)


_ACCT = None


def acct():
    """강의록앱 계정 (구글 로그인 · 서버) — 처음 쓸 때 만듦"""
    global _ACCT
    if _ACCT is None:
        from .account import Account
        _ACCT = Account(M.APP)
    return _ACCT


_SYNC = None


def est_size() -> dict:
    """첫 받기 크기 어림: 지금 학기 강의 수 × 강의록 평균 (이미 받은 게 있으면 그 평균)"""
    try:
        lects = M.load(M.DATA / "시간표.json")
    except Exception:
        lects = []
    n = len(lects)
    avg = 6 * 1024 * 1024                      # 표지 붙인 강의록 한 개 평균 약 6MB
    try:
        root = Path(os.path.expanduser(str(M.read_cfg().get("save_root") or "")))
        fs = [f.stat().st_size for f in root.rglob("*.pdf")][:400] if root.is_dir() else []
        if len(fs) >= 10:
            avg = sum(fs) // len(fs)
    except Exception:
        pass
    return {"ok": True, "lectures": n, "bytes": n * avg}


def state_sync():
    """내 구글 드라이브 강의록앱/_상태 동기화 (구글 로그인 + 드라이브 권한이 있을 때만 돎)"""
    global _SYNC
    if _SYNC is None:
        from .sync import StateSync
        _SYNC = StateSync(M, acct())
    return _SYNC


def drive_auto(body: dict) -> dict:
    """처음 설정 7: 학년 공유 드라이브 주소만 넣으면 학기 폴더를 알아서 찾음 (시간표 과목과 가장 많이 맞는 폴더 · AI 없음)"""
    from . import drive as D
    fid = D.folder_id_of(str(body.get("url") or ""))
    if not fid or not re.fullmatch(r"[\w-]{10,}", fid):
        return {"ok": False, "msg": "구글 드라이브 폴더 주소가 아니에요. 단톡방 공지의 drive.google.com 주소를 붙여 넣어 주세요."}
    courses = _tt_courses_names()
    sem = str(body.get("sem") or _read_cfg().get("drive_semester") or "").strip()
    try:
        top = D.list_folder(fid)
    except Exception:
        return {"ok": False, "blocked": True, "msg": "이 폴더는 열 수 없어요. 「링크가 있는 모든 사용자」로 공유된 학년 드라이브 주소인지 확인해 주세요."}
    cfg = _read_cfg()                             # 이 드라이브에서 직접 · AI로 골라 둔 과목 폴더는 맞은 것으로
    cm = {k: v for k, v in (cfg.get("drive_course_map") or {}).items() if isinstance(v, str) and v != "-"} \
        if (cfg.get("drive_course_map_root") or cfg.get("drive_root")) == fid else {}
    best, seen, queue, listed = None, set(), [(fid, "", top, 0)], 0
    while queue and listed < 60:
        fid_, name, es, dep = queue.pop(0)
        if fid_ in seen:
            continue
        seen.add(fid_)
        hit = {c for c in courses if D.match_course_folder(c, es, cm, courses)[0]}
        score = len(hit) * 10 + (3 if sem and sem.replace(" ", "") in name.replace(" ", "") else 0)
        if hit and (best is None or score > best[0]):
            best = (score, fid_, name, sorted(hit))
        if dep < 3:
            subs = [e for e in es if e[2]]
            subs.sort(key=lambda e: (0 if (sem and sem.replace(" ", "") in e[1].replace(" ", "")) or re.search(r"학기|semester", e[1], re.I) else 1))
            for e in subs[:25]:
                try:
                    queue.append((e[0], e[1], D.list_folder(e[0]), dep + 1))
                    listed += 1
                except Exception:
                    pass
    if not best:
        return {"ok": True, "found": False, "root": fid, "total": len(courses),
                "msg": "시간표 과목과 맞는 폴더를 못 찾았어요. 주소가 우리 학년 드라이브가 맞는지 확인해 주세요."}
    _s, sid, sname, hit = best
    try:                                          # 아직 어느 과목과도 짝이 없는 폴더 (없으면 AI로 맞출 것도 없음)
        ses = D.list_folder(sid)
        used = {f[0] for f in (D.match_course_folder(c, ses, cm, courses)[0] for c in courses) if f}
        spare = sum(1 for e in ses if e[2] and e[0] not in used)
    except Exception:
        spare = None
    return {"ok": True, "found": True, "root": fid, "sem_id": sid, "sem_name": sname or "", "matched": len(hit),
            "total": len(courses), "missing": [c for c in courses if c not in hit], "spare": spare}


def _srv_grade(g: str = "") -> str:
    """서버 학년 값(본2 · 예1 …): 화면이 보낸 값 → 지금 고른 학년 이름(「본과 2학년」)"""
    g = str(g or "").strip()
    if re.fullmatch(r"[예본][1-4]", g):
        return g
    m = re.search(r"(예|본)\s*과?\s*(\d)", g or (_grades.current()[0] or ""))
    return f"{m.group(1)}{m.group(2)}" if m else ""


def drive_ai(body: dict) -> dict:
    """[AI로 정리하기]: 학기 폴더 안 폴더 이름 + 못 찾은 과목 → 서버 AI → 과목마다 폴더 후보 (저장은 화면에서 확인 뒤)"""
    from . import drive as D
    sid = str(body.get("sem_id") or "").strip()
    if not re.fullmatch(r"[\w-]{10,}", sid):
        return {"ok": False, "msg": "학기 폴더를 먼저 찾아 주세요."}
    courses = _tt_courses_names()
    want = [c for c in (body.get("courses") or []) if isinstance(c, str) and c in courses][:40]
    if not want:
        return {"ok": False, "msg": "맞출 과목이 없어요."}
    try:
        es = D.list_folder(sid)
    except Exception:
        return {"ok": False, "msg": "학기 폴더를 열지 못했어요. 다시 해 주세요."}
    cfg = _read_cfg()
    cm = {k: v for k, v in (cfg.get("drive_course_map") or {}).items() if isinstance(v, str) and v != "-"}
    used = {f[0] for f in (D.match_course_folder(c, es, cm, courses)[0] for c in courses if c not in want) if f}
    dirs = [(e[0], e[1]) for e in es if e[2] and e[0] not in used][:300]     # 다른 과목과 이미 짝지은 폴더는 안 보냄
    if not dirs:
        return {"ok": False, "none": True, "msg": "남은 폴더가 없어요. 이 과목들은 학년 드라이브에 아직 폴더가 없는 것 같아요."}
    grade = _srv_grade(body.get("grade"))
    if not grade:
        return {"ok": False, "msg": "학년을 몰라 AI 정리를 못 해요. [직접 고르기]로 맞춰 주세요."}
    now = datetime.now()
    year, term = (now.year - 1 if now.month <= 2 else now.year), (1 if 3 <= now.month <= 8 else 2)
    names = list(dict.fromkeys(n for _i, n in dirs))           # 같은 이름은 한 번만
    r = acct().ai_folders(names, want, grade, year, term, revise=body.get("revise") is True)
    if not r.get("ok"):
        return {"ok": False, "error": r.get("error", ""), "msg": r.get("msg") or "AI 정리가 안 됐어요."}
    by = {}
    for x in ((r.get("answer") or {}).get("match") or []):
        if isinstance(x, dict) and x.get("subject") in want and x.get("subject") not in by:
            f = next((d for d in dirs if d[1] == x.get("name")), None)
            if f:
                by[x["subject"]] = {"folder_id": f[0], "folder": f[1]}
    return {"ok": True, "match": by, "left": r.get("left"), "cached": bool(r.get("cached")),
            "dirs": [{"id": i, "name": n} for i, n in dirs]}


def drive_dirs(body: dict) -> dict:
    """[직접 고르기]: 학기 폴더 안 폴더 목록"""
    from . import drive as D
    sid = str(body.get("sem_id") or "").strip()
    if not re.fullmatch(r"[\w-]{10,}", sid):
        return {"ok": False, "msg": "학기 폴더를 먼저 찾아 주세요."}
    try:
        es = D.list_folder(sid)
    except Exception:
        return {"ok": False, "msg": "학기 폴더를 열지 못했어요. 다시 해 주세요."}
    return {"ok": True, "dirs": sorted([{"id": e[0], "name": e[1]} for e in es if e[2]], key=lambda d: d["name"])}


TTLIB_BASE = "https://raw.githubusercontent.com/DreamingSteward/lecture-app-releases/main/library/"
_TTLIB: dict = {}


def ttlib_get(school: str = "") -> dict:
    """시간표 모음 (GitHub): 학교 목록 → 학교를 고르면 그 학교 과목·연도별 시간표 · 10분 묵힘"""
    import requests
    name = "index.json"
    if school:
        if not re.fullmatch(r"[\w.-]{1,60}\.json", school):
            return {"ok": False, "msg": "학교 이름이 이상해요."}
        name = school
    hit = _TTLIB.get(name)
    if hit and time.time() - hit[0] < 600:
        return hit[1]
    if school:                                   # 학교 인증을 했으면 서버의 시간표 모음 (공개 GitHub 대신)
        try:
            lib = acct().lib_get(school[:-5])
        except Exception:
            lib = None
        if isinstance(lib, dict):
            out = {"ok": True, **lib, "src": "server"}
            _TTLIB[name] = (time.time(), out)
            return out
    try:
        r = requests.get(TTLIB_BASE + quote(name), timeout=12)
        r.raise_for_status()
        data = r.json()
    except Exception as e:
        if hit:
            return hit[1]
        return {"ok": False, "msg": f"시간표 모음을 불러오지 못했어요. 인터넷 연결을 확인해 주세요. ({type(e).__name__})"}
    out = {"ok": True, **(data if isinstance(data, dict) else {})}
    _TTLIB[name] = (time.time(), out)
    return out


def name_state() -> dict:
    """설정 › 강의록 파일 › 파일 이름: 고를 수 있는 모양·칸·지금 모양·예시 강의"""
    cur = M.name_fmt(_read_cfg())
    return {"fmt": cur, "default": M.NAME_DEFAULT, "tokens": list(M.NAME_TOKENS),
            "presets": [{"id": i, "name": n, "fmt": f} for i, n, f in M.NAME_PRESETS]}


def _name_examples(fmt: str) -> list:
    """미리보기: 시간표에서 모양이 다른 강의 몇 개 (교수 여럿·두 시간짜리·교수 없음)"""
    try:
        L = load(M.DATA / "시간표.json")
    except Exception:
        return []
    pick = []
    for cond in (lambda x: x.hours > 1, lambda x: len(x.profs) > 1, lambda x: not x.profs, lambda x: True):
        x = next((x for x in L if cond(x) and x not in pick), None)
        if x:
            pick.append(x)
    cur = M.name_fmt()
    return [{"old": M.out_name(x, cur), "new": M.out_name(x, fmt)} for x in pick[:3]]


def name_preview(body: dict) -> dict:
    fmt = str(body.get("fmt") or "").strip()
    e = M.name_fmt_error(fmt)
    if e:
        return {"ok": False, "msg": e}
    M.CFG.update(M.read_cfg())
    prev = str(M.CFG.get("name_fmt_prev") or "")
    plan = M.rename_plan(fmt, prev or None)
    cnt = {k: sum(1 for m in plan["moves"] if m[3] == k) for k in ("lec", "x", "refs")}
    cloud_n = 0
    try:
        from . import cloud
        for cd in cloud.copy_dirs().values():
            for d, o, n, k in plan["moves"]:
                rel = Path(M.rel_of(d / o) or os.path.relpath(d / o, M.SAVE_ROOT))
                if rel.parts[:1] != ("..",) and (cd / rel).exists():
                    cloud_n += 1
    except Exception:
        pass
    ex = next(((o, n) for d, o, n, k in plan["moves"] if k == "lec"), None)
    return {"ok": True, "same": fmt == M.name_fmt() and not prev, "count": cnt, "cloud": cloud_n, "conflicts": len(plan["conflicts"]),
            "example": list(ex) if ex else None, "examples": _name_examples(fmt)}


def name_apply(body: dict) -> dict:
    fmt = str(body.get("fmt") or "").strip()
    e = M.name_fmt_error(fmt)
    if e:
        return {"ok": False, "msg": e}
    def go():
        M.CFG.update(M.read_cfg())
        M.reload_roots()
        return M.rename_apply(fmt)
    r = _with_run_lock(go, "강의록을 받는 중이에요. 받기가 끝난 뒤에 바꿔 주세요.")
    if r.get("ok") is False:
        return r
    _CLOUD.update(t=0.0)
    n = r["done"]
    msg = f"파일 이름 방식을 바꿨어요 · 이름 바꾼 것 {n}개" + (f" · 클라우드 복사본 {r['cloud']}개" if r["cloud"] else "")
    if r["failed"] or r["conflicts"]:
        msg += f" · 못 바꾼 것 {len(r['failed']) + len(r['conflicts'])}개 (다른 앱에서 열려 있거나 같은 이름이 이미 있어요 · 다시 누르면 남은 것만 해요)"
    return {"ok": True, "msg": msg, **r}


def notify_set(body: dict) -> dict:
    """설정 › 알림: {"on": bool} 또는 {"kind": "lec", "on": bool}"""
    from . import notifier
    with M.CFG_LOCK:
        cfg = M.read_cfg()
        c = dict(cfg.get("notify") or {})
        k = body.get("kind") or "on"
        if k != "on" and k not in notifier.KINDS:
            return {"ok": False, "msg": "모르는 알림 종류예요."}
        c[k] = bool(body.get("on"))
        cfg["notify"] = c
        M.write_cfg(cfg)
    return {"ok": True}


def notify_test(body: dict) -> dict:
    """설정 → 알림 시험 보내기"""
    from . import notifier
    threading.Thread(target=notifier.notify, args=("강의록앱", "알림이 잘 와요. 받기가 끝나면 이렇게 알려 드려요."), daemon=True).start()
    return {"ok": True, "msg": "알림을 보냈어요. 화면 " + ("오른쪽 아래" if os.name == "nt" else "오른쪽 위") + "를 확인해 주세요."
            + (" 처음이면 「알림 허용」을 눌러 주세요." if sys.platform == "darwin" else "")}


def open_linked(body: dict) -> dict:
    """내 컴퓨터 폴더로 연결한 선배 자료 열기: 현황에 기억한 파일 중 i번째 (reveal = 폴더 보기)
    · 그 학번(이름)에 연결한 내 폴더 안의 파일만 (현황 파일이 바뀌어도 아무 파일이나 열지 않게)"""
    key, label = str(body.get("key") or ""), str(body.get("label") or "").strip()
    try:
        i = int(body.get("i") or 0)
        st = json.loads(M.STATUS.read_text("utf-8")) if M.STATUS.exists() else {}
        links = (((st.get(key) or {}).get("선배필야") or {}).get(label) or {}).get("links") or []
        p = Path(links[i])
    except (ValueError, IndexError, OSError, TypeError, AttributeError):
        return {"ok": False, "msg": "파일을 찾지 못했어요. 받기를 한 번 더 해 주세요."}
    if not any(M._within(p, r_) for r_ in M.local_roots(label)):
        return {"ok": False, "msg": "연결한 내 폴더 밖의 파일이라 열지 않아요."}
    if not p.exists():
        return {"ok": False, "msg": "파일이 옮겨졌거나 지워졌어요. 다음 받기 때 다시 찾아요."}
    if body.get("reveal"):
        _os_open(p, True)
        return {"ok": True}
    return open_file_safe(p)


def open_file_safe(p: Path) -> dict:
    if p.is_dir() and p.suffix.lower() in (".app", ".bundle", ".pkg", ".command"):   # 맥 앱 묶음은 실행하지 않고 위치만
        _os_open(p, True)
        return {"ok": True}
    if p.is_file() and p.suffix.lower() not in (".pdf", ".ppt", ".pptx", ".doc", ".docx", ".hwp", ".hwpx", ".key", ".odp",
                                                 ".png", ".jpg", ".jpeg", ".txt", ".zip"):
        _os_open(p, True)              # 실행 파일 같은 건 열지 않고 위치만 보여 줘요
        return {"ok": True}
    _os_open(p, False)
    return {"ok": True}


def open_path(body: dict) -> dict:
    rel = body.get("rel") or ""
    p = M.path_of_rel(rel)          # 정리 폴더 · 저장 위치를 바꾼 과목 폴더 안만
    if p is None:
        return {"ok": False, "msg": "열 수 없는 위치예요."}
    if not p.exists():
        return {"ok": False, "msg": "파일이 없어요."}
    if p.is_file() and not body.get("reveal") and p.suffix.lower() not in (     # 실행 파일 같은 건 열지 않고 위치만 보여 줘요
            ".pdf", ".ppt", ".pptx", ".doc", ".docx", ".hwp", ".hwpx", ".key", ".odp", ".png", ".jpg", ".jpeg", ".txt", ".zip"):
        _os_open(p, True)
        return {"ok": True}
    _os_open(p, bool(body.get("reveal")))
    return {"ok": True}


# ---------------------------------------------------------------- HTTP
class H(BaseHTTPRequestHandler):
    def end_headers(self):
        # 다른 사이트가 이 화면을 몰래 끼워 열어(프레임) 누르게 하는 것 막기
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Content-Security-Policy", "frame-ancestors 'none'")
        self.send_header("X-Content-Type-Options", "nosniff")
        super().end_headers()

    server_version = "LectureApp/1"

    def log_message(self, *a):
        pass

    def _send(self, code: int, body, ctype="application/json; charset=utf-8"):
        data = body if isinstance(body, bytes) else json.dumps(body, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        if self._web_ping():
            self.send_header("Access-Control-Allow-Origin", WEB_ORIGIN)
            self.send_header("Vary", "Origin")
        self.end_headers()
        self.wfile.write(data)

    def _web_ping(self) -> bool:
        """폰·웹앱(lecture-app-knu.pages.dev)이 「이 컴퓨터에 강의록앱이 켜져 있나」만 물어볼 수 있게 — /api/ping 하나만 (다른 정보는 안 보여 줌)"""
        return urlparse(self.path).path == "/api/ping" and (self.headers.get("Origin") or "") == WEB_ORIGIN

    def do_OPTIONS(self):
        if not self._host_ok() or not self._web_ping():
            return self._send(403, {"ok": False, "msg": "forbidden"})
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", WEB_ORIGIN)
        self.send_header("Access-Control-Allow-Methods", "GET")
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Vary", "Origin")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def _host_ok(self) -> bool:
        """다른 사이트가 주소를 바꿔치기(DNS rebinding)해서 접근하지 못하게: 이 컴퓨터 주소로 온 요청만"""
        h = (self.headers.get("Host") or "").lower()
        return h in (f"127.0.0.1:{PORT}", f"localhost:{PORT}")

    def do_GET(self):
        global _last_hit
        if not self._host_ok():
            return self._send(403, {"ok": False, "msg": "forbidden"})
        _last_hit = time.time()
        u = urlparse(self.path)
        q = parse_qs(u.query)
        try:
            if u.path == "/":
                return self._send(200, HTML.read_bytes(), "text/html; charset=utf-8")
            # ---- 앱으로 설치(PWA): 크롬 창 대신 강의록앱 아이콘으로 뜨게
            if u.path == "/manifest.webmanifest":
                return self._send(200, json.dumps(MANIFEST, ensure_ascii=False).encode("utf-8"), "application/manifest+json")
            if u.path == "/sw.js":
                return self._send(200, SW_JS.encode("utf-8"), "text/javascript; charset=utf-8")
            m = re.fullmatch(r"/help-img/([a-z0-9_]+)\.webp", u.path)      # 설정 → 도움말 사진 (앱에 같이 들어 있는 예시 화면)
            if m:
                f = Path(__file__).parent / "assets" / "help" / f"{m.group(1)}.webp"
                if f.is_file():
                    return self._send(200, f.read_bytes(), "image/webp")
                return self._send(404, {"ok": False})
            m = re.fullmatch(r"/icon-(32|64|192|512)\.png", u.path)
            if m:
                return self._send(200, (Path(__file__).parent / "assets" / f"icon-{m.group(1)}.png").read_bytes(), "image/png")
            if u.path == "/api/ping":
                return self._send(200, {"ok": True, "app": "강의록앱"})
            if u.path == "/api/state":
                L = load(M.DATA / "시간표.json")
                lecs = lectures_state()
                return self._send(200, {"cloud": _cloud_map(lecs),
                    "now": f"{datetime.now():%Y-%m-%d %H:%M}", "today": f"{datetime.now():%m%d}",
                    "courses": [{"name": c, "folder": next(x.course_folder for x in L if x.course == c),
                                 "terms": sorted({x.term for x in L if x.course == c and x.term})} for c in tt_courses(L)],
                    "lectures": lecs, "exams": _exams_state(L), "events": _events_state(), "holidays": _hol_state(), "year_key": str(YEAR_KEY), "pending": len(_pending()), "pend_courses": _pend_courses(L),
                    "verq": len(verq_state()), "merge_n": sum(1 for x in lecs if x.get("parts") and x["key"] not in _merge_decided(lecs)),
                    "xlabels": (xl_ := [str(M.CFG.get("extras_label") or "").strip() or "올해"] + _old_labels()), "xord": _xord(xl_),
                    "app_updated": _app_updated(),
                    "version": _app_version(),
                    "ui_ver": str(HTML.stat().st_mtime_ns),     # 화면 파일이 바뀌면 새로고침 때 화면도 새로 불러옴
                    "setup_done": bool(M.CFG.get("setup_done", True)), "pwa_installed": _pwa_shim() is not None, "chrome": _has_chrome(), "platform": "mac" if sys.platform == "darwin" else ("win" if os.name == "nt" else "linux"),
                    "schedule": schedule_state(), "sched_rules": schedule_rules(), "job": job_state(),
                    "lo": bool(render.soffice_bin()),
                    "grade": _grades.current()[0], "p1": _period1(), "grades": [g["name"] for g in _grades.grades()],          # LibreOffice 있음 (없으면 PPT 강의록이 실패)
                    "save_root": str(M.SAVE_ROOT), "update": _upd_status()})
            if u.path == "/api/progress":
                return self._send(200, progress_state())
            if u.path == "/api/job":
                return self._send(200, job_state())
            if u.path == "/api/log":
                return self._send(200, read_log(int((q.get("offset") or ["0"])[0] or 0)))
            if u.path == "/api/events":
                return self._send(200, read_events(int((q.get("offset") or ["0"])[0] or 0)))
            if u.path == "/api/pending":
                return self._send(200, pending_state())
            if u.path == "/api/verq":
                return self._send(200, verq_state())
            if u.path == "/api/merge":
                return self._send(200, merge_state())
            if u.path == "/api/decided":
                return self._send(200, decided_state())
            if u.path == "/api/settings":
                return self._send(200, settings_state())
            if u.path == "/api/prefs":
                return self._send(200, prefs_get())
            if u.path == "/api/rev":
                return self._send(200, rev_get())
            if u.path == "/api/acct/state":
                return self._send(200, acct().state())
            if u.path == "/api/sync/state":
                return self._send(200, state_sync().state())
            if u.path == "/api/acct/devices":
                return self._send(200, state_sync().devices())
            if u.path == "/api/sync/peek":
                return self._send(200, state_sync().peek())
            if u.path == "/api/acct/quota":
                return self._send(200, acct().quota())
            if u.path == "/api/est_size":
                return self._send(200, est_size())
            if u.path == "/api/ttlib":
                return self._send(200, ttlib_get((q.get("school") or [""])[0]))
            if u.path == "/api/name":
                return self._send(200, name_state())
            if u.path == "/api/covers":
                return self._send(200, covers_state())
            if u.path == "/api/cover/preview":
                png = cover_preview((q.get("id") or [""])[0])
                return self._send(200, png, "image/png") if png else self._send(404, {"ok": False})
            if u.path == "/api/font/file":          # 설정 화면 글꼴 미리보기용 (넣은 글꼴 파일만)
                f = font_file(bool(q.get("default")), (q.get("f") or [""])[0])
                if not f:
                    return self._send(404, {"ok": False})
                ct = {".otf": "font/otf", ".ttc": "font/collection"}.get(f.suffix.lower(), "font/ttf")
                return self._send(200, f.read_bytes(), ct)
            if u.path == "/api/cloud":                  # 「클라우드에도 저장」 설정
                from . import cloud
                return self._send(200, cloud.sync_state())
            if u.path == "/api/profs":
                return self._send(200, profs_state())
            if u.path == "/api/tt":
                return self._send(200, tt_state())
            if u.path == "/api/runs":
                return self._send(200, runs_list())
            if u.path == "/api/sched_runs":
                return self._send(200, sched_runs())
            if u.path == "/api/remote":                 # 휴대폰·아이패드에서 열기 (설정 화면)
                from . import remote
                return self._send(200, remote.state(bool(q.get("lite"))))
            if u.path == "/api/run":
                return self._send(200, {"text": run_text((q.get("name") or [""])[0])})
            if u.path == "/api/update":
                return self._send(200, _upd_status())
            if u.path == "/api/update/progress":
                from . import updater
                return self._send(200, updater.progress())
            return self._send(404, {"ok": False})
        except Exception as e:
            return self._fail(e)

    def _fail(self, e):
        import traceback
        sys.stderr.write(f"[{datetime.now():%H:%M:%S}] {self.path}\n{traceback.format_exc()}\n")
        sys.stderr.flush()
        perm = isinstance(e, PermissionError) or "Operation not permitted" in str(e)
        msg = ("데스크탑 폴더(매뉴얼 정리)에 접근할 권한이 없어요. 시스템 설정 → 개인정보 보호 및 보안 → "
               "파일 및 폴더 에서 ‘강의록앱’(또는 python)의 ‘데스크탑 폴더’를 켜 주세요.") if perm else M.err(e)
        return self._send(500, {"ok": False, "perm": perm, "msg": msg})

    def do_POST(self):
        global _last_hit
        if not self._host_ok():
            return self._send(403, {"ok": False, "msg": "forbidden"})
        _last_hit = time.time()
        # 다른 웹사이트가 이 주소로 몰래 요청하지 못하게: 화면이 붙이는 머리글이 있어야만 받음
        if self.headers.get("X-Lecture-App") != "1":
            return self._send(403, {"ok": False})
        n = int(self.headers.get("Content-Length") or 0)
        cap = 420 * 1024 * 1024 if self.path.split("?")[0] == "/api/manual" else 100 * 1024 * 1024   # 직접 올리기: 300MB 파일(base64)까지
        if n > cap:
            try:                    # 본문을 버리고 답해야 브라우저가 '연결 끊김' 대신 메시지를 받음
                left = n
                while left > 0:
                    chunk = self.rfile.read(min(left, 1 << 20))
                    if not chunk:
                        break
                    left -= len(chunk)
            except Exception:
                pass
            return self._send(413, {"ok": False, "msg": "파일이 너무 커요 (300MB까지)."})
        try:
            body = json.loads(self.rfile.read(n) or b"{}")
        except Exception:
            body = {}
        u = urlparse(self.path)
        try:
            fn = {"/api/start": start_job, "/api/stop": lambda b: stop_job(), "/api/pending": pending_set,
                  "/api/schedule": schedule_set, "/api/grade": grade_set, "/api/manual": manual_set, "/api/drive_list": drive_list, "/api/drive_check": drive_check, "/api/drive_check_old": drive_check_old, "/api/old_status": old_status, "/api/local_check_old": local_check_old, "/api/drive_suggest": drive_suggest, "/api/open": open_path, "/api/open_linked": open_linked, "/api/notify_test": notify_test,
                  "/api/tt/preview": tt_preview, "/api/tt/pick": pick_set, "/api/tt/apply": tt_apply, "/api/tt/move": tt_move, "/api/tt/revert": tt_revert, "/api/prefs": prefs_set, "/api/xskip": xskip_set, "/api/view": view_set,
                  "/api/tt/past_preview": tt_past_preview, "/api/tt/past_apply": tt_past_apply, "/api/profs/set": profs_set,
                  "/api/cover/add": cover_add, "/api/cover/bg": cover_bg, "/api/cover/rename": cover_rename, "/api/cover/builder": cover_builder, "/api/cover/make": cover_make, "/api/cover/select": cover_select, "/api/cover/delete": cover_delete,
                  "/api/pending/open": pending_open, "/api/verq": verq_set, "/api/verq/open": verq_open,
                  "/api/merge": merge_set, "/api/file_skip": file_skip, "/api/decided": decided_set, "/api/decided/open": decided_open,
                  "/api/settings": settings_set, "/api/secret": secret_set, "/api/setup_done": setup_done, "/api/font": font_set, "/api/pick_folder": pick_folder, "/api/custom_dir": custom_dir_set, "/api/open_browser": open_in_browser, "/api/restart": restart_app, "/api/uninstall": uninstall_app,
                  "/api/remote/set": _remote_set, "/api/remote/newcode": _remote_code, "/api/remote/forget": _remote_forget, "/api/remote/tunnel": _remote_tunnel, "/api/remote/menubar": _remote_menubar, "/api/cloud/set": _cloud_set,
                  "/api/update/check": update_check, "/api/update/apply": update_apply, "/api/update/later": update_later,
                  "/api/update/schedule": update_schedule, "/api/update/rollback": update_rollback, "/api/update/auto": update_auto, "/api/noretry": noretry_api,
                  "/api/name/preview": name_preview, "/api/drive_auto": drive_auto,
                  "/api/acct/login": lambda b: acct().login_start(b), "/api/acct/logout": lambda b: (state_sync().leave(), acct().logout(b))[1], "/api/acct/kick": lambda b: state_sync().kick(b), "/api/acct/consent": lambda b: acct().consent(b),
                  "/api/acct/lms_verify": lambda b: acct().lms_verify_start(b), "/api/acct/otp_send": lambda b: acct().otp_send(b), "/api/acct/otp_verify": lambda b: acct().otp_verify(b),
                  "/api/acct/delete": lambda b: acct().delete_me(b), "/api/sync/now": lambda b: state_sync().sync_once(), "/api/sync/adopt": lambda b: state_sync().adopt(b), "/api/acct/tt_offer": lambda b: acct().tt_offer(b), "/api/acct/ai_consent": lambda b: acct().ai_consent(b), "/api/wipe_me": wipe_me, "/api/open_rules": open_rules_ping, "/api/drive_ai": drive_ai, "/api/drive_dirs": drive_dirs, "/api/name/apply": name_apply, "/api/notify/set": notify_set}.get(u.path)
            if u.path in ("/api/settings", "/api/secret", "/api/setup_done", "/api/font", "/api/schedule", "/api/grade", "/api/tt/apply", "/api/tt/move", "/api/tt/revert",
                          "/api/tt/past_apply", "/api/profs/set", "/api/cover/select", "/api/cover/delete", "/api/cover/bg", "/api/cover/rename"):
                with M.CFG_LOCK:         # 설정 읽고-고치고-쓰기가 겹치지 않게
                    return self._send(200, fn(body)) if fn else self._send(404, {"ok": False})
            if not fn:
                return self._send(404, {"ok": False})
            return self._send(200, fn(body))
        except Exception as e:
            return self._fail(e)


def _remote_set(body: dict) -> dict:
    from . import remote
    return remote.set_enabled(bool(body.get("enabled")))


def _remote_code(body: dict) -> dict:
    from . import remote
    return {"ok": True, "code": remote.new_code(str(body.get("via") or "lan"))}


def _cloud_set(body: dict) -> dict:
    from . import cloud
    return cloud.set_copy(body)


_CLOUD = {"t": 0.0, "v": {}, "k": None}


def _cloud_map(lecs: list) -> dict:
    """휴대폰용: 강의록·추가자료 PDF가 클라우드(드라이브·iCloud) 어디에 있는지 (컴퓨터가 꺼졌을 때 거기서 열기) · 1분 묵힘"""
    try:
        from . import remote, cloud
        if not remote.serving():
            return {}
        rels, origs = set(), {}

        def walk(o):
            if isinstance(o, dict):
                f_ = o.get("file")
                if isinstance(f_, str) and f_ and isinstance(o.get("orig"), list) and o["orig"]:
                    origs[f_] = o["orig"]
                for k, v in o.items():
                    if k in ("file", "rel", "merged_file") and isinstance(v, str) and v.lower().endswith(".pdf"):
                        rels.add(v)
                    else:
                        walk(v)
            elif isinstance(o, list):
                for v in o:
                    walk(v)
        walk(lecs)
        k = (frozenset(rels), str(sorted((r, str(o)) for r, o in origs.items())), str(M.SAVE_ROOT), str(sorted((k, str(v)) for k, v in cloud.copy_dirs().items())))
        if k == _CLOUD["k"] and time.time() - _CLOUD["t"] < 60:
            return _CLOUD["v"]
        v = cloud.state_map(rels)
        for rel, og in origs.items():          # 추가자료: 원래 드라이브 공유 폴더의 파일 (복사본이 없거나 안 열릴 때)
            v.setdefault(rel, {})["orig"] = [{"name": o.get("name") or "", "url": f"https://drive.google.com/file/d/{o['id']}/view"} for o in og]
        _CLOUD.update(t=time.time(), v=v, k=k)
        return v
    except Exception as e:
        sys.stderr.write(f"클라우드 위치 확인 실패: {e}\n")
        return {}


def _remote_menubar(body: dict) -> dict:
    """메뉴 막대: 어느 QR을 보일지(view: lan·tunnel) · 휴대폰 연결 메뉴 보이기(show)"""
    from . import remote
    return remote.set_menubar(body)


def _remote_tunnel(body: dict) -> dict:
    """밖에서도 열기 (Cloudflare 터널): on 켜기·끄기 / token·host 고정 주소(고급)"""
    from . import tunnel
    on = body.get("on")
    tok = body.get("token")
    host = body.get("host")
    return tunnel.configure(on=None if on is None else bool(on),
                            token=None if tok is None else str(tok)[:4000],
                            host=None if host is None else str(host)[:200])


def _remote_forget(body: dict) -> dict:
    from . import remote
    ids = body.get("ids")
    if isinstance(ids, list):
        n = remote.forget([str(x) for x in ids][:500])
        return {"ok": bool(n), "msg": f"기기 {n}대의 연결을 끊었어요." if n else "끊을 기기가 없어요."}
    ok = remote.forget(str(body.get("id") or ""))
    return {"ok": bool(ok), "msg": "그 기기 연결을 끊었어요." if ok else "없는 기기예요."}


def _open_window(url: str):
    """앱 창 열기: 크롬에서 '앱 설치'를 했으면 그 앱(강의록앱 아이콘)으로, 아니면 주소창 없는 크롬·엣지 창, 없으면 기본 브라우저"""
    shim = _pwa_shim()
    if shim:
        try:
            if sys.platform == "darwin":
                if subprocess.run(["open", "-a", str(shim)], capture_output=True).returncode == 0:
                    return
            elif os.name == "nt":
                os.startfile(str(shim))   # noqa
                return
        except Exception:
            pass
    if sys.platform == "darwin":
        for app in ("Google Chrome", "Chromium", "Microsoft Edge", "Brave Browser"):
            r = subprocess.run(["open", "-na", app, "--args", f"--app={url}", "--window-size=1440,920"],
                               capture_output=True)
            if r.returncode == 0:
                return
        subprocess.run(["open", url])
        return
    if os.name == "nt":
        cands = [Path(os.environ.get(v, "")) / sub for v in ("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA")
                 for sub in ("Google/Chrome/Application/chrome.exe", "Microsoft/Edge/Application/msedge.exe")]
        for exe in cands:
            if exe.is_file():
                subprocess.Popen([str(exe), f"--app={url}", "--window-size=1440,920"])
                return
    import webbrowser
    webbrowser.open(url)


def _already_running(url: str) -> bool:
    try:
        with urllib.request.urlopen(url + "api/ping", timeout=1.5) as r:
            return b"ok" in r.read()
    except Exception:
        return False


def open_only() -> int:
    """앱 창만 열기 (화면 서버가 켜질 때까지 잠깐 기다림). 앱 아이콘을 눌렀을 때 씀."""
    url = f"http://127.0.0.1:{PORT}/"
    for _ in range(40):
        if _already_running(url):
            break
        time.sleep(0.25)
    _open_window(url)
    return 0


_SRV = [None]


_REEXEC = [False]


def _reexec(srv):
    """새 코드로 다시 켜기 요청: 서버를 깔끔히 멈추게 하고(serve 가 끝난 뒤 _do_reexec 가 실제로 다시 켬).
    다른 스레드에서 소켓을 바로 닫으면 윈도우에서 serve_forever 가 오류로 끝나 '오류가 났어요' 알림이 뜸"""
    _REEXEC[0] = True
    srv.shutdown()


def _do_reexec():
    """같은 방식(상주 등)으로 새 프로세스로 다시 켬. 창은 이미 떠 있으니 새로 열지 않음."""
    argv = list(getattr(sys, "orig_argv", []) or []) or [sys.executable, "-m", "lecture_app"] + sys.argv[1:]
    argv[0] = sys.executable
    if "--창없이" not in argv:
        argv.append("--창없이")
    os.environ["LA_REEXEC"] = "1"           # 업데이트로 다시 켠 것 = 공용 PC 정리하지 않음
    if os.name == "nt":      # 윈도우 execv 는 공백·한글 경로 인자가 깨져서 새로 띄우고 끝냄
        subprocess.Popen(argv, creationflags=0x00000008 | 0x00000200, close_fds=True)
        os._exit(0)
    os.execv(sys.executable, argv)


# ---------------------------------------------------------------- 앱 업데이트 (GitHub 릴리스 · 서명 확인)
def _upd_status() -> dict:
    try:
        from . import updater
        return updater.status()
    except Exception as e:
        return {"enabled": False, "err": str(e)[:200]}


BOOT = f"{os.getpid()}-{int(time.time())}"      # 이번에 켠 앱 (화면의 「나중에」는 앱을 다시 켤 때까지만)


def update_check(body: dict) -> dict:
    from . import updater
    return {**updater.check(force=bool(body.get("force")), opening=bool(body.get("opening"))), "boot": BOOT}


def _busy_locked() -> bool:
    """업데이트가 받기 시작과 겹치지 않게: 받기 시작(start_job)과 같은 잠금 안에서 확인"""
    with _lock:
        return _busy()


def _reexec_later():
    srv = _SRV[0]
    if not srv:
        return

    def later():
        time.sleep(1.2)          # 응답을 먼저 보내고
        for _ in range(3600):    # 그 사이 받기가 시작됐으면 끝날 때까지 기다렸다가 (받기는 따로 도는 프로그램이라 새 코드와 상관없음)
            if not _busy():
                break
            time.sleep(2)
        try:
            _reexec(srv)
        except Exception as e:
            sys.stderr.write(f"다시 켜기 실패: {e}\n")
    threading.Thread(target=later, daemon=True).start()


def update_apply(body: dict) -> dict:
    from . import updater
    r = updater.apply(busy=_busy_locked)
    if r.get("ok"):
        _reexec_later()
    return r


def noretry_api(body: dict) -> dict:
    key, side = str(body.get("key") or ""), str(body.get("side") or "")
    if side not in ("LMS", "드라이브") or not key:
        return {"ok": False, "msg": "잘못된 요청이에요."}
    if key not in {L.key for L in load(M.DATA / "시간표.json")}:
        return {"ok": False, "msg": "시간표에 없는 강의예요."}
    on = bool(body.get("on"))
    M.noretry_set(key, side, on, str(body.get("why") or ""))
    return {"ok": True, "msg": f"이 강의의 {side} 자료는 다음 받기부터 다시 시도하지 않아요" if on
            else f"이 강의의 {side} 자료를 다음 받기 때 다시 시도해요"}


def update_later(body: dict) -> dict:
    from . import updater
    return updater.later()


def update_schedule(body: dict) -> dict:
    from . import updater
    at = str(body.get("at") or "").strip()
    return updater.set_schedule(at or None)


def update_auto(body: dict) -> dict:
    from . import updater
    return updater.set_auto(bool(body.get("on")))


def update_rollback(body: dict) -> dict:
    from . import updater
    r = updater.rollback(busy=_busy_locked)
    if r.get("ok"):
        _reexec_later()
    return r


def _update_loop():
    """상주 중: 3시간마다 새 버전 확인, 예약 시각이 지났고 받기가 없으면 업데이트"""
    time.sleep(30)
    fail_at = 0.0
    while True:
        try:
            from . import updater
            updater.check()
            if updater.due() and not _busy() and time.time() - fail_at > 6 * 3600:     # 실패하면 6시간 뒤에 다시
                r = updater.apply(busy=_busy_locked)
                if r.get("ok"):
                    _reexec_later()
                    return
                fail_at = time.time()
        except Exception as e:
            sys.stderr.write(f"업데이트 확인 실패: {e}\n")
        time.sleep(600)


def uninstall_app(body: dict) -> dict:
    """설정 › 앱 지우기: 「강의록앱 삭제」와 같은 삭제 과정을 터미널(윈도우: 검은 창)에서 실행 · 거기서 y 를 넣어야 지움"""
    import tempfile
    try:
        td = Path(tempfile.mkdtemp(prefix="lecture-uninstall-"))
        if sys.platform == "darwin":
            src = Path(__file__).parent / "assets" / "uninstall_mac.sh"
            if not src.exists():
                return {"ok": False, "msg": "삭제 파일을 찾지 못했어요. 앱을 업데이트하거나 dmg 안의 「강의록앱 삭제」를 써 주세요."}
            sh = td / "uninstall.sh"
            shutil.copy(src, sh)                       # 앱 폴더를 지우는 동안에도 끝까지 돌게 앱 밖에 복사해서
            cmd = td / "강의록앱 삭제.command"
            cmd.write_text(f'#!/bin/bash\n/bin/bash "{sh}"\n', "utf-8")
            os.chmod(cmd, 0o755)
            subprocess.Popen(["open", "-a", "Terminal", str(cmd)])
        elif os.name == "nt":
            src = Path.home() / "강의록앱" / "uninstall.ps1"
            if not src.exists():
                return {"ok": False, "msg": "삭제 파일을 찾지 못했어요. 시작 메뉴의 「강의록앱 삭제」를 써 주세요."}
            ps = td / "uninstall.ps1"
            shutil.copy(src, ps)
            subprocess.Popen(["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(ps)],
                             creationflags=getattr(subprocess, "CREATE_NEW_CONSOLE", 0), cwd=str(Path.home()))
        else:
            return {"ok": False, "msg": "이 컴퓨터에서는 앱 지우기를 쓸 수 없어요."}
    except Exception as e:
        return {"ok": False, "msg": f"삭제 창을 열지 못했어요 ({e})"}
    return {"ok": True, "msg": "삭제 창이 열렸어요. 무엇을 지우는지 확인하고 y 를 넣으면 지워요."}


def restart_app(body: dict) -> dict:
    """설정 → 앱 다시 켜기 (업데이트가 바로 안 보이거나 화면이 이상할 때)"""
    if _busy():
        return {"ok": False, "msg": "받기가 진행 중이에요. 끝난 뒤에 다시 켜 주세요."}
    try:
        from . import updater
        if updater._locked():
            return {"ok": False, "msg": "앱을 업데이트하는 중이에요. 끝나면 저절로 다시 켜져요."}
    except Exception:
        pass
    srv = _SRV[0]
    if not srv:
        return {"ok": False, "msg": "다시 켤 수 없어요. 앱을 닫았다가 다시 열어 주세요."}

    def later():
        time.sleep(0.6)          # 응답을 먼저 보내고
        try:
            _reexec(srv)
        except Exception as e:
            sys.stderr.write(f"다시 켜기 실패: {e}\n")
    threading.Thread(target=later, daemon=True).start()
    return {"ok": True, "msg": "다시 켜는 중이에요…"}


OPEN_RUN = M.APP / ".open_run"     # 「앱을 켤 때마다」 규칙이 마지막으로 받은 시각


def open_rules_ping(_b=None) -> dict:
    """창을 열 때(상주 중이라 앱이 새로 켜지지 않았을 때)도 「앱을 켤 때마다」 규칙 — 간격(gap)은 그대로 지킴"""
    if not (_job["proc"] and _job["proc"].poll() is None):
        threading.Thread(target=_open_rules_run, kwargs={"delay0": 2}, daemon=True).start()
    return {"ok": True}


def _open_rules_run(delay0=None):
    """예약의 세 번째 종류 「앱을 켤 때마다」: 앱이 새로 켜질 때만 · 켠 뒤 delay초 · gap분 안에 다시 켜면 건너뜀.
    시스템 예약(LaunchAgent·작업 스케줄러)이 아니라 앱이 직접 확인해서 받기를 시작함 (앱이 꺼져 있으면 안 돎)."""
    try:
        cfg = _read_cfg()
        if cfg.get("setup_done") is False:
            return
        rules = [r for r in ((cfg.get("schedule") or {}).get("rules") or []) if isinstance(r, dict) and r.get("kind") == "open" and r.get("on") is not False]
        if not rules:
            return
        r = rules[0]
        delay = max(0, min(600, int(r.get("delay") or 10))) if delay0 is None else delay0
        gap = max(0, min(24 * 60, int(r.get("gap") if r.get("gap") is not None else 30)))
        try:
            last = float(OPEN_RUN.read_text().strip() or 0)
        except Exception:
            last = 0.0
        if time.time() - last < gap * 60:
            return
        time.sleep(delay)
        if _busy() or _external_running():
            return
        res = start_job({"mode": "today" if r.get("mode") == "오늘" else "all", "target": r.get("target") or "둘다", "years": r.get("years") or []})
        if res.get("ok"):
            _job["label"] = "앱을 켤 때 · " + _job.get("label", "")
            OPEN_RUN.write_text(str(time.time()))
    except Exception as e:
        _log_err("앱 켤 때 받기", e)


def serve(open_window: bool = True, stay: bool = False) -> int:
    url = f"http://127.0.0.1:{PORT}/"
    try:
        if not _external_running():     # 예약 받기가 기록을 쓰는 중이면 그때는 건너뜀 (받기가 시작할 때 함)
            M.migrate_layout()          # 예전 폴더 배치 → 1. 매뉴얼 / 2. 추가자료 · 예전 추가자료 파일 이름
    except Exception as e:
        sys.stderr.write(f"폴더 옮기기 실패: {e}\n")
    if _already_running(url):
        if open_window:
            _open_window(url)
        return 0
    srv = ThreadingHTTPServer(("127.0.0.1", PORT), H)
    srv.daemon_threads = True
    _SRV[0] = srv
    threading.Thread(target=_fix_user_fonts, daemon=True).start()      # 예전에 넣은 CFF 글꼴 → TTF
    threading.Thread(target=_open_rules_run, daemon=True).start()      # 예약 「앱을 켤 때마다」
    threading.Thread(target=lambda: state_sync().loop(), daemon=True).start()   # 내 드라이브 _상태 동기화
    try:
        from . import notifier
        notifier.prepare()                  # 알림을 「강의록앱」 이름·로고로 보낼 준비 (맥: 알림 전용 앱 만들기)
    except Exception:
        pass

    def idle():
        while True:
            time.sleep(60)
            busy = _job["proc"] is not None and _job["proc"].poll() is None
            if not busy and time.time() - _last_hit > IDLE_LIMIT:
                srv.shutdown()
                return
    def shared_watch():
        """여러 사람이 쓰는 컴퓨터: 창을 닫고(화면 요청이 끊기고) 3분 지나면 로그인 흔적을 지움 — 상주 모드여도"""
        while True:
            time.sleep(30)
            try:
                if not shared_pc():
                    continue
                from . import lms as _lms
                busy = _job["proc"] is not None and _job["proc"].poll() is None
                if not busy and time.time() - _last_hit > 300 and (_lms.SESSION_CRED or acct()._st().get("email")):
                    _shared_close()
            except Exception:
                pass
    threading.Thread(target=shared_watch, daemon=True).start()
    if os.environ.pop("LA_REEXEC", None) != "1" and shared_pc():   # 지난번에 정상으로 안 꺼졌어도(강제 종료 · 전원) 켤 때 앞사람 흔적 지움
        threading.Thread(target=_shared_close, daemon=True).start()
    try:                                       # 시스템 로그아웃 · 끄기(SIGTERM)에도 공용 PC 흔적 지우기
        if threading.current_thread() is threading.main_thread():
            def _term(*_a):
                try:
                    if shared_pc():
                        _shared_close()
                finally:
                    os._exit(0)
            signal.signal(signal.SIGTERM, _term)
    except Exception:
        pass

    def code_mtime():
        try:
            return max(f.stat().st_mtime for f in Path(__file__).parent.glob("*.py"))
        except Exception:
            return 0

    def reload_on_update():
        """상주 중에 앱 코드가 바뀌면(업데이트) 받기가 없을 때 새 코드로 다시 켬 → 껐다 켤 필요 없음"""
        base = code_mtime()
        while True:
            time.sleep(10)
            m = code_mtime()
            if m == base or _busy():
                continue
            time.sleep(3)            # 파일 여러 개가 바뀌는 중일 수 있어 잠깐 기다림
            if code_mtime() != m:
                continue
            try:
                _reexec(srv)
            except Exception as e:
                sys.stderr.write(f"새 코드로 다시 켜기 실패: {e}\n")
                base = m
    threading.Thread(target=_update_loop, daemon=True).start()      # 새 버전 확인 (3시간마다) · 예약 업데이트
    try:
        from . import holidays
        threading.Thread(target=holidays.loop, daemon=True).start()   # 공휴일: 켤 때 + 하루 한 번 받아 둠 (못 받으면 전에 받은 것 · 화면 목록)
    except Exception:
        pass
    try:
        from . import cloud
        threading.Thread(target=cloud.loop, daemon=True).start()   # 「클라우드에도 저장」: 새로 만든 강의록 복사 (2분마다)
    except Exception:
        pass
    if not stay:                 # --상주: 로그인할 때부터 켜 두면 Dock의 강의록앱 아이콘이 언제 눌러도 바로 열림
        threading.Thread(target=idle, daemon=True).start()
    else:
        threading.Thread(target=reload_on_update, daemon=True).start()
        if sys.platform == "darwin" or os.name == "nt":     # 맥 메뉴 막대 / 윈도우 알림 영역 현황 아이콘 (설정에서 끌 수 있음)
            def _mb():
                time.sleep(2)
                try:
                    from . import menubar
                    if menubar.running_pid():        # 앱이 새로 켜졌으면(업데이트 등) 메뉴 막대도 새 코드로
                        menubar.stop()
                        time.sleep(1.5)
                    menubar.launch()
                except Exception as e:
                    sys.stderr.write(f"메뉴 막대 띄우기 실패: {e}\n")
            threading.Thread(target=_mb, daemon=True).start()
    try:                                     # 휴대폰·아이패드에서 열기를 켜 뒀으면 그 문도 엶
        from . import remote
        if remote.enabled():                 # 같은 와이파이에서 열기는 없앰 → 켜 둔 사람도 끔 (밖에서 열기만)
            with remote.M.CFG_LOCK:
                cfg = remote.M.read_cfg()
                r = dict(cfg.get("remote") or {})
                r["enabled"] = False
                cfg["remote"] = r
                remote.M.write_cfg(cfg)
        if remote.serving():                 # 같은 와이파이 또는 밖에서 열기 중 하나라도 켜 뒀으면
            threading.Thread(target=remote.start, daemon=True).start()
        from . import tunnel
        if not tunnel.wanted():              # 꺼 둔 뒤 남아 있는 터널 프로그램이 있으면 정리
            threading.Thread(target=tunnel.stop, daemon=True).start()
    except Exception as e:
        sys.stderr.write(f"다른 기기용 화면 켜기 실패: {e}\n")
    if open_window:
        threading.Timer(0.4, _open_window, args=(url,)).start()
    print(f"강의록앱 화면: {url}" + ("" if stay else "  (창을 닫고 15분 지나면 저절로 꺼져요)"), flush=True)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    if not _REEXEC[0] and shared_pc():         # 여러 사람이 쓰는 컴퓨터: 닫으면 로그인 흔적 지우기 (업데이트로 다시 켤 때는 빼고)
        try:
            _shared_close()
        except Exception:
            pass
    try:
        from . import remote
        remote.stop()
    except Exception:
        pass
    if _REEXEC[0]:
        try:
            srv.server_close()
        except Exception:
            pass
        _do_reexec()
    return 0
