#!/bin/bash
# 강의록앱 삭제 (맥). 앱·앱 전용 파이썬·설정·기록·저장한 비밀번호를 지워요.
# 받아 둔 강의록(정리 폴더의 PDF)은 지우지 않아요.
APP="$HOME/강의록앱"
B=$'\033[1m'; G=$'\033[32m'; R=$'\033[31m'; N=$'\033[0m'
clear
printf "${B}강의록앱 삭제${N}\n\n"
SAVE=""
if [ -f "$APP/config.json" ]; then
  PYX="$APP/.venv/bin/python"; [ -x "$PYX" ] || PYX=/usr/bin/python3
  SAVE=$("$PYX" -c 'import json,os,sys; print(os.path.expanduser(json.load(open(sys.argv[1],encoding="utf-8")).get("save_root","")))' "$APP/config.json" 2>/dev/null)
fi
echo "지우는 것"
echo "  · 강의록앱 (응용 프로그램) · 앱 폴더 ~/강의록앱 (앱 전용 파이썬 환경·설정·시간표·고른 자료 기억·기록)"
echo "  · 자동 받기 예약 · 메뉴 막대 아이콘 · 키체인에 저장한 학교 비밀번호·노션 시크릿"
echo "  · 자동 로그인용 브라우저 (~/Library/Caches/ms-playwright)"
[ -n "$SAVE" ] && echo "  · 받기 기록 폴더 ($SAVE/_실행기록)"
echo
printf "${G}남기는 것${N}\n"
echo "  · 받아 둔 강의록·추가자료·표지 PDF${SAVE:+ ($SAVE)}"
echo "  · LibreOffice · 맥의 파이썬 (다른 프로그램도 쓸 수 있어서)"
echo
read -r -p "정말 지울까요? 지우려면 y 를 입력하고 엔터: " A
[ "$A" = "y" ] || [ "$A" = "Y" ] || { echo "취소했어요."; sleep 1; exit 0; }

echo; echo "▶ 앱 끄기"
for f in "$HOME/Library/LaunchAgents"/kr.knu.lecture-app*.plist; do
  [ -e "$f" ] || continue
  launchctl bootout "gui/$(id -u)/$(basename "$f" .plist)" 2>/dev/null
  rm -f "$f"
done
pkill -f "$APP/.venv" 2>/dev/null; pkill -f "lecture_app" 2>/dev/null; pkill -f "$APP/logs/터널/cloudflared" 2>/dev/null; sleep 1

echo "▶ 저장한 비밀번호 지우기"
for s in "강의록앱-KNU" "강의록앱-Notion"; do
  for i in 1 2 3 4 5; do security delete-generic-password -s "$s" >/dev/null 2>&1 || break; done
done

echo "▶ 파일 지우기"
[ -n "$SAVE" ] && [ -d "$SAVE/_실행기록" ] && rm -rf "$SAVE/_실행기록"
rm -rf "$APP"
rm -rf "$HOME/Library/Caches/ms-playwright"
rm -rf "/Applications/강의록앱.app" "$HOME/Applications/강의록앱.app" 2>/dev/null
for d in "$HOME/Applications/Chrome Apps.localized" "$HOME/Applications/Chrome Apps"; do
  rm -rf "$d/강의록앱.app" 2>/dev/null
done

echo
if [ -d "$APP" ] || [ -d "/Applications/강의록앱.app" ]; then
  printf "${R}일부를 지우지 못했어요.${N} 휴지통으로 직접 옮겨 주세요: ~/강의록앱 · 응용 프로그램의 강의록앱\n"
else
  printf "${G}${B}삭제 끝!${N}\n"
fi
echo "  · 크롬에 앱으로 설치했다면: 크롬 주소창에 chrome://apps → 강의록앱 우클릭 → 크롬에서 삭제"
echo "  · 「강의록앱 삭제」 앱이나 받아 둔 dmg·zip이 있으면 휴지통으로 옮기면 돼요."
echo
read -n 1 -s -r -p "아무 키나 누르면 닫혀요"
