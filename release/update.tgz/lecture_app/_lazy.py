"""필요한 프로그램(파이썬 꾸러미)이 아직 없어도 앱 화면이 켜지게 하는 자리표시.

처음 설치하면 앱 화면부터 열고, 사용자가 처음 설정에서 「필요한 프로그램 설치」에 동의한 뒤에 꾸러미를 받음.
그 전까지 requests · pypdf · pptx 는 이 자리표시 모듈이 대신 들어가 있다가,
꾸러미가 깔리면 처음 쓰는 순간 진짜 모듈로 바뀜 (앱을 다시 켤 필요 없음).
아직 없을 때 쓰면 MissingDeps 오류 (화면에는 「필요한 프로그램을 받는 중이에요」).
"""
from __future__ import annotations

import importlib
import importlib.abc
import importlib.machinery
import sys
import types

ROOTS = ("requests", "pypdf", "pptx")       # 앱 모듈 맨 위에서 불러오는 꾸러미만 (함수 안에서 부르는 건 그때 진짜로 부름)


class MissingDeps(RuntimeError):
    def __init__(self, name: str = ""):
        super().__init__("필요한 프로그램을 아직 받는 중이에요. 화면 위 「필요한 프로그램 받는 중」이 끝나면 다시 해 주세요." + (f" ({name})" if name else ""))


def _proxy(m) -> bool:
    return isinstance(m, _Mod)


def _load(name: str):
    """진짜 모듈을 불러옴 (자리표시가 들어가 있으면 빼고 다시 시도) · 아직 없으면 MissingDeps"""
    m = sys.modules.get(name)
    if m is not None and not _proxy(m):
        return m
    root = name.split(".")[0]
    saved = {k: v for k, v in sys.modules.items() if (k == root or k.startswith(root + ".")) and _proxy(v)}
    for k in saved:
        sys.modules.pop(k, None)
    importlib.invalidate_caches()
    _F.off = True
    try:
        return importlib.import_module(name)
    except ImportError:
        for k, v in saved.items():
            sys.modules.setdefault(k, v)
        raise MissingDeps(root) from None
    finally:
        _F.off = False


class _Attr:
    """`from pypdf import PdfReader` 처럼 미리 꺼내 둔 이름: 쓸 때 진짜 것을 찾아 씀"""
    __slots__ = ("_m", "_a")

    def __init__(self, mod: str, attr: str):
        self._m, self._a = mod, attr

    def _real(self):
        return getattr(_load(self._m), self._a)

    def __call__(self, *a, **k):
        return self._real()(*a, **k)

    def __getattr__(self, a):
        return getattr(self._real(), a)

    def __instancecheck__(self, obj):
        return isinstance(obj, self._real())

    def __repr__(self):
        return f"<필요한 프로그램 자리표시 {self._m}.{self._a}>"


class _Mod(types.ModuleType):
    def __getattr__(self, a):
        if a.startswith("__"):
            raise AttributeError(a)
        try:
            return getattr(_load(self.__name__), a)
        except MissingDeps:
            return _Attr(self.__name__, a)


class _Loader(importlib.abc.Loader):
    def create_module(self, spec):
        m = _Mod(spec.name)
        m.__path__ = []                      # 꾸러미처럼 보이게 (pptx.oxml.ns 같은 아래 모듈도 자리표시로)
        return m

    def exec_module(self, module):
        pass


class _Finder(importlib.abc.MetaPathFinder):
    off = False

    def find_spec(self, fullname, path=None, target=None):
        if self.off or fullname.split(".")[0] not in ROOTS:
            return None                      # 진짜 꾸러미를 찾는 중이거나 다른 이름 → 평소대로
        return importlib.machinery.ModuleSpec(fullname, _Loader(), is_package=True)


_F = _Finder()


def install():
    """앱 모듈을 불러오기 전에 한 번 (맨 뒤에 붙어서, 진짜 꾸러미가 있으면 그것이 먼저 쓰임)"""
    if _F not in sys.meta_path:
        sys.meta_path.append(_F)


def refresh():
    """꾸러미를 다 받은 뒤: 자리표시를 진짜 모듈로 바꿔 둠"""
    for r in ROOTS:
        try:
            _load(r)
        except MissingDeps:
            pass


def missing() -> list:
    """아직 없는 꾸러미 이름 (자리표시로 들어가 있거나 아직 안 불러온 것 중 없는 것)"""
    out = []
    for r in ROOTS:
        m = sys.modules.get(r)
        if m is not None and not _proxy(m):
            continue
        try:
            _load(r)
        except MissingDeps:
            out.append(r)
    return out
