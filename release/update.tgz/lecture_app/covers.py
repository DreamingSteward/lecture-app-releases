"""표지 템플릿: 기본 표지 + 내가 넣은 HTML 표지 (AI에게 만들어 달라고 할 때 쓰는 프롬프트 포함).

- 템플릿은 <앱 폴더>/covers/*.html 에 저장. 설정 config.json 의 cover_template 이 고른 파일 이름 ("" = 기본 표지).
- 표지를 만들 때 앱이 window.LECTURE 에 시간표 정보만 넣어 줌 (render.cover_data). {{이름}} 자리표시도 바꿔 넣음.
- 배경 사진 한 장: covers/<이름>.bg.jpg (화면에서 줄여서 JPEG로 보냄) → CSS 변수 --cover-bg 로 넣어 줌.
"""
from __future__ import annotations

import hashlib
import html
import json
import re
from pathlib import Path
from typing import List, Optional

MAX_BYTES = 10 * 1024 * 1024      # 사진을 HTML 안에 넣은(data:) 표지도 받을 수 있게
BG_MAX = 6 * 1024 * 1024


def covers_dir(app: Path) -> Path:
    return app / "covers"


BUILTIN_DIR = Path(__file__).resolve().parent / "covers_builtin"     # 앱에 들어 있는 표지 (id 앞에 @)
_ID_RE = re.compile(r'[^\\/:*?"<>|\x00-\x1f]+\.html')          # 파일 이름만 (경로·드라이브 문자 안 됨)


def _ok_id(name: str) -> bool:
    return bool(name) and bool(_ID_RE.fullmatch(name)) and ".." not in name


def _write(f: Path, data):
    """임시 파일에 쓴 뒤 바꿔 넣기 (윈도우에서 파일이 잠겨 있어도 재시도)"""
    from .matching import safe_replace, _tmp_name
    tmp = _tmp_name(f)
    if isinstance(data, bytes):
        tmp.write_bytes(data)
    else:
        tmp.write_text(data, "utf-8")
    safe_replace(tmp, f)


def _title_of(text: str, fallback: str) -> str:
    m = re.search(r"<title[^>]*>(.*?)</title>", text, re.I | re.S)
    t = html.unescape(re.sub(r"\s+", " ", m.group(1))).strip() if m else ""
    return (t or fallback)[:40]


def _names(app: Path) -> dict:
    """사용자가 바꾼 표지 이름 {id: 이름} (기본 표지는 "")"""
    try:
        d = json.loads((covers_dir(app) / "_이름.json").read_text("utf-8"))
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def rename_cover(app: Path, cid: str, name: str) -> Optional[str]:
    name = re.sub(r"\s+", " ", str(name or "")).strip()[:40]
    if cid and read_cover(app, cid) is None:
        return "없는 표지예요."
    d = _names(app)
    if name:
        d[cid] = name
    else:
        d.pop(cid, None)                 # 비우면 원래 이름으로
    f = covers_dir(app) / "_이름.json"
    f.parent.mkdir(parents=True, exist_ok=True)
    _write(f, json.dumps(d, ensure_ascii=False, indent=1))
    return None


def list_covers(app: Path) -> List[dict]:
    nm = _names(app)
    out = [{"id": "", "name": nm.get("") or "기본 표지", "builtin": True, "ver": "builtin"}]
    if BUILTIN_DIR.exists():
        for f in sorted(BUILTIN_DIR.glob("*.html")):
            try:
                txt = f.read_text("utf-8", errors="replace")
            except OSError:
                continue
            cid = "@" + f.name
            out.append({"id": cid, "name": nm.get(cid) or _title_of(txt, f.stem), "builtin": True,
                        "ver": hashlib.md5(txt.encode("utf-8")).hexdigest()[:10]})
    d = covers_dir(app)
    if d.exists():
        for f in sorted(d.glob("*.html"), key=lambda p: p.stat().st_mtime):
            try:
                txt = f.read_text("utf-8", errors="replace")
            except OSError:
                continue
            bg = bg_bytes(app, f.name)
            h = hashlib.md5(txt.encode("utf-8"))
            if bg:
                h.update(bg)
            out.append({"id": f.name, "name": nm.get(f.name) or _title_of(txt, f.stem), "builtin": False,
                        "ver": h.hexdigest()[:10], "bg": bool(bg), "uses_bg": "--cover-bg" in txt,
                        "builder": "<!--cover-builder:" in txt})
    return out


def read_cover(app: Path, cid: str) -> Optional[str]:
    """고른 템플릿 HTML (기본 표지거나 파일이 없으면 None)"""
    if cid.startswith("@"):
        n = cid[1:]
        if not _ok_id(n):
            return None
        f = BUILTIN_DIR / n
        try:
            return f.read_text("utf-8", errors="replace") if f.is_file() else None
        except OSError:
            return None
    if not _ok_id(cid):
        return None
    f = covers_dir(app) / cid
    try:
        return f.read_text("utf-8", errors="replace") if f.is_file() else None
    except OSError:
        return None


def bg_path(app: Path, cid: str) -> Optional[Path]:
    if not cid or cid.startswith("@") or not _ok_id(cid):
        return None
    return covers_dir(app) / (cid[:-5] + ".bg.jpg")


def bg_bytes(app: Path, cid: str) -> Optional[bytes]:
    f = bg_path(app, cid)
    try:
        return f.read_bytes() if f and f.is_file() else None
    except OSError:
        return None


def read_bg(app: Path, cid: str) -> Optional[str]:
    """배경 사진 → data: 주소 (없으면 None)"""
    b = bg_bytes(app, cid)
    if not b:
        return None
    import base64
    return "data:image/jpeg;base64," + base64.b64encode(b).decode("ascii")


def save_bg(app: Path, cid: str, data: Optional[bytes]) -> Optional[str]:
    """배경 사진 저장 (data None = 빼기). 문제 있으면 이유"""
    f = bg_path(app, cid)
    if not f or read_cover(app, cid) is None:
        return "내가 넣은 표지에만 사진을 넣을 수 있어요."
    if data is None:
        if f.exists():
            f.unlink()
        return None
    if len(data) > BG_MAX:
        return "사진이 너무 커요."
    if not data.startswith(b"\xff\xd8"):
        return "사진 파일을 읽지 못했어요 (JPG·PNG·HEIC 등 사진을 골라 주세요)."
    _write(f, data)
    return None


def cover_tag(app: Path, cid: str) -> str:
    """합본 형식 표시에 붙일 값: 템플릿·배경 사진을 바꾸면 '새 표지로 바꾸기' 대상이 되게"""
    t = read_cover(app, cid)
    if t is None:
        return ""
    h = hashlib.md5(t.encode("utf-8"))
    bg = bg_bytes(app, cid)
    if bg:
        h.update(bg)
    return "|cover:" + h.hexdigest()[:10]


def check_template(text: str) -> Optional[str]:
    """넣으려는 HTML 확인 (문제 없으면 None)"""
    if not text or not text.strip():
        return "빈 파일이에요."
    if len(text.encode("utf-8")) > MAX_BYTES:
        return "파일이 너무 커요 (10MB 이하). 사진은 HTML에 넣지 말고 표지를 넣은 뒤 「표지 사진 넣기」로 넣어 주세요."
    if not re.search(r"<(html|body|div|section|main|svg)\b", text, re.I):
        return "HTML 표지 파일이 아닌 것 같아요. AI가 준 HTML 전체를 저장한 .html 파일을 넣어 주세요."
    return None


def update_cover(app: Path, cid: str, text: str) -> Optional[str]:
    """앱에서 만든 표지를 고쳐 저장 (같은 파일 이름 그대로)"""
    if cid.startswith("@") or read_cover(app, cid) is None:
        return "없는 표지예요."
    f = covers_dir(app) / cid
    _write(f, text)
    return None


def builder_state(app: Path, cid: str) -> Optional[dict]:
    t = read_cover(app, cid) or ""
    m = re.search(r"<!--cover-builder:(.*?)-->", t, re.S)
    if not m:
        return None
    try:
        return json.loads(m.group(1))
    except ValueError:
        return None


def save_cover(app: Path, name: str, text: str) -> str:
    """새 템플릿 저장 → 파일 이름(id)"""
    d = covers_dir(app)
    d.mkdir(parents=True, exist_ok=True)
    base = re.sub(r"[^0-9A-Za-z가-힣_\- ]+", "", _title_of(text, Path(name or "표지").stem)).strip().replace(" ", "_") or "표지"
    base = base[:30]
    f = d / f"{base}.html"
    i = 2
    while f.exists():
        f = d / f"{base}_{i}.html"
        i += 1
    f.write_text(text, "utf-8")
    return f.name


def cover_prompt(sample: dict, year: str) -> str:
    ex = json.dumps(sample, ensure_ascii=False, indent=1)
    return f"""강의록 PDF 맨 앞에 붙는 「표지」를 HTML 파일로 만들어 주세요. 바로 만들지 말고, 먼저 저에게 질문해서 원하는 디자인을 정한 다음 만들어 주세요.

[진행 방식]
1. 아래를 한 번에 1~3개씩 물어보고, 답을 들은 뒤 다음 질문으로 넘어가요. 선택지를 예시로 보여 주면 좋아요.
   - 전체 분위기 (예: 깔끔·미니멀 / 귀여운·파스텔 / 학술·클래식 / 강렬한 대비 / 다크) 와 주 색상
   - 가장 크게 보일 정보 (강의 제목 / 날짜·교시 / 과목명)
   - 넣을 정보 고르기 — 아래 「쓸 수 있는 정보」 안에서만
   - 역대 담당 교수 표시 여부와 방식 (표 / 한 줄 / 숨김), 올해와 다른 교수님 강조 방법
   - CP(증례)·TBL 강의 표시 방법 (배지, 색 등)
   - 장식 (테두리, 도형, 무늬, 마크·로고 모양, 큰 글자 모양 그림 등 — CSS나 인라인 SVG로 그려서 배경이나 구석에)
   - 사진을 넣을지, 넣는다면 어디에 어떻게 (전체 배경 / 한쪽에 크게 / 모서리에 작게 / 동그랗게 잘라서 등)
2. 정한 내용을 짧게 요약해서 확인받은 뒤 HTML을 만들어요.
3. 고치고 싶다고 하면, 고친 HTML 전체를 다시 줘요.

[표지에 쓸 수 있는 정보 — 이것만]
앱이 강의마다 표지를 만들 때 window.LECTURE 에 아래 값을 넣어 줘요. (예시 값)
{ex}

- course: 과목명 · term: 차수(1, 2 … / 0이면 차수 없음 → 차수 표시를 숨기기) · year: 학년도
- date: 날짜(YYYY-MM-DD) · month, day: 월·일 숫자 · weekday: 요일 한 글자 · mmdd: "1027"
- period: 교시("1-2" 또는 "3") · period_start, period_end: 시작·끝 교시 · hours: 시간 수
- title: 강의 제목 (한 시간에 여러 주제를 하면 "주제1·주제2"로 이어짐, 최대 40자쯤) · titles: 주제 목록
- is_cp: CP(증례) 강의인지 · is_tbl: TBL 수업인지
- prof: 담당 교수 ("·"로 이어짐, 없으면 "") · profs: 교수 목록
- history: 지난 해 담당 교수 [{{"year": "2025", "profs": [...], "same": 이번 학기와 같은 교수인지}}] (최근 해부터, 빈 배열일 수 있음 · profs가 빈 배열이면 그 해엔 강의가 없었던 것)
- file_label: 앱 기본 표지의 제목 줄 ("1027-1. 신생아질환 III")

이 목록에 없는 정보는 사용자가 원해도 표지에 넣지 마세요 — 강의실, 시험 날짜, 교수 연락처, 학번·이름, 강의 내용 요약, 직접 적은 고정 문구 등. 앱이 시간표에서 알 수 있는 정보가 아니라서 모든 강의에 맞게 채울 수 없어요. 원하는 게 있으면 위 값으로 표현할 수 있는 다른 방법을 제안해 주세요.
단 이 제한은 강의마다 바뀌는 「정보」에 대한 거예요. 모든 표지에 똑같이 들어가는 「장식」은 괜찮아요 — 배경에 크게 깔리는 마크·로고 모양, 좋아하는 팀·캐릭터 느낌의 무늬, 도형, 일러스트 등. 사용자가 원하면 거절하지 말고 인라인 SVG·CSS로 그려 주세요 (흐리게 깔아서 강의 정보가 잘 읽히게). 사진·그림 파일이 꼭 필요하면 아래 「사진 한 장」 방법을 써요.

[HTML 규칙]
- 파일 하나: <!doctype html> 부터 </html> 까지 전체를 코드 블록 하나로. 사용자가 그대로 .html 파일로 저장해요.
- <title> 에 표지 이름을 적어요 (예: <title>파스텔 카드 표지</title>) — 앱의 표지 목록에 이 이름이 보여요.
- 크기: A4 가로 한 장. @page {{ size: 297mm 210mm; margin: 0 }}, html·body 여백 0, 표지 전체를 width:297mm; height:210mm; overflow:hidden 인 상자 하나에 담아요. 두 장이 되면 안 돼요.
- 값 넣기: 글자는 {{{{title}}}} 처럼 자리표시를 써도 되고(앱이 바꿔 넣음: course, term, year, date, month, day, weekday, mmdd, period, period_start, period_end, hours, title, prof, file_label), <script> 에서 window.LECTURE 를 읽어 그려도 돼요. history·titles·profs 같은 목록은 script로 그려요.
- 미리보기: script 맨 앞에 window.LECTURE 가 없으면 위 예시 값을 쓰게 해 주세요 (브라우저에서 파일을 열어 바로 볼 수 있게).
- 긴 제목·여러 교수·교수 없음·history 빈 배열·term 0 일 때도 깨지지 않게. 제목 길이에 따라 글자 크기를 자동으로 줄여서 넘치지 않게.
  · 글자 크기를 줄일 때는 글자 요소의 scrollHeight 대 clientHeight 가 아니라 「글자를 담은 상자(부모)의 높이」와 비교하세요. 글꼴마다 위아래 여백이 달라서(윈도우 Pretendard, 맥 산돌고딕 등) scrollHeight 가 항상 조금 크게 나와 글자가 끝없이 작아질 수 있어요. 최소 크기도 정해 두세요 (제목은 24px 이상).
- 사진 한 장 (선택): 사용자가 사진을 넣고 싶다고 하거나 대화에 사진을 첨부하면 거절하지 마세요. 「표지에 쓸 수 있는 정보」 제한은 글자 정보에 대한 것이고, 사진은 사용자가 앱에서 직접 넣어요.
  · 첨부된 사진은 보고 색·분위기를 맞추는 데 쓰고, 어디에 둘지 함께 정해요 (전체 배경, 한쪽에 크게, 모서리에 작게, 원형으로 잘라서 등).
  · HTML에는 사진을 직접 넣지 마세요 (base64로 넣으면 너무 길어서 답이 잘려요). 대신 사진 자리를 CSS 변수 --cover-bg 로 만들어요. 사용자가 앱의 표지 카드에서 「표지 사진 넣기」로 사진을 고르면 앱이 --cover-bg 에 url(...) 을 넣어 줘요.
  · 예) 전체 배경: .page {{ background: var(--cover-bg, linear-gradient(135deg, #1d4ed8, #60a5fa)) center / cover no-repeat; }}
        모서리 사진: .photo {{ width: 45mm; height: 45mm; border-radius: 50%; background: var(--cover-bg, #dbeafe) center / cover no-repeat; }}
  · 사진이 없을 때 보일 대체 모양(색·그라데이션)을 꼭 넣고, --cover-bg 를 직접 정의하지는 마세요. 사진 위에 글자가 오면 반투명 덮개나 글자 뒤 판을 깔아 읽히게 해 주세요.
  · 마지막에 사용자에게 「HTML을 앱에 넣은 뒤 그 표지 카드의 『표지 사진 넣기』로 이 사진을 고르면 돼요」라고 알려 주세요.
- 인터넷 사용 금지: 외부 글꼴(Google Fonts 등)·이미지·CDN 스크립트를 쓰지 마세요 (앱은 인터넷 없이 표지를 만들고 외부 요청을 막아요). 글꼴은 font-family: var(--app-font), sans-serif; (앱이 한글 글꼴을 넣어 줘요).
- 인쇄용: 배경색이 PDF에 나오게 * {{ -webkit-print-color-adjust: exact; print-color-adjust: exact; }} 를 넣고, 사진 말고 그림은 CSS·인라인 SVG로만.
- {year} 시간표 기준이에요 (이번 학기).
"""
