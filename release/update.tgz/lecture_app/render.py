"""PDF 만들기: 표지, 오른쪽 위 표시, 변환(LibreOffice), 합치기."""
from __future__ import annotations

import html
import json
import re
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import List, Optional

from pypdf import PdfReader, PdfWriter

# pypdf 6 은 보안상 숫자 하나가 64글자를 넘으면 읽기를 거부함. 일부 필기 앱이 만든 PDF는 숫자를 아주 길게 써서
# 'Read stream length of 112 exceeds maximum allowed length of 64' 로 실패 → 내 컴퓨터의 파일이라 한도를 넉넉히 늘림
try:
    from pypdf.generic import _base as _pb
    if getattr(_pb.NumberObject, "_LENGTH_LIMIT", 0) and _pb.NumberObject._LENGTH_LIMIT < 4096:
        _pb.NumberObject._LENGTH_LIMIT = 4096
    if getattr(_pb.IndirectObject, "_MAXIMUM_PART_LENGTH", 0) and _pb.IndirectObject._MAXIMUM_PART_LENGTH < 4096:
        _pb.IndirectObject._MAXIMUM_PART_LENGTH = 4096
except Exception:
    pass

from .timetable import Lecture, YEAR_KEY

APP_DIR = Path(__file__).resolve().parent.parent
FONT_DIR = APP_DIR / "fonts"


USER_FONT_DIR = FONT_DIR / "user"


def user_font() -> Optional[Path]:
    """설정 탭에서 넣은 글꼴 파일 (없으면 None)"""
    try:
        import json
        cfg = json.loads((APP_DIR / "config.json").read_text("utf-8-sig"))
        name = (cfg.get("font") or {}).get("file")
        f = USER_FONT_DIR / Path(name).name if name else None
        return f if f and f.is_file() else None
    except Exception:
        return None


def _fonttools():
    try:
        import fontTools  # noqa
        return True
    except ImportError:
        import subprocess, sys
        r = subprocess.run([sys.executable, "-m", "pip", "install", "-q", "fonttools>=4.40"], capture_output=True, timeout=300)
        try:
            import importlib
            importlib.invalidate_caches()
            import fontTools  # noqa
            return r.returncode == 0
        except ImportError:
            return False


def needs_ttf(f: Path) -> bool:
    """CFF 윤곽선 OTF('OTTO'): 크롬(표지·미리보기)이 '글꼴 해석 실패'로 거부하는 경우가 있어 TTF로 바꿔 씀"""
    try:
        with open(f, "rb") as fh:
            return f.suffix.lower() == ".otf" and fh.read(4) == b"OTTO"
    except Exception:
        return False


def otf_to_ttf(src: Path) -> Optional[Path]:
    """CFF OTF → TrueType(TTF) (곡선을 2차로 바꿈, 모양은 그대로). 같은 폴더에 같은 이름 .ttf. 실패하면 None"""
    dst = src.with_suffix(".ttf")
    if dst.exists():
        return dst
    if not _fonttools():
        return None
    try:
        from fontTools.ttLib import TTFont, newTable
        from fontTools.pens.cu2quPen import Cu2QuPen
        from fontTools.pens.ttGlyphPen import TTGlyphPen
        f = TTFont(str(src))
        order, gs = f.getGlyphOrder(), f.getGlyphSet()
        glyphs = {}
        for n in order:
            pen = TTGlyphPen(gs)
            try:
                gs[n].draw(Cu2QuPen(pen, 1.0, reverse_direction=True))
            except Exception:
                pen = TTGlyphPen(gs)
            glyphs[n] = pen.glyph()
        f["loca"] = newTable("loca")
        g = f["glyf"] = newTable("glyf")
        g.glyphOrder, g.glyphs = order, glyphs
        for t in ("CFF ", "CFF2", "VORG"):
            if t in f:
                del f[t]
        m = f["maxp"] = newTable("maxp")
        m.tableVersion = 0x00010000
        for k in ("maxZones", "maxTwilightPoints", "maxStorage", "maxFunctionDefs", "maxInstructionDefs",
                  "maxStackElements", "maxSizeOfInstructions", "maxComponentElements"):
            setattr(m, k, 0)
        m.maxZones = 1
        f["head"].glyphDataFormat = 0
        f["post"].formatType, f["post"].extraNames, f["post"].mapping = 2.0, [], {}
        f.sfntVersion = "\x00\x01\x00\x00"
        tmp = dst.with_suffix(".tmp")
        f.save(str(tmp))
        tmp.replace(dst)
        return dst
    except Exception:
        try:
            dst.with_suffix(".tmp").unlink()
        except Exception:
            pass
        return None


def font_family(path: Path) -> str:
    """글꼴 파일 안에 적힌 글꼴 이름 (LibreOffice 바꿔 그리기에 필요). TTF·OTF·TTC 첫 글꼴."""
    import struct
    try:
        b = path.read_bytes()
        off = 0
        if b[:4] == b"ttcf":
            off = struct.unpack(">I", b[12:16])[0]
        n = struct.unpack(">H", b[off + 4:off + 6])[0]
        for i in range(n):
            tag, _cs, toff, _ln = struct.unpack(">4sIII", b[off + 12 + 16 * i: off + 28 + 16 * i])
            if tag != b"name":
                continue
            _fmt, cnt, soff = struct.unpack(">HHH", b[toff:toff + 6])
            best = {}
            for j in range(cnt):
                pid, eid, lid, nid, ln, so = struct.unpack(">6H", b[toff + 6 + 12 * j: toff + 18 + 12 * j])
                if nid not in (1, 16):
                    continue
                raw = b[toff + soff + so: toff + soff + so + ln]
                txt = raw.decode("utf-16-be", "ignore") if pid in (0, 3) else raw.decode("latin-1", "ignore")
                # 영어 이름 우선 (LibreOffice는 영어 이름으로 찾는 경우가 많음), 16(대표 이름) > 1
                score = (nid == 16) * 2 + (lid in (0x409, 0)) * 1
                if txt and score >= best.get("s", -1):
                    best = {"s": score, "t": txt}
            return best.get("t") or path.stem
    except Exception:
        pass
    return path.stem


# 표지는 빈 페이지(about:blank)에 그려서 file:// 글꼴을 못 읽음 → 이 가짜 주소로 부르면 Renderer가 파일을 넘겨 줌
FONT_HOST = "https://fonts.lecture-app.invalid/"


def _font_files() -> dict:
    """{가짜 주소: 글꼴 파일}"""
    out = {}
    uf = user_font()
    if uf:
        out[FONT_HOST + "u/" + uf.name] = uf
    files = sorted(FONT_DIR.glob("Pretendard-*.ttf")) or (sorted(FONT_DIR.glob("*.ttf")) + sorted(FONT_DIR.glob("*.otf")))
    for f in files:
        out[FONT_HOST + "f/" + f.name] = f
    return out


def _font_css(files: Optional[dict] = None) -> str:
    from urllib.parse import quote
    files = _font_files() if files is None else files
    faces = []
    for url, f in files.items():
        u = FONT_HOST + quote(url[len(FONT_HOST):])
        if url.startswith(FONT_HOST + "u/"):
            faces.append(f"@font-face{{font-family:'UserFont';src:url('{u}');}}")
        else:
            w = "600 900" if "bold" in f.stem.lower() else "100 500"       # 굵은 글꼴·보통 글꼴을 따로
            faces.append(f"@font-face{{font-family:'LectureKR';src:url('{u}');font-weight:{w};}}")
    return "\n".join(faces)


# 맥: Apple SD 산돌고딕 Neo / 그 밖(Windows): 앱에 들어 있는 Pretendard(LectureKR) / 설정에서 넣은 글꼴이 있으면 그게 1순위
FONT_STACK = "'Apple SD Gothic Neo','LectureKR','Noto Sans KR','Noto Sans CJK KR','Malgun Gothic',sans-serif"


def font_stack() -> str:
    return ("'UserFont'," if user_font() else "") + FONT_STACK

# ---- 확정 양식 (lecture-cover 스킬과 동일) ----
COVER_HTML = """<!doctype html><html><head><meta charset="utf-8"><style>
{fonts}
@page {{ size: 297mm 210mm; margin: 0; }}
html,body {{ margin:0; padding:0; }}
body {{ font-family: {stack}; }}
.page {{ width:297mm; height:210mm; box-sizing:border-box; position:relative;
  display:flex; flex-direction:column; justify-content:flex-start; align-items:center;
  text-align:center; padding:10mm 12mm 0; }}
.box   {{ border:0.5mm solid #000; padding:3mm 8mm 3.5mm; width:100%; box-sizing:border-box; }}
.title {{ font-size:{title_pt}pt; font-weight:700; line-height:1.3; word-break:keep-all; }}
.prof  {{ font-size:28pt; font-weight:400; margin-top:4mm; color:#333; line-height:1.3; }}
.hist  {{ position:absolute; left:12mm; bottom:10mm; text-align:left; }}
.hist h {{ display:block; font-size:10pt; font-weight:700; color:#777; letter-spacing:.3pt;
          border-bottom:0.2mm solid #aaa; padding-bottom:0.8mm; margin-bottom:1.2mm; }}
.hist table {{ border-collapse:collapse; }}
.hist td {{ font-size:13pt; line-height:1.4; padding:0; vertical-align:top; }}
.hist td.y {{ color:#999; padding-right:5mm; font-variant-numeric:tabular-nums; }}
.hist tr.diff td.p {{ color:#a11d21; font-weight:700; }}
.hist tr.none td.p {{ color:#bbb; }}
</style></head><body><div class="page"><div class="box">
<div class="title">{title}</div>
<div class="prof">{prof}</div>
</div>{hist}</div></body></html>"""

STAMP_HTML = """<!doctype html><html><head><meta charset="utf-8"><style>
{fonts}
@page {{ size: {w}pt {h}pt; margin: 0; }}
html,body {{ margin:0; padding:0; background:transparent; }}
body {{ font-family: {stack}; width:{w}pt; height:{h}pt; position:relative; }}
.tag {{ position:absolute; top:{inset}pt; right:{inset}pt; font-size:{fs}pt; color:#6b6b6b;
  border:{bw}pt solid #9a9a9a; border-radius:{r}pt; padding:{py}pt {px}pt; background:rgba(255,255,255,.85);
  white-space:nowrap; line-height:1.2; }}
</style></head><body><div class="tag">{text}</div></body></html>"""


def cover_texts(L: Lecture):
    try:                                  # 제목 줄 = 설정한 파일 이름 모양 (기본: "1027-1. 신생아질환 III" · 교수는 아래 줄에 따로)
        from . import main as _M
        fmt = _M.name_fmt()
        head = _M.name_base(L, re.sub(r"_?\{교수\}$", "", fmt) if fmt == _M.NAME_DEFAULT else fmt)
    except Exception:
        head = f"{L.mmdd}-{L.start}. {L.title}"
    prof = f"{'·'.join(L.profs)} ({L.hours})" if L.profs else f"({L.hours})"
    return head, prof


def hist_html(L: Lecture) -> str:
    """표지 왼쪽 '역대 담당 교수': 올해를 뺀 지난 연도들. 올해와 다른 분은 빨간 굵은 글씨."""
    now = set(L.profs)
    rows = []
    for y, ps in L.history():
        if y == YEAR_KEY:
            continue
        if not ps:
            rows.append(f'<tr class="none"><td class="y">{y}</td><td class="p">—</td></tr>')
            continue
        cls = "" if set(ps) == now else ' class="diff"'
        rows.append(f'<tr{cls}><td class="y">{y}</td><td class="p">{html.escape("·".join(ps))}</td></tr>')
    if not rows:
        return ""
    return '<div class="hist"><span class="h-wrap"><h>역대 담당 교수</h></span><table>' + "".join(rows) + "</table></div>"


def title_pt(head: str) -> int:
    n = len(head)
    return 44 if n <= 18 else 38 if n <= 26 else 32 if n <= 36 else 26


# ---------------------------------------------------------------- 표지 템플릿 (내가 만든 HTML 표지)
WEEK = "월화수목금토일"


def cover_data(L: Lecture) -> dict:
    """표지 템플릿에 넘기는 정보 = 시간표에 있는 것만 (window.LECTURE / {{이름}})"""
    from datetime import date
    y = int(YEAR_KEY) + (1 if L.month <= 2 else 0)
    try:
        wd = WEEK[date(y, L.month, L.day).weekday()]
    except ValueError:
        wd = ""
    head, _ = cover_texts(L)
    cur = set(L.profs)
    hist = [{"year": yy, "profs": ps, "same": bool(ps) and set(ps) == cur} for yy, ps in L.history() if yy != YEAR_KEY]
    end = L.start + L.hours - 1
    t = L.title
    return {
        "course": L.course, "term": L.term, "year": YEAR_KEY,
        "date": f"{y}-{L.month:02d}-{L.day:02d}", "month": L.month, "day": L.day, "weekday": wd, "mmdd": L.mmdd,
        "period_start": L.start, "period_end": end, "hours": L.hours,
        "period": f"{L.start}" if L.hours <= 1 else f"{L.start}-{end}",
        "title": t, "titles": list(L.titles),
        "is_cp": bool(re.match(r"\s*CP\b", t)), "is_tbl": bool(re.search(r"TBL", t, re.I)),
        "profs": list(L.profs), "prof": "·".join(L.profs),
        "history": hist, "file_label": head,
    }


SAMPLE_LECTURE = {
    "course": "생식성장발달 II", "term": 2, "year": YEAR_KEY, "date": f"{YEAR_KEY}-10-27", "month": 10, "day": 27,
    "weekday": "화", "mmdd": "1027", "period_start": 1, "period_end": 2, "hours": 2, "period": "1-2",
    "title": "신생아질환 III", "titles": ["신생아질환 III"], "is_cp": False, "is_tbl": False,
    "profs": ["김성래"], "prof": "김성래",
    "history": [{"year": str(int(YEAR_KEY) - 1), "profs": ["김성래"], "same": True},
                {"year": str(int(YEAR_KEY) - 3), "profs": ["김성래"], "same": True},
                {"year": str(int(YEAR_KEY) - 4), "profs": ["홍정우"], "same": False}],
    "file_label": "1027-1. 신생아질환 III",
}


def template_doc(tpl: str, data: dict, fonts_css: str, stack: str, bg: Optional[str] = None) -> str:
    """템플릿 HTML + 앱 글꼴 + window.LECTURE. {{이름}} 은 글자로 바꿔 넣음 (HTML 안전하게)"""
    def sub(m):
        k = m.group(1)
        v = data.get(k, "")
        if isinstance(v, list):
            v = "·".join(str(x) for x in v if not isinstance(x, dict))
        return html.escape(str(v))
    body = re.sub(r"\{\{\s*([a-z_]+)\s*\}\}", sub, tpl)
    js = json.dumps(data, ensure_ascii=False).replace("</", "<\\/")
    bgcss = f"--cover-bg:url(\"{bg}\");" if bg and bg.startswith("data:image/") and '"' not in bg else ""
    head = (f"<meta charset=\"utf-8\"><style>{fonts_css}\n:root{{--app-font:{stack};{bgcss}}}</style>"
            f"<script>window.LECTURE={js};</script>")
    if re.search(r"<head(?:\s[^>]*)?>", body, re.I):
        return re.sub(r"(<head(?:\s[^>]*)?>)", lambda m: m.group(1) + head, body, count=1, flags=re.I)
    return "<!doctype html><html><head>" + head + "</head><body>" + body + "</body></html>"


class Renderer:
    """Chromium 하나를 열어 두고 표지·표시 PDF를 찍는다."""

    def __init__(self, pw=None):
        """pw: 이미 켜 둔 playwright (한 프로그램에서 두 번 켤 수 없음)"""
        self._own = pw is None
        if self._own:
            from playwright.sync_api import sync_playwright
            pw = sync_playwright().start()
        self._pw = pw
        self._b = self._pw.chromium.launch()
        self._page = self._b.new_page()
        self._fontfiles = _font_files()
        self._fontbytes: dict = {}
        self._fonts = _font_css(self._fontfiles)
        self._page.route("**/*", self._route)
        self.template: Optional[str] = None      # 내가 고른 표지 HTML (없으면 기본 표지)
        self.template_error: Optional[str] = None
        self.template_bg: Optional[str] = None   # 그 표지의 배경 사진 (data: 주소)
        self.last_failed = False                  # 바로 앞 표지를 고른 템플릿으로 못 만듦
        self._tpage = None

    def _route(self, r):
        """글꼴 가짜 주소 → 파일, data:/about:/blob: → 그대로, 나머지(인터넷) → 막음"""
        from urllib.parse import unquote
        url = r.request.url
        if url.startswith(FONT_HOST):
            key = FONT_HOST + unquote(url[len(FONT_HOST):])
            f = self._fontfiles.get(key)
            if f is None:
                return r.abort()
            b = self._fontbytes.get(key)
            if b is None:
                try:
                    b = self._fontbytes[key] = f.read_bytes()
                except OSError:
                    return r.abort()
            ct = {".otf": "font/otf", ".ttc": "font/collection"}.get(f.suffix.lower(), "font/ttf")
            return r.fulfill(status=200, body=b, headers={"Content-Type": ct, "Access-Control-Allow-Origin": "*"})
        if url.startswith(("data:", "about:", "blob:")):
            return r.continue_()
        return r.abort()

    def _template_page(self):
        """템플릿 전용 페이지: 인터넷 요청은 막음 (표지는 이 컴퓨터 안에서만 만들어지게)"""
        if self._tpage is None:
            self._tpage = self._b.new_page()
            self._tpage.route("**/*", self._route)
        return self._tpage

    def render_template(self, tpl: str, data: dict, out: Path, png: bool = False, bg: Optional[str] = None) -> Path:
        pg = self._template_page()
        pg.set_content(template_doc(tpl, data, self._fonts, font_stack(), bg), wait_until="load", timeout=15000)
        pg.evaluate("document.fonts.ready")
        pg.wait_for_timeout(150)
        if png:
            pg.set_viewport_size({"width": 1123, "height": 794})          # A4 가로 96dpi
            pg.screenshot(path=str(out), full_page=False)
            return out
        pg.pdf(path=str(out), width="297mm", height="210mm", print_background=True, prefer_css_page_size=True,
               page_ranges="1")
        return out

    def close(self):
        try:
            self._b.close()
        finally:
            if self._own:
                self._pw.stop()

    def cover(self, L: Lecture, out: Path) -> Path:
        self.last_failed = False
        if self.template:
            try:
                return self.render_template(self.template, cover_data(L), out, bg=self.template_bg)
            except Exception as e:           # 템플릿이 망가졌으면 기본 표지로 (받기가 멈추지 않게)
                self.template_error = f"{type(e).__name__}: {str(e)[:120]}"
                self.last_failed = True
        self._page.set_content(self._default_doc(L), wait_until="load")
        self._page.evaluate("document.fonts.ready")
        self._page.pdf(path=str(out), width="297mm", height="210mm", print_background=True)
        return out

    def _default_doc(self, L: Lecture) -> str:
        head, prof = cover_texts(L)
        return COVER_HTML.format(fonts=self._fonts, stack=font_stack(), title_pt=title_pt(head),
                                 title=html.escape(head), prof=html.escape(prof), hist=hist_html(L))

    def cover_png(self, L: Lecture, out: Path, tpl: Optional[str] = None, bg: Optional[str] = None) -> Path:
        """설정 화면 미리보기 그림 (A4 가로 1123×794)"""
        if tpl:
            return self.render_template(tpl, cover_data(L), out, png=True, bg=bg)
        self._page.set_viewport_size({"width": 1123, "height": 794})
        self._page.set_content(self._default_doc(L), wait_until="load")
        self._page.evaluate("document.fonts.ready")
        self._page.screenshot(path=str(out))
        return out

    def stamp(self, text: str, w: float, h: float, out: Path) -> Path:
        w, h = round(w, 2), round(h, 2)
        s = max(w, h) / 960.0          # 16:9 슬라이드(960pt 폭) 기준 크기
        doc = STAMP_HTML.format(fonts=self._fonts, stack=font_stack(), w=w, h=h, text=html.escape(text),
                                inset=round(6 * s, 2), fs=round(11 * s, 2), bw=round(0.75 * s, 2),
                                r=round(3 * s, 2), py=round(2 * s, 2), px=round(5 * s, 2))
        self._page.set_content(doc, wait_until="load")
        self._page.evaluate("document.fonts.ready")
        self._page.pdf(path=str(out), width=f"{w / 72:.4f}in", height=f"{h / 72:.4f}in", print_background=False)
        return out


# ---------------------------------------------------------------- LibreOffice
def soffice_bin() -> Optional[str]:
    """LibreOffice 실행 파일 (맥·Windows·리눅스)"""
    import os
    cands = ["soffice", "libreoffice", "/Applications/LibreOffice.app/Contents/MacOS/soffice",
             str(Path.home() / "Applications" / "LibreOffice.app" / "Contents" / "MacOS" / "soffice")]
    for v in ("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA"):
        if os.environ.get(v):
            cands.append(str(Path(os.environ[v]) / "LibreOffice" / "program" / "soffice.exe"))
    for c in cands:
        p = shutil.which(c) or (c if Path(c).exists() else None)
        if p:
            return p
    return None


# PPT에 자주 쓰이는 한글 글꼴 → 앱에 들어 있는 Noto Sans KR 로 바꿔 그림
# (맥에는 맑은 고딕·굴림 등이 없고, LibreOffice가 한글 글꼴을 못 찾으면 한글이 □ 로 깨지거나 사라짐)
KO_FONTS = ["맑은 고딕", "Malgun Gothic", "굴림", "Gulim", "굴림체", "GulimChe", "돋움", "Dotum", "돋움체", "DotumChe",
            "바탕", "Batang", "바탕체", "BatangChe", "궁서", "Gungsuh", "나눔고딕", "NanumGothic", "나눔바른고딕",
            "NanumBarunGothic", "나눔스퀘어", "NanumSquare", "나눔명조", "NanumMyeongjo", "함초롬돋움", "함초롬바탕",
            "HCR Dotum", "HCR Batang", "맑은 고딕 Semilight", "Malgun Gothic Semilight", "새굴림", "New Gulim",
            "HY견고딕", "HY헤드라인M", "HY중고딕", "HY그래픽M", "휴먼명조", "한컴 고딕", "Apple SD Gothic Neo",
            "AppleGothic", "Noto Sans CJK KR", "Source Han Sans KR", "본고딕", "Pretendard", "에스코어 드림",
            "S-Core Dream", "KoPub돋움체", "KoPubDotum", "Spoqa Han Sans", "Spoqa Han Sans Neo"]


# 이 컴퓨터에 없을 때만 한글 글꼴로 바꿔 그릴 영문 글꼴 (주로 맥·웹 글꼴. Calibri·Arial 등은 LibreOffice가 같은 폭 글꼴로 대신 그림)
LATIN_FALLBACK = ["Helvetica", "Helvetica Neue", "Avenir", "Avenir Next", "SF Pro", "SF Pro Display", "SF Pro Text",
                  ".AppleSystemUIFont", "San Francisco", "Lucida Grande", "Futura", "Gill Sans", "Optima", "Myriad Pro",
                  "Segoe UI", "Roboto", "Open Sans", "Noto Sans", "Lato", "Montserrat", "Source Sans Pro"]


# 1순위: 맥에 기본으로 들어 있는 Apple SD 산돌고딕 Neo (앱에 넣어 배포하지 않고 이 맥의 파일을 그대로 씀)
APPLE_KO = [Path("/System/Library/Fonts/AppleSDGothicNeo.ttc"),
            Path("/System/Library/Fonts/Supplemental/AppleSDGothicNeo.ttc"),
            Path("/Library/Fonts/AppleSDGothicNeo.ttc")]


# Windows: 기본으로 들어 있는 맑은 고딕
WIN_KO = [Path(r"C:\Windows\Fonts\malgun.ttf"), Path(r"C:\Windows\Fonts\malgunbd.ttf")]


def ko_font():
    """(LibreOffice에 넣을 글꼴 파일들, 글꼴 이름). PPT·문서를 PDF로 바꿀 때 한글 글꼴을 이걸로 바꿔 그림.
    설정에서 넣은 글꼴 → Windows: 맑은 고딕 → 맥: Apple SD 산돌고딕 Neo → 앱의 Pretendard → Noto Sans KR"""
    uf = user_font()
    if uf:
        return [uf], font_family(uf)
    import os
    if os.name == "nt":                      # Windows: 기본으로 맑은 고딕 (한글·영문 모두 원래 PPT에 가장 가깝게)
        win = [f for f in WIN_KO if f.exists()]
        if win:
            return win, "Malgun Gothic"
    for f in APPLE_KO:
        if f.exists():
            return [f], "Apple SD Gothic Neo"
    pre = sorted(FONT_DIR.glob("Pretendard-*.ttf"))
    if pre:
        return pre, "Pretendard"
    win = [f for f in WIN_KO if f.exists()]
    if win:
        return win, "Malgun Gothic"
    return sorted((FONT_DIR / "lo").glob("*.ttf")), "Noto Sans KR"


SYMBOL_FONTS = ("wingdings", "webdings", "symbol", "marlett", "mt extra", "cambria math", "opensymbol", "starsymbol",
                "monotype sorts", "zapf dingbats", "zapfdingbats", "segoe ui symbol", "segoe ui emoji", "apple color emoji",
                "noto color emoji", "font awesome", "fontawesome", "material icons", "mdl2", "fluent icons", "bookshelf",
                "dingbat", "icons", "emoji")


def doc_fonts(path: Path) -> List[str]:
    """PPT·Word 파일에 쓰인 모든 글꼴 이름 (기호 글꼴 빼고) → 전부 한 글꼴(맥: 산돌고딕 Neo · 윈도우: 맑은 고딕)로 그려요.
    글꼴이 섞여 보이지 않게 · 글머리 기호에 쓰이는 기호 글꼴은 바꾸면 기호가 깨져서 그대로"""
    import re as _re
    import zipfile
    names = set()
    try:
        with zipfile.ZipFile(path) as z:
            for n in z.namelist():
                if n.endswith(".xml") and (n.startswith("ppt/") or n.startswith("word/")):
                    t = z.read(n).decode("utf-8", "ignore")
                    names.update(_re.findall(r'typeface="([^"]+)"', t))
                    names.update(_re.findall(r'w:(?:eastAsia|ascii|hAnsi|cs)="([^"]+)"', t))
                    names.update(_re.findall(r'<w:font w:name="([^"]+)"', t))
    except Exception:
        return []
    out = []
    for f in sorted(names):
        f = f.strip()
        if not f or f.startswith("+") or f in KO_FONTS or any(x in f.lower() for x in SYMBOL_FONTS):
            continue
        out.append(f)
    return out[:200]


def _lo_profile(prof: Path, extra_ko=()):
    """LibreOffice 임시 프로필: 한글 글꼴을 넣고, PPT의 한글 글꼴 이름을 그 글꼴로 바꿔 그리게 설정"""
    fdir = prof / "user" / "fonts"
    fdir.mkdir(parents=True, exist_ok=True)
    files, family = ko_font()
    for f in files:
        try:
            (fdir / f.name).symlink_to(f)          # 복사 대신 연결 (시스템 글꼴은 30MB 가까이 됨)
        except Exception:
            try:
                shutil.copy(f, fdir / f.name)
            except Exception:
                pass
    if not any(fdir.iterdir()):
        return
    def node(i, n, always):
        return (f'<node oor:name="{i}" oor:op="replace">'
                f'<prop oor:name="Always" oor:type="xs:boolean"><value>{"true" if always else "false"}</value></prop>'
                f'<prop oor:name="OnScreenOnly" oor:type="xs:boolean"><value>false</value></prop>'
                f'<prop oor:name="ReplaceFont" oor:type="xs:string"><value>{html.escape(n)}</value></prop>'
                f'<prop oor:name="SubstituteFont" oor:type="xs:string"><value>{family}</value></prop></node>')
    pairs = "".join(node(f"ko{i}", n, True) for i, n in enumerate(KO_FONTS) if n != family)
    # 그 파일에 쓰인 다른 글꼴(한컴산뜻돋움·Arial·Calibri 등)도 전부 같은 글꼴로 (한글·영어 글꼴이 섞여 보이지 않게)
    pairs += "".join(node(f"kx{i}", n, True) for i, n in enumerate(extra_ko) if n != family)
    # 이 컴퓨터에 없는 영문 글꼴(맥에서 만든 PPT의 Helvetica 등)도 같은 글꼴로 (있는 글꼴은 그대로)
    pairs += "".join(node(f"la{i}", n, False) for i, n in enumerate(LATIN_FALLBACK) if n != family)
    xcu = ('<?xml version="1.0" encoding="UTF-8"?>\n'
           '<oor:items xmlns:oor="http://openoffice.org/2001/registry" xmlns:xs="http://www.w3.org/2001/XMLSchema" '
           'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">\n'
           '<item oor:path="/org.openoffice.Office.Common/Font/Substitution">'
           '<prop oor:name="Replacement" oor:op="fuse"><value>true</value></prop></item>\n'
           f'<item oor:path="/org.openoffice.Office.Common/Font/Substitution/FontPairs">{pairs}</item>\n'
           '</oor:items>\n')
    (prof / "user" / "registrymodifications.xcu").write_text(xcu, "utf-8")


import threading as _th
_CONVERT_LOCK = _th.Lock()     # 강의록·필야가 동시에 돌 때 LibreOffice 변환은 하나씩


def convert(src: Path, fmt: str, outdir: Path, fonts=None, hidden: bool = False) -> Path:
    """LibreOffice로 변환 (fmt: 'pdf' | 'pptx'). 결과 경로 반환.
    fonts: 한 글꼴로 바꿔 그릴 글꼴 이름들 (없으면 파일에서 찾음) · hidden: 숨긴 슬라이드도 PDF에"""
    extra = fonts if fonts is not None else (doc_fonts(src) if fmt == "pdf" and src.suffix.lower() in (".pptx", ".docx") else [])
    if hidden and fmt == "pdf":
        fmt = 'pdf:impress_pdf_Export:{"ExportHiddenSlides":{"type":"boolean","value":"true"}}'
    with _CONVERT_LOCK:
        return _convert(src, fmt, outdir, extra)


def table_fill_lost(pptx: Path) -> bool:
    """예전 .ppt 를 .pptx 로 옮길 때 표 칸 색이 테마 색(accent)으로만 남았는지 (최신 LibreOffice: 원래 색이 사라지고 다른 색으로 칠해져요)"""
    import zipfile
    from lxml import etree
    A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
    try:
        with zipfile.ZipFile(pptx) as z:
            for n in z.namelist():
                if n.startswith("ppt/slides/slide") and n.endswith(".xml"):
                    b = z.read(n)
                    if b"<a:tbl" not in b:
                        continue
                    for pr in etree.fromstring(b).iter(A + "tcPr"):
                        f = pr.find(A + "solidFill")             # 칸 자체의 색만 (테두리 색은 빼고)
                        if f is not None and f.find(A + "schemeClr") is not None:
                            return True
    except Exception:
        return False
    return False


def fix_table_fills(pptx: Path, odp: Path, out: Path) -> int:
    """.pptx 의 표 칸 색을 같은 파일을 .odp 로 바꾼 것(칸마다 실제 색이 적혀 있음)에 맞춰 고친 사본을 out 에.
    슬라이드·표·칸 수가 하나라도 안 맞으면 0 (고치지 않음) · 고친 칸 수를 돌려줘요"""
    import zipfile
    import posixpath
    from lxml import etree
    O = {"office": "urn:oasis:names:tc:opendocument:xmlns:office:1.0", "draw": "urn:oasis:names:tc:opendocument:xmlns:drawing:1.0",
         "table": "urn:oasis:names:tc:opendocument:xmlns:table:1.0", "style": "urn:oasis:names:tc:opendocument:xmlns:style:1.0"}
    A = "http://schemas.openxmlformats.org/drawingml/2006/main"
    P = "http://schemas.openxmlformats.org/presentationml/2006/main"
    RN = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
    q = lambda ns, t: "{%s}%s" % (O[ns], t)
    with zipfile.ZipFile(odp) as z:
        root = etree.fromstring(z.read("content.xml"))
    fills = {}
    for st in root.iter(q("style", "style")):
        if st.get(q("style", "family")) != "table-cell":
            continue
        for gp in st:
            if gp.tag.endswith("graphic-properties"):
                f = gp.get(q("draw", "fill"))
                c = gp.get(q("draw", "fill-color"))
                op = (gp.get(q("draw", "opacity")) or "100%").rstrip("%")
                fills[st.get(q("style", "name"))] = (f, c, op)
    pages = []
    for pg in root.iter(q("draw", "page")):
        tabs = []
        for tb in pg.iter(q("table", "table")):
            rows = []
            for tr in tb.iter(q("table", "table-row")):
                rows.append([fills.get(tc.get(q("table", "style-name"))) for tc in tr
                             if tc.tag in (q("table", "table-cell"), q("table", "covered-table-cell"))])
            tabs.append(rows)
        pages.append(tabs)
    zin = zipfile.ZipFile(pptx)
    # .odp 쪽도 같은 문제(모든 칸이 테마 1번 색)면 믿을 수 없어서 고치지 않음
    used = {(c or "").lstrip("#").upper() for pg in pages for tb in pg for row in tb for f in row if f and f[0] == "solid" for c in [f[1]]}
    try:
        import re as _re
        th = zin.read("ppt/theme/theme1.xml").decode("utf-8", "ignore")
        m = _re.search(r'<a:accent1><a:srgbClr val="([0-9A-Fa-f]{6})"', th)
        if m and used and used <= {m.group(1).upper()}:
            zin.close()
            return 0
    except KeyError:
        pass
    pres = etree.fromstring(zin.read("ppt/presentation.xml"))
    rels = etree.fromstring(zin.read("ppt/_rels/presentation.xml.rels"))
    rmap = {r.get("Id"): r.get("Target") for r in rels}
    order = ["ppt/" + posixpath.normpath(rmap[s.get("{%s}id" % RN)]).lstrip("/").replace("ppt/", "", 1)
             for s in pres.iter("{%s}sldId" % P)]
    if len(order) != len(pages):
        return 0
    changed, n = {}, 0
    for path, tabs in zip(order, pages):
        sx = etree.fromstring(zin.read(path))
        tbls = list(sx.iter("{%s}tbl" % A))
        if len(tbls) != len(tabs):
            return 0
        if not tbls:
            continue
        for tbl, rows in zip(tbls, tabs):
            trs = tbl.findall("{%s}tr" % A)
            if len(trs) != len(rows):
                return 0
            for tr, cols in zip(trs, rows):
                tcs = tr.findall("{%s}tc" % A)
                if len(tcs) != len(cols):
                    return 0
                for tc, fc in zip(tcs, cols):
                    if not fc or not fc[0]:
                        continue
                    if fc[0] == "solid" and fc[1]:
                        el = etree.Element("{%s}solidFill" % A)
                        clr = etree.SubElement(el, "{%s}srgbClr" % A, val=fc[1].lstrip("#").upper())
                        try:
                            if float(fc[2]) < 100:
                                etree.SubElement(clr, "{%s}alpha" % A, val=str(int(float(fc[2]) * 1000)))
                        except ValueError:
                            pass
                    elif fc[0] == "none":
                        el = etree.Element("{%s}noFill" % A)
                    else:
                        continue                            # 그라데이션 등: 원래 칸 색 그대로 둠
                    pr = tc.find("{%s}tcPr" % A)
                    if pr is None:
                        pr = etree.SubElement(tc, "{%s}tcPr" % A)
                    for ch in list(pr):
                        if etree.QName(ch).localname in ("noFill", "solidFill", "gradFill", "blipFill", "pattFill", "grpFill"):
                            pr.remove(ch)
                    k = 0                                   # 선(ln*)·cell3D 뒤, headers·extLst 앞에
                    for i, ch in enumerate(pr):
                        if etree.QName(ch).localname in ("lnL", "lnR", "lnT", "lnB", "lnTlToBr", "lnBlToTr", "cell3D"):
                            k = i + 1
                    pr.insert(k, el)
                    n += 1
        changed[path] = etree.tostring(sx, xml_declaration=True, encoding="UTF-8", standalone=True)
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zo:
        for info in zin.infolist():
            if info.filename in changed:
                zo.writestr(info, changed[info.filename])
            else:
                with zin.open(info) as fi, zo.open(info, "w") as fo:
                    shutil.copyfileobj(fi, fo, 1 << 20)
    zin.close()
    return n


def take_pages(base: Path, other: Path, pick: List[Optional[int]], out: Path) -> Path:
    """base 의 쪽마다 pick[i] 가 있으면 other 의 그 쪽(0부터)으로 바꿔 끼운 PDF"""
    a, b = PdfReader(str(base)), PdfReader(str(other))
    if len(a.pages) != len(pick):
        return base                                   # 쪽 수가 안 맞으면 바꾸지 않음
    w = PdfWriter()
    for i, page in enumerate(a.pages):
        j = pick[i] if i < len(pick) else None
        w.add_page(b.pages[j] if j is not None and j < len(b.pages) else page)
    with open(out, "wb") as f:
        w.write(f)
    return out


def _convert(src: Path, fmt: str, outdir: Path, extra_ko=()) -> Path:
    sb = soffice_bin()
    if not sb:
        raise RuntimeError("LibreOffice(soffice)를 찾을 수 없어요")
    outdir.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as prof:
        _lo_profile(Path(prof), extra_ko)
        cmd = [sb, f"-env:UserInstallation={Path(prof).as_uri()}", "--headless",
               "--convert-to", fmt, "--outdir", str(outdir), str(src)]
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
    out = outdir / (src.stem + "." + fmt.split(":", 1)[0])
    if not out.exists():
        msg = "\n".join(l for l in (r.stderr or r.stdout or "").splitlines()
                        if l.strip() and not l.startswith("Fontconfig")).strip()
        raise RuntimeError(f"변환 실패: {src.name} → {fmt} ({msg[:200] or 'LibreOffice가 결과 없이 끝남'})")
    return out


MEDIA_EXT = (".mp4", ".m4v", ".mov", ".avi", ".wmv", ".mpg", ".mpeg", ".mkv", ".webm", ".flv",
             ".mp3", ".wav", ".m4a", ".wma", ".aac")


def strip_media(src: Path, out: Path) -> int:
    """PPT 안의 동영상·소리 파일을 빈 파일로 바꾼 사본 (PDF에는 어차피 정지 화면만 들어감).
    큰 동영상이 든 PPT는 LibreOffice가 변환 중 죽는 경우가 있어서. 바꾼 개수 반환."""
    import zipfile
    n = 0
    with zipfile.ZipFile(src) as zi, zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zo:
        for info in zi.infolist():
            if info.filename.lower().endswith(MEDIA_EXT):
                zo.writestr(info, b"")
                n += 1
            else:
                with zi.open(info) as f_in, zo.open(info, "w") as f_out:
                    shutil.copyfileobj(f_in, f_out, 1 << 20)
    return n


# ---------------------------------------------------------------- 표시 + 합치기
def apply_labels(pdf: Path, labels: List[str], renderer: Renderer, out: Path, tmp: Path) -> int:
    """labels[i]가 있으면 i번째 쪽 오른쪽 위에 표시. 표시한 쪽 수 반환."""
    reader = PdfReader(str(pdf))
    writer = PdfWriter()
    n = 0
    cache = {}
    for i, page in enumerate(reader.pages):
        lab = labels[i] if i < len(labels) else ""
        if lab:
            w, h = float(page.mediabox.width), float(page.mediabox.height)
            key = (lab, round(w), round(h))
            if key not in cache:
                sp = tmp / f"stamp_{len(cache)}.pdf"
                renderer.stamp(lab, w, h, sp)
                cache[key] = PdfReader(str(sp)).pages[0]
            page.merge_page(cache[key])
            n += 1
        writer.add_page(page)
    with open(out, "wb") as f:
        writer.write(f)
    return n


A4_LONG, A4_SHORT = 841.89, 595.28      # pt
A4_TOL = 2.0


# 용지 크기 (pt, 긴 변 × 짧은 변). B5는 우리나라에서 흔히 쓰는 JIS B5 (182×257mm)
PAPERS = {"A4": (841.89, 595.28), "B5": (728.5, 515.9), "A5": (595.28, 419.53), "Letter": (792.0, 612.0)}


_CUSTOM = re.compile(r"^\s*(\d+(?:\.\d+)?)\s*[x×*]\s*(\d+(?:\.\d+)?)\s*$", re.I)


def paper_dims(paper: str):
    """용지 이름('A4' 등) 또는 사용자 설정('210x297', mm) → (긴 변, 짧은 변) pt. 모르는 값이면 None"""
    if paper in PAPERS:
        return PAPERS[paper]
    m = _CUSTOM.match(paper or "")
    if not m:
        return None
    a, b = float(m.group(1)), float(m.group(2))
    if not (50 <= a <= 1200 and 50 <= b <= 1200):
        return None
    a, b = a * 72 / 25.4, b * 72 / 25.4
    return (max(a, b), min(a, b))


def _to_a4(page, paper: str = "A4"):
    """페이지를 정한 용지 크기로: 가로 페이지 → 가로, 세로 페이지 → 세로.
    내용은 비율을 유지한 채 최대한 크게, 가운데 정렬 (남는 곳은 흰 여백)."""
    A4_LONG, A4_SHORT = paper_dims(paper) or PAPERS["A4"]
    from pypdf import PageObject, Transformation
    try:
        page.transfer_rotation_to_content()
    except Exception:
        pass
    box = page.cropbox
    x0, y0 = float(box.left), float(box.bottom)
    w, h = float(box.width), float(box.height)
    W, H = (A4_LONG, A4_SHORT) if w >= h else (A4_SHORT, A4_LONG)
    if abs(w - W) < A4_TOL and abs(h - H) < A4_TOL and abs(x0) < A4_TOL and abs(y0) < A4_TOL:
        return page                                  # 이미 A4
    k = min(W / w, H / h)
    tx = (W - w * k) / 2 - x0 * k
    ty = (H - h * k) / 2 - y0 * k
    new = PageObject.create_blank_page(width=W, height=H)
    new.merge_transformed_page(page, Transformation().scale(k).translate(tx, ty))
    return new


def merge(parts: List[Path], out: Path, a4: bool = True, paper: Optional[str] = None):
    """paper: 'A4'·'B5'·'A5'·'Letter'·'가로x세로'(mm) = 그 크기로 맞춤 / '' = 원본 크기 그대로. (a4 는 예전 방식 호환)"""
    size = (paper if paper is not None else ("A4" if a4 else "")) or ""
    w = PdfWriter()
    for p in parts:
        for pg in PdfReader(str(p)).pages:
            w.add_page(_to_a4(pg, size) if size else pg)
    try:
        w.compress_identical_objects(remove_identicals=True, remove_orphans=True)
    except Exception:
        pass
    out.parent.mkdir(parents=True, exist_ok=True)
    tmp = out.with_suffix(".tmp.pdf")
    with open(tmp, "wb") as f:
        w.write(f)
    tmp.replace(out)


def page_count(pdf: Path) -> int:
    return len(PdfReader(str(pdf)).pages)
