"""시간표 고치기·가져오기.

시간표.json(과목 → rows) 을 '수업 한 번 = 한 항목'으로 펼쳐서 다루고,
새 시간표(직접 수정 / AI가 만든 결과 / 사진)와 비교해 바뀐 점을 보여 주고, 고른 것만 적용한다.
적용하면 이미 만든 강의록·매칭 기억도 새 시간표에 맞게 정리한다.
"""
from __future__ import annotations

import json
import re
import shutil
from datetime import date, datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from .timetable import YEAR_KEY, _parse_period, _profs, folder_course, norm_course

WEEK = "월화수목금토일"
SKIP = re.compile(r"시험|(중간|기말)고사|휴강|오리엔테이션\s*$|자습|공강")


# ---------------------------------------------------------------- 기본 도구
def nt(t: str) -> str:
    """제목 비교용: 띄어쓰기·기호 무시, 로마숫자 통일 ('신생아 질환 III' == '신생아질환 III')"""
    t = (t or "").replace("Ⅰ", "I").replace("Ⅱ", "II").replace("Ⅲ", "III").replace("Ⅳ", "IV")
    return re.sub(r"[\s\-·ㆍ・_/(),.]+", "", t).lower()


def year_for(mm: int) -> int:
    y = int(YEAR_KEY)
    return y + 1 if mm <= 2 else y


def wd(mmdd: str) -> str:
    try:
        return WEEK[date(year_for(int(mmdd[:2])), int(mmdd[:2]), int(mmdd[2:])).weekday()]
    except ValueError:
        return ""


def parse_date(s) -> Optional[str]:
    s = str(s or "")
    m = re.search(r"(?:20\d{2}[-./\s]*)?(\d{1,2})\s*[-./월]\s*(\d{1,2})", s) or re.fullmatch(r"\s*(\d{2})(\d{2})\s*", s)
    if not m:
        return None
    mo, d = int(m.group(1)), int(m.group(2))
    return f"{mo:02d}{d:02d}" if 1 <= mo <= 12 and 1 <= d <= 31 else None


def parse_period(s) -> Optional[Tuple[int, int]]:
    if isinstance(s, (int, float)):
        return int(s), 1
    return _parse_period(str(s or "").replace("교시", ""))


def prof_str(p) -> str:
    if isinstance(p, list):
        p = "·".join(p)
    return "·".join(_profs(str(p or "")))


# ---------------------------------------------------------------- 펼치기 / 접기
def expand(data: list) -> List[dict]:
    """rows → 수업 한 번씩: {course, mmdd, start, hours, title, prof, term, row}"""
    out = []
    for ci, c in enumerate(data):
        for ri, r in enumerate(c.get("rows") or []):
            dates = [parse_date(x) for x in re.split(r"[·,]", r.get("d") or "")]
            gs = re.split(r"·", r.get("g") or "")
            prof = prof_str((r.get("y") or {}).get(YEAR_KEY, ""))
            for i, dd in enumerate(d for d in dates if d):
                p = parse_period(gs[i] if i < len(gs) else (gs[-1] if gs else ""))
                if not p:
                    continue
                out.append({"course": c["name"], "mmdd": dd, "start": p[0], "hours": p[1],
                            "title": (r.get("t") or "").strip(), "prof": prof,
                            "term": int(r.get("term") or 0), "row": [ci, ri]})
    out.sort(key=lambda x: (x["course"], x["mmdd"], x["start"]))
    return out


def _gtxt(start: int, hours: int) -> str:
    return f"{start}" if hours <= 1 else f"{start}-{start + hours - 1}"


def collapse(items: List[dict], old: list) -> list:
    """수업 목록 → 시간표.json 형식. 역대 교수 기록은 같은 제목의 예전 행에서 이어받는다."""
    new = []
    for c in old:
        hist_rows = {nt(r.get("t")): r for r in c.get("rows") or []}
        mine = [x for x in items if x["course"] == c["name"]]
        groups: Dict[tuple, List[dict]] = {}
        for x in sorted(mine, key=lambda x: (x["mmdd"], x["start"])):
            groups.setdefault((x["title"], x["prof"], x["term"]), []).append(x)
        rows, used = [], set()
        order = {nt(r.get("t")): i for i, r in enumerate(c.get("rows") or [])}
        for (title, prof, term), xs in sorted(groups.items(), key=lambda kv: (order.get(nt(kv[0][0]), 10 ** 6), kv[1][0]["mmdd"], kv[1][0]["start"])):
            base = hist_rows.get(nt(title)) or {}
            used.add(nt(title))
            y = dict(base.get("y") or {})
            y[YEAR_KEY] = prof or "—"
            tm = dict(base.get("tm") or {})
            if term:
                tm[YEAR_KEY] = term
            rows.append({"t": title,
                         "d": "·".join(f"{int(x['mmdd'][:2])}/{int(x['mmdd'][2:])}({wd(x['mmdd'])})" for x in xs),
                         "g": "·".join(_gtxt(x["start"], x["hours"]) for x in xs),
                         "y": y, "term": term, "tm": tm})
        # 올해 수업은 없지만 예전 기록만 있는 행(비교용)은 그대로 둔다
        for r in c.get("rows") or []:
            if nt(r.get("t")) not in used and not (r.get("d") or "").strip():
                rows.append(r)
        ys = sorted({str(y) for y in (c.get("years") or [])} | {YEAR_KEY}, reverse=True)   # 올해 칸이 꼭 있게
        new.append({**c, "years": ys, "rows": rows})
    # 새 과목
    known = {c["name"] for c in old}
    for cname in sorted({x["course"] for x in items} - known):
        new.append({"name": cname, "years": [YEAR_KEY], "rows": [], "hasTerm": False})
        new[-1] = collapse([x for x in items if x["course"] == cname], [new[-1]])[0]
    return new


# ---------------------------------------------------------------- 가져오기(정리)
def guess_course(title: str, mmdd: str, cur: List[dict], names: List[str]) -> Optional[str]:
    t = nt(title)
    hit = [x["course"] for x in cur if nt(x["title"]) == t]
    if hit:
        return max(set(hit), key=hit.count)
    # 비슷한 제목 (포함 관계)
    hit = [x["course"] for x in cur if t and (t in nt(x["title"]) or nt(x["title"]) in t) and len(t) >= 3]
    if hit:
        return max(set(hit), key=hit.count)
    # 같은 날 다른 수업이 가장 많은 과목
    same = [x["course"] for x in cur if x["mmdd"] == mmdd]
    if same:
        return max(set(same), key=same.count)
    return names[0] if len(names) == 1 else None


def _overlap(a: str, b: str) -> float:
    """두 제목의 글자 2개 묶음 겹침 비율 (짧은 쪽 기준)"""
    A = {a[i:i + 2] for i in range(len(a) - 1)}
    B = {b[i:i + 2] for i in range(len(b) - 1)}
    return len(A & B) / max(1, min(len(A), len(B)))


def normalize(raw, cur: List[dict], course_names: List[str]) -> Tuple[List[dict], List[str]]:
    """AI 결과·직접 수정·사진 결과 → 수업 목록. (목록, 경고)"""
    if isinstance(raw, str):
        txt = raw.strip()
        m = re.search(r"\{.*\}|\[.*\]", txt, re.S)        # 설명 글이 섞여 있어도 JSON 부분만
        raw = json.loads(m.group(0) if m else txt)
    rows = []
    if isinstance(raw, dict) and "courses" in raw:
        for c in raw["courses"] or []:
            for l in c.get("lectures") or []:
                rows.append({**l, "course": l.get("course") or c.get("name")})
    elif isinstance(raw, dict) and "lectures" in raw:
        rows = list(raw["lectures"])
    elif isinstance(raw, list):
        rows = raw
    warn, out, nocourse = [], [], []
    for i, l in enumerate(rows):
        title = str(l.get("title") or l.get("t") or "").strip()
        if not title or SKIP.search(title):
            continue
        dd = parse_date(l.get("date") or l.get("d") or l.get("mmdd"))
        p = parse_period(l.get("period") or l.get("g") or (f"{l.get('start')}-{int(l.get('start')) + int(l.get('hours', 1)) - 1}" if l.get("start") else ""))
        if not dd or not p:
            warn.append(f"{i + 1}번째 항목 「{title}」: 날짜나 교시를 못 읽었어요 → 빼고 진행")
            continue
        course = str(l.get("course") or "").strip()
        from .matching import same_course
        cn = next((n for n in course_names if norm_course(n) == norm_course(course) or same_course(n, course)), None) if course else None
        if not cn and course:
            cn = course                  # 지금 시간표에 없는 과목 → 새 과목으로 (처음 넣는 시간표·새 학기)
        if not cn:
            cn = guess_course(title, dd, cur, course_names)
        if not cn:
            nocourse.append(f"「{title}」({dd[:2]}/{dd[2:]})")
            continue
        # 띄어쓰기만 다른 제목, 또는 같은 날·같은 교시에 이름 일부만 다른 제목('유전대사' ↔ '유전-대사 질환')은 기존 이름 유지
        same = next((x["title"] for x in cur if x["course"] == cn and nt(x["title"]) == nt(title)), None)
        if not same:
            t2 = nt(title)
            same = next((x["title"] for x in cur if x["course"] == cn and x["mmdd"] == dd and x["start"] == p[0]
                         and len(t2) >= 2 and (t2 in nt(x["title"]) or nt(x["title"]) in t2 or _overlap(t2, nt(x["title"])) >= 0.6)), None)
        term = l.get("term")
        try:
            term = int(re.sub(r"\D", "", str(term))) if term not in (None, "") else None
        except ValueError:
            term = None
        out.append({"course": cn, "mmdd": dd, "start": p[0], "hours": p[1], "title": same or title,
                    "prof": prof_str(l.get("prof") or l.get("profs") or l.get("professor") or ""), "term": term})
    if len(nocourse) > 3:
        warn.insert(0, f"과목명이 없어서 수업 {len(nocourse)}개를 뺐어요 (예: {', '.join(nocourse[:2])} …). "
                       "AI에게 「과목 이름과 기간을 알려 줄게」 하고 과목명을 알려 준 뒤 다시 받아 주세요.")
    else:
        warn += [f"{x}: 어느 과목인지 몰라서 뺐어요" for x in nocourse]
    # 차수가 없으면: 같은 제목의 기존 차수 → 날짜가 가장 가까운 기존 수업의 차수
    for x in out:
        if x["term"] is None:
            same = [c["term"] for c in cur if c["course"] == x["course"] and nt(c["title"]) == nt(x["title"]) and c["term"]]
            if same:
                x["term"] = same[0]
            else:
                near = sorted((c for c in cur if c["course"] == x["course"] and c["term"]),
                              key=lambda c: abs(int(c["mmdd"]) - int(x["mmdd"])))
                x["term"] = near[0]["term"] if near else 0
    return out, warn


# ---------------------------------------------------------------- 비교
def _same(a, b) -> bool:
    return (a["mmdd"], a["start"], a["hours"], nt(a["title"]), a["prof"], a["term"]) == \
           (b["mmdd"], b["start"], b["hours"], nt(b["title"]), b["prof"], b["term"])


def diff(cur: List[dict], new: List[dict], mode: str, courses: Optional[List[str]] = None) -> List[dict]:
    """mode: all(시간표 전체를 새 것으로) / full(새 목록에 있는 과목 전체 교체) / partial(새 목록에 있는 날짜만) / course(지정 과목 전체)
    → [{id, type: add|remove|change, before, after, fields}]"""
    if mode == "all":                    # 처음 설정: 새 시간표가 전부 (새 목록에 없는 과목·수업은 모두 뺌)
        scope = list(cur)
    elif mode == "partial":
        days = {x["mmdd"] for x in new}
        scope = [x for x in cur if x["mmdd"] in days]
    elif mode == "course":
        cs = set(courses or {x["course"] for x in new})
        scope = [x for x in cur if x["course"] in cs]
    else:
        cs = {x["course"] for x in new}
        scope = [x for x in cur if x["course"] in cs]        # 새 목록에 없는 과목은 건드리지 않음
    olds, news = list(scope), list(new)
    pairs = []
    def take(pred):
        for n in list(news):
            o = next((o for o in olds if o["course"] == n["course"] and pred(o, n)), None)
            if o:
                pairs.append((o, n))
                olds.remove(o)
                news.remove(n)
    take(_same)
    take(lambda o, n: o["mmdd"] == n["mmdd"] and o["start"] == n["start"])               # 같은 시간 → 제목/교수 바뀜
    take(lambda o, n: nt(o["title"]) == nt(n["title"]) and o["prof"] == n["prof"])        # 같은 강의 → 날짜/교시 이동
    take(lambda o, n: nt(o["title"]) == nt(n["title"]))
    out = []
    for o, n in pairs:
        if _same(o, n):
            continue
        f = [k for k, a, b in (("날짜", o["mmdd"], n["mmdd"]), ("교시", (o["start"], o["hours"]), (n["start"], n["hours"])),
                               ("제목", nt(o["title"]), nt(n["title"])), ("교수", o["prof"], n["prof"]), ("차수", o["term"], n["term"])) if a != b]
        out.append({"type": "change", "before": o, "after": n, "fields": f})
    out += [{"type": "add", "before": None, "after": n, "fields": []} for n in news]
    out += [{"type": "remove", "before": o, "after": None, "fields": []} for o in olds]
    out.sort(key=lambda c: ((c["after"] or c["before"])["course"], (c["after"] or c["before"])["mmdd"], (c["after"] or c["before"])["start"]))
    for i, c in enumerate(out):
        c["id"] = i
    return out


def apply_changes(cur: List[dict], changes: List[dict], accept: Optional[List[int]] = None) -> List[dict]:
    acc = set(accept) if accept is not None else {c["id"] for c in changes}
    res = [dict(x) for x in cur]
    def find(x):
        return next((i for i, y in enumerate(res) if y["course"] == x["course"] and y["mmdd"] == x["mmdd"]
                     and y["start"] == x["start"] and nt(y["title"]) == nt(x["title"])), None)
    for c in changes:
        if c["id"] not in acc:
            continue
        if c["type"] in ("remove", "change"):
            i = find(c["before"])
            if i is not None:
                res.pop(i)
        if c["type"] in ("add", "change"):
            a = {k: c["after"][k] for k in ("course", "mmdd", "start", "hours", "title", "prof", "term")}
            res.append(a)
    res.sort(key=lambda x: (x["course"], x["mmdd"], x["start"]))
    return res


# ---------------------------------------------------------------- 강의록 정리
def _key(x: dict, group: List[dict]) -> str:
    """timetable.load 와 같은 방식의 강의 key (같은 날·교시·교수 묶음은 제목을 · 로 이음)"""
    title = "·".join(g["title"] for g in group)
    return f"{folder_course(x['course'])}|{x['mmdd']}-{x['start']}|{title}"


def tidy_outputs(app: Path, old_lectures, new_lectures, out_dir, out_name, read_records, write_records, log=print) -> dict:
    """시간표가 바뀌어 이름·표지가 달라진 강의록은 _이전버전 으로 옮기고 기록을 지운다 (다음 받기 때 새로 만듦).
    매칭 기억의 강의 key 도 새 key 로 바꾼다."""
    new_by = {L.key: L for L in new_lectures}
    moved, remap = [], {}
    stamp = f"{datetime.now():%m%d}"
    for L in old_lectures:
        same = new_by.get(L.key)
        if same and out_name(same) == out_name(L) and out_dir(same) == out_dir(L) and same.hours == L.hours \
                and same.profs == L.profs:
            continue
        # 짝 찾기: 같은 과목·같은 제목 → 같은 과목·같은 날짜·교시
        cand = [N for N in new_lectures if N.course == L.course and nt(N.title) == nt(L.title)]
        cand = cand or [N for N in new_lectures if N.course == L.course and N.mmdd == L.mmdd and N.start == L.start]
        if cand:
            remap[L.key] = sorted(cand, key=lambda N: abs(int(N.mmdd) - int(L.mmdd)))[0].key
        d, name = out_dir(L), out_name(L)
        if (d / name).exists():
            prev = d / "_이전버전"
            prev.mkdir(exist_ok=True)
            shutil.move(str(d / name), str(prev / name.replace(".pdf", f"_시간표변경{stamp}.pdf")))
            refs = d / (name[:-4] + "_참고자료")
            if refs.exists():
                shutil.move(str(refs), str(prev / (refs.name + f"_시간표변경{stamp}")))
            recs = read_records(d)
            recs.pop(name, None)
            write_records(d, recs)
            moved.append(name)
    from .matching import safe_replace

    def _save(path: Path, obj):          # 임시 파일에 쓰고 바꿔치기 (쓰는 도중 다른 쪽이 읽어도 깨진 파일을 안 보게)
        tmp = path.with_name(path.stem + ".tt.tmp")
        tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=1), "utf-8")
        safe_replace(tmp, path)
    # 매칭 기억 key 바꾸기 (내가 정한 자료 + 앱이 정한 자료)
    mp = app / "매칭기억.json"
    if mp.exists() and remap:
        try:
            mem = json.loads(mp.read_text("utf-8-sig"))
            for k, v in list(mem.items()):
                if v not in ("제외", "범위밖", "보류"):
                    mem[k] = "||".join(remap.get(x, x) for x in v.split("||"))
            _save(mp, mem)
        except Exception:
            pass
    ap = app / "자동분류.json"
    if ap.exists() and remap:
        try:
            auto = json.loads(ap.read_text("utf-8-sig"))
            for e in auto.values():
                e["keys"] = [remap.get(x, x) for x in e.get("keys") or []]
            _save(ap, auto)
        except Exception:
            pass
    # 현황 기록에서 바뀐 강의는 지움 (다음 받기 때 다시 채움)
    sp = app / "현황.json"
    if sp.exists():
        try:
            st = json.loads(sp.read_text("utf-8-sig"))
            for k in list(st):
                if k not in new_by:
                    st.pop(k)
            _save(sp, st)
        except Exception:
            pass
    return {"moved": moved, "remap": remap}


def backup(path: Path) -> Path:
    d = path.parent / "시간표_백업"
    d.mkdir(exist_ok=True)
    dst = d / f"시간표_{datetime.now():%Y%m%d_%H%M%S}.json"
    shutil.copy(path, dst)
    return dst


PROMPT = """첨부한 시간표(강의계획서/시간표 PDF 또는 사진)를 읽어서, 아래 형식의 JSON만 출력해 주세요. 설명 문장은 쓰지 마세요.
올해 시간표 하나만 있어도 되고, 지난 연도 시간표를 같이 첨부했으면 한꺼번에 적어요.

{
  "courses": [
    {
      "name": "과목명 (예: 생식성장발달 II)",
      "lectures": [
        {"year": "2026", "date": "10/27", "period": "1-2", "title": "신생아질환 III", "prof": "김성래", "term": 2},
        {"year": "2025", "title": "신생아질환 III", "prof": "김성래", "term": 1}
      ]
    }
  ]
}

규칙
- year: 그 시간표의 학년도 (예: 2026). 2학기 시간표의 1·2월 수업도 같은 학년도예요. 여러 해를 첨부했으면 해마다 따로 적어요.
- 수업 한 번(한 칸) = lectures 항목 하나. 같은 강의가 여러 날이면 날마다 따로 적어요.
- date: "월/일" (예: "10/27"). period: 시작-끝 교시 (예: 1교시만이면 "1", 6~9교시면 "6-9"). 여러 교시를 합친 칸은 합친 범위로.
  · 가장 최근 해(올해) 시간표는 date·period가 꼭 있어야 해요. 지난 연도는 몰라도 돼요 (교수님 비교용).
- title: 칸에 적힌 강의 제목 그대로.
  · 시간표에서 **파란 글씨**인 칸은 CP(증례) 강의예요. 제목에 CP가 안 써 있어도 앞에 "CP "를 붙여요.
  · TBL 수업이면 끝에 " -TBL"을 붙여요. 예: 파란 글씨 「신생아 황달 (TBL)」 → "CP 신생아 황달 -TBL"
- prof: 담당 교수 이름. 여러 명이면 "·"로 이어요 (예: "백정현·김민수"). 없으면 "".
- term: 차수(1차/2차 시험 범위)가 표시돼 있으면 숫자로, 모르면 빼요.
- 시험·중간고사·기말고사·휴강·오리엔테이션·빈 칸은 빼요.
- name(과목명): 시간표 맨 위·옆 제목, 과목별 기간 표, 범례, 색·블록 구분, 강의계획서 표지에서 찾아요. LMS에 나오는 과목 이름과 같게 적어야 해요 (예: "생식성장발달 II").
  · 시간표 어디에도 과목명이 없으면 지어내거나 비워 두지 말고, JSON을 쓰기 전에 먼저 나에게 물어봐요.
    "이 시간표에는 과목명이 안 보여요. 과목 이름과 기간(예: 생식성장발달 II 10/20~11/14)을 알려 주세요"처럼 묻고, 답을 받은 뒤 날짜로 나눠 적어요.
  · 예외: 이미 앱에 시간표가 있고 주간 수정본 사진처럼 몇 칸만 고치는 경우에는 "name"을 "" 로 두면 앱이 기존 시간표에서 찾아 넣어요.
- 날짜·교시가 확실하지 않은 올해 칸은 빼고, 그냥 생략해요."""


# ---------------------------------------------------------------- 지난 연도 시간표 (역대 담당 교수 채우기)
PROMPT_PAST = PROMPT          # 예전 이름 (같은 프롬프트로 올해·지난 연도를 함께 읽음)


def _past_items(raw) -> Tuple[Optional[str], List[dict]]:
    if isinstance(raw, str):
        txt = raw.strip()
        m = re.search(r"\{.*\}|\[.*\]", txt, re.S)
        raw = json.loads(m.group(0) if m else txt)
    year = None
    rows = []
    if isinstance(raw, dict):
        year = str(raw.get("year") or "").strip() or None
        for c in raw.get("courses") or []:
            for l in c.get("lectures") or []:
                rows.append({**l, "course": l.get("course") or c.get("name") or ""})
        for l in raw.get("lectures") or []:
            rows.append(l)
    elif isinstance(raw, list):
        rows = raw
    return year, rows


def split_years(raw) -> Tuple[List[dict], Dict[str, List[dict]], List[str]]:
    """AI 결과 → (올해 수업, {지난 연도: 수업들}, 올해보다 뒤의 연도). year 가 없는 항목은 올해로."""
    y0, items = _past_items(raw)
    cur, past, future = [], {}, set()
    for l in items:
        y = str(l.get("year") or y0 or "")
        m = re.search(r"20\d\d", y)
        y = m.group(0) if m else YEAR_KEY
        if y == YEAR_KEY:
            cur.append(l)
        elif y < YEAR_KEY:
            past.setdefault(y, []).append(l)
        else:
            future.add(y)
    return cur, past, sorted(future)


def plan_past(data: list, raw, year: Optional[str] = None) -> Tuple[str, List[dict], List[str]]:
    """지난 연도 시간표 → 역대 교수 칸 변경 목록. 과목·강의는 제목으로 지금 시간표에 맞추고,
    지금 시간표에 없는 강의는 '올해 없는 강의(비교용)' 줄로 추가."""
    y0, items = _past_items(raw)
    year = str(year or y0 or "").strip()
    m = re.search(r"20\d\d", year)
    if not m:
        raise ValueError("몇 년도 시간표인지 알 수 없어요. 연도를 적어 주세요.")
    year = m.group(0)
    if year >= YEAR_KEY:
        raise ValueError(f"{year}년은 지난 연도가 아니에요. 올해({YEAR_KEY}) 시간표는 위의 「시간표 가져오기」로 넣어 주세요.")
    names = [c["name"] for c in data]
    warn, agg = [], {}
    for l in items:
        title = str(l.get("title") or l.get("t") or "").strip()
        if not title or SKIP.search(title):
            continue
        praw = str(l.get("prof") or l.get("profs") or l.get("professor") or "")
        prof = prof_str(praw)
        cname = str(l.get("course") or "")
        ci = next((i for i, n in enumerate(names) if cname and norm_course(n) == norm_course(cname)), None)
        t = nt(title)
        if ci is None:                   # 과목명이 없거나 다르면 제목으로 찾기
            hits = [(i, r) for i, c in enumerate(data) for r in c.get("rows") or [] if nt(r.get("t")) == t]
            if not hits:
                best = max(((i, _overlap(t, nt(r.get("t")))) for i, c in enumerate(data) for r in c.get("rows") or []),
                           key=lambda x: x[1], default=(None, 0))
                hits = [(best[0], None)] if best[1] >= 0.7 else []
            ci = hits[0][0] if hits else None
        if ci is None:
            warn.append(f"「{title}」: 지금 시간표의 어느 과목인지 몰라서 뺐어요")
            continue
        rows = data[ci].get("rows") or []
        ri = next((i for i, r in enumerate(rows) if nt(r.get("t")) == t), None)
        if ri is None and len(t) >= 2:
            sc = sorted(((i, _overlap(t, nt(r.get("t")))) for i, r in enumerate(rows)), key=lambda x: -x[1])
            if sc and sc[0][1] >= 0.75 and (len(sc) == 1 or sc[0][1] - sc[1][1] >= 0.1):
                ri = sc[0][0]
        term = l.get("term")
        try:
            term = int(re.sub(r"\D", "", str(term))) if term not in (None, "") else None
        except ValueError:
            term = None
        k = (ci, ri if ri is not None else "new:" + t)
        a = agg.setdefault(k, {"ci": ci, "ri": ri, "title": rows[ri]["t"] if ri is not None else title,
                               "from": title, "profs": [], "term": term, "star": praw.strip().startswith("*")})
        for p in _profs(prof):
            if p not in a["profs"]:
                a["profs"].append(p)
        if a["term"] is None:
            a["term"] = term
    changes = []
    for a in agg.values():
        c = data[a["ci"]]
        r = c["rows"][a["ri"]] if a["ri"] is not None else None
        before = str((r.get("y") or {}).get(year, "")) if r else ""
        after = ("*" if a.get("star") and a["profs"] else "") + ("·".join(a["profs"]) or "—")   # * = 시간표 대신 기출 출제자 기준
        tm_b = (r.get("tm") or {}).get(year) if r else None
        if r is not None and (before == after or before.lstrip("*") == after) and (a["term"] is None or tm_b == a["term"]):
            continue
        changes.append({"course": c["name"], "title": a["title"], "from": a["from"], "ri": a["ri"], "new": r is None,
                        "before": before, "after": after, "term": a["term"]})
    changes.sort(key=lambda x: (names.index(x["course"]), x["new"], x["ri"] if x["ri"] is not None else 0))
    for i, x in enumerate(changes):
        x["id"] = i
        x["key"] = f"{year}|{x['course']}|{x['title']}"
    return year, changes, warn


def apply_past(data: list, year: str, changes: List[dict], accept: Optional[List[int]] = None) -> list:
    acc = set(accept) if accept is not None else {c["id"] for c in changes}
    out = json.loads(json.dumps(data))
    idx = {c["name"]: c for c in out}
    for x in changes:
        if x["id"] not in acc:
            continue
        c = idx[x["course"]]
        if x["new"]:
            r = {"t": x["title"], "d": "", "g": "", "y": {YEAR_KEY: "—"}, "term": 0, "tm": {}}
            c.setdefault("rows", []).append(r)
        else:
            r = c["rows"][x["ri"]]
        r.setdefault("y", {})[year] = x["after"]
        if x.get("term"):
            r.setdefault("tm", {})[year] = x["term"]
        c["years"] = sorted({str(y) for y in (c.get("years") or [])} | {year, YEAR_KEY}, reverse=True)
    return out


def set_prof(data: list, course: str, ri: int, year: str, value: str) -> list:
    """강좌별 교수 표에서 한 칸 고치기 (지난 연도만)"""
    out = json.loads(json.dumps(data))
    c = next(c for c in out if c["name"] == course)
    r = c["rows"][ri]
    v = prof_str(value)
    r.setdefault("y", {})[year] = v or "—"
    c["years"] = sorted({str(y) for y in (c.get("years") or [])} | {year, YEAR_KEY}, reverse=True)
    return out
