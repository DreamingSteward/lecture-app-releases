"""학년(프로필) 나누기. 학년마다 시간표·현황·고른 자료 기억·정리 폴더·드라이브·예약을 따로 가져요.

- config.json 의 "grades": [{"name": "본과 2학년", "dir": ""}, {"name": "본과 1학년", "dir": "학년/본과 1학년"}]
  "grade": 지금 고른 학년 이름. 학년 목록이 없으면 예전처럼 앱 폴더 하나만 써요.
- dir "" 은 원래 앱 폴더(처음부터 쓰던 학년). 그 학년의 설정은 config.json 에 그대로 있어요.
- 다른 학년은 <앱 폴더>/학년/<이름>/ 에 데이터 파일과 설정.json(그 학년 설정)을 따로 둬요.
- 표지·용지·글꼴·화면·휴대폰 연결·메뉴 막대 같은 앱 설정은 모든 학년이 같이 써요.
- 학년을 목록에서 빼도 폴더(기록)는 남겨 둬요. 같은 이름으로 다시 넣으면 그대로 돌아와요.
"""
from __future__ import annotations

import json
import os
import re
import threading
import time
from pathlib import Path
from typing import List, Optional, Tuple

APP = Path(__file__).resolve().parent.parent

# 학년마다 따로 가지는 설정
GRADE_KEYS = {"save_root", "manual_dir", "extra_dir", "drive_root", "drive_semester", "drive_sem_id", "drive_sem_label", "drive_course_map", "drive_course_map_root", "drive_manual_map", "drive_extras_map", "drive_extras", "board_include",
              "extras", "extras_label", "extras_old", "notion", "schedule", "setup_done", "tt_year", "tt_label",
              "recheck_past"}

GRADE_FILE = "설정.json"


def _read_json(p: Path, default):
    try:
        d = json.loads(p.read_text("utf-8-sig"))
        return d if isinstance(d, type(default)) else default
    except Exception:
        return default


def _read_strict(p: Path, missing_ok: bool = True) -> dict:
    """설정 파일 읽기: 잠깐 잠겨 있으면(백신·OneDrive·iCloud) 몇 번 다시 시도, 그래도 안 되면 오류
    (빈 설정을 돌려주면 그걸 그대로 저장해서 다른 학년 설정을 덮거나 날려 버림). 파일이 아예 없으면 {}"""
    err = None
    for i in range(5):
        if missing_ok and not p.exists():
            return {}
        try:
            d = json.loads(p.read_text("utf-8-sig"))
            if isinstance(d, dict):
                return d
            err = ValueError("형식 오류")
        except Exception as e:
            err = e
        time.sleep(0.15 * (i + 1))
    raise RuntimeError(f"설정 파일({p.name})을 읽지 못했어요 ({type(err).__name__ if err else '형식 오류'})")


def _write_json(p: Path, d):
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_name(f"{p.name}.{os.getpid()}.{threading.get_ident()}.tmp")
    tmp.write_text(json.dumps(d, ensure_ascii=False, indent=2), "utf-8")
    for i in range(6):                 # 윈도우: 백신·OneDrive가 잠깐 잡고 있으면 다시 시도
        try:
            os.replace(tmp, p)
            return
        except PermissionError:
            if i == 5:
                raise
            time.sleep(0.2 * (i + 1))


def raw_cfg() -> dict:
    return _read_strict(APP / "config.json", missing_ok=False)


def grades(cfg: Optional[dict] = None) -> List[dict]:
    cfg = raw_cfg() if cfg is None else cfg
    out = [g for g in (cfg.get("grades") or []) if isinstance(g, dict) and g.get("name")]
    return out


def current(cfg: Optional[dict] = None) -> Tuple[str, str]:
    """(학년 이름, 폴더) — 폴더 "" 는 원래 앱 폴더"""
    cfg = raw_cfg() if cfg is None else cfg
    gs = grades(cfg)
    if not gs:
        return "", ""
    name = cfg.get("grade") or gs[0]["name"]
    g = next((g for g in gs if g["name"] == name), gs[0])
    return g["name"], str(g.get("dir") or "")


def data_dir(cfg: Optional[dict] = None) -> Path:
    """지금 학년의 데이터 폴더 (시간표.json·현황.json·확인필요.json·매칭기억.json …)"""
    _, d = current(cfg)
    p = APP / d if d else APP
    p.mkdir(parents=True, exist_ok=True)
    tt = p / "시간표.json"          # 새 학년·새로 깐 앱: 빈 시간표로 시작 (없으면 화면이 못 열려요)
    if not tt.exists():
        try:
            tt.write_text("[]", "utf-8")
        except Exception:
            pass
    return p


def merge(raw: dict) -> dict:
    """config.json + 지금 학년 설정 → 앱이 쓰는 설정 하나로"""
    _, d = current(raw)
    if not d:
        return dict(raw)
    g = _read_strict(APP / d / GRADE_FILE)
    out = {k: v for k, v in raw.items() if k not in GRADE_KEYS}
    out.update({k: v for k, v in g.items() if k in GRADE_KEYS})
    return out


def split_write(cfg: dict, write_raw):
    """합친 설정을 저장: 학년 설정은 그 학년 설정.json 에, 나머지는 config.json 에. write_raw(dict) 가 config.json 을 씀"""
    raw = raw_cfg()
    gs = grades(raw)
    # 이 설정을 읽었던 학년에 저장 (그 사이 학년을 바꿨어도 다른 학년에 쓰지 않게)
    g = next((x for x in gs if x["name"] == cfg.get("grade")), None) if cfg.get("grade") else None
    d = str(g.get("dir") or "") if g else current(raw)[1]
    keep = {k: raw[k] for k in ("grades", "grade", "grades_hidden") if k in raw}   # 학년 목록·지금 학년은 디스크 값 그대로
    if not d:
        write_raw({**cfg, **keep})
        return
    new_raw = {k: v for k, v in raw.items() if k in GRADE_KEYS}           # 원래 학년(앱 폴더) 설정은 그대로
    new_raw.update({k: v for k, v in cfg.items() if k not in GRADE_KEYS})
    new_raw.update(keep)
    _write_json(APP / d / GRADE_FILE, {k: v for k, v in cfg.items() if k in GRADE_KEYS})
    write_raw(new_raw)


def safe_name(name: str) -> str:
    n = re.sub(r"[\\/:*?\"<>|\x00-\x1f]", "", str(name or "")).strip().strip(".")
    return n[:30]


NAME_MAX = 10      # 학기 이름: 띄어쓰기 포함 10자까지 (예: 본과 2학년 2학기) · 이름표가 넘치지 않게


def new_name(name: str):
    """새로 짓는 학기 이름 → (이름, 오류 메시지)"""
    n = re.sub(r"\s+", " ", safe_name(name))
    if not n:
        return "", "학기 이름을 적어 주세요."
    if len(n) > NAME_MAX:
        return "", f"학기 이름은 띄어쓰기 포함 {NAME_MAX}자까지예요 (예: 본과 2학년 2학기)."
    return n, ""


def new_grade_cfg(name: str) -> dict:
    return {"save_root": f"~/Desktop/매뉴얼 정리 ({name})", "drive_root": "", "drive_semester": "2학기",
            "board_include": ["강의자료", "자료실"], "extras": True, "extras_label": "", "extras_old": [],
            "notion": {"sources": {}}, "schedule": {}, "setup_done": False}
