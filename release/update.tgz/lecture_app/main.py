"""강의록앱 — LMS·드라이브 강의록을 받아 표지를 붙여 「매뉴얼 정리/과목/차수」에 모은다.

사용:
  강의록앱 받기 [--과목 생식성장발달II] [--차수 2] [--자동]
  강의록앱 확인            애매했던 자료를 어느 강의인지 골라 주기
  강의록앱 로그인정보      학번·비밀번호를 macOS 키체인에 저장/변경
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import hashlib
import re
import shutil
import subprocess
import sys
import inspect
import tempfile
import threading
import time
import unicodedata
import traceback
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional

from . import drive, render
from .lms import LMS, LoginNeeded, KEYCHAIN_SERVICE, course_map, RetryLater, ClosedOnLMS
from .matching import is_ref, Item, Memory, match, match_old, choose, LMS_SOURCES, base_name, safe_replace, save_auto, prefer_slides
from . import notion_sync
from .pptx_proc import process as pptx_process
from .timetable import Lecture, load, courses as tt_courses, norm_course
from . import grades as _grades

APP = Path(__file__).resolve().parent.parent
if os.name == "nt":
    # 윈도우: 창 없이 도는 앱(pythonw)에서 schtasks·taskkill·powershell 같은 명령을 부르면 검은 창이 잠깐씩 뜸 → 창 없이 실행
    _CREATE_NO_WINDOW, _DETACHED = 0x08000000, 0x00000008
    _popen_init = subprocess.Popen.__init__

    def _popen_no_window(self, *a, **k):
        f = k.get("creationflags", 0) or 0
        if not f & _DETACHED:
            k["creationflags"] = f | _CREATE_NO_WINDOW
        _popen_init(self, *a, **k)
    subprocess.Popen.__init__ = _popen_no_window

if sys.platform == "darwin":
    # 바탕 화면·문서가 iCloud에 동기화되고 「Mac 저장 공간 최적화」가 켜져 있으면, 오래된 파일은 내용이 iCloud에만 있고
    # (빈 껍데기), 백그라운드로 도는 앱이 읽으면 'Resource deadlock avoided'(11) 오류가 남.
    # → 이 앱이 읽을 때 iCloud에서 내려받도록 허용 (IOPOL_TYPE_VFS_MATERIALIZE_DATALESS_FILES = ON)
    try:
        import ctypes as _ct
        _ct.CDLL("/usr/lib/libSystem.B.dylib").setiopolicy_np(3, 0, 2)
    except Exception:
        pass

CFG_LOCK = threading.RLock()     # config.json 읽고-고치고-쓰기를 한 번에 하나씩 (화면 요청이 동시에 와도 설정이 안 날아가게)


def read_cfg() -> dict:
    """config.json 읽기. 잠깐 잠겨 있거나(백신·OneDrive) 쓰는 중이면 몇 번 다시 시도하고, 그래도 안 되면 오류
    (빈 설정을 돌려주면 그걸 그대로 저장해서 설정이 날아감)"""
    err = None
    for i in range(5):
        try:
            d = json.loads((APP / "config.json").read_text("utf-8-sig"))
            if isinstance(d, dict):
                return _grades.merge(d)          # 학년을 나눠 쓰면 지금 학년 설정을 합쳐서
        except Exception as e:
            err = e
        time.sleep(0.15 * (i + 1))
    raise RuntimeError(f"설정 파일(config.json)을 읽지 못했어요 ({type(err).__name__ if err else '형식 오류'})")


def _write_raw_cfg(cfg: dict):
    p = APP / "config.json"
    tmp = p.with_name(f"config.{os.getpid()}.{threading.get_ident()}.tmp")
    tmp.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), "utf-8")
    safe_replace(tmp, p)


def write_cfg(cfg: dict):
    """임시 파일에 쓰고 바꿔치기 (도중에 꺼져도 config.json 이 깨지지 않게). 학년 설정은 그 학년 폴더에"""
    _grades.split_write(cfg, _write_raw_cfg)
    CFG.clear()
    CFG.update(cfg)


CFG = read_cfg()
DATA = _grades.data_dir()          # 지금 학년의 시간표·현황·고른 자료 기억 (학년을 안 나누면 앱 폴더)
GRADE = _grades.current()[0]
def desktop_dir() -> Path:
    """실제 바탕 화면 폴더. 윈도우는 OneDrive 백업을 켜면 바탕 화면이 OneDrive 안으로 옮겨져서 ~/Desktop 이 안 보이는 폴더가 됨"""
    if os.name == "nt":
        try:
            import ctypes
            buf = ctypes.create_unicode_buffer(520)
            if ctypes.windll.shell32.SHGetFolderPathW(None, 0x0010, None, 0, buf) == 0 and buf.value:   # CSIDL_DESKTOPDIRECTORY
                return Path(buf.value)
        except Exception:
            pass
    return Path.home() / "Desktop"


def expand_root(s: str) -> Path:
    """'~/Desktop/…' 은 실제 바탕 화면 기준으로 (윈도우 OneDrive 바탕 화면 대응)"""
    t = (s or "~/Desktop/매뉴얼 정리").replace("\\", "/")
    m = re.match(r"^~/(?:Desktop|바탕 화면)(/.*)?$", t)
    if m:
        return desktop_dir() / (m.group(1) or "/").lstrip("/")
    return Path(s).expanduser()


SAVE_ROOT = expand_root(CFG.get("save_root") or "~/Desktop/매뉴얼 정리")
MANUAL_ROOT = SAVE_ROOT / CFG.get("manual_dir", "1. 매뉴얼")      # 강의록(매뉴얼) 합본
EXTRA_ROOT = SAVE_ROOT / CFG.get("extra_dir", "2. 추가자료")      # 필야(드라이브 추가자료)


def reload_roots():
    """설정에서 정리 폴더를 바꾸면 켜져 있는 화면도 바로 새 폴더를 보게"""
    global SAVE_ROOT, MANUAL_ROOT, EXTRA_ROOT
    SAVE_ROOT = expand_root(CFG.get("save_root") or "~/Desktop/매뉴얼 정리")
    MANUAL_ROOT = SAVE_ROOT / CFG.get("manual_dir", "1. 매뉴얼")
    EXTRA_ROOT = SAVE_ROOT / CFG.get("extra_dir", "2. 추가자료")


RECORD = "_다운로드기록.csv"
REC_COLS = ["합본파일명", "출처", "원본파일명", "업로드일시", "서명", "처리일시", "상태", "비고", "나눔"]   # 나눔: 폴더에 따로 만든 파일들 (JSON)


# ---------------------------------------------------------------- 공통
class Log:
    """화면 출력 + 진행 중에도 파일에 바로 적어 둠 (도중에 멈춰도 어디까지 했는지 남도록)"""
    current = None

    def __init__(self):
        self.lines: List[str] = []
        self.live: Optional[Path] = None
        Log.current = self

    def start_file(self, path: Path):
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text("", "utf-8")
            self.live = path
        except Exception:
            self.live = None

    _lock = threading.Lock()

    def __call__(self, msg: str):
        with self._lock:          # 강의록·필야가 동시에 적어도 줄이 섞이지 않게
            self.lines.append(msg)
            print(msg, flush=True)
            if self.live:
                try:
                    with open(self.live, "a", encoding="utf-8") as f:
                        f.write(msg + "\n")
                except Exception:
                    pass


class Events:
    """앱 화면(받기 진행판)용 진행 기록: 한 줄에 사건 하나(JSON). 운영체제와 상관없이 같은 형식."""
    current = None
    PATH = APP / "logs" / "진행.jsonl"
    _lock = threading.Lock()

    def __init__(self):
        self.key = None
        self.t0 = time.time()
        Events.current = self
        try:
            self.PATH.parent.mkdir(parents=True, exist_ok=True)
            self.PATH.write_text("", "utf-8")
            self.ok = True
        except Exception:
            self.ok = False

    def __call__(self, kind: str, **kw):
        if not self.ok:
            return
        kw = {"t": round(time.time() - self.t0, 1), "type": kind, **kw}
        if self.key and "key" not in kw and kind in ("step", "dl"):
            kw["key"] = self.key
        try:
            with self._lock, open(self.PATH, "a", encoding="utf-8") as f:
                f.write(json.dumps(kw, ensure_ascii=False) + "\n")
        except Exception:
            pass


def _lec(L) -> dict:
    return {"key": L.key, "course": L.course, "term": L.term, "mmdd": L.mmdd, "start": L.start, "hours": L.hours,
            "title": L.title, "profs": L.profs, "name": out_name(L)}


NEWS: Dict[str, list] = {"lec": [], "x": []}      # 이번 받기에서 새로·다시 올라온 강의록·추가자료 (알림용)


def news_text(items) -> str:
    """알림 내용: 「생식성장발달II · 10/29 1교시 CP 소아 복통」 3개까지 + 외 n개"""
    seen, rows = set(), []
    for L, tag in items:
        k = (L.key, tag)
        if k in seen:
            continue
        seen.add(k)
        rows.append(f"{L.course} · {L.month}/{L.day} {L.start}교시 {L.title}" + (f" ({tag})" if tag else ""))
    return "\n".join(rows[:3]) + (f"\n외 {len(rows) - 3}개" if len(rows) > 3 else "")


def notify(title: str, msg: str, kind: str = ""):
    """시스템 알림 (「강의록앱」 이름·로고 · notifier.py). 실패해도 조용히 넘어감. kind: 설정 › 알림의 종류"""
    try:
        from . import notifier
        notifier.notify(title, msg, kind=kind)
    except Exception:
        pass


def safe(s: str) -> str:
    return re.sub(r'[\\/:*?"<>|]', "·", s).strip().rstrip(".")


# ---------------------------------------------------------------- 파일 이름 방식 (설정 › 강의록 파일 › 파일 이름)
NAME_PRESETS = [        # (id, 이름, 모양)
    ("basic", "기본", "{날짜}-{교시}. {제목}_{교수}"),
    ("drive", "드라이브와 같게", "{날짜}({교시들})_{제목}_{교수이름}"),
    ("num", "숫자만", "{날짜}-{교시}"),
    ("numd", "숫자만 (드라이브식)", "{날짜}({교시들})"),
    ("course", "과목 먼저", "[{과목}] {날짜}-{교시}. {제목}"),
    ("easy", "읽기 쉽게", "{월}.{일} {교시}교시 {제목} ({교수이름})"),
    ("title", "제목 먼저", "{제목}_{날짜}-{교시}"),
]
NAME_DEFAULT = NAME_PRESETS[0][2]
NAME_TOKENS = ("날짜", "월", "일", "요일", "교시", "교시들", "제목", "교수", "교수이름", "과목", "차수", "원본")

# {원본}: 강의마다 강의록 원본 파일 이름(확장자 뺌)을 기억해 두고 파일 이름에만 붙임
#  · 앱은 강의를 여전히 시간표(L.key)로 찾음 → 이 표만 있으면 파일 이름이 늘 같게 나옴
#  · 처음 만들 때 · 다시 올라와 원본 이름이 바뀔 때 고침 (강의록이 여러 개라 폴더로 나뉘면 안 붙임)
ORIG_NAMES: Dict[str, str] = {}
_ORIG_MT = [None]                         # 마지막으로 읽은 파일 시각 (다른 프로세스 — 받기 — 가 고치면 다시 읽음)
_ORIG_TL = threading.local()               # 강의록을 만드는 스레드가 정했지만 아직 저장 안 한 것 (다른 스레드 — 추가자료 — 에는 안 보임)


def _pend() -> Dict[str, str]:
    p = getattr(_ORIG_TL, "p", None)
    if p is None:
        p = _ORIG_TL.p = {}
    return p
_ORIG_TMP: List[Optional[Dict[str, str]]] = [None]     # 이름 바꾸기 미리보기용 임시 표 (실제 표는 건드리지 않음)
_ORIG_LOCK = threading.RLock()


def _orig_path() -> Path:
    return DATA / "원본이름.json"


def _orig_disk() -> Dict[str, str]:
    try:
        v = json.loads(_orig_path().read_text(encoding="utf-8"))
        if isinstance(v, dict):
            return {str(k): str(x) for k, x in v.items() if x}
    except Exception:
        pass
    return {}


def orig_names() -> Dict[str, str]:
    """{원본} 표 (읽기용) · 파일이 바뀌었으면 다시 읽고 아직 저장 안 한 것을 얹음"""
    if _ORIG_TMP[0] is not None:
        return _ORIG_TMP[0]
    with _ORIG_LOCK:
        try:
            mt = _orig_path().stat().st_mtime_ns
        except OSError:
            mt = 0
        if mt != _ORIG_MT[0]:
            _ORIG_MT[0] = mt
            ORIG_NAMES.clear()
            ORIG_NAMES.update(_orig_disk())
        p = _pend()
        if not p:
            return ORIG_NAMES
        v = dict(ORIG_NAMES)
        for k, x in p.items():
            if x:
                v[k] = x
            else:
                v.pop(k, None)
        return v


def set_orig(key: str, stem: Optional[str]):
    """원본 이름 정하기 (저장은 save_orig_names) · stem 이 비면 지움"""
    _pend()[key] = stem or ""


def drop_orig_pending(key: str, prev: Optional[str]):
    """정했던 것 취소 (강의록을 못 만들었을 때) → 원래 값으로"""
    _pend().pop(key, None)


def save_orig_names():
    """디스크의 표를 다시 읽어 이 프로세스에서 정한 것만 얹어 저장 (다른 프로세스가 넣은 것을 덮어쓰지 않게)"""
    p = _pend()
    if not p:
        return
    with _ORIG_LOCK:
        try:
            cur = _orig_disk()
            for k, v in p.items():
                if v:
                    cur[k] = v
                else:
                    cur.pop(k, None)
            tmp = _orig_path().with_suffix(".tmp")
            tmp.write_text(json.dumps(cur, ensure_ascii=False, indent=1), encoding="utf-8")
            safe_replace(tmp, _orig_path())
            p.clear()
            _ORIG_MT[0] = None
        except Exception:
            pass


def orig_stem(filename: str) -> str:
    st = Path(filename or "").stem.strip()
    st = re.sub(r"\s+", " ", st)
    return st if len(st) <= 60 else st[:59].rstrip() + "…"


def uses_orig(fmt: Optional[str] = None) -> bool:
    return "{원본}" in (fmt or name_fmt())
_TOK_RE = re.compile(r"\{(" + "|".join(NAME_TOKENS) + r")\}")


def name_fmt(cfg: Optional[dict] = None) -> str:
    v = str((cfg if cfg is not None else CFG).get("name_fmt") or "").strip()
    return v or NAME_DEFAULT


def name_fmt_error(fmt: str) -> str:
    """저장하면 안 되는 모양이면 이유 (같은 이름이 생기지 않게 날짜·교시는 꼭)"""
    fmt = (fmt or "").strip()
    if not fmt:
        return "모양을 적어 주세요."
    if len(fmt) > 120:
        return "너무 길어요 (120자까지)."
    left = _TOK_RE.sub("", fmt)
    bad = re.findall(r"\{[^}]*\}", left)
    if bad:
        return f"모르는 칸이에요: {bad[0]} (쓸 수 있는 칸: " + " ".join("{" + t + "}" for t in NAME_TOKENS) + ")"
    if re.search(r'[\\/:*?"<>|]', left):
        return '파일 이름에 쓸 수 없는 글자가 있어요 (\\ / : * ? " < > |).'
    toks = set(_TOK_RE.findall(fmt))
    if not ({"날짜"} <= toks or {"월", "일"} <= toks):
        return "날짜가 빠지면 같은 이름이 생길 수 있어요 → {날짜} 또는 {월}·{일}을 넣어 주세요."
    if not toks & {"교시", "교시들"}:
        return "교시가 빠지면 같은 날 강의끼리 이름이 겹쳐요 → {교시} 또는 {교시들}을 넣어 주세요."
    return ""


def name_values(L: Lecture) -> dict:
    from .timetable import YEAR_KEY, year_num, cal_year
    y = cal_year(L.month)
    try:
        wd = "월화수목금토일"[datetime(y, L.month, L.day).weekday()]
    except ValueError:
        wd = ""
    return {"날짜": L.mmdd, "월": f"{L.month:02d}", "일": f"{L.day:02d}", "요일": wd, "교시": (L.extra or {}).get("kg") or str(L.start),     # 같은 칸에 같은 제목 반 교시 강의가 둘일 때만 「2A」·「2B」 (그 밖엔 예전처럼 숫자)
            "교시들": ",".join(str(p) for p in L.periods()), "제목": L.title,
            "교수": "·".join(f"{p}T" for p in L.profs), "교수이름": "·".join(L.profs),
            "과목": L.course, "차수": f"{L.term}차" if L.term else "",
            "원본": orig_names().get(L.key or "", "") or L.title}     # 아직 원본을 모르면(받기 전·자료 여러 개) 시간표 제목


def _cal(month: int) -> int:
    """이번 학기 수업의 실제 달력 연도 (학기 이름표 기준)"""
    from .timetable import cal_year
    return cal_year(month)


def name_base(L: Lecture, fmt: Optional[str] = None, part: Optional[int] = None) -> str:
    """확장자 없는 이름 (표지 제목 줄에도 씀) · 빈 칸(교수 없음 등)은 앞의 구분 글자와 같이 빠짐
    part: 강의록이 여러 개라 폴더에 따로 만들 때의 번호 → 교시 뒤에 (1), (2) (예: 1030-1(1). 제목)"""
    fmt = fmt or name_fmt()
    if part:
        fmt = re.sub(r"(\{교시들?\}(?:교시|\))?)", lambda m: m.group(1) + f"({part})", fmt, count=1)
    vals = name_values(L)
    out = re.sub(r"[_\-\s·,]*\{(" + "|".join(NAME_TOKENS) + r")\}",
                 lambda m: (m.group(0)[:-len(m.group(1)) - 2] + vals[m.group(1)]) if vals[m.group(1)] else "", fmt)
    out = re.sub(r"\(\s*\)|\[\s*\]", "", out)                 # 비게 된 괄호
    out = re.sub(r"\s{2,}", " ", out).strip(" _-·,")
    out = safe(out) or safe(f"{L.mmdd}-{L.start}")
    if len(out.encode("utf-8")) > 200:          # 긴 제목을 합친 강의: 파일 이름 한도(255바이트)에 _참고자료·_시간표변경 꼬리까지 들어가게 줄임
        while len(out.encode("utf-8")) > 196:
            out = out[:-1]
        out = out.rstrip(" _-·,.") + "…"
    return out


def out_name(L: Lecture, fmt: Optional[str] = None) -> str:
    return name_base(L, fmt) + ".pdf"


# 저장 위치 바꾸기: 종류(lec 강의록 · x 추가자료)마다 과목별로 다른 폴더 (설정 custom_dirs = {"lec": {과목: 경로}, "x": {…}})
#  · 그 폴더가 「정리 폴더/1. 매뉴얼/<과목>」(또는 2. 추가자료/<과목>) 자리를 대신함 → 안의 차수·학번 폴더 구조는 같음
#  · 휴대폰·클라우드에는 원래 자리 경로(가상 경로)로 보여 줌 (rel_of / path_of_rel)
CUSTOM_KINDS = ("lec", "x")


def custom_dir(kind: str, course: str) -> Optional[Path]:
    v = ((CFG.get("custom_dirs") or {}).get(kind) or {}).get(course)
    if not v or not str(v).strip():
        return None
    try:
        return Path(os.path.expanduser(str(v).strip()))
    except Exception:
        return None


def course_base(kind: str, course: str, course_folder: Optional[str] = None) -> Path:
    """그 과목·종류 파일이 들어가는 맨 위 폴더 (차수·학번 폴더 바로 위)"""
    from .timetable import folder_course
    c = custom_dir(kind, course)
    if c:
        return c
    return (MANUAL_ROOT if kind == "lec" else EXTRA_ROOT) / (course_folder or folder_course(course))


def custom_bases() -> List[tuple]:
    """[(실제 폴더, 정리 폴더 안의 원래 자리 rel)] — 저장 위치를 바꾼 과목들"""
    from .timetable import folder_course
    out = []
    for kind in CUSTOM_KINDS:
        for course, v in ((CFG.get("custom_dirs") or {}).get(kind) or {}).items():
            c = custom_dir(kind, course)
            if not c:
                continue
            try:
                vrel = (MANUAL_ROOT if kind == "lec" else EXTRA_ROOT).resolve().relative_to(SAVE_ROOT.resolve()) / folder_course(course)
            except Exception:
                continue
            out.append((c, vrel))
    return out


def rel_of(p: Path) -> str:
    """파일 → 정리 폴더 기준 경로 (저장 위치를 바꾼 과목이면 원래 자리 경로) · 못 찾으면 ''"""
    try:
        rp = p.resolve()
    except Exception:
        return ""
    for base, vrel in custom_bases():
        try:
            return str(vrel / rp.relative_to(base.resolve()))
        except Exception:
            continue
    try:
        return str(rp.relative_to(SAVE_ROOT.resolve()))
    except Exception:
        return ""


def path_of_rel(rel: str) -> Optional[Path]:
    """rel_of 의 반대 · 정리 폴더나 바꾼 저장 위치 밖이면 None (휴대폰에서 아무 파일이나 열지 못하게)"""
    from pathlib import PurePosixPath
    try:
        parts = PurePosixPath(str(rel).replace("\\", "/")).parts
    except Exception:
        return None
    if not parts or ".." in parts:
        return None
    for base, vrel in custom_bases():
        n = len(vrel.parts)
        if tuple(parts[:n]) == tuple(vrel.parts):
            try:
                p = (base / Path(*parts[n:])).resolve() if parts[n:] else base.resolve()
                b = base.resolve()
            except Exception:
                return None
            return p if (p == b or b in p.parents) else None
    try:
        p = (SAVE_ROOT / Path(*parts)).resolve()
        root = SAVE_ROOT.resolve()
    except Exception:
        return None
    return p if (p == root or root in p.parents) else None


def out_dir(L: Lecture) -> Path:
    d = course_base("lec", L.course, L.course_folder)
    return d / L.term_folder if L.term_folder else d


def xfolder(label: str = "") -> str:
    """추가자료 학번 폴더 이름: 드라이브에 정해 둔 이름 그대로 (숫자만이면 '20학번') · 올해 = 설정의 우리 학번"""
    lab = str(label or CFG.get("extras_label") or "").strip()
    if not lab:
        return "올해"
    return f"{lab}학번" if lab.isdigit() else (safe(lab) or "올해")


def extra_dir(L: Lecture, label: str = "") -> Path:
    """추가자료: 2. 추가자료/<과목>/<차수>/<학번>/"""
    d = course_base("x", L.course, L.course_folder)
    d = d / L.term_folder if L.term_folder else d
    return d / xfolder(label)


def course_started(course: str, lectures) -> bool:
    """시간표상 이 과목의 첫 강의 날이 오늘이거나 지났는지 (학기가 해를 넘기면 1·2월은 다음 해로 봄)."""
    now = datetime.now()
    for L in lectures:
        if L.course != course:
            continue
        y = _cal(L.month)
        try:
            if datetime(y, L.month, L.day) <= now:
                return True
        except ValueError:
            continue
    return False


def extra_name(L: Lecture, label: str = "", fmt: Optional[str] = None) -> str:
    """추가자료 파일 이름 '…_추가자료.pdf' (학번은 폴더로 나눔 · extra_dir)"""
    return out_name(L, fmt)[:-4] + "_추가자료.pdf"


def old_extra_name(L: Lecture, label: str = "", fmt: Optional[str] = None) -> str:
    """예전(학번 폴더 전) 이름: 올해 '…_추가자료.pdf' / 선배 '…_추가자료(21학번).pdf'"""
    return out_name(L, fmt)[:-4] + (f"_추가자료({label}학번).pdf" if label else "_추가자료.pdf")


def _rename_extras(L: Lecture, old_name: str, new_name: str, log=lambda *a: None) -> int:
    """강의록 이름이 바뀌면(원본 이름 바뀜) 학번 폴더마다 추가자료 파일·받은 기록·클라우드 복사본 이름도 바꿈"""
    if old_name == new_name:
        return 0
    xo, xn = old_name[:-4] + "_추가자료.pdf", new_name[:-4] + "_추가자료.pdf"
    try:
        from . import cloud as _cloud
        cdirs = _cloud.copy_dirs()
    except Exception:
        cdirs = {}
    n = 0
    for lab in [""] + [str(s_.get("label", "")).strip() for s_ in old_sources()]:
        xd = extra_dir(L, lab)
        if not (xd / xo).is_file():
            continue
        if (xd / xn).exists():                      # 새 이름 파일이 이미 있음(동시에 만들어짐) → 옛 이름은 _이전버전으로, 기록도 정리
            try:
                prev = xd / "_이전버전"
                prev.mkdir(exist_ok=True)
                shutil.move(str(xd / xo), str(_backup_name(prev, xo, f"{datetime.now():%m%d}")))
                with REC_LOCK:
                    r_ = read_records(xd)
                    if r_.pop(xo, None) is not None:
                        write_records(xd, r_)
            except Exception:
                pass
            continue
        old_rel = rel_of(xd / xo)
        try:
            os.rename(xd / xo, xd / xn)
            n += 1
        except OSError as e:
            log(f"추가자료 이름 바꾸기 실패: {xo} ({err(e)})")
            continue
        with REC_LOCK:
            try:
                r = read_records(xd)
                if xo in r and xn not in r:
                    v = r.pop(xo)
                    v["합본파일명"] = xn
                    r[xn] = v
                    write_records(xd, r)
            except Exception:
                pass
        new_rel = rel_of(xd / xn)
        for cd in cdirs.values():
            try:
                if old_rel and new_rel and (cd / old_rel).is_file() and not (cd / new_rel).exists():
                    os.replace(cd / old_rel, cd / new_rel)
            except OSError:
                pass
    return n


def tidy_extras(old_lectures, new_lectures, remap: Dict[str, str]) -> int:
    """시간표를 고쳐 강의 이름·key가 바뀌면: {원본} 기억을 새 key로 옮기고, 학번 폴더마다 추가자료 파일·기록을 새 이름으로
    (짝을 못 찾은 강의의 추가자료는 _이전버전으로)"""
    new_by = {L.key: L for L in new_lectures}
    labels = [""] + [str(s_.get("label", "")).strip() for s_ in old_sources()]
    found = []                                   # 옛 이름은 옛 {원본} 기억으로 먼저 찾아 둠
    for L in old_lectures:
        N = new_by.get(remap.get(L.key, L.key))
        for lab in labels:
            xd, xo = extra_dir(L, lab), extra_name(L, lab)
            if (xd / xo).is_file():
                found.append((xd, xo, N, lab))
    on = _orig_disk()
    ch = False
    for ok_, nk_ in remap.items():
        if ok_ != nk_ and on.get(ok_) and not on.get(nk_):
            set_orig(nk_, on[ok_])
            set_orig(ok_, "")
            ch = True
    if ch:
        save_orig_names()
    n = 0
    for xd, xo, N, lab in found:
        if not (xd / xo).is_file():
            continue
        if N is not None:
            nd, xn = extra_dir(N, lab), extra_name(N, lab)
            if (nd, xn) == (xd, xo):
                continue
            if not (nd / xn).exists():
                nd.mkdir(parents=True, exist_ok=True)
                os.replace(xd / xo, nd / xn)
                with REC_LOCK:
                    ro = read_records(xd)
                    rn = read_records(nd) if nd != xd else ro
                    r_ = ro.pop(xo, None)
                    if r_ is not None:
                        r_["합본파일명"] = xn
                        rn[xn] = r_
                    write_records(xd, ro)
                    if nd != xd:
                        write_records(nd, rn)
                n += 1
                continue
        prev = xd / "_이전버전"                   # 짝이 없거나 새 이름이 이미 있음 → 옛것은 _이전버전으로
        prev.mkdir(exist_ok=True)
        shutil.move(str(xd / xo), str(_backup_name(prev, xo, f"{datetime.now():%m%d}")))
        with REC_LOCK:
            r_ = read_records(xd)
            if r_.pop(xo, None) is not None:
                write_records(xd, r_)
        n += 1
    return n


def migrate_extra_folders(log=lambda *a: None) -> int:
    """예전 배치(차수 폴더에 '…_추가자료(21학번).pdf')를 학번 폴더로 옮김 (받은 기록·클라우드 복사본도). 옮긴 개수"""
    try:
        lects = load(DATA / "시간표.json")
    except Exception:
        return 0
    labels = [""] + [str(s.get("label", "")).strip() for s in old_sources()]
    try:
        from . import cloud as _cloud
        cdirs = _cloud.copy_dirs()
    except Exception:
        cdirs = {}
    moved, seen = 0, set()
    recs_cache: Dict[Path, dict] = {}
    dirty = set()

    def recs(d):
        if d not in recs_cache:
            try:
                recs_cache[d] = read_records(d)
            except Exception:
                recs_cache[d] = None
        return recs_cache[d]
    for L in lects:
        base = course_base("x", L.course, L.course_folder)
        od = base / L.term_folder if L.term_folder else base
        for lab in labels:
            on, nd, nn = old_extra_name(L, lab), extra_dir(L, lab), extra_name(L, lab)
            if (od, on) in seen or not (od / on).is_file():
                continue
            seen.add((od, on))
            if (nd / nn).exists():
                continue
            try:
                old_rel = rel_of(od / on)
                nd.mkdir(parents=True, exist_ok=True)
                os.replace(od / on, nd / nn)
                moved += 1
            except OSError as e:
                log(f"추가자료 학번 폴더로 옮기기 실패: {on} ({err(e)})")
                continue
            ro, rn = recs(od), recs(nd)
            if ro is not None and rn is not None and on in ro:
                r = ro.pop(on)
                r["합본파일명"] = nn
                rn[nn] = r
                dirty |= {od, nd}
            new_rel = rel_of(nd / nn)
            for cd in cdirs.values():             # 클라우드 복사본도 같은 자리로 (다시 올리지 않게)
                try:
                    if old_rel and new_rel and (cd / old_rel).is_file() and not (cd / new_rel).exists():
                        (cd / new_rel).parent.mkdir(parents=True, exist_ok=True)
                        os.replace(cd / old_rel, cd / new_rel)
                except OSError:
                    pass
    for d in dirty:
        if recs_cache.get(d) is not None:
            write_records(d, recs_cache[d])
    if moved:
        log(f"추가자료 {moved}개를 학번 폴더로 옮겼어요")
    return moved


def _same_dir(a: Path, b: Path) -> bool:
    """표기(대소문자·한글 자모 방식·별칭)가 달라도 같은 폴더인지"""
    try:
        if a.exists() and b.exists():
            return os.path.samefile(a, b)
    except OSError:
        pass
    try:
        return a.resolve() == b.resolve()
    except Exception:
        return False


def _within(a: Path, b: Path) -> bool:
    """a 가 b 와 같거나 b 안에 있는지 (있는 폴더는 실제 위치로 비교)"""
    try:
        ra = a.resolve()
    except Exception:
        return False
    cur = ra
    while True:
        if _same_dir(cur, b):
            return True
        if cur.parent == cur:
            return False
        cur = cur.parent


def custom_dir_problem(kind: str, course: str, newp: Path, courses: List[str]) -> str:
    """과목 저장 위치로 고른 폴더가 다른 것과 겹치면 그 이유 ('' = 괜찮음)
    · 정리 폴더·바탕화면 같은 위쪽 폴더, 1. 매뉴얼·2. 추가자료 안, 다른 과목·종류의 폴더와 같거나 안팎이면 안 됨"""
    from .timetable import folder_course
    kn = lambda k: "강의록" if k == "lec" else "추가자료"
    home = Path.home()
    if _within(home, newp) or len(newp.resolve().parts) <= 1:
        return "너무 위쪽 폴더예요 (홈·드라이브 맨 위). 과목만 담을 폴더를 새로 만들어 골라 주세요."
    if _within(SAVE_ROOT, newp):
        return "정리 폴더 자체나 그 위쪽 폴더는 고를 수 없어요. 과목만 담을 폴더를 골라 주세요."
    if _within(newp, APP) or _within(APP, newp):
        return "앱 폴더(강의록앱) 안이나 그 위쪽은 고를 수 없어요 (앱을 업데이트·삭제할 때 같이 지워져요). 다른 폴더를 골라 주세요."
    for root in (MANUAL_ROOT, EXTRA_ROOT):
        if _within(newp, root):
            return f"「{root.name}」 폴더 안은 고를 수 없어요 (다른 과목 폴더와 섞여요). 다른 곳의 폴더를 골라 주세요."
    try:
        from . import cloud as _c
        for d in _c.copy_dirs().values():
            if _within(newp, Path(d)) or _within(Path(d), newp):
                return "클라우드 복사 폴더와 겹쳐요 (복사본을 또 복사하게 돼요). 다른 폴더를 골라 주세요."
    except Exception:
        pass
    for c in courses:
        for k in CUSTOM_KINDS:
            if (k, c) == (kind, course):
                continue
            base = course_base(k, c)
            if _within(newp, base) or _within(base, newp):
                return f"「{c}」 {kn(k)} 폴더와 겹쳐요. 다른 폴더를 골라 주세요."
    return ""


def _app_items(kind: str, course: str, src: Path) -> set:
    """옮길 것: 앱이 만든 것만 (차수·학번 폴더, 받은 기록, _이전버전, 기록에 있는 강의록과 그 폴더들)"""
    names = {RECORD, "_이전버전"}
    try:
        lects = [L for L in load(DATA / "시간표.json") if L.course == course]
    except Exception:
        lects = []
    for L in lects:
        if L.term_folder:
            names.add(L.term_folder)
    if kind == "x":
        names |= {xfolder(l) for l in [""] + [str(s_.get("label", "")).strip() for s_ in old_sources()]}
    try:
        for n in read_records(src):
            names |= {n, split_folder(src / n).name, n[:-4] + "_원본", n[:-4] + "_참고자료"}
    except Exception:
        pass
    return names


def move_course_dir(kind: str, course: str, new: Optional[str]) -> dict:
    """과목 저장 위치를 바꿀 때 지금 폴더 안의 것들(앱이 만든 것만)을 새 폴더로 옮김
    · 같은 이름이 있으면 그건 두고 알려 줌 · 도중에 실패하면 옮긴 것을 되돌림"""
    from .timetable import folder_course
    src = course_base(kind, course)
    dst = Path(os.path.expanduser(new)) if new else (MANUAL_ROOT if kind == "lec" else EXTRA_ROOT) / folder_course(course)
    if _same_dir(src, dst):
        return {"moved": 0, "skipped": []}
    if _within(dst, src) or _within(src, dst):
        return {"moved": 0, "skipped": [], "err": "지금 폴더와 새 폴더가 서로 안에 들어 있어요. 다른 폴더를 골라 주세요."}
    if not src.is_dir():
        return {"moved": 0, "skipped": []}
    top = _app_items(kind, course, src)
    dst.mkdir(parents=True, exist_ok=True)
    done: List[tuple] = []          # (원래, 옮긴 곳) — 실패하면 거꾸로 되돌림
    rec_merge: List[tuple] = []     # 받은 기록 합치기는 파일을 다 옮긴 뒤에
    skipped: List[str] = []

    def merge(a: Path, b: Path, first: bool):
        for x in sorted(a.iterdir(), key=lambda p: p.name):
            if first and x.name not in top and not x.name.startswith("."):
                continue                         # 사용자가 넣어 둔 다른 파일·폴더는 그대로
            t = b / x.name
            if t.exists() and _same_dir(x, t):
                continue
            if x.name == RECORD and t.exists():
                rec_merge.append((a, b))
                continue
            if not t.exists():
                shutil.move(str(x), str(t))
                done.append((x, t))
            elif x.is_dir() and t.is_dir():
                merge(x, t, False)
            else:
                skipped.append(str(x.relative_to(src)))
    try:
        merge(src, dst, True)
    except Exception as e:
        back = 0
        for x, t in reversed(done):
            try:
                x.parent.mkdir(parents=True, exist_ok=True)
                shutil.move(str(t), str(x))
                back += 1
            except Exception:
                pass
        left = len(done) - back
        for d_ in sorted([p for p in dst.rglob("*") if p.is_dir()] + [dst], key=lambda p: -len(p.parts)):
            try:
                d_.rmdir()                       # 되돌리고 남은 빈 폴더 정리 (빈 것만)
            except OSError:
                pass
        return {"moved": 0, "skipped": [], "err": f"옮기다가 멈췄어요 ({err(e)}). 옮긴 것은 원래 자리로 되돌렸어요"
                + (f" · {left}개는 못 되돌려 새 폴더에 있어요: {dst}" if left else "") + "."}
    for a, b in rec_merge:
        try:
            with REC_LOCK:
                ra, rb = read_records(a), read_records(b)
                for k, v in ra.items():
                    rb.setdefault(k, v)
                write_records(b, rb)
                if not _same_dir(a, b):
                    (a / RECORD).unlink()
        except Exception:
            skipped.append(str((a / RECORD).relative_to(src)))
    for d in sorted({x.parent for x, _ in done} | {src}, key=lambda p: -len(p.parts)):   # 빈 폴더 정리 (빈 것만)
        try:
            if d == src or src in d.parents:
                d.rmdir()
        except OSError:
            pass
    nf = 0                           # 옮긴 강의록·추가자료 파일 수 (폴더째 옮긴 것은 안의 PDF를 셈)
    for _, t in done:
        try:
            nf += sum(1 for _ in t.rglob("*.pdf")) if t.is_dir() else int(t.suffix.lower() == ".pdf")
        except OSError:
            pass
    return {"moved": nf, "skipped": skipped}


_OLD_XNAME = re.compile(r"_필야(\(\d+학번\))?\.pdf$")


def migrate_extra_names():
    """예전 추가자료 파일 이름 '…_필야.pdf' → '…_추가자료.pdf' (받은 기록도 같이). 한 번 바뀌면 다시 할 일 없음."""
    if not EXTRA_ROOT.exists():
        return
    try:
        dirs = [EXTRA_ROOT] + [p for p in EXTRA_ROOT.rglob("*") if p.is_dir()
                               and not any(x.startswith(("_", ".")) for x in p.relative_to(EXTRA_ROOT).parts)]
    except OSError:
        return
    for d in dirs:
        try:
            olds = [f for f in d.iterdir() if f.is_file() and _OLD_XNAME.search(unicodedata.normalize("NFC", f.name))]
            if not olds:
                continue
            recs = read_records(d) if (d / RECORD).exists() else {}
            changed = False
            for f in olds:
                nm = unicodedata.normalize("NFC", f.name)
                new = _OLD_XNAME.sub(lambda m: "_추가자료" + (m.group(1) or "") + ".pdf", nm)
                if (d / new).exists():                  # 새 이름이 이미 있으면 예전 것은 _이전버전 으로
                    prev = d / "_이전버전"
                    prev.mkdir(exist_ok=True)
                    os.replace(f, _backup_name(prev, nm, "예전이름"))
                    if recs.pop(nm, None) is not None or recs.pop(f.name, None) is not None:
                        changed = True
                    continue
                os.replace(f, d / new)
                r = recs.pop(nm, None) or recs.pop(f.name, None)
                if r is not None:
                    r["합본파일명"] = new
                    recs[new] = r
                    changed = True
            if changed:
                write_records(d, recs)
        except Exception as e:
            sys.stderr.write(f"추가자료 이름 바꾸기 실패 ({d}): {e}\n")


def old_sources() -> List[dict]:
    """설정의 선배 필야 드라이브 목록 (label·folder 가 있는 것만)"""
    return [s for s in CFG.get("extras_old") or [] if str(s.get("label", "")).strip() and (s.get("folder") or s.get("local"))]


def local_roots(label: str) -> List[Path]:
    """내 폴더 선배 자료: 그 이름의 내 폴더 + 과목마다 Finder로 직접 고른 폴더들 (열기·클라우드 복사가 이 안의 파일만)"""
    out = []
    for s_ in old_sources():
        if str(s_.get("label", "")).strip() != label or not s_.get("local") or s_.get("folder"):
            continue
        out.append(Path(os.path.expanduser(str(s_["local"]))))
        for v in (s_.get("map") or {}).values():
            if isinstance(v, list):
                out += [Path(os.path.expanduser(str(x))) for x in v if isinstance(x, str) and os.path.isabs(os.path.expanduser(x))]
    return out


def migrate_layout():
    """예전 배치(매뉴얼 정리/<과목>/…)를 새 배치(매뉴얼 정리/1. 매뉴얼/<과목>/…)로 옮긴다. 한 번만 일어남."""
    if not SAVE_ROOT.exists():
        return
    try:
        names = {L.course_folder for L in load(DATA / "시간표.json")}
    except Exception:
        names = set()
    if MANUAL_ROOT.exists():           # 이미 새 배치 → 다시 옮기지 않음 (정리 폴더를 바꿨을 때 사용자 폴더를 끌어오지 않게)
        return _migrate_tail()
    customs = [b for b, _ in custom_bases()]
    for d in list(SAVE_ROOT.iterdir()):
        if not d.is_dir() or d in (MANUAL_ROOT, EXTRA_ROOT) or d.name.startswith(("_", ".")) or d.suffix == ".app":
            continue
        if any(_within(c, d) for c in customs):   # 과목별로 정한 폴더(이거나 그걸 품은 폴더)는 건드리지 않음
            continue
        # 예전 배치의 과목 폴더만: 시간표 과목 이름이거나, 바로 안(또는 차수 폴더 안)에 받은 기록이 있는 폴더
        if d.name in names or (d / RECORD).exists() or any((x / RECORD).exists() for x in d.iterdir() if x.is_dir()):
            MANUAL_ROOT.mkdir(parents=True, exist_ok=True)
            dst = MANUAL_ROOT / d.name
            if dst.exists():                       # 이미 있으면 안의 것만 합침
                for x in d.iterdir():
                    if not (dst / x.name).exists():
                        shutil.move(str(x), str(dst / x.name))
                try:
                    d.rmdir()
                except OSError:
                    pass
            else:
                shutil.move(str(d), str(dst))
    _migrate_tail()


def _migrate_tail():
    migrate_extra_names()
    try:
        migrate_extra_folders()
    except Exception as e:
        sys.stderr.write(f"추가자료 학번 폴더 옮기기 실패: {e}\n")


def read_records(d: Path, tries: int = 6) -> Dict[str, dict]:
    """폴더의 받은 기록. 맥 iCloud(데스크탑 동기화)가 파일을 내려받는 중이면 'Resource deadlock avoided'(11)·
    잠김 오류가 잠깐 날 수 있어서 몇 번 다시 읽음. 그래도 안 되면 오류 (빈 기록으로 착각해 덮어쓰지 않게)"""
    p = d / RECORD
    if not p.exists():
        return {}
    last = None
    for i in range(tries):
        try:
            with open(p, encoding="utf-8-sig") as f:
                return {r["합본파일명"]: r for r in csv.DictReader(f)}
        except (OSError, csv.Error) as e:
            last = e
            time.sleep(0.25 * (i + 1))
    raise last


REC_LOCK = threading.RLock()


def write_records(d: Path, recs: Dict[str, dict]):
    d.mkdir(parents=True, exist_ok=True)
    with REC_LOCK:                       # 임시 파일에 쓰고 바꿔치기 (쓰는 도중에 읽어도 깨지지 않게)
        tmp = d / f".{RECORD}.{os.getpid()}.{threading.get_ident() % 100000}.tmp"   # 프로세스마다 다른 임시 파일 (화면·받기가 동시에 써도 안 섞이게)
        with open(tmp, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.DictWriter(f, fieldnames=REC_COLS)
            w.writeheader()
            for k in sorted(recs):
                w.writerow({c: recs[k].get(c, "") for c in REC_COLS})
        safe_replace(tmp, d / RECORD)


def rename_plan(new_fmt: str, old_fmt: Optional[str] = None) -> dict:
    """파일 이름 방식을 바꿀 때 바뀌는 것들: [(폴더, 옛 이름, 새 이름, 종류)] · 종류: lec/x/refs
    (_이전버전 백업·원본 캐시는 그대로) · 새 이름 자리에 다른 파일이 있으면 conflicts"""
    old_fmt = old_fmt or name_fmt()
    moves, conflicts, seen = [], [], set()
    if old_fmt == new_fmt:
        return {"moves": [], "conflicts": []}
    xre = re.compile(r"_추가자료(\(\d+학번\))?\.pdf$")
    xlist: Dict[Path, list] = {}
    lects = load(DATA / "시간표.json")
    fill: Dict[str, str] = {}
    if uses_orig(new_fmt):                 # {원본}을 처음 쓰면: 받은 기록의 원본 파일 이름으로 채움 (자료가 하나인 강의만)
        on = dict(orig_names())            #  · 미리보기라 진짜 표는 건드리지 않음 (적용할 때 fill 로 저장)
        rc: Dict[Path, dict] = {}
        for L in lects:
            if not L.key or on.get(L.key):
                continue
            d = out_dir(L)
            if d not in rc:
                try:
                    rc[d] = read_records(d)
                except Exception:
                    rc[d] = {}
            r = rc[d].get(out_name(L, old_fmt)) or {}
            src = (r.get("원본파일명") or "").strip()
            if src and " + " not in src and not split_parts(r):
                on[L.key] = fill[L.key] = orig_stem(src)
        _ORIG_TMP[0] = on
    try:
        return _rename_plan_inner(lects, new_fmt, old_fmt, moves, conflicts, seen, fill)
    finally:
        _ORIG_TMP[0] = None


def _rename_plan_inner(lects, new_fmt, old_fmt, moves, conflicts, seen, fill) -> dict:
    for L in lects:
        d, o, n = out_dir(L), out_name(L, old_fmt), out_name(L, new_fmt)
        if (d, o) in seen or o == n:
            continue
        seen.add((d, o))
        if (d / o).is_file():
            (conflicts if (d / n).exists() else moves).append((d, o, n, "lec"))
        fo, fn = o[:-4], n[:-4]                 # 강의록 여러 개를 따로 만든 폴더 + 안의 (1), (2) 파일
        if (d / fo).is_dir() and (d / fn).exists():
            conflicts.append((d, fo, fn, "split"))
        elif (d / fo).is_dir():
            moves.append((d, fo, fn, "split"))
            try:
                ps = split_parts(read_records(d).get(o))
            except Exception:
                ps = []
            for k, x in enumerate(ps, 1):
                po = x["f"]
                mode = "tt" if po == part_name(L, k, old_fmt) else "orig"
                pn_ = part_file(L, k, x.get("src", ""), new_fmt, mode)
                if (d / fo / po).is_file() and po != pn_:
                    moves.append((d / fn, po, pn_, "part"))
        ro, rn = o[:-4] + "_참고자료", n[:-4] + "_참고자료"
        if (d / ro).is_dir():
            (conflicts if (d / rn).exists() else moves).append((d, ro, rn, "refs"))
        oo, on_ = o[:-4] + "_원본", n[:-4] + "_원본"
        if (d / oo).is_dir():
            (conflicts if (d / on_).exists() else moves).append((d, oo, on_, "refs"))
        for lab in [""] + [str(s_.get("label", "")).strip() for s_ in old_sources()]:     # 학번 폴더마다
            xd = extra_dir(L, lab)
            xo, xn = extra_name(L, lab, old_fmt), extra_name(L, lab, new_fmt)
            if (xd, xo) in seen or xo == xn or not (xd / xo).is_file():
                continue
            seen.add((xd, xo))
            (conflicts if (xd / xn).exists() else moves).append((xd, xo, xn, "x"))
    return {"moves": moves, "conflicts": conflicts, "fill": fill}


def rename_apply(new_fmt: str, log=lambda *a: None) -> dict:
    """정리 폴더의 강의록·추가자료·참고자료 폴더 + 받은 기록 + 클라우드 복사본 이름을 새 방식으로 바꾸고 설정 저장
    · 일부를 못 바꾸면 예전 방식을 name_fmt_prev 에 남겨 둠 → 다시 누르면 남은 것만 (그전 방식 기준으로) 다시 시도"""
    old_fmt = str(CFG.get("name_fmt_prev") or "") or name_fmt()
    plan = rename_plan(new_fmt, old_fmt)
    try:
        from . import cloud as _cloud
        cdirs = _cloud.copy_dirs()
    except Exception:
        cdirs = {}
    done, failed, cdone = 0, [], 0
    by_dir: Dict[Path, list] = {}
    pmap: Dict[Path, Dict[str, str]] = {}      # 따로 만든 파일 이름 바뀐 것 (기록의 나눔 칸도 고침)
    for d, o, n, kind in plan["moves"]:
        try:
            os.rename(d / o, d / n)
            done += 1
            if kind == "split":
                by_dir.setdefault(d, []).append((o + ".pdf", n + ".pdf"))
            elif kind == "part":
                pmap.setdefault(d.parent, {})[o] = n
            else:
                by_dir.setdefault(d, []).append((o, n))
        except OSError as e:
            failed.append(f"{o} ({err(e)})")
            continue
        for cd in cdirs.values():             # 클라우드에 복사해 둔 것도 같은 이름으로 (다시 올리지 않게)
            try:
                r_ = rel_of(d / o)
                if not r_:
                    continue
                rel = Path(r_)
                src, dst = cd / rel, cd / rel.parent / n
                if src.exists() and not dst.exists():
                    os.rename(src, dst)
                    cdone += 1
            except (OSError, ValueError):
                pass
    with REC_LOCK:                            # 받은 기록의 이름도
        for d in pmap:
            by_dir.setdefault(d, [])
        for d, pairs in by_dir.items():
            try:
                recs = read_records(d)
            except Exception:
                continue
            ch = False
            for o, n in pairs:
                if o in recs and n not in recs:
                    r = recs.pop(o)
                    r["합본파일명"] = n
                    recs[n] = r
                    ch = True
            for r in recs.values():
                ps = split_parts(r)
                if ps and any(p_["f"] in pmap.get(d, {}) for p_ in ps):
                    for p_ in ps:
                        p_["f"] = pmap[d].get(p_["f"], p_["f"])
                    r["나눔"] = json.dumps(ps, ensure_ascii=False)
                    ch = True
            if ch:
                write_records(d, recs)
    if uses_orig(new_fmt) and plan.get("fill"):
        for k, v in plan["fill"].items():
            set_orig(k, v)
        save_orig_names()
    left = bool(failed or plan["conflicts"])
    with CFG_LOCK:
        cfg = read_cfg()
        if new_fmt == NAME_DEFAULT:
            cfg.pop("name_fmt", None)
        else:
            cfg["name_fmt"] = new_fmt
        if left and old_fmt != new_fmt:
            cfg["name_fmt_prev"] = old_fmt
        else:
            cfg.pop("name_fmt_prev", None)
        write_cfg(cfg)
        CFG.update(cfg)
        if new_fmt == NAME_DEFAULT:
            CFG.pop("name_fmt", None)
        if "name_fmt_prev" not in cfg:
            CFG.pop("name_fmt_prev", None)
    _TAG[0] = None
    return {"ok": True, "done": done, "cloud": cdone, "failed": failed, "conflicts": [o for _, o, _, _ in plan["conflicts"]]}


def err(e) -> str:
    """오류 메시지를 기록용으로 정리: 첫 줄만, 로그인 토큰·쿠키·긴 주소는 지움"""
    if isinstance(e, subprocess.TimeoutExpired):          # LibreOffice 등이 너무 오래 걸림 (명령 전체는 안 남김)
        prog = Path(str(e.cmd[0] if isinstance(e.cmd, (list, tuple)) else e.cmd)).name
        return f"{'PDF 변환(LibreOffice)' if 'office' in prog.lower() else prog}이 {int(e.timeout or 0)}초 넘게 끝나지 않음"
    if isinstance(e, subprocess.CalledProcessError):
        prog = Path(str(e.cmd[0] if isinstance(e.cmd, (list, tuple)) else e.cmd)).name
        return f"{'PDF 변환(LibreOffice)' if 'office' in prog.lower() else prog} 오류 (코드 {e.returncode})"
    t = str(e).split("\nCall log:")[0].strip().splitlines()[0] if str(e).strip() else type(e).__name__
    t = re.sub(r"(Bearer|token=|cookie:?)\s*[\w\-.%=+/]+", r"\1 ***", t, flags=re.I)
    t = re.sub(r"eyJ[\w\-.]{20,}", "***", t)
    t = re.sub(r"https?://[^\s)]+", lambda m: m.group(0).split("?")[0], t)
    return t[:200]


def _cache_path(cache: Path, it: Item) -> Path:
    stamp = re.sub(r"\D", "", it.uploaded)[:12]
    return cache / it.source / f"{safe(it.uid)}_{stamp}{Path(it.filename).suffix.lower()}"


MANUAL_EXT = (".pdf", ".ppt", ".pptx", ".doc", ".docx", ".hwp", ".hwpx", ".key", ".odp")


def manual_dir(L) -> Path:
    """앱에서 직접 넣은 자료 폴더 (LMS·드라이브에 없는 강의록도 정리할 수 있게)"""
    return DATA / "직접넣은자료" / safe(L.key)


def manual_files(L) -> List[Path]:
    d = manual_dir(L)
    try:
        return sorted((f for f in d.iterdir() if f.is_file() and f.suffix.lower() in MANUAL_EXT), key=lambda f: f.name)
    except Exception:
        return []


def manual_items(lectures) -> List[tuple]:
    """(Item, 강의): 직접 넣은 자료는 그 강의 것으로 바로 정해짐 (LMS·드라이브 자료보다 먼저)"""
    out = []
    for L in lectures:
        for f in manual_files(L):
            t = datetime.fromtimestamp(f.stat().st_mtime).strftime("%Y-%m-%dT%H:%M:%S")
            out.append((Item(source="직접", course=L.course, uid=f"{safe(L.key)}/{f.name}", title=f.stem, filename=f.name,
                             uploaded=t, date_hint=L.mmdd, size=f.stat().st_size, fetch={"kind": "local", "path": str(f)}), L))
    return out


FORMAT = "fmt:a4v7"     # 합본 만드는 방식이 바뀌면 올림 → 자료가 그대로여도 다시 만든다


def paper_size() -> str:
    """설정의 용지 크기 ('' = 맞추지 않음). 예전 설정(a4: false)도 이해함."""
    p = CFG.get("paper")
    if p is None:
        return "A4" if CFG.get("a4", True) else ""
    return p if render.paper_dims(p) else ""


_TAG: List[Optional[str]] = [None]     # 받기 한 번 동안은 같은 값 (도중에 표지를 고쳐도 기록이 실제와 같게)


def fmt_tag(extra: bool = False) -> str:
    """합본 형식 표시 (FORMAT|nocover|paper|font|cover). 기본으로는 FORMAT 만 비교하고,
    표지·용지·글꼴은 '새 표지로 바꾸기'(REMAKE) 때 비교. 필야(extra)는 표지가 없어서 FORMAT·용지만."""
    pp = paper_size()
    paper = f"|paper:{pp or 'none'}" if pp != "A4" else ""
    if extra:
        return FORMAT + paper
    if _TAG[0] is not None:
        return _TAG[0]
    t = FORMAT
    cover_on = CFG.get("cover", True) is not False
    if not cover_on:
        t += "|nocover"
    t += paper
    from . import render as _r
    uf = _r.user_font()                   # 글꼴은 PPT 변환에도 써서 표지를 꺼도 표시
    if uf:
        try:
            t += f"|font:{uf.name}:{uf.stat().st_size}"
        except OSError:
            t += "|font:" + uf.name
    if cover_on:
        from . import covers as _covers
        t += _covers.cover_tag(APP, CFG.get("cover_template", ""))     # 표지 모양
        if name_fmt() != NAME_DEFAULT:                                  # 표지 제목 줄 = 파일 이름 모양
            t += "|name:" + hashlib.md5(name_fmt().encode("utf-8")).hexdigest()[:8]
    return t


def _tag_of(sig: Optional[str], extra: bool = False) -> str:
    t = (sig or "").split(" || ")[0]
    if extra:                               # 예전 필야 기록에는 표지·글꼴 표시가 붙어 있었음 → 빼고 비교
        t = "|".join(p for p in t.split("|") if not p.startswith(("nocover", "font:", "cover:")))
    return t


def is_past(L) -> bool:
    """오늘보다 앞선 날 강의인지 (2학기 1·2월 수업은 다음 해)"""
    from datetime import date
    from .timetable import YEAR_KEY, year_num, cal_year
    try:
        return date(cal_year(L.month), L.month, L.day) < date.today()
    except ValueError:
        return False


def _backup_name(prev: Path, name: str, tag: str) -> Path:
    """_이전버전 에 옮길 이름: 같은 이름이 이미 있으면 덮지 않게 시각·번호를 붙임"""
    p = prev / name.replace(".pdf", f"_{tag}.pdf")
    if p.exists():
        p = prev / name.replace(".pdf", f"_{tag}_{datetime.now():%H%M}.pdf")
    n = 2
    while p.exists():
        p = prev / name.replace(".pdf", f"_{tag}_{datetime.now():%H%M}_{n}.pdf")
        n += 1
    return p


def _stale_drive(plan) -> Dict[str, tuple]:
    """드라이브 자료로만 만들 강의 중, 올린 날짜가 강의 날짜보다 300일 넘게 앞선 것 (다른 학번 드라이브를 넣은 경우)"""
    out = {}
    for k, v in plan.items():
        L, use = v[0], v[1]
        if not use or any(i.source != "드라이브" for i in use):
            continue
        try:
            t0 = date.today()           # 강의 날짜: 올해·작년·내년 중 오늘과 가장 가까운 날 (학기가 해를 넘겨도 맞게)
            cands = []
            for y in (t0.year - 1, t0.year, t0.year + 1):
                try:
                    cands.append(date(y, L.month, L.day))
                except ValueError:
                    pass
            lec = min(cands, key=lambda d: abs((d - t0).days))
            ups = [date.fromisoformat(i.uploaded[:10]) for i in use if re.match(r"\d{4}-\d{2}-\d{2}", i.uploaded or "")]
        except Exception:
            continue
        if ups and (lec - max(ups)).days > 300:
            out[k] = (f"드라이브 자료가 작년 것 같아요 (올린 날 {max(ups):%Y-%m-%d}) · 다른 학번 드라이브인지 설정 탭에서 확인", L)
    return out


def drive_sem() -> str:
    """학기 폴더: 처음 설정에서 골랐으면 그 폴더(id), 아니면 이름으로 찾기 (예전 설정)"""
    sid = (CFG.get("drive_sem_id") or "").strip()
    return f"id:{sid}" if sid else (CFG.get("drive_semester") or "2학기")


def keep_past(L, old: Optional[dict], path: Path, extra: bool = False) -> bool:
    """지난 강의인데 이미 잘 만들어 둔 파일이 있으면 다시 확인하지 않음 (빠진 강의만 받기).
    단 '처음부터', '새 설정으로 다시 만들기'(표지·용지·글꼴이 바뀐 것), 임시 자료(드라이브판·검수 전·실패)는 다시 봄.
    설정 recheck_past: true 면 예전처럼 지난 강의도 교수님 재업로드를 확인."""
    if FORCE[0] or CFG.get("recheck_past") or not old or not is_past(L):
        return False
    if getattr(L, "key", None) in REDO_NOW:      # 화면에서 자료를 고르거나 역할을 바꾼 강의
        return False
    if not extra and manual_files(L):        # 직접 넣은 자료가 있으면 (바뀌었을 수 있으니) 서명으로 비교
        return False
    if not extra and "직접" in (old.get("출처") or ""):   # 직접 넣은 자료를 뺐으면 → LMS·드라이브 자료로 다시
        return False
    if old.get("상태") in ("드라이브판", "검수 전", "실패", "확인 필요") or "드라이브 자료로 만듦" in (old.get("비고") or ""):
        return False                     # 드라이브판(LMS로 바꿀 예정)·검수 전 필야는 계속 확인
    if _tag_of(old.get("서명")).split("|")[0] != FORMAT:
        return False                     # 합본 방식이 바뀜
    if REMAKE[0] and _tag_of(old.get("서명"), extra) != fmt_tag(extra):
        return False                     # 새 설정으로 다시 만들기
    return has_out(path) and not mode_change(getattr(L, "key", ""), old)


def signature(items: List[Item], extra: bool = False, cover_failed: bool = False) -> str:
    t = fmt_tag(extra)
    if cover_failed:                         # 고른 표지로 못 만들고 기본 표지를 씀 → 다음 '새 표지로 바꾸기' 때 다시
        t = "|".join(p for p in t.split("|") if not p.startswith("cover:"))
    rl = load_roles()
    mark = lambda i: ("~" + rl[f"{i.source}:{i.uid}"]) if rl.get(f"{i.source}:{i.uid}") in ("본", "보조") else ""
    return t + " || " + " | ".join(f"{i.source}:{i.uid}:{i.uploaded}{mark(i)}" for i in items)


def _sig_items(sig: str) -> List[str]:
    """서명 → 자료 목록. 예전 버전의 드라이브 '9999-시각' 표기(오늘 수정분)는 날짜 없이 비교."""
    body = (sig or "").split(" || ", 1)[-1]
    out = []
    for part in body.split(" | "):
        src, _, rest = part.partition(":")
        uid, _, up = rest.partition(":")
        if src == "드라이브" and up.startswith("9999"):
            up = "*"
        out.append(f"{src}:{uid}:{up}")
    return out


def _same_source(old_sig: str, sig: str) -> bool:
    """형식만 바뀌고 자료는 그대로인지 (드라이브는 파일이 같으면 표시 날짜 차이는 무시)"""
    a, b = _sig_items(old_sig), _sig_items(sig)
    return len(a) == len(b) and all(x == y or (x.endswith(":*") or y.endswith(":*")) and x.rsplit(":", 1)[0] == y.rsplit(":", 1)[0]
                                     for x, y in zip(a, b))


# ---------------------------------------------------------------- 한 파일 → PDF
def to_pdf(src: Path, work: Path, rd: render.Renderer, notes: List[str]) -> Path:
    ext = src.suffix.lower()
    if ext == ".pdf":
        return src
    if ext in (".ppt", ".pptx", ".odp", ".key"):
        pptx = src
        if ext != ".pptx":
            pptx = render.convert(src, "pptx", work / "conv")
        tables_ok = False
        if ext == ".ppt" and render.table_fill_lost(pptx):
            # 최신 LibreOffice 는 예전 .ppt 의 표 색을 .pptx 로 옮길 때 잃어버려요 → 같은 파일을 .odp 로 바꾼 쪽의 칸 색으로 바로잡기
            try:
                odp = render.convert(src, "odp", work / "odp")
                tfix = work / (src.stem + "_표색.pptx")
                if render.fix_table_fills(pptx, odp, tfix):
                    pptx, tables_ok = tfix, True
                    notes.append("예전 PPT 형식(.ppt)이라 표 색을 원본대로 맞춤")
            except Exception:
                pass
        fixed = work / (src.stem + "_처리.pptx")
        try:
            res = pptx_process(pptx, fixed)
        except Exception as e:
            notes.append(f"PPT 분석 실패({type(e).__name__}) → 원본 그대로 변환")
            return render.convert(pptx, "pdf", work / "pdf")
        try:
            pdf = render.convert(fixed, "pdf", work / "pdf")
        except Exception:
            # 큰 동영상이 든 PPT는 변환 중 죽을 수 있음 → 동영상·소리를 빼고 다시 (PDF엔 정지 화면만 들어감)
            lite = work / (src.stem + "_처리_가벼움.pptx")
            n = render.strip_media(fixed, lite)
            try:
                if not n:
                    raise RuntimeError("동영상 없음")
                pdf = render.convert(lite, "pdf", work / "pdf")
                notes.append(f"동영상·소리 {n}개를 빼고 변환 (PDF엔 정지 화면)")
            except Exception:
                # 앱이 손본 PPT가 LibreOffice에서 안 열리는 경우 → 원본 PPT 그대로 한 번 더
                pdf = render.convert(pptx, "pdf", work / "pdf_orig")
                notes.append("손본 PPT 변환이 안 돼서 원본 그대로 변환 (오른쪽 위 표시 생략)")
                return pdf
        if ext == ".ppt" and not tables_ok and render.table_fill_lost(pptx):     # (위에서 못 고쳤을 때)
            # 최신 LibreOffice 는 예전 .ppt 의 표 색을 .pptx 로 옮길 때 잃어버려요 → 원본 .ppt 를 바로 PDF로 만든 쪽으로 바꿔 끼움
            # (애니메이션으로 나눈 슬라이드는 그대로 · 숨긴 슬라이드도 같이 넣어서 쪽 번호를 맞춤)
            try:
                direct = render.convert(src, "pdf", work / "pdf_direct", fonts=render.doc_fonts(pptx), hidden=True)
                if render.page_count(direct) == len(res.reports):
                    pick = []
                    for r in res.reports:
                        pick += [r.index - 1] if r.split == 1 else [None] * r.split
                    pdf = render.take_pages(pdf, direct, pick, work / (src.stem + "_표색.pdf"))
                    notes.append("예전 PPT 형식(.ppt)이라 표 색을 원본대로 맞춤")
            except Exception:
                pass
        if render.page_count(pdf) == len(res.labels):
            if any(res.labels):
                stamped = work / (src.stem + "_표시.pdf")
                render.apply_labels(pdf, res.labels, rd, stamped, work)
                pdf = stamped
        else:
            notes.append("쪽수가 달라 오른쪽 위 표시는 생략")
        if res.hidden_count:
            notes.append(f"숨긴 슬라이드 {res.hidden_count}장 포함")
        for r in res.split_slides:
            notes.append(f"{r.index}번 슬라이드 애니메이션 {r.split}장으로 분할")
        if res.overlap_slides:
            notes.append("애니메이션 없이 겹친 슬라이드(그대로 둠): " + ", ".join(str(r.index) for r in res.overlap_slides))
        return pdf
    if ext in (".doc", ".docx", ".hwp", ".hwpx", ".odt", ".rtf"):
        return render.convert(src, "pdf", work / "pdf")
    raise RuntimeError(f"처리할 수 없는 형식: {ext}")


# ---------------------------------------------------------------- 받기
RUN_LOCK = APP / "logs" / "받기중.json"
SCHED_LOG = APP / "logs" / "예약기록.jsonl"      # 예약(자동) 받기 실행 기록: 예약 탭에 보여 줌


def sched_log(**kw):
    """예약 받기 기록 한 줄 추가 (최근 300줄만 남김)"""
    try:
        SCHED_LOG.parent.mkdir(parents=True, exist_ok=True)
        lines = SCHED_LOG.read_text("utf-8").splitlines()[-299:] if SCHED_LOG.exists() else []
        lines.append(json.dumps({"t": f"{datetime.now():%Y-%m-%d %H:%M}", **kw}, ensure_ascii=False))
        tmp = SCHED_LOG.with_suffix(".tmp")
        tmp.write_text("\n".join(lines) + "\n", "utf-8")
        os.replace(tmp, SCHED_LOG)
    except Exception:
        pass


def pid_alive(pid: int) -> bool:
    """그 프로그램이 아직 살아 있는지 (macOS·Windows 공통)"""
    if not pid or pid <= 0:
        return False
    if os.name == "nt":
        try:
            import ctypes
            h = ctypes.windll.kernel32.OpenProcess(0x1000, False, pid)   # PROCESS_QUERY_LIMITED_INFORMATION
            if not h:
                return False
            code = ctypes.c_ulong()
            ctypes.windll.kernel32.GetExitCodeProcess(h, ctypes.byref(code))
            ctypes.windll.kernel32.CloseHandle(h)
            return code.value == 259                                      # STILL_ACTIVE
        except Exception:
            return False
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except Exception:
        return False


def _is_app_pid(pid: int) -> bool:
    """그 번호의 프로그램이 정말 강의록앱(파이썬)인지. 윈도우는 프로그램 번호를 금방 다시 써서,
    남은 잠금 파일의 번호가 크롬 같은 다른 프로그램을 가리킬 수 있음 → 그걸 '받는 중'으로 보거나 끄지 않게"""
    try:
        if os.name == "nt":
            import ctypes
            from ctypes import wintypes
            k = ctypes.windll.kernel32
            h = k.OpenProcess(0x1000, False, pid)                       # PROCESS_QUERY_LIMITED_INFORMATION
            if not h:
                return True
            try:
                buf = ctypes.create_unicode_buffer(1024)
                n = wintypes.DWORD(1024)
                if not k.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(n)):
                    return True
                return "python" in Path(buf.value).name.lower()
            finally:
                k.CloseHandle(h)
        r = subprocess.run(["ps", "-p", str(pid), "-o", "command="], capture_output=True, text=True, timeout=5)
        return (not r.stdout.strip()) or ("lecture_app" in r.stdout) or ("python" in r.stdout.lower())
    except Exception:
        return True


def run_lock() -> Optional[dict]:
    """지금 받기 중인 실행 정보 {pid, auto, started, label} (없거나 이미 끝났으면 None)"""
    try:
        info = json.loads(RUN_LOCK.read_text("utf-8"))
        pid = int(info.get("pid") or 0)
        if pid_alive(pid) and _is_app_pid(pid):
            return info
    except Exception:
        pass
    if os.name != "nt":            # 잠금 파일을 안 남기는 예전 버전 실행도 찾음 (맥)
        try:
            r = subprocess.run(["pgrep", "-f", "lecture_app 받기"], capture_output=True, text=True, timeout=5)
            pids = [int(x) for x in r.stdout.split() if x.strip().isdigit() and int(x) not in (os.getpid(), os.getppid())]
            if pids:
                return {"pid": min(pids), "auto": False, "started": ""}
        except Exception:
            pass
    return None


def _other_run() -> bool:
    """다른 '받기'가 이미 돌고 있는지 (예약 실행·화면 실행이 겹치면 같은 브라우저 프로필을 두고 서로 꺼 버림)"""
    info = run_lock()
    return bool(info) and int(info.get("pid") or 0) not in {os.getpid(), os.getppid()}


REDO_NOW: set = set()
FORCE = [False]      # --처음부터: 이미 만든 것도 다시 만듦
REMAKE = [False]     # --새표지: 표지·용지·글꼴 설정이 바뀐 강의록도 새 설정으로 다시 만듦 (기본은 그대로 둠)


# ---------------------------------------------------------------- 자료 역할 (본 강의록 / 보조자료)
def _roles_path() -> Path:
    return DATA / "자료역할.json"


def load_roles() -> Dict[str, str]:
    """애매한 자료에서 직접 정한 역할: {"출처:uid": "본" | "보조"}"""
    try:
        return json.loads(_roles_path().read_text("utf-8")) if _roles_path().exists() else {}
    except Exception:
        return {}


def _redo_path() -> Path:
    return DATA / "다시만들기.json"


def redo_keys() -> set:
    """화면에서 자료를 고르거나 역할을 바꿔서 다음 받기 때 다시 만들 강의 (지난 강의라도)"""
    try:
        return set(json.loads(_redo_path().read_text("utf-8"))) if _redo_path().exists() else set()
    except Exception:
        return set()


# ---------------------------------------------------------------- 강의록 여러 개 → 폴더에 따로 / 합본 (강의록 합치기 탭)
def split_folder(path: Path) -> Path:
    """'…/1030-1. 제목_교수.pdf' → 따로 만든 파일을 넣는 폴더 '…/1030-1. 제목_교수'"""
    return path.with_name(path.name[:-4] if path.name.lower().endswith(".pdf") else path.name)


def part_name(L: Lecture, n: int, fmt: Optional[str] = None) -> str:
    return name_base(L, fmt, part=n) + ".pdf"


def part_file(L: Lecture, n: int, src: str = "", fmt: Optional[str] = None, mode: Optional[str] = None) -> str:
    """폴더에 따로 만든 강의록 파일 이름. 설정 split_name: "tt"(시간표 이름, 기본) | "orig"(원본 파일 이름)
    원본 이름: 이름 모양에서 (n) 까지 + 원본 파일 이름 (예: 1030-1(1) 신생아 발열 CP.pdf)"""
    mode = mode or str(CFG.get("split_name") or "tt")
    if mode == "orig" and src:
        base, plain, tag = name_base(L, fmt, part=n), name_base(L, fmt), f"({n})"
        i = next((k for k in range(min(len(base), len(plain))) if base[k] != plain[k]), min(len(base), len(plain)))
        pre = base[:i + len(tag)] if base[i:i + len(tag)] == tag else base
        return safe(f"{pre} {Path(src).stem}")[:150].rstrip(" .") + ".pdf"
    return part_name(L, n, fmt)


def split_parts(rec: Optional[dict]) -> List[dict]:
    """기록의 나눔 칸 → [{"f": 파일 이름, "id": "출처:uid", "src": 원본 이름}]"""
    try:
        v = json.loads((rec or {}).get("나눔") or "[]")
        return [x for x in v if isinstance(x, dict) and x.get("f")] if isinstance(v, list) else []
    except Exception:
        return []


def has_out(path: Path) -> bool:
    """강의록이 있는지: 합본 파일 하나 또는 폴더에 따로 만든 파일들"""
    if path.exists():
        return True
    fd = split_folder(path)
    try:
        return fd.is_dir() and any(f.suffix.lower() == ".pdf" for f in fd.iterdir())
    except OSError:
        return False


def _merge_path() -> Path:
    return DATA / "강의록합치기.json"


def load_merge() -> Dict[str, dict]:
    """강의록 합치기 탭에서 고른 것: {강의 key: {"files": [출처:uid…], "do": "merge"|"split", "del": bool}}"""
    try:
        v = json.loads(_merge_path().read_text("utf-8")) if _merge_path().exists() else {}
        return v if isinstance(v, dict) else {}
    except Exception:
        return {}


def save_merge(v: Dict[str, dict]):
    tmp = _merge_path().with_suffix(".tmp")
    tmp.write_text(json.dumps(v, ensure_ascii=False, indent=1), "utf-8")
    safe_replace(tmp, _merge_path())


def merge_choice(key: str, ids: List[str]) -> Optional[dict]:
    """지금 자료 묶음 그대로 고른 게 있으면 그 선택 (자료가 바뀌면 다시 물어봄)"""
    e = load_merge().get(key)
    return e if e and sorted(e.get("files") or []) == sorted(ids) else None


def mode_change(key: str, old: Optional[dict]) -> bool:
    """따로 만든 강의록인데 합본을 만들기로 골랐으면 → 다시 만들어야 함"""
    ps = split_parts(old)
    if not ps:
        return False
    c = merge_choice(key, [p.get("id", "") for p in ps])
    return bool(c and c.get("do") == "merge")


def _verq_path() -> Path:
    return DATA / "재업로드확인.json"


def load_verq() -> dict:
    """이름이 비슷한 자료가 같이 있을 때 물어보기: {"q": [질문], "ans": {묶음 id: "re"|"diff"}}"""
    try:
        v = json.loads(_verq_path().read_text("utf-8")) if _verq_path().exists() else {}
    except Exception:
        v = {}
    if not isinstance(v, dict):
        v = {}
    v.setdefault("q", [])
    v.setdefault("ans", {})
    return v


def save_verq(v: dict):
    tmp = _verq_path().with_suffix(".tmp")
    tmp.write_text(json.dumps(v, ensure_ascii=False, indent=1), "utf-8")
    safe_replace(tmp, _verq_path())


def _edited_after(p: Path, when: str, slack: int = 120) -> bool:
    """만든 뒤(받은 기록의 처리일시)에 사용자가 고친 파일이 있는지 (PDF에 직접 필기 · 폴더 안 파일을 고침)
    · 처리일시를 모르면 고친 것으로 봄 (덮어쓰지 않게)"""
    if not p.exists():
        return False
    try:
        t = datetime.strptime((when or "").strip()[:16], "%Y-%m-%d %H:%M").timestamp()
    except ValueError:
        return True
    try:
        files = [p] if p.is_file() else [x for x in p.rglob("*") if x.is_file()]
        return any(x.stat().st_mtime > t + slack for x in files)
    except OSError:
        return True


def _keep_or_drop(d: Path, folder: Path, when: str, tag: str):
    """다시 만들며 지울 폴더(_참고자료 · _원본): 사용자가 고쳤으면 _이전버전으로, 아니면 지움"""
    if not folder.is_dir():
        return
    if _edited_after(folder, when):
        prev = d / "_이전버전"
        prev.mkdir(exist_ok=True)
        shutil.move(str(folder), str(unique_dir(prev / f"{folder.name}_{tag}")))
    else:
        shutil.rmtree(folder)


def _retire(d: Path, name: str, tag: str):
    """이전 강의록(합본 파일·따로 만든 폴더)을 _이전버전 으로"""
    prev = d / "_이전버전"
    if (d / name).exists():
        prev.mkdir(exist_ok=True)
        shutil.move(str(d / name), str(_backup_name(prev, name, tag)))
    for fd in (split_folder(d / name), d / (name[:-4] + "_원본")):
        if fd.is_dir():
            prev.mkdir(exist_ok=True)
            shutil.move(str(fd), str(unique_dir(prev / f"{fd.name}_{tag}")))


def unique_dir(p: Path) -> Path:
    """이미 있으면 _2, _3 … (폴더를 옮길 때 기존 폴더 안으로 들어가지 않게)"""
    q, k = p, 2
    while q.exists():
        q = p.with_name(f"{p.name}_{k}")
        k += 1
    return q


def _redo_done(keys):
    left = redo_keys() - set(keys)
    try:
        _redo_path().write_text(json.dumps(sorted(left), ensure_ascii=False), "utf-8")
    except Exception:
        pass


SLIDE_EXT = (".ppt", ".pptx", ".key", ".odp", ".pps", ".ppsx")
DOC_EXT = (".doc", ".docx", ".hwp", ".hwpx", ".odt", ".rtf", ".txt")


def orient(path: Path, name: str = "") -> str:
    """자료 모양: slide(가로 슬라이드) · doc(세로 문서) · mixed(섞임) · unknown"""
    ext = Path(name or path.name).suffix.lower()
    if ext in SLIDE_EXT:
        return "slide"
    if ext in DOC_EXT:
        return "doc"
    if ext != ".pdf":
        return "unknown"
    try:
        from pypdf import PdfReader
        ps = PdfReader(str(path)).pages
        land = port = 0
        for p in list(ps)[:12]:
            w, h = float(p.mediabox.width), float(p.mediabox.height)
            if int(p.get("/Rotate") or 0) % 180:
                w, h = h, w
            if w > h * 1.05:
                land += 1
            elif h > w * 1.05:
                port += 1
        if land and not port:
            return "slide"
        if port and not land:
            return "doc"
        res = "mixed" if (land and port) else "unknown"
    except Exception:
        res = "unknown"
    stem = Path(name or path.name).stem.lower()      # 모양이 섞였으면 이름으로 한 번 더
    if re.search(r"슬라이드|slide|ppt|발표", stem):
        return "slide"
    if re.search(r"강의록|원고|유인물|handout|note|노트", stem):
        return "doc"
    return res


ROLE_PEND: List[dict] = []      # 이번 받기에서 본/보조를 못 정한 자료 (애매한 자료로 물어봄)


def split_roles(main_items, path_of, key: str):
    """본 강의록 / 보조자료 / 물어볼 것 나누기.
    - 직접 정한 역할이 있으면 그대로
    - 가로 슬라이드와 세로 문서(강의록 원고)가 같이 있으면 슬라이드가 본, 문서는 보조자료
    - 슬라이드+슬라이드, 문서+문서, 하나뿐이면 지금처럼 모두 본 (합침)
    - 슬라이드와 같이 있는데 모양이 섞였거나 모르면 애매한 자료로 물어봄 (이번엔 빼고 만듦)"""
    roles = load_roles()
    if len(main_items) < 2:
        return list(main_items), [], []
    kinds = {}
    for it in main_items:
        r = roles.get(f"{it.source}:{it.uid}")
        kinds[id(it)] = {"본": "main", "보조": "aux"}.get(r) or orient(path_of(it), it.filename)
    has_slide = any(kinds[id(i)] in ("slide", "main") for i in main_items)
    has_doc = any(kinds[id(i)] == "doc" for i in main_items)
    main, aux, ask = [], [], []
    for it in main_items:
        k = kinds[id(it)]
        if k == "aux":
            aux.append(it)
        elif k in ("main", "slide"):
            main.append(it)
        elif k == "doc":
            (aux if has_slide else main).append(it)
        else:      # mixed · unknown
            (ask if has_slide else main).append(it)
    if not main:                      # 전부 보조/애매면 원래대로 합침
        return list(main_items), [], []
    return main, aux, ask




def same_sig(old_sig, sig: str, extra: bool = False) -> bool:
    """이미 만든 파일을 그대로 써도 되는지: 자료와 합본 방식(FORMAT)이 같으면 OK.
    표지·용지·글꼴 설정이 바뀐 건 기본으로 무시하고, '새 설정으로 다시 만들기'(REMAKE)일 때만 따짐"""
    if not old_sig:
        return False
    if old_sig.split(" || ", 1)[-1] != sig.split(" || ", 1)[-1]:
        return False
    if REMAKE[0]:
        return _tag_of(old_sig, extra) == _tag_of(sig, extra)
    return _tag_of(old_sig).split("|")[0] == _tag_of(sig).split("|")[0]


def _wait_update() -> bool:
    """앱 업데이트 중이면 끝날 때까지 기다림 (최대 30분). 기다렸으면 True"""
    try:
        from . import updater
    except Exception:
        return False
    waited = False
    t0 = time.time()
    while updater._locked() and time.time() - t0 < 1800:
        if not waited:
            print("앱을 업데이트하는 중이라 끝나면 받을게요.", flush=True)
        waited = True
        time.sleep(3)
    return waited


def run(args) -> int:
    if _wait_update():               # 업데이트가 끝났으면 새 코드로 다시 실행
        return subprocess.call([sys.executable, "-m", "lecture_app", *sys.argv[1:]], cwd=str(APP))
    if _other_run():
        print("다른 받기가 이미 진행 중이라 이번 실행은 건너뛰어요.", flush=True)
        if getattr(args, "auto", False):
            sched_log(ev="skip", msg="다른 받기가 진행 중이라 건너뜀")
            return 0
        return 3
    # 잠금 파일을 '없을 때만 만들기'로 잡아서, 예약 실행과 화면 실행이 같은 순간 시작해도 하나만 돌게
    info = json.dumps({"pid": os.getpid(), "auto": bool(getattr(args, "auto", False)),
                       "started": f"{datetime.now():%H:%M}"}, ensure_ascii=False)
    try:
        RUN_LOCK.parent.mkdir(parents=True, exist_ok=True)
        for _ in range(2):
            try:
                fd = os.open(str(RUN_LOCK), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                with os.fdopen(fd, "w", encoding="utf-8") as f:
                    f.write(info)
                break
            except FileExistsError:
                if _other_run():
                    print("다른 받기가 이미 진행 중이라 이번 실행은 건너뛰어요.", flush=True)
                    if getattr(args, "auto", False):
                        sched_log(ev="skip", msg="다른 받기가 진행 중이라 건너뜀")
                    return 0 if getattr(args, "auto", False) else 3
                try:
                    RUN_LOCK.unlink()          # 이미 끝난 실행이 남긴 잠금
                except Exception:
                    pass
    except Exception:
        pass
    try:
        from . import updater
        if updater._locked():         # 잠그는 사이에 업데이트가 시작됐으면 잠금을 풀고 끝난 뒤 새 코드로
            RUN_LOCK.unlink()
            _wait_update()
            return subprocess.call([sys.executable, "-m", "lecture_app", *sys.argv[1:]], cwd=str(APP))
    except Exception:
        pass
    try:
        return _run(args)
    finally:
        try:
            if run_lock() and int(json.loads(RUN_LOCK.read_text("utf-8")).get("pid") or 0) == os.getpid():
                RUN_LOCK.unlink()
        except Exception:
            pass


def _run(args) -> int:
    try:
        migrate_layout()
    except Exception as e:
        print(f"폴더 옮기기 실패: {e}", flush=True)
    log = Log()
    ev = Events()
    started = datetime.now()
    log.start_file(SAVE_ROOT / "_실행기록" / f"{started:%Y-%m-%d_%H%M}_진행중.txt")
    log(f"강의록앱 실행 {started:%Y-%m-%d %H:%M}")
    RUN_ID = f"{started:%Y-%m-%d_%H%M}"
    if args.auto:
        sched_log(ev="start", id=RUN_ID, mode="오늘" if getattr(args, "today", False) else "전체",
                  target=getattr(args, "target", None) or "둘다")
    lectures = load(DATA / "시간표.json")
    days = set()
    if getattr(args, "today", False):
        days.add(f"{datetime.now():%m%d}")
    for d in getattr(args, "dates", None) or []:
        m = re.fullmatch(r"(\d{1,2})[/.\-]?(\d{2})", d.strip()) or re.fullmatch(r"(\d{1,2})/(\d{1,2})", d.strip())
        if m:
            days.add(f"{int(m.group(1)):02d}{int(m.group(2)):02d}")
        else:
            log(f"날짜 형식을 모르겠어요: {d} (예: 1024, 10/24)")
    scope = [L for L in lectures
             if (not args.course or norm_course(L.course) in {norm_course(c) for c in args.course})
             and (args.term is None or L.term == args.term)
             and (not days or L.mmdd in days)
             and (not getattr(args, "keys", None) or L.key in set(args.keys))]
    if days:
        log("범위: " + ", ".join(f"{d[:2]}/{d[2:]}" for d in sorted(days)) + f" 강의 {len(scope)}개")
    if not scope:
        log("범위에 해당하는 강의가 시간표에 없어요")
        return 1
    want_courses = tt_courses(scope)
    mem = Memory(DATA / "매칭기억.json")
    label = ", ".join(args.course) if args.course else "전체 과목"
    label += " · " + ("오늘 강의" if getattr(args, "today", False) else "날짜 " + " ".join(f"{d[:2]}/{d[2:]}" for d in sorted(days)) if days
                      else f"{args.term}차" if args.term else f"고른 강의 {len(args.keys)}개" if getattr(args, "keys", None) else "전체 강의")
    _tg = getattr(args, "target", None) or "둘다"
    if _tg != "둘다":
        label += f" · {'추가자료' if _tg == '필야' else _tg}만"
    if getattr(args, "src", "전체") == "드라이브" and _tg != "필야":
        label += " · 강의록은 드라이브만"
    if getattr(args, "force", False):
        label += " · 다시 만들기" if getattr(args, "keys", None) else " · 처음부터"
    elif getattr(args, "remake", False):
        label += " · 새 설정으로"
    ev("start", label=label, started=f"{started:%H:%M}", auto=bool(args.auto), scope=[_lec(L) for L in scope], target=_tg)
    if scope:                                  # 받기 시작 알림 (따로 보내서 받기를 늦추지 않게)
        import threading as _th
        _th.Thread(target=notify, args=("강의록앱 · " + ("예약 받기 시작" if args.auto else "받기 시작"), f"{label} · 강의 {len(scope)}개"), daemon=True).start()

    FORCE[0] = bool(getattr(args, "force", False))
    REDO_NOW.clear(); REDO_NOW.update(redo_keys())
    _mr = CFG.get("drive_course_map_root") or ""
    drive.LINK = {}
    drive.COURSE_MAP = dict(CFG.get("drive_course_map") or {}) if (not _mr or _mr == CFG.get("drive_root")) else {}   # 직접 골라 준 과목 폴더 (그 드라이브일 때만)
    _same = drive.maps_apply(CFG)               # 매뉴얼·추가자료를 고른 드라이브·학기 폴더일 때만
    drive.MANUAL_MAP = dict(CFG.get("drive_manual_map") or {}) if _same else {}     # 과목마다 직접 고른 매뉴얼 폴더
    drive.EXTRAS_MAP = dict(CFG.get("drive_extras_map") or {}) if _same else {}     # 과목마다 직접 고른 추가자료 폴더
    drive.EXTRAS_LAYOUT = dict(CFG.get("drive_extras") or {}) if _same else {}      # 추가자료 위치 (추가자료 › 학기 › 과목 등)
    try:
        drive.ALL_COURSES = sorted({L.course for L in load(DATA / "시간표.json")})
    except Exception:
        drive.ALL_COURSES = []
    REMAKE[0] = bool(getattr(args, "remake", False))
    if REMAKE[0] and not FORCE[0]:
        log("새 설정으로 다시 만들기: 표지·용지·글꼴 설정이 바뀐 강의록·추가자료를 지금 설정으로 다시 만들어요 (원본은 다시 안 받음)")
    if FORCE[0]:
        log("처음부터: 이미 만든 강의록·추가자료도 전부 다시 만들어요 (받아 둔 원본은 다시 안 받음)")
    target = getattr(args, "target", None) or "둘다"
    do_lec = target in ("둘다", "강의록")
    do_x = target in ("둘다", "필야") and CFG.get("extras", True)
    report: Dict[str, list] = {k: [] for k in ("new", "updated", "same", "missing", "pending", "fail", "replaced", "reformat", "upgraded", "closed")}
    NEWS["lec"].clear(); NEWS["x"].clear()
    scope_keys = {L.key for L in scope}
    cache = APP / ".cache"

    # ---- 필야(추가자료): 학교 로그인과 상관없어서 강의록과 따로(동시에) 돌린다
    xbox: Dict[str, object] = {"st": {}, "pend": [], "ran": False, "old": {}, "groups": set(), "xskip": set(), "oskip": {}}
    cur_label = str(CFG.get("extras_label") or "").strip() or "올해"
    years = [str(y).strip() for y in (getattr(args, "years", None) or []) if str(y).strip()]
    want_cur = not years or cur_label in years
    old_srcs = [o for o in old_sources() if not years or str(o["label"]).strip() in years]
    if do_x and years:
        log("추가자료 학번: " + ", ".join(years))

    xlock = threading.Lock()

    def x_cur():
        """우리 학번 필야 (날짜로 강의 찾기, 검수 전 → 검수본으로 교체)"""
        sent_plan = False
        try:
            extras: List[Item] = []
            bad: set = set()
            for cname in want_courses:
                try:
                    xs = drive.extras_for_course(CFG["drive_root"], drive_sem(), cname, log)
                    extras += xs
                    if xs:
                        log(f"[{cname}] 드라이브 추가자료 {len(xs)}" + (f" · 검수 전 {sum(1 for x in xs if not x.fetch.get('checked'))}" if any(not x.fetch.get('checked') for x in xs) else ""))
                except Exception as e:
                    bad.add(cname)
                    log(f"[{cname}] 추가자료 목록 실패: {err(e)} (이 과목 추가자료 현황은 그대로 둠)")
            xbox["xskip"] = {L.key for L in scope if L.course in bad}
            x_dec = match(extras, lectures, mem) if extras else []
            mem.remember(extras)
            save_auto(DATA / "자동분류.json", x_dec)
            x_pend = [d for d in x_dec if d.how == "애매"]
            for d in x_pend:          # 애매한 추가자료도 미리 받아 둠 (열어 보고 고를 수 있게)
                cf = _cache_path(cache, d.item)
                if not cf.exists():
                    try:
                        drive.download(d.item, cf)
                    except Exception as e:
                        PREFETCH_ERR[f"{d.item.source}:{d.item.uid}"] = err(e)
                        log(f"   · 애매한 추가자료 미리 받기 실패: {d.item.filename} ({err(e)})")
            with xlock:
                xbox["pend"] = list(xbox["pend"]) + x_pend
            sent_plan = True
            xbox["st"] = process_extras(x_dec, scope_keys, cache, log, report, ev)
            with xlock:                 # 목록을 다 읽고 끝까지 처리했을 때만 '확인함'으로 침
                xbox["ran"] = True
                if not bad:
                    xbox["groups"].add("필야")
        except Exception as e:
            log(f"추가자료 정리 중 오류: {err(e)}")
            xbox["error"] = err(e)
            if not sent_plan:
                ev("xplan", keys=[])

    def x_old(src):
        """선배 학번 필야 (날짜가 해마다 달라 제목·교수로 강의 찾기). 학번마다 따로 돌아감."""
        lab = str(src["label"]).strip()
        sent_plan = False
        try:
            ev("xphase", lab=lab, text=f"{xfolder(lab)} 추가자료 목록을 읽는 중")
            olds: List[Item] = []
            bad: set = set()
            for cname in want_courses:
                try:
                    olds += drive.old_extras(src, src.get("semester") or CFG.get("drive_semester") or "2학기", cname, log)
                except Exception as e:
                    bad.add(cname)
                    log(f"[{cname}] 선배 추가자료({lab}) 목록 실패: {err(e)}")
            with xlock:
                xbox["oskip"][lab] = {L.key for L in scope if L.course in bad}
            o_dec = match_old(olds, lectures, mem, str(src.get("year") or ""))
            mem.remember(olds)
            save_auto(DATA / "자동분류.json", o_dec)
            o_pend = [d for d in o_dec if d.how == "애매"]
            log(f"선배 추가자료({xfolder(lab)}) {len(olds)}개 · 강의 찾음 {len({d.item.uid for d in o_dec if d.lecture})} · 애매 {len(o_pend)}")
            linked = bool(src.get("local") and not src.get("folder"))     # 내 컴퓨터 폴더 = 연결만 (드라이브는 받아서 합침)
            if o_pend and not linked:
                ev("xphase", lab=lab, text=f"{xfolder(lab)} 애매한 추가자료 {len(o_pend)}개를 미리 받는 중")
            for d in ([] if linked else o_pend):
                cf = _cache_path(cache, d.item)
                if not cf.exists():
                    try:
                        drive.download(d.item, cf)
                    except Exception:
                        pass
            with xlock:
                xbox["pend"] = list(xbox["pend"]) + o_pend
            sent_plan = True
            res = link_extras(o_dec, scope_keys, log, ev, label=lab) if linked else process_extras(o_dec, scope_keys, cache, log, report, ev, label=lab)
            with xlock:
                xbox["old"][lab] = res
                if not bad:
                    xbox["groups"].add("필야" + lab)
        except Exception as e:
            log(f"선배 추가자료({lab}) 정리 중 오류: {err(e)}")
            if not sent_plan:
                ev("xplan", keys=[], lab=lab)

    def x_job():
        """필야: 학번마다 따로(동시에) 돌림. 한 학번이 막혀도 다른 학번은 계속.
        구글이 한꺼번에 많이 받으면 막아서 동시에는 최대 3개 학번까지."""
        from concurrent.futures import ThreadPoolExecutor
        if not want_cur:
            ev("xplan", keys=[], off=True)
        jobs = ([x_cur] if want_cur else []) + [(lambda s=s: x_old(s)) for s in old_srcs]
        if not jobs:
            return
        with ThreadPoolExecutor(max_workers=min(3, len(jobs)), thread_name_prefix="필야") as pool:
            for f in [pool.submit(j) for j in jobs]:
                try:
                    f.result()
                except Exception as e:
                    log(f"추가자료 정리 중 오류: {err(e)}")

    xt = None
    if do_x:
        xt = threading.Thread(target=x_job, name="필야", daemon=True)
        xt.start()
    else:
        ev("xplan", keys=[], off=True)

    lms = LMS(APP, log, interactive=not args.auto) if do_lec else None
    lec_ran, lec_error = False, ""
    pend: List = []
    decisions: List = []
    nr_dropped: List = []
    plan: Dict = {}
    st: Dict[str, tuple] = {}     # 강의 key → (처리 여부, 비고)
    stale_keys: set = set()       # 작년 드라이브 자료라 만들지 않은 강의 (자료 없음으로 세지 않음)
    try:
        manual_only = bool(scope) and all(manual_files(L) for L in scope)     # 직접 넣은 자료만으로 만들면 LMS 로그인 없이
        drive_only = getattr(args, "src", "전체") == "드라이브"                # 드라이브만 확인: LMS 로그인·목록 없이
        if do_lec and not manual_only and not drive_only:
            ev("phase", text="학교 LMS에 로그인하는 중")
            try:
                lms.login()
            except LoginNeeded:
                log("로그인 실패: 키체인 정보 확인 또는 직접 실행 필요" + (" (추가자료는 따로 계속 받아요)" if do_x else ""))
                if args.auto:
                    notify("강의록앱", "LMS 로그인이 필요해요. 강의록앱을 직접 한 번 실행해 주세요.", "login")
                do_lec, lec_error = False, "로그인 실패"
        if not do_lec:
            ev("plan", keys=[], pending=0, files={}, off=True)
    except BaseException:
        if xt:
            xt.join()
        raise
    try:
      if do_lec:
        ev("phase", text="직접 넣은 자료로 만드는 중" if manual_only else "드라이브에서 강의 자료 목록을 읽는 중" if drive_only
           else "LMS·드라이브에서 강의 자료 목록을 읽는 중")
        lms.on_progress = lambda got, total, rate: ev("dl", got=got, total=total, rate=round(rate))
        cmap = {} if manual_only or drive_only else course_map(lms.courses(), want_courses)
        items: List[Item] = []
        for cname in ([] if manual_only else want_courses):
            c = cmap.get(cname)
            if drive_only:
                pass
            elif c:
                try:
                    a, b = lms.classroom_items(c), lms.board_items(c, tuple(CFG.get("board_include", ["강의자료"])))
                    items += a + b
                    log(f"[{cname}] 강의실 {len(a)} · 게시판 {len(b)}")
                except Exception as e:
                    log(f"[{cname}] LMS 목록 실패: {err(e)}")
            else:
                log(f"[{cname}] LMS 과목을 못 찾음")
            try:
                dv = drive.items_for_course(CFG["drive_root"], drive_sem(), cname, log)
                items += dv
                why = drive.LINK.get(cname)
                if why:
                    log(f"[{cname}] 드라이브 연결이 안 되었어요: {why} → 설정 → 구글 드라이브 → 드라이브에서 고르기")
                    if course_started(cname, lectures):   # 시간표상 아직 첫 강의 전인 과목은 알림 안 띄움
                        ev("driveoff", course=cname, why=why)
                else:
                    log(f"[{cname}] 드라이브 매뉴얼 {len(dv)}")
            except Exception as e:
                log(f"[{cname}] 드라이브 목록 실패: {err(e)}")

        decisions = match(items, lectures, mem)
        NORETRY.clear()
        NORETRY.update(noretry_load())
        if NORETRY:       # 「다시 시도하지 않기」로 한 강의·출처의 자료는 받지 않음 (다른 출처 자료가 있으면 그걸로 만듦)
            skip_ = lambda d: d.lecture and d.item.source != "직접" and _side_of(d.item) in NORETRY.get(d.lecture.key, {})
            nr_dropped += [d for d in decisions if skip_(d)]
            decisions = [d for d in decisions if not skip_(d)]
            if nr_dropped:
                log(f"다시 시도하지 않기로 한 자료 {len(nr_dropped)}개는 건너뜀")
        mi = manual_items([L for L in lectures if L.key in scope_keys])
        if mi:
            from .matching import Decision
            decisions += [Decision(it, L, "직접") for it, L in mi]
            log(f"직접 넣은 자료 {len(mi)}개")
        lec_ran = True
        pend = [d for d in decisions if d.how == "애매" and norm_course(d.item.course) in {norm_course(c) for c in want_courses}]
        mem.remember(items)
        save_auto(DATA / "자동분류.json", decisions + nr_dropped)   # 건너뛴 것도 자동분류 기록은 그대로
        # 애매한 자료도 미리 받아 둔다 → 앱 화면에서 열어 보고 어느 강의인지 고를 수 있게
        if pend:
            ev("phase", text=f"애매한 자료 {len(pend)}개를 미리 받는 중")
            for d in pend:
                it = d.item
                cf = _cache_path(cache, it)
                if cf.exists():
                    continue
                try:
                    if it.source in LMS_SOURCES:
                        if "quick" in inspect.signature(lms.download).parameters:
                            lms.download(it, cf, quick=True)
                        else:
                            lms.download(it, cf)
                    else:
                        drive.download(it, cf)
                except Exception as e:
                    PREFETCH_ERR[f"{it.source}:{it.uid}"] = err(e)
                    log(f"   · 애매한 자료 미리 받기 실패: {it.filename} ({err(e)})")
        save_pending(pend, cache, ran={"강의록"}, courses={norm_course(c) for c in want_courses},
                     keep=_pend_keep(drive_only, manual_only))       # 필야 쪽 애매한 자료는 필야가 끝난 뒤 합쳐서 저장
        from . import matching as _mt
        _vq = load_verq()
        _mt.VER_ANS = dict(_vq["ans"])
        _mt.VER_Q.clear()
        plan = {k: v for k, v in choose(decisions).items() if k in scope_keys}
        try:        # 이름이 비슷한 자료가 같이 올라와 있는 강의 → 애매한 자료에서 「재업로드 / 서로 다른 자료」 물어봄
            byk = {L.key: L for L in scope}
            allk = {L.key for L in lectures}
            q = [x for x in _vq["q"] if x.get("key") not in scope_keys and x.get("key") in allk]
            for e in _mt.VER_Q:
                L0 = byk.get(e["key"])
                if not L0 or e["key"] not in plan:
                    continue
                q.append({"id": e["id"], "key": e["key"], "course": L0.course, "mmdd": L0.mmdd, "start": L0.start,
                          "title": L0.title, "at": f"{datetime.now():%Y-%m-%d %H:%M}",
                          "files": [{"source": i.source, "uid": i.uid, "filename": i.filename, "uploaded": i.uploaded,
                                     "file": str(_cache_path(cache, i))} for i in e["items"]]})
            _vq["q"] = q
            save_verq(_vq)
        except Exception as e:
            log(f"재업로드 확인 목록 저장 실패: {err(e)}")
        if drive_only:          # 이미 LMS 자료로 만든 강의록은 드라이브 자료로 바꾸지 않음
            def _lms_made(L):
                d0, n0 = out_dir(L), out_name(L)
                rec = read_records(d0).get(n0) or {}
                return has_out(d0 / n0) and any(s in (rec.get("출처") or "") for s in LMS_SOURCES)
            kept = [k for k, v in plan.items() if _lms_made(v[0]) and not any(i.source == "직접" for i in v[1])]
            for k in kept:
                plan.pop(k)
            if kept:
                log(f"LMS 자료로 만든 강의록 {len(kept)}개는 그대로 둠 (드라이브만 확인)")
        stale = _stale_drive(plan)      # 강의 날짜보다 훨씬 전(작년)에 올라온 드라이브 자료만 있으면 → 만들지 않고 확인 필요
        for k, (why, L0) in stale.items():
            plan.pop(k, None)
            st[k] = ("확인 필요", why)
            stale_keys.add(k)
        if stale:
            log(f"드라이브 자료가 작년 것 같아서 만들지 않은 강의 {len(stale)}개 (설정 탭 → 구글 드라이브 → 드라이브에서 고르기로 확인)")
        ev("plan", keys=[k for k in plan], pending=len(pend),
           files={k: [{"source": i.source, "name": i.filename} for i in v[1]] for k, v in plan.items()})

        rd = render.Renderer(getattr(lms, "_pw", None))
        from . import covers as _covers
        rd.template = _covers.read_cover(APP, CFG.get("cover_template", ""))     # 내가 고른 표지 (없으면 기본)
        rd.template_bg = _covers.read_bg(APP, CFG.get("cover_template", ""))     # 그 표지의 배경 사진
        _TAG[0] = None
        _TAG[0] = fmt_tag()                  # 이번 받기의 형식 표시 (도중에 설정을 바꿔도 그대로)
        try:
            todo = sorted(plan.items(), key=lambda kv: (kv[1][0].course, kv[1][0].mmdd, kv[1][0].start))

            lms_fails: Dict[str, int] = {}
            LMS_TRIES = 3          # 드라이브에 없는 강의: LMS에서 이만큼 실패하면 실패 처리

            def drive_alt(dropped):
                groups: Dict[str, List[Item]] = {}
                for i in dropped:
                    if i.source == "드라이브":
                        groups.setdefault(base_name(i), []).append(i)
                return [sorted(g, key=lambda i: i.uploaded)[-1] for g in groups.values()]

            def fetch(use, quick):
                for it in use:
                    cf = _cache_path(cache, it)
                    if cf.exists() and (cf.stat().st_size == 0 or it.source == "직접"):   # 받다 만 빈 파일 · 직접 넣은 자료(같은 분에 바꿨을 수 있음)는 새로
                        cf.unlink()
                    if cf.exists():
                        ev("step", step="download", file=it.filename, source=it.source, cached=True)
                        continue
                    ev("step", step="download", file=it.filename, source=it.source, size=it.size)
                    if it.source == "직접":            # 앱에서 직접 넣은 자료
                        cf.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy(it.fetch["path"], cf)
                    elif it.source in LMS_SOURCES:
                        if "quick" in inspect.signature(lms.download).parameters:
                            lms.download(it, cf, quick=quick)
                        else:                      # 테스트용 가짜 LMS
                            lms.download(it, cf)
                    else:
                        drive.download(it, cf)

            def merge_note(items):
                if len(items) < 2:
                    return ""
                nm = [Path(i.filename).stem for i in items]
                nm = [x if len(x) <= 24 else x[:23] + "…" for x in nm]
                return f"강의록 {len(items)}개 합침: " + " + ".join(nm)

            def build(key, L, use, notes, kind):
                """build_ 를 감쌈: {원본} 이름은 강의록을 다 만든 뒤에만 저장 (실패하면 원래대로)"""
                prev = orig_names().get(L.key or "") if L.key else None
                try:
                    return build_(key, L, use, notes, kind)
                except BaseException:
                    if L.key:
                        drop_orig_pending(L.key, prev)
                    raise

            def build_(key, L, use, notes, kind):
                """받아 둔 원본으로 표지+합본을 만들어 저장. kind: 새로/갱신/형식/드라이브먼저/LMS교체"""
                d, name = out_dir(L), out_name(L)
                old_name, had_orig = name, bool(orig_names().get(L.key or ""))
                if uses_orig() and L.key:        # {원본}: 강의록 자료가 하나면 그 원본 이름을 기억 (바뀌었으면 새 이름으로)
                    mains0 = [i for i in use if not is_ref(i)] or use
                    if len(mains0) == 1:
                        st0 = orig_stem(mains0[0].filename)
                        if st0 and orig_names().get(L.key) != st0:
                            set_orig(L.key, st0)          # 저장은 다 만든 뒤 (아래 write_records 다음)
                            name = out_name(L)
                recs = read_records(d)
                old = recs.get(name) or recs.get(old_name)
                # 참고자료·부록은 합본에 붙이지 않고 '<강의명>_참고자료' 폴더에 원본 그대로
                refs = [i for i in use if is_ref(i)]
                main_items = [i for i in use if not is_ref(i)]
                if not main_items:              # 참고자료뿐이면 그걸 합본으로
                    main_items, refs = refs, []
                main_items, aux, ask = split_roles(main_items, lambda i: _cache_path(cache, i), key)
                if aux:
                    refs = aux + refs
                    notes.append(f"슬라이드와 강의록(세로 문서)이 같이 있어서 슬라이드로 만들고, 강의록 {len(aux)}개는 보조자료로")
                for it in ask:
                    cf = _cache_path(cache, it)
                    ROLE_PEND.append({"source": it.source, "uid": it.uid, "course": it.course, "title": it.title,
                                      "filename": it.filename, "candidates": [key], "uploaded": it.uploaded,
                                      "file": str(cf) if cf.exists() else "", "why": "", "role_q": True,
                                      "size": cf.stat().st_size if cf.exists() else 0})
                    notes.append(f"「{it.filename}」은 슬라이드인지 강의록인지 애매해서 빼고 만들었어요 · 애매한 자료에서 골라 주세요")
                if ask:
                    _append_pending(ROLE_PEND[-len(ask):])
                mids = [f"{i.source}:{i.uid}" for i in main_items]
                mc = merge_choice(key, mids) if len(main_items) > 1 else None
                split = len(main_items) > 1 and not (mc and mc.get("do") == "merge")
                if split:       # 강의록이 여러 개 → 합치지 않고 폴더에 (1), (2) … 로 따로 (합본은 「강의록 합치기」 탭에서)
                    mn = f"강의록 {len(main_items)}개 → 폴더에 따로 만듦: " + " / ".join(
                        f"({n}) {Path(i.filename).name}" for n, i in enumerate(main_items, 1))
                else:
                    mn = merge_note(main_items)      # 자료 여러 개를 한 강의록으로 합침 → 비고에 남김
                if mn:
                    notes.append(mn)
                fd = split_folder(d / name)
                pnames = [part_file(L, n, it.filename) for n, it in enumerate(main_items, 1)] if split else []
                with tempfile.TemporaryDirectory() as td:
                    work = Path(td)
                    outs = []                           # (저장할 이름, 만든 파일)
                    groups = [[it] for it in main_items] if split else [main_items]
                    cov_failed = False
                    for gi, grp in enumerate(groups, 1):
                        parts = []
                        for n, it in enumerate(grp):
                            w = work / f"g{gi}p{n}"
                            w.mkdir()
                            local = w / safe(Path(it.filename).name)
                            shutil.copy(_cache_path(cache, it), local)
                            ev("step", step="ppt" if local.suffix.lower() in (".ppt", ".pptx", ".key", ".odp") else "convert",
                               file=it.filename)
                            nb: List[str] = []
                            parts.append(to_pdf(local, w, rd, nb))
                            notes.extend(f"({gi}) {x}" for x in nb) if split else notes.extend(nb)
                        rd.last_failed = False
                        if CFG.get("cover", True):            # 설정: 표지 넣기
                            ev("step", step="cover")
                            if split:
                                L.extra["part"] = gi           # 표지 제목 줄: 1030-1(1)
                            try:
                                pdfs = [rd.cover(L, work / f"cover{gi}.pdf")] + parts
                            finally:
                                L.extra.pop("part", None)
                            cov_failed = cov_failed or rd.last_failed
                        else:
                            pdfs = parts
                        ev("step", step="merge", pages=None)
                        o = work / f"out{gi}.pdf"
                        render.merge(pdfs, o, paper=paper_size())   # 설정: 용지 크기 맞추기
                        outs.append((pnames[gi - 1] if split else name, o))
                    rd.last_failed = cov_failed
                    ev("step", step="save")
                    d.mkdir(parents=True, exist_ok=True)
                    tag0 = re.sub(r"\D", "", (old or {}).get("처리일시", ""))[4:8] or f"{datetime.now():%m%d}"
                    quiet = False                         # 새 자료 알림을 보내지 않음 (파일을 뺀 것뿐일 때)
                    if kind == "형식":
                        when0 = (old or {}).get("처리일시", "")
                        if _edited_after(d / name, when0) or _edited_after(fd, when0):   # 만든 뒤 필기 등으로 고친 파일 → 덮어쓰지 않고 _이전버전으로
                            _retire(d, name, tag0)
                            notes.append(f"만든 뒤 고친 파일(필기 등)은 _이전버전에 남겨 둠 ({tag0})")
                        report["reformat"].append(name)
                        status = (old or {}).get("상태") or "완료"
                        keep = [n for n in ((old or {}).get("비고") or "").split("; ")
                                if n and not re.match(r"강의록 \d+개 (합침|→ 폴더에 따로)", n)]
                        notes[:] = (keep + ([mn] if mn else [])) if keep else notes
                    elif kind == "갱신":
                        _retire(d, name, tag0)
                        if any(i.source == "직접" for i in use):       # 내 파일로 바꾼 것: 재업로드가 아님
                            report["new"].append(name)
                            status = "완료"
                            notes.insert(0, f"내 파일로 다시 만듦 (이전본 {tag0})")
                        else:
                            report["updated"].append(name)
                            status = "갱신"
                            o_ids = {":".join(x.split(":", 2)[:2]) for x in _sig_items((old or {}).get("서명") or "")}
                            n_ids = {f"{i.source}:{i.uid}" for i in use}
                            if o_ids and o_ids < n_ids:     # 옛 자료는 그대로 있고 새 자료가 더 올라옴 (재업로드 아님)
                                notes.insert(0, f"자료 {len(n_ids - o_ids)}개 더 올라옴 (이전본 {tag0})")
                            elif o_ids and n_ids < o_ids:   # 파일을 뺌 (다시 받지 않기 등)
                                report["updated"].remove(name)
                                report["new"].append(name)
                                status = "완료"
                                notes.insert(0, f"자료 {len(o_ids - n_ids)}개 빼고 다시 만듦 (이전본 {tag0})")
                                quiet = True
                            else:
                                notes.insert(0, f"재업로드 반영 (이전본 {tag0})")
                    elif kind == "역할":
                        _retire(d, name, tag0)
                        report["new"].append(name)
                        status = "완료"
                        notes.insert(0, f"고른 대로(본 강의록·보조자료) 다시 만듦 (이전본 {tag0})")
                    elif kind == "LMS교체":
                        _retire(d, name, tag0)          # 드라이브판(합본·따로 만든 폴더)은 _이전버전 으로
                        report.setdefault("upgraded", []).append(name)
                        status = "완료"
                    else:
                        if name not in report["new"]:
                            report["new"].append(name)
                        status = "완료"
                    if split:
                        if (d / name).exists():         # 예전에 합쳐 만든 파일 → _이전버전 (폴더와 같이 있으면 헷갈려서)
                            prev = d / "_이전버전"
                            prev.mkdir(exist_ok=True)
                            shutil.move(str(d / name), str(_backup_name(prev, name, tag0)))
                        tmpd = d / ("." + fd.name + "._만드는중")      # 점으로 시작 = 숨김 (도중에 꺼져도 클라우드에 안 올라감)
                        if tmpd.exists():
                            shutil.rmtree(tmpd)
                        tmpd.mkdir()
                        for nm_, o in outs:
                            shutil.move(str(o), str(tmpd / nm_))
                        if fd.exists():
                            shutil.rmtree(fd)
                        os.rename(tmpd, fd)
                    else:
                        shutil.move(str(outs[0][1]), str(d / name))
                        if fd.is_dir() and mc and mc.get("do") == "merge" and mc.get("del"):
                            shutil.rmtree(fd)            # 합본을 만들며 '나눠 만든 파일 지우기'를 고름
                            notes.append("합본을 만들고 나눠 만든 파일은 지움")
                        elif fd.is_dir() and mc and mc.get("do") == "merge":
                            notes.append(f"합본을 만들고 나눠 만든 파일은 '{fd.name}' 폴더에 그대로")
                    if (name in report["new"] or name in report["updated"]) and not quiet:
                        NEWS["lec"].append((L, "" if name in report["new"] else "다시 올라옴"))
                odir = d / (name[:-4] + "_원본")      # 설정: PPT·워드 원본도 같이 저장 (PDF로 올라온 자료는 PDF 그대로라 안 넣음)
                origs = [i for i in main_items if i.ext != "pdf"]
                when1 = (old or {}).get("처리일시", "")
                if CFG.get("keep_orig") and not origs and odir.exists():
                    _keep_or_drop(d, odir, when1, tag0)  # 원본이 모두 PDF가 됨 → 예전 원본 폴더 정리 (고쳤으면 _이전버전)
                if CFG.get("keep_orig") and origs:
                    if odir.exists():
                        _keep_or_drop(d, odir, when1, tag0)
                    odir.mkdir(parents=True)
                    for n_, it in enumerate(main_items, 1):
                        if it.ext == "pdf":
                            continue
                        pre = f"({n_}) " if split else ""
                        shutil.copy(_cache_path(cache, it), odir / safe(pre + Path(it.filename).name))
                    notes.append(f"원본 파일 {len(origs)}개는 '{odir.name}' 폴더에")
                rdir = d / (name[:-4] + "_참고자료")
                if refs:
                    if rdir.exists():
                        _keep_or_drop(d, rdir, when1, tag0)   # 고쳐 둔 참고자료는 _이전버전으로
                    rdir.mkdir(parents=True)
                    for it in refs:
                        shutil.copy(_cache_path(cache, it), rdir / safe(Path(it.filename).name))
                    notes.append(f"참고자료·보조자료 {len(refs)}개는 '{rdir.name}' 폴더에")
                elif rdir.exists() and kind != "형식":
                    _keep_or_drop(d, rdir, when1, tag0)
                recs = read_records(d)
                if old_name != name:             # 원본 이름이 바뀌어 파일 이름도 바뀜 → 옛 이름 파일은 _이전버전으로, 기록도 옮김
                    if (d / old_name).exists() or split_folder(d / old_name).is_dir():
                        try:
                            _retire(d, old_name, f"{datetime.now():%m%d}")
                        except Exception:
                            pass
                    recs.pop(old_name, None)
                    ro_ = d / (old_name[:-4] + "_참고자료")
                    if ro_.is_dir() and not refs:           # 옛 이름 참고자료 폴더 (새 이름 폴더는 위에서 다시 만듦)
                        try:
                            prev_ = d / "_이전버전"
                            prev_.mkdir(exist_ok=True)
                            shutil.move(str(ro_), str(unique_dir(prev_ / f"{ro_.name}_{datetime.now():%m%d}")))
                        except OSError:
                            pass
                    elif ro_.is_dir():
                        shutil.rmtree(ro_, ignore_errors=True)
                    _rename_extras(L, old_name, name, log)   # 추가자료도 새 이름으로 (중복·새 알림 안 생기게)
                    if had_orig:
                        notes.append("원본 파일 이름이 바뀌어 파일 이름도 바꿈")
                recs[name] = {"합본파일명": name, "출처": "+".join(i.source for i in use),
                              "원본파일명": " + ".join(i.filename for i in use),
                              "업로드일시": max(i.uploaded for i in use), "서명": signature(use, cover_failed=getattr(rd, "last_failed", False)),
                              "처리일시": f"{datetime.now():%Y-%m-%d %H:%M}",
                              "상태": status, "비고": "; ".join(notes),
                              "나눔": json.dumps([{"f": pn, "id": mid, "src": it.filename, "up": it.uploaded}
                                                  for pn, mid, it in zip(pnames, mids, main_items)], ensure_ascii=False) if split else ""}
                write_records(d, recs)
                save_orig_names()                   # {원본}: 다 만든 뒤에 저장
                st[key] = (status, "; ".join(notes))
                if key in REDO_NOW:
                    _redo_done([key])
                for n_ in notes:
                    log(f"   · {name}: {n_}")

            def process(idx, total, key, L, use, dropped, rnd, last):
                """강의 하나 처리.
                1바퀴: LMS가 안 되면 드라이브 자료로 바로 만들고, LMS는 2바퀴에서 한 번 더.
                드라이브에도 없으면 뒤로 미뤄 다시 (최대 3번)."""
                d, name = out_dir(L), out_name(L)
                print(f"  ({idx}/{total}) {L.course_folder} {name}", flush=True)
                ev.key = key
                ev("lecture", key=key, idx=idx, total=total, round=rnd,
                   files=[{"source": i.source, "name": i.filename} for i in use])
                def fin(result, notes_=None, msg=""):
                    ev("done", key=key, result=result, notes=list(notes_ or []), msg=msg, round=rnd)
                recs = read_records(d)
                sig = signature(use)
                old = recs.get(name)
                if not FORCE[0] and old and same_sig(old.get("서명"), sig) and has_out(d / name) and not mode_change(key, old):
                    report["same"].append(name)
                    nt = old.get("비고", "") or ""
                    mi = [i for i in use if not is_ref(i)]
                    mn = merge_note(mi) if mi else ""
                    if mn and "개 합침" not in nt and not split_parts(old):          # 예전에 합친 강의록도 비고에 보이게
                        nt = "; ".join(x for x in (nt, mn) if x)
                    st[key] = (old.get("상태") or "완료", nt)
                    if key in REDO_NOW:
                        _redo_done([key])
                    fin("same")
                    return
                is_lms = any(i.source in LMS_SOURCES for i in use)
                alt = drive_alt(dropped) if is_lms else []
                drive_made = bool(old) and same_sig(old.get("서명"), signature(alt)) and has_out(d / name) if alt else False
                notes: List[str] = []
                if any(i.source == "직접" for i in use):
                    notes.append("직접 넣은 자료로 만듦")
                if is_lms and alt:
                    notes.append("드라이브에도 있으나 LMS 자료 사용")
                try:
                    fetch(use, quick=(rnd == 0))
                except RetryLater as e:
                    if is_lms and alt:
                        if rnd == 0:
                            # LMS가 안 되면 드라이브부터: 바로 합본을 만들고 LMS는 2바퀴에서 한 번 더
                            log(f"   · {name}: LMS 안 받아짐 ({err(e)}) → 드라이브 자료로 먼저 만들고, LMS는 다음 바퀴에 다시")
                            if not drive_made and has_out(d / name):
                                log(f"   · {name}: 이미 만든 강의록은 그대로 두고, LMS 자료를 다음 바퀴에 다시 받아요")
                            elif not drive_made:
                                try:
                                    fetch(alt, quick=False)
                                    build(key, L, alt, ["LMS 다운로드 실패 → 드라이브 자료로 만듦 (LMS 나중에 다시)"],
                                          "새로")
                                except Exception as e2:
                                    log(f"   · {name}: 드라이브 자료도 실패 ({err(e2)})")
                            fin("drive_first", msg=err(e))
                            raise
                        # 2바퀴에서도 LMS 실패 → 드라이브 버전으로 마무리
                        log(f"   · {name}: LMS 다시 시도도 실패 → 드라이브 자료로 마무리")
                        if has_out(d / name):
                            st[key] = ((old or {}).get("상태") or "완료", "LMS 다운로드 실패 → 이미 만든 강의록 그대로 (드라이브 자료로 만듦과 같은 상태)")
                            fin("drive_kept", msg=err(e))
                            return
                        report["fail"].append(f"{name} ({err(e)})")
                        st[key] = ("실패", err(e))
                        fin("fail", msg=err(e))
                        return
                    lms_fails[key] = lms_fails.get(key, 0) + 1
                    if not last and lms_fails[key] < LMS_TRIES:
                        log(f"   · {name}: 지금은 안 받아져서 뒤로 미룸 ({err(e)})")
                        fin("defer", msg=err(e))
                        raise
                    report["fail"].append(f"{name} ({err(e)})")
                    log(f"실패 {name}: {err(e)}")
                    st[key] = ("실패", err(e))
                    fin("fail", msg=err(e))
                    return
                except ClosedOnLMS as e:
                    # 학습 기간 종료 = 자료는 있는데 못 받음 → 실패 · 아직 공개 전은 기다리면 받으니 '자료 없음' 그대로
                    st[key] = ("자료 없음" if "공개 전" in str(e) else "실패", f"{err(e)} · 드라이브에도 없음")
                    report.setdefault("closed", []).append(name)
                    log(f"   · {name}: {err(e)}, 드라이브에도 없음")
                    fin("closed", msg=err(e))
                    return
                except Exception as e:
                    report["fail"].append(f"{name} ({err(e)})")
                    log(f"실패 {name}: {err(e)}")
                    st[key] = ("실패", err(e))
                    fin("fail", msg=err(e))
                    return
                # 원본 다 받음 → 합본
                _nr = lambda x: re.sub(r"~(본|보조)(?= \||$)", "", x or "")
                if old and _same_source(old.get("서명"), sig):
                    kind = "형식"
                elif old and has_out(d / name) and _same_source(_nr(old.get("서명")), _nr(sig)):
                    kind = "역할"           # 애매한 자료에서 본/보조만 바꿈
                elif drive_made or (old and old.get("출처") == "드라이브" and is_lms and has_out(d / name)
                                    and "드라이브 자료로 만듦" in (old.get("비고") or "")):
                    kind = "LMS교체"
                    notes.append("LMS 자료로 교체")
                elif has_out(d / name):
                    kind = "갱신"
                else:
                    kind = "새로"
                try:
                    build(key, L, use, notes, kind)
                    if is_lms and alt:
                        report["replaced"].append(name)
                    fin("new" if any(i.source == "직접" for i in use) else {"새로": "new", "갱신": "updated", "형식": "redo", "LMS교체": "swap", "역할": "redo"}.get(kind, "new"), notes)
                except Exception as e:
                    # LMS 자료를 PDF로 못 바꿨는데 드라이브에 같은 강의 자료가 있으면 그걸로라도 만듦
                    if is_lms and alt:
                        try:
                            fetch(alt, quick=False)
                            build(key, L, alt, [f"LMS 자료 변환 실패 → 드라이브 자료로 만듦 ({err(e)[:60]})"], kind)
                            log(f"   · {name}: LMS 자료 변환 실패 → 드라이브 자료로 만듦")
                            fin("drive_first", msg="LMS 자료 변환 실패 → 드라이브 자료 사용")
                            return
                        except Exception as e2:
                            log(f"   · {name}: 드라이브 자료로도 실패 ({err(e2)})")
                    report["fail"].append(f"{name} ({err(e)})")
                    log(f"실패 {name}: {err(e)}")
                    st[key] = ("실패", err(e))
                    fin("fail", msg=err(e))

            # 한 바퀴 다 돌고, 미룬 것만 쉬었다가 다시 (10초 → 30초 → 60초)
            # 이미 받아 둔 그대로인 강의는 한꺼번에 건너뜀 → 중지 후 다시 받기 해도 남은 것부터
            work, n_same = [], 0
            for key, (L, use, dropped) in todo:
                d0, name0 = out_dir(L), out_name(L)
                old0 = read_records(d0).get(name0)
                if (not FORCE[0] and old0 and same_sig(old0.get("서명"), signature(use)) and has_out(d0 / name0) and not mode_change(key, old0)) \
                        or keep_past(L, old0, d0 / name0):
                    report["same"].append(name0)
                    st[key] = (old0.get("상태") or "완료", old0.get("비고", ""))
                    ev("done", key=key, result="same", notes=[], msg="", round=0, quiet=True)
                    n_same += 1
                else:
                    work.append((key, (L, use, dropped)))
            if n_same:
                log(f"이미 받아 둔 강의 {n_same}개는 건너뛰고(지난 강의는 다시 확인 안 함), 남은 {len(work)}개만 받아요")
                ev("skip", n=n_same, left=len(work))
            queue = work
            waits = [10, 30, 60]
            for rnd in range(len(waits) + 1):
                later = []
                last = rnd == len(waits)
                for idx, (key, (L, use, dropped)) in enumerate(queue, 1):
                    if not drive_only and not all(i.source == "직접" for i in use) and hasattr(lms, "wait_online") and not lms.wait_online():
                        log("인터넷이 20분 넘게 끊겨서 여기서 멈춰요. 남은 강의는 다음 실행 때 받아요.")
                        later = []
                        break
                    try:
                        process(idx, len(queue), key, L, use, dropped, rnd, last)
                    except RetryLater:
                        later.append((key, (L, use, dropped)))
                if not later:
                    break
                log(f"\n미룬 강의 {len(later)}개 → {waits[rnd]}초 쉬고 다시 시도 ({rnd + 1}/{len(waits)}번째)")
                ev("round", n=rnd + 2, waiting=[k for k, _ in later], wait=waits[rnd])
                time.sleep(waits[rnd])
                queue = later
        finally:
            if rd.template_error:
                log(f"   · 고른 표지 템플릿으로 만들지 못해 기본 표지를 썼어요 ({rd.template_error})")
            try:
                rd.close()
            except Exception:
                pass          # 브라우저가 이미 닫혔으면 무시 (원래 오류가 가려지지 않게)

      # ---- 필야가 아직이면 기다림 (강의록 쪽 브라우저는 먼저 닫음)
      try:
          if lms:
              lms.close()
      except Exception:
          pass
      if xt and xt.is_alive():
          ev("phase", text="추가자료 정리가 끝나길 기다리는 중")
          xt.join()
      xst = xbox["st"] if xbox["ran"] else None
      now = datetime.now()
      def past(L):   # 학기가 해를 넘기면(1·2월 강의) 다음 해로 본다
          y = _cal(L.month)
          return datetime(y, L.month, L.day) <= now
      x_pend = list(xbox["pend"])
      if lec_ran:
          miss = [L for L in scope if L.key not in plan and L.key not in stale_keys and past(L)
                  and not (drive_only and has_out(out_dir(L) / out_name(L)))]   # 드라이브만: 이미 있는 강의록은 '없음' 아님
          # 드라이브 연결이 안 된 과목은 '자료 없음'이 아니라 실패 (연결하면 받을 수 있을 수 있어서)
          miss = [L for L in miss if L.key not in NORETRY]      # 다시 시도하지 않기로 한 강의는 빠진 자료로 안 셈
          report["missing"] = [out_name(L) for L in miss if not drive.LINK.get(L.course)]
          report["fail"] += [f"{out_name(L)} (드라이브 연결이 안 되었어요)" for L in miss if drive.LINK.get(L.course)]
      report["pending"] = [f"{d.item.source} · {d.item.filename}" for d in pend + x_pend]
      try:
          save_pending(pend + x_pend, cache, ran=({"강의록"} if lec_ran else set()) | set(xbox["groups"]),
                       keep=_pend_keep(drive_only, manual_only) if lec_ran else None,
                       courses={norm_course(c) for c in want_courses})
      except Exception as e:
          log(f"애매한 자료 저장 실패: {err(e)}")

      rows = None
      try:
          if lec_ran:
              sc_ = [L for L in scope if L.key in plan or L.key in st] if drive_only else scope   # 드라이브만: 손댄 강의만 상태 갱신
              rows = notion_rows(sc_, decisions + nr_dropped, plan, st, pend, past)   # 업로드 날짜는 건너뛴 출처 것도
              if drive_only or manual_only:      # 이번에 안 본 출처의 업로드 날짜는 예전 값 그대로 (현황·노션에서 지워지지 않게)
                  _keep_dates(rows, ["LMS 업로드"] + (["드라이브 업로드"] if manual_only else []))
              save_status(rows, None if manual_only else source_states(sc_, decisions, plan, st, pend), xst, xbox["old"] or None,
                          skip=xbox["xskip"], oskip=xbox["oskip"], keep_src="LMS" if drive_only else None)   # 앱 화면(현황판)용
          elif xst is not None or xbox["old"]:
              save_extra_status(scope, xst, xbox["old"], skip=xbox["xskip"], oskip=xbox["oskip"])
      except Exception as e:
          log(f"현황 저장 실패: {err(e)}")
      if rows is not None and CFG.get("notion", {}).get("sources"):
          try:
              notion_sync.sync(rows, CFG["notion"]["sources"], DATA / "노션_상태.json", log)
          except Exception as e:
              log(f"노션 기록 실패: {err(e)}")
    finally:
        try:
            if lms:
                lms.close()
        except Exception:
            pass
        if xt and xt.is_alive():
            xt.join()

    write_report(log, report, started)
    errs = [e for e in (lec_error and ("강의록: " + lec_error + (" · 추가자료는 받았어요" if xbox["ran"] else "")),
                        xbox.get("error") and ("추가자료: " + str(xbox["error"]))) if e]
    ev("end", summary={k: len(v) for k, v in report.items()}, missing=[n for n in report["missing"]],
       **({"error": " / ".join(errs)} if errs else {}), target=target)
    n_new = len(report["new"]) + len(report["updated"])
    msg = f"강의록 새로 {len(report['new'])} · 갱신 {len(report['updated'])}"
    if report.get("extras"):
        msg += f" · 추가자료 {len(report['extras'])}"
    if report["pending"]:
        msg += f" · 애매한 자료 {len(report['pending'])}"
    if report["fail"]:
        msg += f" · 실패 {len(report['fail'])}"
    if args.auto:
        sched_log(ev="end", id=RUN_ID, msg=msg, error=" / ".join(errs) if errs else "")
    sent_news = False
    try:
        from . import notifier as _nt
        for k, title in (("lec", "강의록이 올라왔어요!"), ("x", "추가자료가 올라왔어요!")):
            if NEWS[k] and _nt.allowed(k):
                notify(title, news_text(NEWS[k]), k)
                sent_news = True
    except Exception:
        pass
    if errs:
        notify("강의록앱 · 받기 멈춤", " / ".join(errs)[:120], "err")
    elif sent_news and not report["pending"] and not report["fail"]:
        pass                                  # 새 자료 알림이 이미 갔으면 요약은 생략 (애매한 자료·실패가 있으면 보냄)
    elif not args.auto or n_new or report["pending"] or report["fail"] or report.get("extras"):
        notify("강의록앱 · 받기 끝", msg, "end")     # 직접 누른 받기는 늘 알림, 예약은 바뀐 게 있을 때만
    if lec_error:
        return 2
    if pend and not args.auto and sys.stdin.isatty():
        print(f"\n어느 강의인지 애매한 자료가 {len(pend)}개 있어요. 지금 골라 줄까요? (y/n) ", end="")
        if input().strip().lower().startswith("y"):
            resolve(None)
            print("\n고른 내용으로 다시 받기를 실행할게요.\n")
            return run(args)
    return 0


def notion_rows(scope, decisions, plan, st, pend, past) -> Dict[str, List[dict]]:
    """노션 표에 쓸 행: 강의날짜 · 교시 · 제목 · LMS 업로드 · 드라이브 업로드 · 최신 강의록 · 처리 여부 · 비고"""
    up: Dict[str, Dict[str, str]] = {}
    for dcs in decisions:
        if dcs.lecture and dcs.item.source != "직접":          # 직접 넣은 자료는 LMS·드라이브 업로드 날짜가 아님
            side = "LMS" if dcs.item.source in LMS_SOURCES else "드라이브"
            cur = up.setdefault(dcs.lecture.key, {})
            if dcs.item.uploaded > cur.get(side, ""):
                cur[side] = dcs.item.uploaded
    maybe: Dict[str, List[str]] = {}
    for dcs in pend:
        for L in dcs.candidates[:3]:
            maybe.setdefault(L.key, []).append(dcs.item.filename)
    now = datetime.now()
    out: Dict[str, List[dict]] = {}
    for L in scope:
        y = _cal(L.month)
        u = up.get(L.key, {})
        latest = max(i.uploaded for i in plan[L.key][1]) if L.key in plan else None
        if L.key in st:
            status, note = st[L.key]
        elif L.key in maybe:
            status, note = "확인 필요", "어느 강의인지 애매한 자료: " + ", ".join(maybe[L.key][:3])
        elif past(L) and L.key in NORETRY:
            status, note = "실패", "다시 시도하지 않기로 한 자료가 있어요 (" + "·".join(NORETRY[L.key]) + ")"
        elif past(L) and drive.LINK.get(L.course):
            status, note = "실패", "드라이브 연결이 안 되었어요 (" + drive.LINK[L.course] + ") → 설정 → 구글 드라이브 → 드라이브에서 고르기"
        elif past(L):
            status, note = "자료 없음", ""
        else:
            status, note = "예정", ""
        g = L.period_label
        out.setdefault(L.course, []).append({
            "키": L.key, "제목": L.title, "강의날짜": f"{y}-{L.mmdd[:2]}-{L.mmdd[2:]}", "교시": g,
            "차수": L.term_folder or "-", "LMS 업로드": _iso(u.get("LMS")),
            "드라이브 업로드": _iso(u.get("드라이브")), "최신 강의록": _iso(latest),
            "처리 여부": status, "비고": note})
    return out


STATUS = DATA / "현황.json"
NORETRY_FILE = DATA / "다시시도안함.json"     # {강의 키: {"LMS"|"드라이브": {"이유": ..., "시각": ...}}}
NORETRY: Dict[str, dict] = {}
_NR_LOCK = threading.Lock()


def noretry_load() -> Dict[str, dict]:
    try:
        d = json.loads(NORETRY_FILE.read_text("utf-8"))
        return {k: v for k, v in d.items() if isinstance(v, dict) and v} if isinstance(d, dict) else {}
    except Exception:
        return {}


def noretry_set(key: str, side: str, on: bool, why: str = "") -> Dict[str, dict]:
    """실패한 자료를 앞으로 다시 시도하지 않기 (켜기/끄기). 강의 하나 · 출처(LMS/드라이브) 하나 단위."""
    with _NR_LOCK:
        d = noretry_load()
        cur = dict(d.get(key) or {})
        if on:
            cur[side] = {"이유": (why or "")[:300], "시각": f"{datetime.now():%Y-%m-%d %H:%M}"}
        else:
            cur.pop(side, None)
        if cur:
            d[key] = cur
        else:
            d.pop(key, None)
        NORETRY_FILE.parent.mkdir(parents=True, exist_ok=True)
        tmp = NORETRY_FILE.with_suffix(f".{os.getpid()}.tmp")
        tmp.write_text(json.dumps(d, ensure_ascii=False, indent=1), "utf-8")
        safe_replace(tmp, NORETRY_FILE)
        return d


def _side_of(it) -> str:
    return "LMS" if it.source in LMS_SOURCES else "드라이브"


def choose_extras(decisions) -> Dict[str, tuple]:
    """필야: 강의별로 검수된(정리된) 것이 있으면 그것만, 없으면 검수 전 것. 같은 이름은 최신 하나."""
    per: Dict[str, tuple] = {}
    for d in decisions:
        if d.lecture and d.item.ext in ("pdf", "ppt", "pptx", "doc", "docx", "hwp", "hwpx"):
            per.setdefault(d.lecture.key, (d.lecture, []))[1].append(d.item)
    out = {}
    for k, (L, its) in per.items():
        ok = [i for i in its if i.fetch.get("checked")]
        use = ok or its
        groups: Dict[str, List[Item]] = {}
        for i in use:
            groups.setdefault(base_name(i), []).append(i)
        chosen = [prefer_slides(g)[-1] for g in groups.values()]      # 같은 이름 PDF·PPT → PPT
        chosen.sort(key=lambda i: (re.search(r"\((\d)\)", i.filename) and int(re.search(r"\((\d)\)", i.filename).group(1)) or 0, i.filename))
        out[k] = (L, chosen, bool(ok))
    return out


def linked_files() -> List[tuple]:
    """내 폴더로 연결한 선배 자료 → [(원본 파일, 정리 폴더 기준 자리)] · 클라우드 복사가 원본을 그 자리에 바로 올리게
    (정리 폴더에는 복사하지 않음 · 연결한 내 폴더 안의 파일만)"""
    try:
        st = json.loads(STATUS.read_text("utf-8")) if STATUS.exists() else {}
        lects = {L.key: L for L in load(DATA / "시간표.json")}
    except Exception:
        return []
    roots = {str(s_.get("label", "")).strip(): local_roots(str(s_.get("label", "")).strip())
             for s_ in old_sources() if s_.get("local") and not s_.get("folder")}
    out, seen, done = [], set(), set()
    for key, v in st.items():
        L = lects.get(key)
        if L is None:
            continue
        for lab, x in ((v or {}).get("선배필야") or {}).items():
            root = roots.get(str(lab).strip())
            links = (x or {}).get("links") or []
            if not root or not links:
                continue
            xd = extra_dir(L, lab)
            for p_ in links:
                pp = Path(p_)
                if not any(_within(pp, r_) for r_ in root) or not pp.is_file():
                    continue
                if (xd, str(pp)) in done:               # 같은 파일이 두 강의에 걸려 같은 폴더면 한 번만
                    continue
                done.add((xd, str(pp)))
                nm, k = pp.name, 2
                while (xd, nm) in seen:                 # 다른 파일인데 이름이 같으면 (2)
                    nm = f"{pp.stem} ({k}){pp.suffix}"
                    k += 1
                seen.add((xd, nm))
                r_ = rel_of(xd / nm)
                if r_:
                    out.append((pp, Path(r_)))
    return out


def link_extras(x_dec, scope_keys, log, ev=None, label: str = "") -> Dict[str, dict]:
    """내 컴퓨터 폴더로 연결한 선배 자료: 복사본을 만들지 않고 어느 강의 자료인지만 기억 (현황에서 원본을 바로 열기)
    · 사진·zip·키노트 등 어떤 파일이든 그대로 (변환하지 않으니까)"""
    ev = ev or (lambda *a, **k: None)
    per: Dict[str, tuple] = {}
    for d in x_dec:
        if d.lecture and d.lecture.key in scope_keys and d.item.fetch.get("path"):
            per.setdefault(d.lecture.key, (d.lecture, []))[1].append(d.item)
    ev("xplan", keys=list(per), lab=label)
    res: Dict[str, dict] = {}
    for key, (L, its) in per.items():
        its = sorted(its, key=lambda i: i.filename)
        paths = [str(i.fetch["path"]) for i in its]
        res[key] = {"상태": "연결", "파일수": len(its), "links": paths, "담당": []}
        ev("xdone", key=key, result="same", state="연결", takers=[], lab=label)
    if per:
        log(f"   · 선배 추가자료({xfolder(label)}): 내 폴더 자료 {sum(len(v[1]) for v in per.values())}개를 강의 {len(per)}개에 연결 (복사하지 않음)")
    return res


def process_extras(x_dec, scope_keys, cache: Path, log, report, ev=None, label: str = "") -> Dict[str, dict]:
    """필야 받기 → (필요하면 PDF로 변환) → A4로 맞춰 한 파일로 → 2. 추가자료/<과목>/<차수>/ 에 저장"""
    res: Dict[str, dict] = {}
    rep = report.setdefault("extras", [])
    ev = ev or (lambda *a, **k: None)
    plan_x = {k: v for k, v in choose_extras(x_dec).items() if k in scope_keys}
    if label:
        ev("xplan", keys=list(plan_x), lab=label)
    else:
        ev("xplan", keys=list(plan_x))
    for key, (L, use, checked) in plan_x.items():
        d, name = extra_dir(L, label), extra_name(L, label)
        takers = sorted({t for t in (drive.taker(i.filename) for i in use) if t})
        state = "완료" if checked else "검수 전"
        recs = read_records(d)
        old = recs.get(name)
        sig = signature(use, extra=True)
        info = {"상태": state, "담당": takers, "파일수": len(use)}
        if (not FORCE[0] and old and same_sig(old.get("서명"), sig, True) and (d / name).exists()) or keep_past(L, old, d / name, True):
            if old and not same_sig(old.get("서명"), sig, True):          # 지난 강의라 다시 확인 안 함 → 상태는 기록 그대로
                info = {"상태": old.get("상태") or state, "담당": takers, "파일수": len(use)}
            elif old and old.get("상태") != state:          # 같은 파일인데 검수 폴더로 옮겨졌음(검수 전 → 검수됨) → 기록의 상태만 고침
                with REC_LOCK:
                    recs = read_records(d)
                    if name in recs:
                        recs[name] = {**recs[name], "상태": state,
                                      "비고": ("담당 " + "·".join(takers) if takers else "") + ("" if checked else " · 검수 전 자료")}
                        write_records(d, recs)
                if checked:
                    log(f"   · 추가자료{f'({xfolder(label)})' if label else ''} {name}: 검수됨 (같은 파일이 검수 폴더로 옮겨짐)")
            res[key] = info
            ev("xdone", key=key, result="same", state=state, takers=takers, lab=label)
            continue
        ev("xstart", key=key, files=[i.filename for i in use], lab=label)
        try:
            parts = []
            with tempfile.TemporaryDirectory() as td:
                work = Path(td)
                for n, it in enumerate(use):
                    cf = _cache_path(cache, it)
                    if not cf.exists():
                        drive.download(it, cf)
                    src = work / f"{n}_{safe(Path(it.filename).name)}"
                    shutil.copy(cf, src)
                    parts.append(src if src.suffix.lower() == ".pdf" else render.convert(src, "pdf", work / f"c{n}"))
                tmp_out = work / "out.pdf"
                render.merge(parts, tmp_out, paper=paper_size())   # 용지 크기로 맞춤 (가로는 가로, 세로는 세로)
                d.mkdir(parents=True, exist_ok=True)
                name2 = extra_name(L, label)        # 만드는 사이 강의록 이름({원본})이 바뀌었으면 새 이름으로
                if name2 != name:
                    if (d / name).exists() and not (d / name2).exists():
                        os.replace(d / name, d / name2)
                    name = name2
                if (d / name).exists():
                    prev = d / "_이전버전"
                    prev.mkdir(exist_ok=True)
                    tag = re.sub(r"\D", "", (old or {}).get("처리일시", ""))[4:8] or f"{datetime.now():%m%d}"
                    shutil.move(str(d / name), str(_backup_name(prev, name, tag)))
                    how = "정리본으로 교체" if old and old.get("상태") == "검수 전" and checked else "다시 올라와서 갱신"
                else:
                    how = "새로"
                shutil.move(str(tmp_out), str(d / name))
            with REC_LOCK:       # 학번별로 동시에 돌아서 같은 폴더 기록을 다시 읽고 합쳐서 씀
                recs = read_records(d)
                recs[name] = {"합본파일명": name, "출처": "추가자료" + label, "원본파일명": " + ".join(i.filename for i in use),
                              "업로드일시": max(i.uploaded for i in use), "서명": sig,
                              "처리일시": f"{datetime.now():%Y-%m-%d %H:%M}", "상태": state,
                              "비고": ("담당 " + "·".join(takers) if takers else "") + ("" if checked else " · 검수 전 자료")}
                write_records(d, recs)
            rep.append(f"{name} ({how}{'' if checked else ', 검수 전'})")
            NEWS["x"].append((L, (xfolder(label) if label else "") + ("" if how == "새로" else (" · " if label else "") + "다시 올라옴")))
            log(f"   · 추가자료{f'({xfolder(label)})' if label else ''} {name}: {how}" + ("" if checked else " (검수 전 자료 → 검수본이 올라오면 다시 받아요)"))
            res[key] = info
            ev("xdone", key=key, result={"새로": "new", "정리본으로 교체": "swap"}.get(how, "updated"), state=state, takers=takers, lab=label)
        except Exception as e:
            log(f"   · 추가자료 {name}: 실패 ({err(e)})")
            res[key] = {**info, "상태": "실패", "이유": err(e)}
            ev("xdone", key=key, result="fail", state="실패", msg=err(e), lab=label)
    return res


def source_states(scope, decisions, plan, st, pend) -> Dict[str, dict]:
    """강의별·출처별(LMS / 드라이브) 자료 상태: 존재 / 비존재 / 주의 (+ 이유, 올린 날짜)"""
    by: Dict[str, Dict[str, list]] = {}
    for d in decisions:
        if d.lecture and d.item.source != "직접":          # 직접 넣은 자료는 LMS·드라이브 출처가 아님
            side = "LMS" if d.item.source in LMS_SOURCES else "드라이브"
            by.setdefault(d.lecture.key, {}).setdefault(side, []).append(d.item)
    maybe: Dict[str, set] = {}
    for d in pend:
        side = "LMS" if d.item.source in LMS_SOURCES else "드라이브"
        for L in d.candidates[:3]:
            maybe.setdefault(L.key, set()).add(side)
    out = {}
    for L in scope:
        status, note = st.get(L.key, ("", ""))
        use = plan[L.key][1] if L.key in plan else []
        used = {"LMS" if i.source in LMS_SOURCES else "드라이브" for i in use if i.source != "직접"}
        res = {}
        for side in ("LMS", "드라이브"):
            its = by.get(L.key, {}).get(side, [])
            live = [i for i in its if i.fetch.get("kind") != "closed"]
            date = max((i.uploaded for i in (live or its)), default="")
            date = date[:10] if re.match(r"\d{4}-\d{2}-\d{2}", date or "") else ""
            nr = NORETRY.get(L.key, {}).get(side)
            if nr is not None:
                r = ("실패", "다시 시도하지 않기로 했어요" + (f" · {nr.get('이유')}" if nr.get("이유") else ""))
            elif its:
                if side == "LMS" and not live:
                    r = ("주의", "LMS에 아직 공개 전 (교수님이 정한 시간에 열려요)") if any(i.fetch.get("why") == "notyet" for i in its) \
                        else ("실패", "학습 기간 종료 (LMS 사이트에서도 못 받음)")
                elif side == "LMS" and ("드라이브 자료로 만듦" in (note or "") or "LMS 다운로드 실패" in (note or "")):    # LMS 자료는 실패 (강의록은 드라이브로 만듦)
                    r = ("실패", ("LMS 자료를 PDF로 바꾸지 못해서" if "변환 실패" in note else "LMS 자료를 받지 못해서")
                         + f" 드라이브 자료로 대신 만들었어요 (다음 받기 때 다시 시도){' · ' + note if '변환 실패' in note else ''}")
                elif status == "실패" and side in used:
                    r = ("실패", f"다운로드 실패: {note}")
                else:
                    r = ("존재", "")
            elif side in maybe.get(L.key, set()):
                r = ("주의", "어느 강의인지 애매한 자료가 있어요 → 애매한 자료 탭")
            elif side == "드라이브" and drive.LINK.get(L.course):
                r = ("미연결", drive.LINK[L.course])
            else:
                r = ("비존재", "")
            res[side] = {"상태": r[0], "이유": r[1], "날짜": date, "개수": len(live or its)}
        out[L.key] = res
    return out


def _keep_dates(rows: Dict[str, List[dict]], cols: List[str]):
    try:
        prev = json.loads(STATUS.read_text("utf-8")) if STATUS.exists() else {}
    except Exception:
        prev = {}
    for rs in rows.values():
        for r in rs:
            p = prev.get(r["키"]) or {}
            for c in cols:
                if not r.get(c) and p.get(c):
                    r[c] = p[c]


def save_status(rows: Dict[str, List[dict]], srcs: Optional[Dict[str, dict]] = None, extras: Optional[Dict[str, dict]] = None,
                old: Optional[Dict[str, Dict[str, dict]]] = None, skip: Optional[set] = None, oskip: Optional[dict] = None,
                keep_src: Optional[str] = None):
    """skip/oskip: 목록을 못 읽은 과목의 강의 → 필야 칸은 예전 값 그대로 · keep_src: 이번에 안 본 출처(예: LMS) 칸은 예전 값 그대로"""
    skip, oskip = skip or set(), oskip or {}
    """강의별 마지막 처리 결과를 저장 (이번 실행 범위만 덮어씀)."""
    try:
        cur = json.loads(STATUS.read_text("utf-8")) if STATUS.exists() else {}
    except Exception:
        cur = {}
    stamp = f"{datetime.now():%Y-%m-%d %H:%M}"
    for course, rs in rows.items():
        for r in rs:
            prev = cur.get(r["키"]) or {}
            src_ = srcs.get(r["키"], {}) if srcs is not None else prev.get("출처상태", {})
            if keep_src and srcs is not None:
                src_ = {**src_, keep_src: (prev.get("출처상태") or {}).get(keep_src, {})}
            cur[r["키"]] = {**r, "과목": course, "확인시각": stamp, "출처상태": src_,
                            "필야": extras.get(r["키"], {"상태": "없음"}) if extras is not None and r["키"] not in skip else prev.get("필야", {}),
                            "선배필야": {**prev.get("선배필야", {}), **{lab: res.get(r["키"], {"상태": "없음"}) for lab, res in (old or {}).items()
                                                                   if r["키"] not in oskip.get(lab, set())}}}
    tmp = STATUS.with_suffix(".tmp")
    tmp.write_text(json.dumps(cur, ensure_ascii=False, indent=1), "utf-8")
    safe_replace(tmp, STATUS)


def save_extra_status(scope, extras: Optional[Dict[str, dict]], old: Optional[Dict[str, Dict[str, dict]]] = None,
                      skip: Optional[set] = None, oskip: Optional[dict] = None):
    skip, oskip = skip or set(), oskip or {}
    """필야만 받았을 때: 강의록 현황은 그대로 두고 필야 칸만 바꿈"""
    try:
        cur = json.loads(STATUS.read_text("utf-8")) if STATUS.exists() else {}
    except Exception:
        cur = {}
    for L in scope:
        if L.key in cur:
            if extras is not None and L.key not in skip:
                cur[L.key]["필야"] = extras.get(L.key, {"상태": "없음"})
            if old:
                cur[L.key]["선배필야"] = {**cur[L.key].get("선배필야", {}), **{lab: res.get(L.key, {"상태": "없음"}) for lab, res in old.items()
                                                                       if L.key not in oskip.get(lab, set())}}
    tmp = STATUS.with_suffix(".tmp")
    tmp.write_text(json.dumps(cur, ensure_ascii=False, indent=1), "utf-8")
    safe_replace(tmp, STATUS)


def _iso(s):
    return s[:10] if s and re.match(r"\d{4}-\d{2}-\d{2}", s) else None


def write_report(log: Log, rep: Dict[str, list], started: datetime):
    titles = [("new", "새로 만든 합본"), ("updated", "교수님 재업로드로 갱신 (이전본은 _이전버전/)"),
              ("replaced", "드라이브에도 있었지만 LMS 자료로 만든 강의"), ("extras", "추가자료 새로 받음·갱신"),
              ("upgraded", "드라이브 자료로 먼저 만들었다가 LMS 자료로 교체"),
              ("closed", "LMS 학습 기간 종료 + 드라이브에도 없음 (사이트에서도 못 받음)"), ("missing", "자료 없음 (지난 강의)"),
              ("pending", "어느 강의인지 확인 필요 → '강의록앱 확인'"), ("fail", "실패")]
    log("")
    log(f"== 요약: 새로 {len(rep['new'])} · 갱신 {len(rep['updated'])} · 다시 만듦 {len(rep.get('reformat', []))} · 변경 없음 {len(rep['same'])} "
        f"· 자료 없음 {len(rep['missing'])} · 확인 필요 {len(rep['pending'])} · 실패 {len(rep['fail'])} · 추가자료 {len(rep.get('extras', []))}")
    for k, t in titles:
        if rep.get(k):
            log(f"\n[{t}] {len(rep[k])}")
            for x in rep[k]:
                log(f"  - {x}")
    d = SAVE_ROOT / "_실행기록"
    d.mkdir(parents=True, exist_ok=True)
    (d / f"{started:%Y-%m-%d_%H%M}.txt").write_text("\n".join(log.lines), "utf-8")
    if log.live and log.live.exists():
        try:
            log.live.unlink()
        except Exception:
            pass


# ---------------------------------------------------------------- 확인 (애매한 자료)
PENDING = DATA / "확인필요.json"


PREFETCH_ERR: dict = {}     # 애매한 자료 미리 받기 실패 이유 (화면에 보여 줌)


def _pend_keep(drive_only: bool, manual_only: bool) -> Optional[set]:
    """이번에 목록을 안 본 출처의 애매한 자료는 그대로 둠 (드라이브만 → LMS, 직접 넣은 자료만 → LMS·드라이브)"""
    if manual_only:
        return set(LMS_SOURCES) | {"드라이브"}
    if drive_only:
        return set(LMS_SOURCES)
    return None


def save_pending(pend, cache: Optional[Path] = None, ran: Optional[set] = None, courses: Optional[set] = None,
                 keep: Optional[set] = None):
    """ran: 이번에 실제로 확인한 묶음('강의록', '필야', '필야21' …). 확인 안 한 묶음의 기존 애매한 자료는 그대로 둠.
    None 이면 전부 새로 씀."""
    data = []
    try:
        old = json.loads(PENDING.read_text("utf-8")) if PENDING.exists() else []
    except Exception:
        old = []
    grp = lambda e: str(e.get("source", "")) if str(e.get("source", "")).startswith("필야") else "강의록"
    if ran is not None:     # 이번에 확인 안 한 묶음 · 이번 범위 밖 과목의 애매한 자료는 그대로 둠
        data += [e for e in old if grp(e) not in ran
                 or (courses is not None and norm_course(e.get("course", "")) not in courses)
                 or (keep is not None and e.get("source") in keep)]       # 이번에 안 본 출처(드라이브만 → LMS)는 그대로
    for d in pend:
        cf = _cache_path(cache, d.item) if cache else None
        data.append({"source": d.item.source, "uid": d.item.uid, "course": d.item.course, "title": d.item.title,
                     "filename": d.item.filename, "candidates": [L.key for L in d.candidates],
                     "uploaded": d.item.uploaded,
                     "file": str(cf) if cf and cf.exists() else "",
                     "why": PREFETCH_ERR.get(f"{d.item.source}:{d.item.uid}", "") if not (cf and cf.exists()) else "",
                     "size": cf.stat().st_size if cf and cf.exists() else 0})
    data += [dict(e) for e in ROLE_PEND]
    _rl = load_roles()
    data += [e for e in old if e.get("role_q") and f"{e.get('source')}:{e.get('uid')}" not in _rl]   # 아직 안 고른 본/보조 질문은 남겨 둠
    try:
        decided = set(Memory(DATA / "매칭기억.json").data)
    except Exception:
        decided = set()
    roles = load_roles()
    seen, out = set(), []
    for e in data:
        k = f"{e.get('source')}:{e.get('uid')}"
        if (k in roles if e.get("role_q") else k in decided) or k in seen:   # 받기 도중 화면에서 이미 골랐으면 다시 안 띄움
            continue
        seen.add(k)
        out.append(e)
    tmp = PENDING.with_suffix(".tmp")
    tmp.write_text(json.dumps(out, ensure_ascii=False, indent=1), "utf-8")
    safe_replace(tmp, PENDING)


def _append_pending(entries):
    """받는 도중 생긴 애매한 자료(본/보조)를 바로 목록에 더함"""
    try:
        old = json.loads(PENDING.read_text("utf-8")) if PENDING.exists() else []
    except Exception:
        old = []
    ks = {f"{e.get('source')}:{e.get('uid')}" for e in old}
    old += [e for e in entries if f"{e['source']}:{e['uid']}" not in ks]
    tmp = PENDING.with_suffix(".tmp")
    tmp.write_text(json.dumps(old, ensure_ascii=False, indent=1), "utf-8")
    safe_replace(tmp, PENDING)


def resolve(_args) -> int:
    if not PENDING.exists():
        print("확인할 자료가 없어요.")
        return 0
    data = json.loads(PENDING.read_text("utf-8"))
    lectures = {L.key: L for L in load(DATA / "시간표.json")}
    mem = Memory(DATA / "매칭기억.json")
    if not data:
        print("확인할 자료가 없어요.")
        return 0
    for n, e in enumerate(data, 1):
        it = Item(e["source"], e["course"], e["uid"], e["title"], e["filename"], "")
        cands = [lectures[k] for k in e["candidates"] if k in lectures]
        if not cands:
            cands = [L for L in lectures.values() if norm_course(L.course) == norm_course(e["course"])]
        print(f"\n({n}/{len(data)}) [{e['source']}] {e['filename']}")
        if e["title"] and e["title"] not in e["filename"]:
            print(f"      제목: {e['title']}")
        for k, L in enumerate(cands[:12], 1):
            print(f"   {k}. {L.mmdd}-{L.start}교시 {L.title} ({'·'.join(L.profs)})")
        print("   0. 강의록 아님(앞으로 무시)   Enter: 건너뛰기   여러 강의면 1,2")
        a = input("   선택: ").strip()
        if not a:
            continue
        if a == "0":
            mem.set(it, "제외")
            continue
        picks = [cands[int(x) - 1].key for x in re.findall(r"\d+", a) if 0 < int(x) <= len(cands[:12])]
        if picks:
            mem.set(it, "||".join(picks))
    PENDING.write_text("[]", "utf-8")
    print("\n저장했어요.")
    return 0


# ---------------------------------------------------------------- 키체인
def set_login(_args) -> int:
    import getpass
    from . import secrets_store
    uid = input("경북대 통합로그인 아이디(학번): ").strip()
    if not uid:
        return 1
    pw = getpass.getpass("비밀번호 (화면에 안 보여요. 이 컴퓨터의 키체인/자격 증명 관리자에만 저장돼요): ")
    if not pw:
        return 1
    ok, msg = secrets_store.put(KEYCHAIN_SERVICE, uid, pw)
    print("저장했어요." if ok else (msg or "저장 실패"))
    return 0 if ok else 1


LABEL = "kr.knu.lecture-app"
AGENTS = Path.home() / "Library" / "LaunchAgents"


def _sched_times(cfg) -> List[str]:
    sc = cfg.get("schedule", {})
    if "times" in sc:
        return list(sc["times"])
    if "hour" in sc:
        return [f"{sc['hour']:02d}:{sc.get('minute', 0):02d} 전체"]
    return []


def _uid() -> str:
    return subprocess.run(["id", "-u"], capture_output=True, text=True).stdout.strip()


def _clear_agents():
    for f in AGENTS.glob(f"{LABEL}*.plist"):
        subprocess.run(["launchctl", "bootout", f"gui/{_uid()}/{f.stem}"], capture_output=True)
        f.unlink()


EVERY_MIN, EVERY_MAX = 10, 24 * 60          # 「n분·n시간마다」 예약: 10분 ~ 24시간


def _every_txt(ev: int) -> str:
    return f"매 {ev // 60}시간" if ev % 60 == 0 else f"매 {ev}분"


def _norm_slot(s) -> tuple:
    """(시, 분, 범위, 대상, 학번[, 마다(분)]) → 6개 칸으로 · 마다 = 0 이면 매일 그 시각"""
    s = tuple(s) + ("둘다", "", 0)[max(0, len(s) - 3):]
    h, mi, mode, tgt, ys, ev = s[:6]
    tgt = tgt or "둘다"
    ev = int(ev or 0)
    if ev:
        h = mi = 0
    return (h, mi, mode, tgt, ys if tgt != "강의록" else "", ev)


def _slot_txt(sl) -> str:
    h, mi, mode, tgt, ys, ev = sl
    return (_every_txt(ev) if ev else f"{h:02d}:{mi:02d}") + f" {mode}" + (f" {tgt}" if tgt != "둘다" else "") + (f" 학번{ys}" if ys else "")


def _parse_slot(tok: str):
    """'12:30' '12:30오늘' '1230=전체' '07:00 오늘 필야' · '매 30분 오늘' '매 2시간' → (12, 30, '오늘'|'전체', '둘다'|'강의록'|'필야', 학번, 마다(분))"""
    m = re.fullmatch(r"매\s*(\d{1,4})\s*(분|시간)\s*[=:/-]?\s*(오늘|전체)?\s*(둘다|강의록|필야)?\s*(?:학번\s*([\d,·]+))?", tok.strip())
    if m:
        ev = int(m.group(1)) * (60 if m.group(2) == "시간" else 1)
        if not EVERY_MIN <= ev <= EVERY_MAX:
            return None
        ys = ",".join(re.findall(r"\d+", m.group(5) or ""))
        return 0, 0, m.group(3) or "전체", m.group(4) or "둘다", ys, ev
    m = re.fullmatch(r"(\d{1,2}):?(\d{2})\s*[=:/-]?\s*(오늘|전체)?\s*(둘다|강의록|필야)?\s*(?:학번\s*([\d,·]+))?", tok.strip())
    if not m or int(m.group(1)) > 23 or int(m.group(2)) > 59:
        return None
    ys = ",".join(re.findall(r"\d+", m.group(5) or ""))
    return int(m.group(1)), int(m.group(2)), m.group(3) or "전체", m.group(4) or "둘다", ys, 0


WIN_TASK = "강의록앱_예약"


_SCHED_CACHE: list = []


def schedule_on() -> bool:
    """예약이 실제로 등록돼 있는지 (맥: LaunchAgent / Windows: 작업 스케줄러)"""
    if os.name == "nt":            # schtasks 는 느려서 화면이 자주 물어도 1분에 한 번만 확인
        c = _SCHED_CACHE
        if c and time.time() - c[0] < 60:
            return c[1]
        try:
            r = subprocess.run(["schtasks", "/Query", "/FO", "CSV", "/NH"], capture_output=True, text=True, timeout=20)
            on = WIN_TASK in (r.stdout or "")
        except Exception:
            on = False
        _SCHED_CACHE[:] = [time.time(), on]
        return on
    return any(AGENTS.glob(f"{LABEL}*.plist"))


def _win_schedule(slots) -> int:
    """Windows 작업 스케줄러에 매일 실행 등록 (로그인한 동안, 창 없이)"""
    _SCHED_CACHE.clear()
    r = subprocess.run(["schtasks", "/Query", "/FO", "CSV", "/NH"], capture_output=True, text=True)
    for line in (r.stdout or "").splitlines():
        name = line.split(",")[0].strip('"').lstrip("\\")
        if name.startswith(WIN_TASK):
            subprocess.run(["schtasks", "/Delete", "/F", "/TN", name], capture_output=True)
    pyw = Path(sys.executable)
    if pyw.name.lower() == "python.exe" and (pyw.parent / "pythonw.exe").exists():
        pyw = pyw.parent / "pythonw.exe"          # 검은 창 없이
    rc = 0
    for i, (h, mi, mode, tgt, ys, ev) in enumerate(sorted(set(slots))):
        args = ["-m", "lecture_app", "받기", "--자동"] + (["--오늘"] if mode == "오늘" else []) \
            + (["--대상", tgt] if tgt in ("강의록", "필야") else []) + (["--학번", *ys.split(",")] if ys else [])
        # 실행기(lecture_app_run.pyw)가 앱 폴더를 알아서 찾음 → 작업 폴더 설정·검은 창 없이 실행
        tr = f'"{pyw}" "{APP / "lecture_app_run.pyw"}" ' + " ".join(args[2:])
        name = f"{WIN_TASK}_e{ev}_{i}" if ev else f"{WIN_TASK}_{h:02d}{mi:02d}_{i}"
        if ev:                                    # n분·n시간마다 (지금부터)
            sc = ["/SC", "HOURLY", "/MO", str(ev // 60)] if ev % 60 == 0 and ev < 24 * 60 else \
                 (["/SC", "DAILY"] if ev == 24 * 60 else ["/SC", "MINUTE", "/MO", str(ev)])
            st = (datetime.now() + timedelta(minutes=1)).strftime("%H:%M")
            r = subprocess.run(["schtasks", "/Create", "/F", *sc, "/ST", st, "/TN", name, "/TR", tr], capture_output=True, text=True)
        else:
            r = subprocess.run(["schtasks", "/Create", "/F", "/SC", "DAILY", "/ST", f"{h:02d}:{mi:02d}", "/TN", name, "/TR", tr],
                               capture_output=True, text=True)
        if r.returncode:
            print(f"{_slot_txt((h, mi, mode, tgt, ys, ev))} 등록 실패: {(r.stderr or r.stdout).strip()[:120]}")
            rc = r.returncode
    return rc


def _apply_schedule(slots) -> int:
    if os.name == "nt":
        slots = [_norm_slot(s) for s in slots]
        rc = _win_schedule(slots)
        _SCHED_CACHE.clear()
        shown = [_slot_txt(sl) for sl in sorted(set(slots))]
        with CFG_LOCK:
            cfg = read_cfg()
            cfg["schedule"] = {"times": shown}
            write_cfg(cfg)
        print("예약을 껐어요." if not shown else "예약: " + ", ".join(("" if x.startswith("매") else "매일 ") + x for x in shown) + " (컴퓨터가 켜져 있고 로그인돼 있을 때)")
        return rc
    if sys.platform != "darwin":
        print("자동 예약은 macOS·Windows에서만 돼요.")
        return 1
    import plistlib
    _clear_agents()
    AGENTS.mkdir(parents=True, exist_ok=True)
    (APP / "logs").mkdir(exist_ok=True)
    rc = 0
    slots = [_norm_slot(s) for s in slots]
    for h, mi, mode, tgt, ys, ev in sorted(set(slots)):
        label = (f"{LABEL}.e{ev}m" if ev else f"{LABEL}.{h:02d}{mi:02d}") + ({"강의록": ".lec", "필야": ".x"}.get(tgt, "")) + (f".y{ys.replace(',', '-')}" if ys else "")
        args = [str(APP / ".venv" / "bin" / "python"), "-m", "lecture_app", "받기", "--자동"]
        if mode == "오늘":
            args.append("--오늘")
        if tgt in ("강의록", "필야"):
            args += ["--대상", tgt]
        if ys:
            args += ["--학번", *ys.split(",")]
        data = {"Label": label, "ProgramArguments": args, "WorkingDirectory": str(APP),
                **({"StartInterval": ev * 60} if ev else {"StartCalendarInterval": {"Hour": h, "Minute": mi}}),
                "StandardOutPath": str(APP / "logs" / "auto.log"),
                "StandardErrorPath": str(APP / "logs" / "auto.log")}
        plist = AGENTS / f"{label}.plist"
        with open(plist, "wb") as f:
            plistlib.dump(data, f)
        r = subprocess.run(["launchctl", "bootstrap", f"gui/{_uid()}", str(plist)], capture_output=True, text=True)
        if r.returncode:
            print(f"{_slot_txt((h, mi, mode, tgt, ys, ev))} 등록 실패: {r.stderr.strip()}")
            rc = r.returncode
    shown = [_slot_txt(sl) for sl in sorted(set(slots))]
    with CFG_LOCK:
        cfg = read_cfg()
        cfg["schedule"] = {"times": shown}
        write_cfg(cfg)
    print("예약을 껐어요." if not shown else "예약: " + ", ".join(("" if x.startswith("매") else "매일 ") + x for x in shown))
    return rc


def set_schedule(args) -> int:
    """강의록앱 예약 12:30오늘 18:00전체 22:30 / 강의록앱 예약 끄기 / (인자 없으면 하나씩 물어봄)"""
    joined = " ".join(args.time or []).strip()
    # '07:00 오늘 필야 학번21,20' 같은 한 덩어리를 통째로 찾음 (띄어쓰기·쉼표로 자르면 깨짐)
    toks = [m.group(0) for m in re.finditer(r"(?:매\s*\d{1,4}\s*(?:분|시간)|\d{1,2}:?\d{2})(?:\s*[=:/-]?\s*(?:오늘|전체))?(?:\s*(?:둘다|강의록|필야))?(?:\s*학번\s*[\d,·]+)?", joined)] \
        or [t for t in re.split(r"[\s,]+", joined) if t]
    if toks == ["끄기"] or toks == ["off"]:
        return _apply_schedule([])
    if toks:
        slots = []
        for t in toks:
            sl = _parse_slot(t)
            if not sl:
                print(f"'{t}' 형식을 모르겠어요. 예: 12:30오늘 22:30전체")
                return 1
            slots.append(sl)
        return _apply_schedule(slots)
    # 대화형: 시간대를 하나씩
    cur = _sched_times(CFG) if schedule_on() else []
    print("지금 예약: " + (", ".join(cur) if cur else "없음"))
    print("\n새 예약을 하나씩 넣어요. (기존 예약은 지워져요 / 아무것도 안 넣고 Enter면 그대로 둬요)")
    slots = []
    while True:
        t = input(f"\n{len(slots) + 1}번째 시간 (예: 12:30, 끝내려면 Enter): ").strip()
        if not t:
            break
        sl = _parse_slot(t)
        if not sl:
            print("  22:30 처럼 적어 주세요.")
            continue
        print("  이 시간에는")
        print("    1. 모든 강의 확인 (Enter)")
        print("    2. 오늘 강의만 확인")
        c = input("  > ").strip()
        slots.append((sl[0], sl[1], "오늘" if c == "2" else "전체", "둘다", "", sl[5]))
        print(f"  → {sl[0]:02d}:{sl[1]:02d} {'오늘' if c == '2' else '전체'}")
    if not slots:
        if input("\n예약을 모두 끌까요? (y/N) ").strip().lower().startswith("y"):
            return _apply_schedule([])
        print("그대로 뒀어요.")
        return 0
    return _apply_schedule(slots)


def menu(_args) -> int:
    """더블클릭용: 과목·범위를 골라서 받기"""
    lectures = load(DATA / "시간표.json")
    cs = tt_courses(lectures)
    print("\n과목을 고르세요 (여러 개는 띄어쓰기, Enter = 전체)")
    for i, c in enumerate(cs, 1):
        print(f"  {i}. {c}")
    pick = input("> ").strip()
    chosen = [cs[int(x) - 1] for x in re.findall(r"\d+", pick) if 0 < int(x) <= len(cs)]
    print("\n범위를 고르세요")
    print("  1. 오늘 강의만")
    print("  2. 전체 (Enter)")
    print("  3. 날짜 지정 (예: 1024 10/27)")
    print("  4. 차수 지정")
    r = input("> ").strip() or "2"
    extra = []
    if r == "1":
        extra = ["--오늘"]
    elif r == "3":
        ds = input("날짜 (띄어쓰기로 여러 개): ").strip().split()
        if ds:
            extra = ["--날짜", *ds]
    elif r == "4":
        t = input("차수 (예: 2): ").strip()
        if t.isdigit():
            extra = ["--차수", t]
    return main(["받기"] + (["--과목", *chosen] if chosen else []) + extra)


def main(argv=None):
    ap = argparse.ArgumentParser(prog="강의록앱")
    sub = ap.add_subparsers(dest="cmd")
    a = sub.add_parser("받기")
    a.add_argument("--과목", dest="course", nargs="+", help="과목명 (여러 개 가능)")
    a.add_argument("--차수", dest="term", type=int)
    a.add_argument("--자동", dest="auto", action="store_true", help="예약 실행(창·질문 없음)")
    a.add_argument("--오늘", dest="today", action="store_true", help="오늘 강의만")
    a.add_argument("--날짜", dest="dates", nargs="+", help="특정 날짜만 (예: 1024 10/27)")
    a.add_argument("--학번", dest="years", nargs="+", help="필야 학번만 (예: 22 21)")
    a.add_argument("--처음부터", dest="force", action="store_true", help="이미 만든 것도 전부 다시 만들기")
    a.add_argument("--강의", dest="keys", nargs="+", help="이 강의들만 (시간표 키: 과목|날짜-교시|제목)")
    a.add_argument("--새표지", dest="remake", action="store_true", help="표지·용지·글꼴 설정이 바뀐 강의록을 새 설정으로 다시 만들기")
    a.add_argument("--출처", dest="src", choices=["전체", "드라이브"], default="전체",
                   help="강의록을 어디서 찾을지: 전체(LMS+드라이브) / 드라이브(LMS 로그인 없이 학년 드라이브만)")
    a.add_argument("--대상", dest="target", choices=["둘다", "강의록", "필야"], default="둘다",
                   help="강의록만 / 필야만 / 둘 다 (기본)")
    sub.add_parser("확인")
    sub.add_parser("메뉴")
    sub.add_parser("로그인정보")
    sub.add_parser("노션연결")
    g = sub.add_parser("화면")
    g.add_argument("--상주", dest="stay", action="store_true", help="창을 닫아도 꺼지지 않음 (로그인할 때 켜 두는 용도)")
    g.add_argument("--창없이", dest="nowin", action="store_true", help="화면 서버만 켜고 창은 안 엶")
    sub.add_parser("창")
    sub.add_parser("메뉴막대")
    e = sub.add_parser("예약")
    e.add_argument("time", nargs="*", help="12:30 18:00 22:30 또는 끄기")
    args = ap.parse_args(argv)
    try:
        if args.cmd == "확인":
            return resolve(args)
        if args.cmd == "메뉴":
            return menu(args)
        if args.cmd == "로그인정보":
            return set_login(args)
        if args.cmd == "예약":
            return set_schedule(args)
        if args.cmd == "노션연결":
            return notion_sync.save_token()
        if args.cmd == "화면":
            from . import gui
            return gui.serve(open_window=not args.nowin, stay=args.stay)
        if args.cmd == "창":
            from . import gui
            return gui.open_only()
        if args.cmd == "메뉴막대":
            from . import menubar
            return menubar.main()
        if args.cmd is None:
            args = ap.parse_args(["받기"])
        return run(args)
    except KeyboardInterrupt:
        return 130
    except Exception:
        tb = traceback.format_exc()
        hint = ""
        if re.search(r"Connection closed|has been closed|Target closed|driver", tb):
            hint = ("\n[설명] 앱이 쓰는 브라우저가 도중에 꺼졌어요. 앱이 연 Chrome 창을 닫았거나(⌘Q 포함), "
                    "맥이 잠자기에 들어갔거나, 메모리가 부족했을 때 생겨요. 다시 실행하면 이어서 받아요.\n")
        if Events.current:
            Events.current("end", error=tb.strip().splitlines()[-1][:200])
        lg = Log.current
        head = ("\n".join(lg.lines) + "\n\n----- 오류 -----\n") if lg and lg.lines else ""
        print(tb + hint)
        d = SAVE_ROOT / "_실행기록"
        d.mkdir(parents=True, exist_ok=True)
        (d / f"{datetime.now():%Y-%m-%d_%H%M}_오류.txt").write_text(head + tb + hint, "utf-8")
        if lg and lg.live and lg.live.exists():
            try:
                lg.live.unlink()
            except Exception:
                pass
        notify("강의록앱", "오류가 났어요. 매뉴얼 정리/_실행기록 을 확인해 주세요.", "err")
        return 1


if __name__ == "__main__":
    sys.exit(main())
