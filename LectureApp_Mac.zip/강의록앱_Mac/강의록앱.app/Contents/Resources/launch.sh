#!/bin/bash
# 앱 화면 열기.
# 화면 서버는 macOS(launchd)가 로그인할 때부터 켜 둠(--상주) → Dock의 강의록앱 아이콘이 언제 눌러도 바로 열림
# 예약 실행과 같은 파이썬 권한(데스크탑 폴더 접근 등)을 써서, 앱 아이콘 권한 때문에 막히는 일이 없음
APP="$HOME/강의록앱"
LBL="kr.knu.lectureapp-gui"
PL="$HOME/Library/LaunchAgents/$LBL.plist"
U="$(/usr/bin/id -u)"
mkdir -p "$APP/logs" "$HOME/Library/LaunchAgents"
# 업데이트 도중 전원이 꺼져 앱 코드 폴더가 없으면 직전 버전으로 되살림 (개발 폴더는 건드리지 않음)
if [ ! -f "$APP/lecture_app/__main__.py" ] && [ ! -e "$APP/.git" ]; then
  OLD="$(ls -d "$APP"/lecture_app_이전_* 2>/dev/null | sort | tail -1)"
  BAK="$APP/logs/업데이트_이전/lecture_app"
  if [ -n "$OLD" ] && [ -f "$OLD/__main__.py" ]; then
    [ -e "$APP/lecture_app" ] && mv "$APP/lecture_app" "$APP/lecture_app_실패_$(date +%s)"
    mv "$OLD" "$APP/lecture_app" && echo "$(date '+%F %T') [실행기] 앱 폴더가 없어서 $(basename "$OLD") 를 제자리로 되살림" >> "$APP/logs/업데이트.log"
  elif [ -f "$BAK/__main__.py" ]; then
    [ -e "$APP/lecture_app" ] && mv "$APP/lecture_app" "$APP/lecture_app_실패_$(date +%s)"
    cp -R "$BAK" "$APP/lecture_app" && echo "$(date '+%F %T') [실행기] 앱 폴더가 없어서 logs/업데이트_이전 백업으로 되살림" >> "$APP/logs/업데이트.log"
  fi
fi
PRE=""
if [ "$(/usr/sbin/sysctl -n hw.optional.arm64 2>/dev/null)" = "1" ] && /usr/bin/arch -arm64 "$APP/.venv/bin/python" -c "" 2>/dev/null; then
  PRE="<string>/usr/bin/arch</string><string>-arm64</string>"
fi
cat > "$PL" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>$LBL</string>
  <key>ProgramArguments</key><array>$PRE<string>$APP/.venv/bin/python</string><string>-m</string><string>lecture_app</string><string>화면</string><string>--상주</string><string>--창없이</string></array>
  <key>WorkingDirectory</key><string>$APP</string>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
  <key>StandardOutPath</key><string>$APP/logs/화면.log</string>
  <key>StandardErrorPath</key><string>$APP/logs/화면.log</string>
</dict></plist>
PLIST
# 새로 설치·업데이트했거나 서버가 안 켜져 있으면 다시 켬 (그 밖엔 켜져 있는 서버를 그대로 씀)
if [ "$1" = "restart" ] || ! /usr/bin/curl -s -m 1 http://127.0.0.1:8765/api/ping | grep -q ok; then
  /bin/launchctl bootout "gui/$U/$LBL" 2>/dev/null
  /usr/bin/pkill -f "lecture_app 화면" 2>/dev/null
  sleep 0.5
  /bin/launchctl bootstrap "gui/$U" "$PL" 2>>"$APP/logs/화면.log" || /bin/launchctl kickstart -k "gui/$U/$LBL" 2>>"$APP/logs/화면.log"
fi
# 창 열기 (크롬에서 '앱 설치'를 했으면 강의록앱 아이콘 창으로)
cd "$APP" && $( [ -n "$PRE" ] && echo /usr/bin/arch -arm64 ) "$APP/.venv/bin/python" -m lecture_app 창 >>"$APP/logs/화면.log" 2>&1 &
exit 0
