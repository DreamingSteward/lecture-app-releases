#!/bin/bash
# 강의록앱 설치·업데이트 (맥). 앱을 처음 열었거나 새 버전일 때 창 없이 한 번 돌아가요 (터미널 안 뜸 · 기록은 logs/설치.log).
# 앱 파일 복사 · 파이썬 환경까지만 하고 바로 앱 화면을 엶. 필요한 프로그램은 앱 처음 설정에서 동의한 뒤 앱이 받음 (lecture_app/deps.py).
# 받아 둔 강의록·설정·시간표·매칭 기억은 건드리지 않아요.
RES="$1"
APP="$HOME/강의록앱"
trap 'rmdir "$APP/logs/setup.lock" 2>/dev/null' EXIT      # 설치가 끝나거나 멈추면 '설치 중' 표시를 지움
PAY="$RES/app"
B=$'\033[1m'; G=$'\033[32m'; R=$'\033[31m'; N=$'\033[0m'
say(){ printf "\n${B}▶ %s${N}\n" "$1"; }
note(){ /usr/bin/osascript -e "display notification \"$1\" with title \"강의록앱\"" >/dev/null 2>&1; }
fail(){ printf "\n${R}%s${N}\n\n" "$1"; /usr/bin/osascript -e "display dialog \"$1\" with title \"강의록앱\" buttons {\"확인\"} default button 1 with icon caution" >/dev/null 2>&1; exit 1; }
printf "${B}강의록앱 설치·업데이트${N}  (버전 %s)\n" "$(cat "$PAY/VERSION")"
echo "몇 분 걸릴 수 있어요. 끝나면 앱 화면이 저절로 열려요."

say "1/3 앱 파일 복사 → ~/강의록앱"
mkdir -p "$APP"
/usr/bin/rsync -a --delete --exclude "__pycache__" "$PAY/lecture_app/" "$APP/lecture_app/" || fail "앱 파일을 복사하지 못했어요."
mkdir -p "$APP/fonts"; /usr/bin/rsync -a --exclude "user" "$PAY/fonts/" "$APP/fonts/"
cp -f "$PAY/requirements.txt" "$PAY/lecture_app_run.pyw" "$APP/"
cp -fX "$PAY/앱 다시 켜기.command" "$APP/" 2>/dev/null && chmod 755 "$APP/앱 다시 켜기.command" && /usr/bin/xattr -d com.apple.quarantine "$APP/앱 다시 켜기.command" 2>/dev/null
for f in config.json 시간표.json; do [ -f "$APP/$f" ] || cp "$PAY/$f" "$APP/$f"; done   # 내 설정·시간표는 그대로
[ -f "$APP/매칭기억.json" ] || echo "{}" > "$APP/매칭기억.json"

say "2/3 파이썬 확인"
PY=""
ARM=""; [ "$(/usr/sbin/sysctl -n hw.optional.arm64 2>/dev/null)" = "1" ] && ARM=1
for c in /opt/homebrew/bin/python3.12 /opt/homebrew/bin/python3.11 /opt/homebrew/bin/python3 /usr/local/bin/python3.12 /usr/local/bin/python3.11 /usr/local/bin/python3 /usr/bin/python3; do
  [ -x "$c" ] || continue
  # 애플 실리콘 맥: 인텔용(로제타) 파이썬은 빼고 (앱이 arm64 로 실행돼서 'Bad CPU type' 이 남)
  if [ -n "$ARM" ]; then /usr/bin/arch -arm64 "$c" -c "import sys; assert sys.version_info >= (3,9)" 2>/dev/null || continue
  else "$c" -c "import sys; assert sys.version_info >= (3,9)" 2>/dev/null || continue; fi
  PY="$c"; break
done
if [ -z "$PY" ]; then
  xcode-select --install 2>/dev/null
  fail "강의록앱을 열려면 파이썬이 필요해요. 곧 뜨는 「개발자 도구 설치」 창에서 [설치]를 누르고, 끝나면 강의록앱을 다시 열어 주세요."
fi
echo "사용할 파이썬: $PY ($("$PY" -V 2>&1))"
if [ -x "$APP/.venv/bin/python" ]; then   # 망가졌거나(파이썬을 지움) 애플 실리콘에서 인텔용으로 만들어진 환경은 새로 만듦
  if [ -n "$ARM" ]; then /usr/bin/arch -arm64 "$APP/.venv/bin/python" -c "import sys" 2>/dev/null || rm -rf "$APP/.venv"
  else "$APP/.venv/bin/python" -c "import sys" 2>/dev/null || rm -rf "$APP/.venv"; fi
fi
[ -x "$APP/.venv/bin/python" ] || "$PY" -m venv "$APP/.venv" || fail "앱 전용 파이썬 환경을 만들지 못했어요."
"$APP/.venv/bin/python" -m pip --version >/dev/null 2>&1 || "$APP/.venv/bin/python" -m ensurepip --upgrade --default-pip >>"$APP/logs/설치.log" 2>&1 || true   # pip 없이 만들어진 환경 (새 맥에서 봄) → 앱이 받을 때 다시 확인

# 필요한 프로그램(꾸러미 · 자동 로그인 브라우저 · LibreOffice)은 여기서 받지 않음 → 앱 처음 설정에서 동의한 뒤 앱이 받음

say "3/3 마무리"
cp -f "$PAY/VERSION" "$APP/VERSION"
/bin/bash "$RES/launch.sh" restart
printf "\n${G}${B}설치 끝! 앱 화면이 열려요.${N}\n"
exit 0
