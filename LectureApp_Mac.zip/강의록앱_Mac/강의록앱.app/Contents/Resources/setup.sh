#!/bin/bash
# 강의록앱 설치·업데이트 (맥). 앱을 처음 열었거나 새 버전일 때 터미널 창에서 한 번 돌아가요.
# 받아 둔 강의록·설정·시간표·매칭 기억은 건드리지 않아요.
RES="$1"
APP="$HOME/강의록앱"
trap 'rmdir "$APP/logs/setup.lock" 2>/dev/null' EXIT      # 설치가 끝나거나 멈추면 '설치 중' 표시를 지움
PAY="$RES/app"
B=$'\033[1m'; G=$'\033[32m'; R=$'\033[31m'; N=$'\033[0m'
say(){ printf "\n${B}▶ %s${N}\n" "$1"; }
fail(){ printf "\n${R}%s${N}\n\n" "$1"; read -n 1 -s -r -p "아무 키나 누르면 닫혀요"; exit 1; }
clear
printf "${B}강의록앱 설치·업데이트${N}  (버전 %s)\n" "$(cat "$PAY/VERSION")"
echo "몇 분 걸릴 수 있어요. 끝나면 앱 화면이 저절로 열려요."

say "1/5 앱 파일 복사 → ~/강의록앱"
mkdir -p "$APP"
/usr/bin/rsync -a --delete --exclude "__pycache__" "$PAY/lecture_app/" "$APP/lecture_app/" || fail "앱 파일을 복사하지 못했어요."
mkdir -p "$APP/fonts"; /usr/bin/rsync -a --exclude "user" "$PAY/fonts/" "$APP/fonts/"
cp -f "$PAY/requirements.txt" "$PAY/lecture_app_run.pyw" "$APP/"
cp -fX "$PAY/앱 다시 켜기.command" "$APP/" 2>/dev/null && chmod 755 "$APP/앱 다시 켜기.command" && /usr/bin/xattr -d com.apple.quarantine "$APP/앱 다시 켜기.command" 2>/dev/null
for f in config.json 시간표.json; do [ -f "$APP/$f" ] || cp "$PAY/$f" "$APP/$f"; done   # 내 설정·시간표는 그대로
[ -f "$APP/매칭기억.json" ] || echo "{}" > "$APP/매칭기억.json"

say "2/5 파이썬 확인"
PY=""
ARM=""; [ "$(/usr/sbin/sysctl -n hw.optional.arm64 2>/dev/null)" = "1" ] && ARM=1
for c in /opt/homebrew/bin/python3.12 /opt/homebrew/bin/python3.11 /opt/homebrew/bin/python3 /usr/local/bin/python3.12 /usr/local/bin/python3.11 /usr/local/bin/python3 /usr/bin/python3; do
  [ -x "$c" ] || continue
  # 애플 실리콘 맥: 인텔용(로제타) 파이썬은 빼고 (앱이 arm64 로 실행돼서 'Bad CPU type' 이 남)
  if [ -n "$ARM" ]; then /usr/bin/arch -arm64 "$c" -c "import sys; assert sys.version_info >= (3,9)" 2>/dev/null || continue
  else "$c" -c "import sys; assert sys.version_info >= (3,9)" 2>/dev/null || continue; fi
  PY="$c"; break
done
if [ -z "$PY" ]; then
  echo "파이썬이 필요해요. 곧 뜨는 '개발자 도구 설치' 창에서 [설치]를 누르고, 끝나면 강의록앱을 다시 열어 주세요."
  xcode-select --install 2>/dev/null
  fail "설치가 끝나면 강의록앱을 다시 열어 주세요."
fi
echo "사용할 파이썬: $PY ($("$PY" -V 2>&1))"
if [ -x "$APP/.venv/bin/python" ]; then   # 망가졌거나(파이썬을 지움) 애플 실리콘에서 인텔용으로 만들어진 환경은 새로 만듦
  if [ -n "$ARM" ]; then /usr/bin/arch -arm64 "$APP/.venv/bin/python" -c "import sys" 2>/dev/null || rm -rf "$APP/.venv"
  else "$APP/.venv/bin/python" -c "import sys" 2>/dev/null || rm -rf "$APP/.venv"; fi
fi
[ -x "$APP/.venv/bin/python" ] || "$PY" -m venv "$APP/.venv" || fail "앱 전용 파이썬 환경을 만들지 못했어요."

say "3/5 필요한 프로그램 설치 (처음엔 몇 분 걸려요)"
"$APP/.venv/bin/python" -m pip install -q --upgrade pip
# 메뉴 막대(rumps)는 따로: 실패해도 설치는 계속 (앱이 나중에 다시 설치해 봐요)
REQ="$(mktemp)"; grep -v '^rumps' "$APP/requirements.txt" > "$REQ"
"$APP/.venv/bin/python" -m pip install -q -r "$REQ" || { rm -f "$REQ"; fail "프로그램 설치에 실패했어요. 인터넷 연결을 확인하고 강의록앱을 다시 열어 주세요."; }
rm -f "$REQ"
"$APP/.venv/bin/python" -m pip install -q "rumps>=0.4" || echo "(메뉴 막대 프로그램은 나중에 앱이 다시 설치해 볼게요)"
"$APP/.venv/bin/python" -m playwright install chromium || fail "자동 로그인용 브라우저를 받지 못했어요. 인터넷 연결을 확인하고 다시 열어 주세요."

say "4/5 LibreOffice (PPT → PDF 변환) 확인"
lo_ok(){ [ -x "/Applications/LibreOffice.app/Contents/MacOS/soffice" ] || [ -x "$HOME/Applications/LibreOffice.app/Contents/MacOS/soffice" ] || command -v soffice >/dev/null; }
if lo_ok; then
  echo "${G}있어요.${N}"
else
  if command -v brew >/dev/null; then
    brew install --cask libreoffice || true
  fi
  if ! lo_ok; then      # 홈브루가 없으면 공식 사이트에서 직접 받아 설치 (약 300MB)
    echo "LibreOffice를 받아서 설치할게요 (무료, 약 300MB · 몇 분 걸려요)."
    LB="https://download.documentfoundation.org/libreoffice/stable"
    LV=$(curl -fsSL "$LB/" 2>/dev/null | grep -oE 'href="[0-9]+\.[0-9]+\.[0-9]+/"' | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | sort -t. -k1,1n -k2,2n -k3,3n | tail -1)
    if [ -n "$ARM" ]; then LA=aarch64; LF=aarch64; else LA=x86-64; LF=x86_64; fi
    LT="$(mktemp -d)"
    if [ -n "$LV" ] && curl -fL --progress-bar -o "$LT/lo.dmg" "$LB/$LV/mac/$LF/LibreOffice_${LV}_MacOS_${LA}.dmg"; then
      MP=$(/usr/bin/hdiutil attach -nobrowse -readonly "$LT/lo.dmg" 2>/dev/null | grep -o '/Volumes/.*' | head -1)
      if [ -n "$MP" ] && [ -d "$MP/LibreOffice.app" ]; then
        /usr/bin/ditto "$MP/LibreOffice.app" "/Applications/LibreOffice.app" 2>/dev/null \
          || { mkdir -p "$HOME/Applications"; /usr/bin/ditto "$MP/LibreOffice.app" "$HOME/Applications/LibreOffice.app"; }
      fi
      [ -n "$MP" ] && /usr/bin/hdiutil detach -quiet "$MP" 2>/dev/null
    fi
    rm -rf "$LT"
  fi
  if lo_ok; then
    echo "${G}LibreOffice 설치 완료.${N}"
  else
    printf "\n${R}${B}LibreOffice를 자동으로 설치하지 못했어요. 꼭 직접 설치해 주세요!${N}\n"
    echo "  · 없으면 PPT로 올라온 강의록이 「실패」로 떠요 (PDF 강의록은 받아져요)."
    echo "  · 곧 열리는 페이지에서 macOS용을 받아 → 받은 파일을 열고 LibreOffice를 '응용 프로그램' 폴더로 끌어다 놓기."
    echo "  · 설치한 뒤 앱에서 받기를 다시 돌리면 실패한 강의록이 만들어져요."
    open "https://www.libreoffice.org/download/download-libreoffice/"
    read -n 1 -s -r -p "확인했으면 아무 키나 누르세요"; echo
  fi
fi

say "5/5 마무리"
cp -f "$PAY/VERSION" "$APP/VERSION"
/bin/bash "$RES/launch.sh" restart
printf "\n${G}${B}설치 끝! 앱 화면이 열려요.${N}\n이 창은 닫아도 돼요.\n"
sleep 2
exit 0
