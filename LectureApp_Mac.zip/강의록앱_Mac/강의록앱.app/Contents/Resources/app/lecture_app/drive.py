"""구글 드라이브(링크 공개 폴더) 「26년 본과 2학년/<학기>/<과목>/매뉴얼/<MMDD>/파일」 목록·다운로드.
로그인 없이 공개 보기 페이지(embeddedfolderview)를 읽고, 파일은 gdown으로 받는다."""
from __future__ import annotations

import html
import os
import re
from pathlib import Path
from typing import Optional, List, Tuple

import requests

from .matching import Item
from .timetable import norm_course

UA = {"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_0) AppleWebKit/537.36 Chrome/124 Safari/537.36",
      "Accept-Language": "ko-KR,ko;q=0.9"}

ENTRY = re.compile(
    r'<div class="flip-entry" id="entry-([\w-]+)".*?<a href="([^"]+)".*?<div class="flip-entry-title">(.*?)</div>'
    r'.*?<div class="flip-entry-last-modified"><div>(.*?)</div>', re.S)


def list_folder(folder_id: str) -> List[Tuple[str, str, bool, str]]:
    """[(id, 이름, 폴더여부, 수정표시)]"""
    r = requests.get("https://drive.google.com/embeddedfolderview", params={"id": folder_id, "hl": "ko"},
                     headers=UA, timeout=60)
    r.raise_for_status()
    out = []
    for fid, href, name, mod in ENTRY.findall(r.text):
        out.append((fid, html.unescape(name).strip(), "/folders/" in href, html.unescape(mod).strip()))
    return out


def _find(entries, pred):
    for e in entries:
        if pred(e):
            return e
    return None


_folders: dict = {}
LINK: dict = {}              # 받기 때 과목별 드라이브 연결 상태: 과목 → "" (연결됨) / 연결 안 된 이유
COURSE_MAP: dict = {}        # 설정: 시간표 과목 → 드라이브 과목 폴더 id (이름이 많이 달라서 직접 골라 준 것)
MANUAL_MAP: dict = {}        # 설정: 시간표 과목 → 매뉴얼(강의록) 폴더 id · '-' = 매뉴얼 없음 (자동으로 못 찾거나 다른 폴더일 때)
EXTRAS_MAP: dict = {}        # 설정: 시간표 과목 → 추가자료 폴더 id · '-' = 추가자료 없음
EXTRAS_LAYOUT: dict = {}     # 설정: 우리 학년 추가자료 위치 {"container": 과목 폴더들이 든 폴더 id(비면 학기 폴더), "sub": 과목 폴더 안 폴더 이름("" = 과목 폴더 전체)}
EXTRA_RE = re.compile(r"추가|필야|필기|정리본|요약|족보|노트|note", re.I)          # 추가자료 · 필야 · 필기 …
SEM_TOKEN = "{학기}"
MANUAL_RE = re.compile(r"매뉴얼|메뉴얼|강의록|강의\s*자료|강의안|강의\s*슬라이드|슬라이드|수업\s*자료|lecture|manual|slides?", re.I)   # 학번마다 이름이 달라요


def _bigrams(s: str) -> set:
    return {s[i:i + 2] for i in range(len(s) - 1)} or {s}


_RN2 = {"I": "1", "II": "2", "III": "3", "IV": "4"}


def _cnum(s: str):
    """과목 이름 → (몸통, 끝 번호) · '생식성장발달II' → ('생식성장발달', '2'), '의학연구 1' → ('의학연구', '1')"""
    s = re.sub(r"\s*[\(\[（][\d\s/~\-.,월일]+[\)\]）]\s*$", "", str(s or ""))   # 끝의 기간 표시 빼기 '진단의 기본 (8/11 - 8/28)'
    s = re.sub(r"\s*[\(\[（][가-힣\s·,]{1,12}[\)\]）]\s*$", "", s)                 # 끝의 설명 빼기 '생식성장발달 1 (산부인과)'
    k = norm_course(s)
    m = re.search(r"(IV|III|II|I|\d)$", k)
    if m and re.search(r"[가-힣]$", k[:m.start()] or "x"):
        return k[:m.start()], _RN2.get(m.group(1), m.group(1))
    return k, ""


ALL_COURSES: list = []       # 받기 때 시간표 과목 전체 (다른 과목과 이름이 똑같은 폴더는 비슷한 이름으로 가져가지 않게)


def match_course_folder(course: str, entries, cmap: Optional[dict] = None, others=None):
    """학기 폴더 안에서 시간표 과목의 폴더 찾기 → ((id, 이름), 방법) · 방법: 고름/같음/포함/비슷
    1) 직접 골라 둔 폴더 ('-' 이면 「이 과목 폴더 없음」으로 골라 둔 것)
    2) 이름이 같음 (번호 앞 · 띄어쓰기 · 점 무시, 2 = II)
    3) 한쪽이 다른 쪽을 포함 (감염학 ⊂ 인체감염학)  4) 글자 겹침이 큰 폴더 하나
    3)·4)는 후보가 하나뿐일 때만 · 끝 번호(I·II·1·2)가 둘 다 있으면 같아야 함 · 다른 과목과 이름이 똑같은 폴더는 빼요"""
    dirs = [(e[0], e[1]) for e in entries if e[2]]
    cm = COURSE_MAP if cmap is None else cmap
    fid = (cm or {}).get(course)
    if fid == "-":
        return None, "고름"
    if isinstance(fid, list):                       # 내 폴더: 과목마다 폴더 여러 개를 직접 고름 → (첫 폴더, 「폴더 N개」)
        fs = [str(x) for x in fid if str(x).strip()]
        if not fs:
            return None, "고름"
        return (fs[0], Path(fs[0]).name if len(fs) == 1 else f"{Path(fs[0]).name} 외 {len(fs) - 1}개"), "고름"
    if fid:
        f = next((x for x in dirs if x[0] == fid), None)
        if f:
            return f, "고름"
    base, num = _cnum(course)
    same = lambda n: _cnum(n) == (base, num)
    f = next((x for x in dirs if same(x[1])), None)
    if f:
        return f, "같음"
    oth = [o for o in (ALL_COURSES if others is None else others) if _cnum(o) != (base, num)]
    taken = {x[0] for x in dirs for o in oth if _cnum(x[1]) == _cnum(o)}
    cands = []
    for x in dirs:
        if x[0] in taken:
            continue
        b2, n2 = _cnum(x[1])
        if num and n2 and num != n2:
            continue
        cands.append((x, b2))
    inc = [x for x, b2 in cands if len(b2) >= 3 and len(base) >= 3 and (b2 in base or base in b2)]
    if len(inc) == 1:
        return inc[0], "포함"
    kb = _bigrams(base)
    sc = sorted(((len(kb & _bigrams(b2)) / max(1, len(kb | _bigrams(b2))), x) for x, b2 in cands), key=lambda z: -z[0])
    if sc and sc[0][0] >= 0.5 and (len(sc) == 1 or sc[0][0] - sc[1][0] >= 0.15):
        return sc[0][1], "비슷"
    return None, ""


def find_manual(entries):
    """과목 폴더 안의 강의록 폴더 (매뉴얼·강의록·강의자료). 없고 날짜 폴더(MMDD)가 바로 있으면 과목 폴더 자체"""
    m = _find(entries, lambda e: e[2] and MANUAL_RE.search(e[1]) and "추가" not in e[1])
    return m


def _course_folder(root_id: str, semester: str, course_name: str, log):
    """「26년 본과 2학년/<학기>/<과목>」 폴더 (한 번 찾으면 기억)"""
    if not root_id:                   # 처음 설정에서 학년 드라이브를 안 넣음 → 드라이브는 건너뜀
        if not _folders.get("_noroot"):
            _folders["_noroot"] = True
            log("드라이브: 학년 드라이브 링크가 없어서 건너뛰어요 (설정 탭 → 구글 드라이브에 넣어 주세요)")
        LINK[course_name] = "학년 드라이브가 연결되지 않았어요"
        return None
    k = (root_id, semester, course_name)
    if k not in _folders:
        if semester.startswith("id:"):      # 처음 설정에서 고른 학기 폴더 (드라이브 어디에 있든, 이름이 뭐든)
            sem = (semester[3:], "", True, "")
        else:
            sem = _find(list_folder(root_id), lambda e: e[2] and e[1] == semester)
        if not sem:
            log(f"드라이브: '{semester}' 폴더 없음 (설정 탭 → 구글 드라이브 → 드라이브에서 고르기)")
            _folders[k] = None
        else:
            f, how = match_course_folder(course_name, list_folder(sem[0]))
            if f and how in ("포함", "비슷"):
                log(f"드라이브: '{course_name}' 과목은 이름이 비슷한 '{f[1]}' 폴더로 찾았어요")
            _folders[k] = (f[0], f[1], True, "") if f else None
            if not f:
                _folders[("why",) + k] = ("이 과목은 「이 과목 폴더 없음」으로 골라 두었어요" if how == "고름"
                                          else "드라이브에서 이 과목 폴더를 못 찾았어요 (폴더 이름이 달라요)")
        if not sem:
            _folders[("why",) + k] = f"드라이브에서 학기 폴더({semester})를 못 찾았어요"
    LINK[course_name] = "" if _folders[k] else _folders.get(("why",) + k, "드라이브 폴더를 못 찾았어요")
    return _folders[k]


def extras_for_course(root_id: str, semester: str, course_name: str, log) -> List[Item]:
    """「<과목>/추가자료」의 필야(학생 필기·정리본). 하위 폴더까지 모두.
    '검수 전' 폴더에 있는 것은 fetch['checked']=False (나중에 정리된 판이 올라오면 그걸로 바꿈)."""
    ex = extras_folder(root_id, semester, course_name, log)[0]
    if not ex:
        return []
    items: List[Item] = []

    def walk(fid, checked, depth):
        for eid, name, isdir, mod in list_folder(fid):
            if isdir:
                if depth < 3:
                    walk(eid, checked and "검수 전" not in name and "검수전" not in name, depth + 1)
                continue
            m = re.match(r"\s*(\d{2})(\d{2})(?=[_\s\-(.])", name)
            it = Item(source="필야", course=course_name, uid=eid, title=Path(name).stem, filename=name,
                      uploaded=_mod_sortable(mod), date_hint=(m.group(1) + m.group(2)) if m else None,
                      fetch={"kind": "drive", "id": eid, "checked": checked})
            items.append(it)
    walk(ex[0], True, 0)
    return items


_ex_cont: dict = {}


def find_sub(ents, sub: str):
    """과목 폴더 안에서 추가자료 폴더: 이름이 같은 폴더 → 없으면 추가·필야·필기가 들어간 폴더 하나"""
    sub = (sub or "").strip()
    e = _find(ents, lambda e: e[2] and e[1].strip() == sub) if sub else None
    if e:
        return e
    cands = [e for e in ents if e[2] and EXTRA_RE.search(e[1]) and not MANUAL_RE.search(e[1])]
    return cands[0] if len(cands) == 1 else None          # 여러 개면 아무거나 고르지 않음 (직접 골라 달라고)


def extras_folder(root_id: str, semester: str, course_name: str, log=lambda *a: None):
    """우리 학년 추가자료 폴더 → ((id, 이름), 방법) · 방법: 고름/자동/""
    1) 과목마다 직접 고른 폴더  2) 추가자료 위치(EXTRAS_LAYOUT): 과목 폴더들이 든 폴더(기본 학기 폴더) → 과목 폴더 → (안쪽 폴더)"""
    xid = EXTRAS_MAP.get(course_name)
    if xid == "-":
        return None, "고름"
    if xid:
        return (xid, ""), "고름"
    lay = EXTRAS_LAYOUT or {}
    sub = lay.get("sub", "추가자료") if "sub" in lay else "추가자료"
    cont = str(lay.get("container") or "")
    if cont:
        if cont not in _ex_cont:
            try:
                _ex_cont[cont] = list_folder(cont)
            except Exception as e:                       # 못 열면 「없음」이 아니라 실패로 (다음에 다시 확인)
                log(f"드라이브: 추가자료 폴더를 열지 못했어요 ({type(e).__name__})")
                raise
        f, _h = match_course_folder(course_name, _ex_cont[cont], {})
        cf = (f[0], f[1]) if f else None
    else:
        cf = _course_folder(root_id, semester, course_name, log)
    if not cf:
        return None, ""
    if not sub and cont:
        return (cf[0], cf[1]), "자동"
    ex = find_sub(list_folder(cf[0]), sub or "추가자료")
    return ((ex[0], ex[1]), "자동") if ex else (None, "")


def taker(filename: str) -> str:
    """필야 담당자: 'MMDD_교시_제목_교수님 - 홍길동.pdf' / '..._교수님_홍길동.pdf' 의 마지막 이름"""
    stem = Path(filename).stem
    m = re.search(r"(?:[-_]\s*)([가-힣]{2,4})\s*$", stem)
    if m and not re.search(r"교수", m.group(1)):
        return m.group(1)
    return ""


def manual_folder(cf, course_name: str, ents=None, use_map: bool = True):
    """과목의 매뉴얼(강의록) 폴더 → ((id, 이름, True, ""), 날짜폴더만_쓰기, 방법) · 방법: 고름/자동/없음
    직접 고른 폴더가 있으면 그것 · 아니면 과목 폴더 안 매뉴얼·강의록 폴더 · 날짜 폴더(MMDD)가 과목 폴더에 바로 있으면 과목 폴더"""
    mid = MANUAL_MAP.get(course_name) if use_map else None
    if mid == "-":
        return None, False, "고름"
    if mid:
        return (mid, "", True, ""), mid == (cf[0] if cf else ""), "고름"
    if not cf:
        return None, False, ""
    ents = list_folder(cf[0]) if ents is None else ents
    man = find_manual(ents)
    if man:
        return man, False, "자동"
    if any(e[2] and re.fullmatch(r"\d{4}", e[1].strip()) for e in ents):    # 날짜 폴더가 과목 폴더에 바로 있음
        return cf, True, "자동"
    # 「학기 › 메뉴얼 › 과목」 드라이브: 과목 폴더에 강의록 파일이 바로 (또는 「이미 진행한 수업」 같은 폴더 안에) 있음
    if any(not e[2] and LECT_EXT.search(e[1]) for e in ents):
        return cf, False, "자동"
    for e in [e for e in ents if e[2] and not (EXTRA_RE.search(e[1]) and not MANUAL_RE.search(e[1]))][:3]:
        try:
            if any(not x[2] and LECT_EXT.search(x[1]) for x in list_folder(e[0])):
                return cf, False, "자동"
        except Exception:
            pass
    return None, False, ""


LECT_EXT = re.compile(r"\.(pdf|pptx?|key|odp|docx?|hwpx?)$", re.I)


def items_for_course(root_id: str, semester: str, course_name: str, log) -> List[Item]:
    cf = _course_folder(root_id, semester, course_name, log)
    if not cf and not MANUAL_MAP.get(course_name, "").strip("-"):
        return []
    man, direct, _how = manual_folder(cf, course_name)
    if not man:
        return []
    if _how == "고름":
        LINK[course_name] = ""          # 매뉴얼 폴더를 직접 골랐으면 과목 폴더가 없어도 연결된 것
    items = []

    def walk(fid, mmdd, depth):
        for did, dname, isdir, mod in list_folder(fid):
            if isdir:
                m = re.fullmatch(r"(\d{4})", dname.strip())
                if depth == 0 and direct and not m:      # 날짜 폴더만 (추가자료·계획서 같은 건 빼요)
                    continue
                if EXTRA_RE.search(dname) and not MANUAL_RE.search(dname):   # 매뉴얼 안의 추가자료 폴더는 빼요
                    continue
                if mmdd and depth > 0:                   # 날짜 폴더 안의 폴더는 예전처럼 안 봐요 (이전 판 등)
                    continue
                if depth < 3:
                    walk(did, m.group(1) if m else mmdd, depth + 1)
                continue
            if depth == 0 and direct:
                continue
            md = mmdd
            if not md:                                   # 날짜 폴더가 없으면 파일 이름 앞 날짜 (0827-1. …)
                mm = re.match(r"\s*(?:\([^)]*\)\s*)?(\d{2})(\d{2})(?=[-_.\s,(])", dname)
                md = (mm.group(1) + mm.group(2)) if mm and 1 <= int(mm.group(1)) <= 12 and 1 <= int(mm.group(2)) <= 31 else None
            items.append(_item(did, dname, md, course_name, mod))
    walk(man[0], None, 0)
    return items


def _item(fid, name, mmdd, course, mod) -> Item:
    return Item(source="드라이브", course=course, uid=fid, title=Path(name).stem, filename=name,
                uploaded=_mod_sortable(mod), date_hint=mmdd, fetch={"kind": "drive", "id": fid})


def _mod_sortable(mod: str) -> str:
    """'10월 21일' → '2026-10-21', 시각만 있으면(오늘 수정) 오늘 날짜. 정렬·변경 확인용."""
    m = re.search(r"(\d{4})\.\s*(\d{1,2})\.\s*(\d{1,2})", mod)
    if m:
        return f"{m.group(1)}-{int(m.group(2)):02d}-{int(m.group(3)):02d}"
    m = re.search(r"(?<!\d)(\d{2})\.\s*(\d{1,2})\.\s*(\d{1,2})\.?", mod)     # '25. 8. 9.' (지난해 이전)
    if m:
        return f"20{m.group(1)}-{int(m.group(2)):02d}-{int(m.group(3)):02d}"
    m = re.search(r"(\d{1,2})월\s*(\d{1,2})일", mod)
    if m:                                  # 올해 파일은 '10월 21일' 처럼 연도 없이 보임
        from datetime import date
        return f"{date.today().year}-{int(m.group(1)):02d}-{int(m.group(2)):02d}"
    m = re.search(r"(\d{1,2}):(\d{2})", mod)
    if m:                                  # 오늘 수정한 파일은 시각만 보임 → 오늘 날짜로
        from datetime import date
        return date.today().isoformat()
    return "9999-" + mod


def download(it: Item, dest: Path) -> Path:
    dest.parent.mkdir(parents=True, exist_ok=True)
    if (it.fetch or {}).get("kind") == "local":       # 내 컴퓨터 폴더에 있는 선배 자료: 그냥 복사
        import shutil
        part = dest.with_name(dest.name + ".part")
        shutil.copy(it.fetch["path"], part)
        part.replace(dest)
        return dest
    import gdown
    from .lms import RetryLater
    part = dest.with_name(dest.name + ".part")      # 받다가 멈추면 반쪽 파일이 '받아 둔 것'으로 남지 않게
    try:
        part.unlink(missing_ok=True)
        out = gdown.download(id=it.fetch["id"], output=str(part), quiet=True)
        if out and Path(out).exists() and Path(out).stat().st_size > 0:
            Path(out).replace(dest)
            return dest
        first = "응답 없음"
    except Exception as e:
        first = type(e).__name__
    # gdown이 못 받으면(큰 파일 확인 화면·일시 제한 등) 직접 다운로드 주소로 한 번 더
    try:
        return _direct(it.fetch["id"], dest)
    except Exception as e:
        hint = " · 구글이 잠시 다운로드를 막은 것 같아요(많이 받으면 생겨요). 조금 뒤 다시 받기를 하면 돼요" \
            if "FileURLRetrieval" in first or "제한" in str(e) else ""
        raise RetryLater(f"드라이브 다운로드 실패 ({first}){hint}")


def _direct(fid: str, dest: Path) -> Path:
    r = requests.get("https://drive.usercontent.google.com/download",
                     params={"id": fid, "export": "download", "confirm": "t"}, headers=UA, timeout=120, stream=True)
    r.raise_for_status()
    if "text/html" in (r.headers.get("Content-Type") or ""):
        body = r.text[:4000]
        raise RuntimeError("일시 제한" if ("Too many users" in body or "할당량" in body or "quota" in body.lower()) else "HTML 응답")
    tmp = dest.with_suffix(dest.suffix + ".part")
    with open(tmp, "wb") as f:
        for chunk in r.iter_content(1 << 16):
            f.write(chunk)
    if tmp.stat().st_size == 0:
        tmp.unlink()
        raise RuntimeError("빈 파일")
    tmp.replace(dest)
    return dest


# ---------------------------------------------------------------- 선배 필야 (다른 학번 드라이브)
def folder_id_of(link: str) -> str:
    """드라이브 폴더 링크 또는 id → id"""
    m = re.search(r"/folders/([\w-]{10,})", link or "") or re.search(r"[?&]id=([\w-]{10,})", link or "")
    return m.group(1) if m else (link or "").strip()


_old_courses: dict = {}


def old_parts(src: dict, semester: str) -> List[str]:
    """선배 드라이브에서 과목 폴더들이 든 폴더까지의 경로 · path 에 {학기} 가 있으면 그 자리에 학기, 없으면 맨 뒤에 학기
    ("." 학기 = 링크(또는 path)가 곧 과목 폴더들이 든 폴더)"""
    sem = str(semester or "").strip()
    parts = [p.strip() for p in str(src.get("path", "")).split("/") if p.strip()]
    if SEM_TOKEN in parts:
        return [sem if p == SEM_TOKEN else p for p in parts if not (p == SEM_TOKEN and sem in ("", "."))]
    return parts + ([sem] if sem not in ("", ".") else [])


def old_sem_folder(src: dict, semester: str):
    """선배 드라이브의 과목 폴더들이 든 폴더 id (없으면 None)"""
    cur = folder_id_of(src.get("folder", ""))
    for part in old_parts(src, semester):
        e = _find(list_folder(cur), lambda e, part=part: e[2] and e[1].strip() == part.strip())
        if not e:
            return None
        cur = e[0]
    return cur


def _toks(s) -> List[str]:
    """「PDF, 한글 파일」 → ["pdf", "한글 파일"] (쉼표로만 나눔 · 띄어쓰기는 이름의 일부 · 대소문자 무시)"""
    return [t.strip() for t in re.split(r"[,，|]+", str(s or "").lower()) if t.strip()]


def name_filter_ok(rel_dirs: List[str], only: str = "", skip: str = "") -> bool:
    """과목 폴더 아래 경로의 폴더 이름들로 거르기 · skip 이름이 든 폴더는 빼고, only 를 정했으면 그 이름이 든 폴더 안 파일만
    (이름 일부만 같아도 됨: only=PDF → 「PDF」「PDF본」「1차 pdf」)"""
    ns = [d.lower() for d in rel_dirs]
    sk, on = _toks(skip), _toks(only)
    if sk and any(t in n for n in ns for t in sk):
        return False
    if on and not any(t in n for n in ns for t in on):
        return False
    return True


def local_course_files(roots: List[Tuple[Path, bool]], only: str = "", skip: str = "", depth: int = 3, limit: int = 0):
    """내 폴더 과목 폴더(들) 아래 강의 자료 파일 → [(경로, 이름, 수정 시각)] (같은 파일은 한 번만)"""
    out, seen = [], set()

    def walk(base: Path, d: Path, dep: int, picked: bool):
        for p_, name, isdir, mt in _local_entries(d):
            if limit and len(out) >= limit:
                return
            if isdir:
                if dep < depth:
                    walk(base, Path(p_), dep + 1, picked)
                continue
            if Path(name).suffix.lower() not in LOCAL_EXT or p_ in seen:
                continue
            rel = list(Path(os.path.relpath(p_, base)).parts[:-1])
            if not (name_filter_ok(rel, "", skip) if picked else name_filter_ok(rel, only, skip)):
                continue
            seen.add(p_)
            out.append((p_, name, mt))
    for r, picked in roots:
        if Path(r).is_dir():
            walk(Path(r), Path(r), 0, picked)
    return out


LOCAL_EXT = {".pdf", ".ppt", ".pptx", ".doc", ".docx", ".hwp", ".hwpx", ".key", ".odp", ".png", ".jpg", ".jpeg", ".zip"}


def _local_entries(d: Path):
    """내 폴더 안 (경로, 이름, 폴더여부, 수정 시각) · 숨김·임시 파일은 빼고"""
    out = []
    try:
        for x in sorted(d.iterdir(), key=lambda x: x.name):
            if x.name.startswith((".", "~$", "_")):
                continue
            try:
                out.append((str(x), x.name, x.is_dir(), x.stat().st_mtime))
            except OSError:
                continue
    except OSError:
        pass
    return out


_LOCAL_SUG: dict = {}


def local_suggest(root, courses: List[str], depth: int = 4, limit: int = 600) -> dict:
    """내 폴더 안을 depth 단계까지 둘러보고, 이번 학기 과목 폴더가 가장 많이 든 폴더를 찾아요
    → {"parts": [root 아래 경로 이름들], "dir": 경로, "found": 찾은 과목 수} (못 찾으면 found 0)"""
    from collections import deque
    root = Path(root)
    best = {"parts": [], "dir": str(root), "found": 0}
    q, seen = deque([(root, [])]), 0
    while q and seen < limit:
        d, parts = q.popleft()
        seen += 1
        ents = [(p_, n, True, "") for p_, n, isdir, _ in _local_entries(d) if isdir]
        if not ents:
            continue
        n = sum(1 for c in courses if match_course_folder(c, ents, {}, courses)[0])
        if n > best["found"] or (n == best["found"] and n and len(parts) < len(best["parts"])):
            best = {"parts": parts, "dir": str(d), "found": n}
        if n >= max(1, min(2, len(courses))):
            continue                                   # 과목 폴더 안으로는 더 안 들어감
        if len(parts) < depth:
            for p_, nm, _d, _ in ents[:40]:
                q.append((Path(p_), parts + [nm]))
    return best


def old_local_dirs(src: dict, semester: str, courses: Optional[List[str]] = None):
    """내 폴더 → (과목 폴더들이 든 폴더, 그 안 폴더 목록, root 아래 경로 이름들, 자동으로 찾았는지)
    설정한 구조에서 과목 폴더를 하나도 못 찾으면 더 깊이(4단계) 찾아봐요 (본2 › 2학기 › 22학번 필야 › 과목 같은 구조)"""
    root = Path(os.path.expanduser(str(src.get("local") or ""))).resolve()
    if not root.is_dir():
        return None, [], [], False
    cur, parts = root, []
    for part in [p.strip() for p in str(src.get("path", "")).split("/") if p.strip()]:
        if (cur / part).is_dir():
            cur, parts = cur / part, parts + [part]
    sem = str(semester or "").strip()
    if sem and sem != "." and (cur / sem).is_dir():
        cur, parts = cur / sem, parts + [sem]
    ents = [(p_, n, True, "") for p_, n, isdir, _ in _local_entries(cur) if isdir]
    cs = list(courses or ALL_COURSES or [])
    if cs and not any(match_course_folder(c, ents, src.get("map") or {}, cs)[0] for c in cs):
        k = (str(root), tuple(cs))
        sg = _LOCAL_SUG.get(k)
        if sg is None:
            sg = _LOCAL_SUG[k] = local_suggest(root, cs)
        if sg["found"]:
            cur, parts = Path(sg["dir"]), list(sg["parts"])
            return cur, [(p_, n, True, "") for p_, n, isdir, _ in _local_entries(cur) if isdir], parts, True
    return cur, ents, parts, False


def old_check(src: dict, semester: str, courses: List[str]) -> dict:
    """선배 추가자료 줄 하나: 이번 학기 과목마다 과목 폴더를 찾았는지 (설정 화면 표시용)"""
    from .matching import same_course
    if src.get("local") and not src.get("folder"):
        _LOCAL_SUG.clear()                                  # 폴더 안이 바뀌었을 수 있어서 새로 찾기
        cur, ents, parts, auto = old_local_dirs(src, semester, courses)
        if cur is None:
            return {"ok": False, "msg": "내 폴더를 찾을 수 없어요"}
    else:
        fid = folder_id_of(src.get("folder", ""))
        cur, parts, auto = fid, [], False
        for part in old_parts(src, semester):
            e = _find(list_folder(cur), lambda e, part=part: e[2] and e[1].strip() == part.strip())
            if not e:
                return {"ok": True, "found": [], "miss": list(courses), "parts": parts, "auto": False, "stop": part}
            cur, parts = e[0], parts + [part]
        ents = [(e[0], e[1], True, "") for e in list_folder(cur) if e[2]]
    found, miss = [], []
    for c in courses:
        f, how = match_course_folder(c, ents, src.get("map") or {}, courses)
        if not f and how != "고름":
            f = next(((e[0], e[1]) for e in ents if same_course(e[1], c)), None)
        (found.append([c, f[1]]) if f else miss.append(c))
    return {"ok": True, "found": found, "miss": miss, "parts": parts, "auto": auto}


def _local_roots(src: dict, course: str, f) -> List[Tuple[Path, bool]]:
    """그 과목에서 읽을 폴더들: 직접 여러 개 골랐으면 그 폴더들(거르기 없이) · 아니면 과목 폴더(거르기 적용)"""
    v = (src.get("map") or {}).get(course)
    if isinstance(v, list):
        return [(Path(os.path.expanduser(str(x))), True) for x in v if str(x).strip()]      # 「~/Desktop/…」로 저장돼도
    return [(Path(os.path.expanduser(str(f[0]))), False)] if f else []


def old_local_check(src: dict, semester: str, courses: List[str]) -> dict:
    """내 폴더 「과목 폴더 연결」 창: 과목마다 맞춘 폴더(직접 고른 것 포함) + 파일 수 + 고를 수 있는 폴더 목록"""
    from .matching import same_course
    cur, ents, parts, auto = old_local_dirs(src, semester, courses)
    if cur is None:
        return {"ok": False, "msg": "내 폴더를 찾을 수 없어요"}
    cmap = src.get("map") or {}
    out = []
    for c in courses:
        f, how = match_course_folder(c, ents, cmap, courses)
        if not f and how != "고름":
            f = next(((e[0], e[1]) for e in ents if same_course(e[1], c)), None)
            how = "같음" if f else how
        roots = _local_roots(src, c, f)
        n = len(local_course_files(roots, src.get("only", ""), src.get("skip", ""), limit=300)) if f else 0
        mv = cmap.get(c)
        out.append({"course": c, "folder": f[1] if f else "", "folder_id": f[0] if f else "", "how": how or "", "files": n,
                    "picked": [str(x) for x in mv] if isinstance(mv, list) else []})
    return {"ok": True, "courses": out, "dirs": [{"id": e[0], "name": e[1]} for e in ents], "parts": parts, "auto": auto,
            "found": sum(1 for x in out if x["folder"]), "total": len(courses)}


def old_extras_local(src: dict, semester: str, course_name: str, log) -> List[Item]:
    """src = {"label": "선배이름", "local": 내 컴퓨터 폴더} → 그 폴더(안에 학기 폴더가 있으면 그 안) › 과목 폴더 아래 파일 전부"""
    import hashlib
    from datetime import datetime
    from .matching import same_course
    label = str(src.get("label", "")).strip()
    root = Path(os.path.expanduser(str(src.get("local") or ""))).resolve()
    if not root.is_dir():
        log(f"선배 추가자료({label}): 내 폴더가 없어요 ({root})")
        return []
    cur, ents, parts, auto = old_local_dirs(src, semester)
    if cur is None:
        return []
    if auto and course_name == (ALL_COURSES or [course_name])[0]:
        log(f"선배 추가자료({label}): 과목 폴더를 「{' › '.join(parts)}」 안에서 찾았어요")
    f, how = match_course_folder(course_name, ents, src.get("map") or {})
    if not f and how != "고름":
        f = next(((e[0], e[1]) for e in ents if same_course(e[1], course_name)), None)
    if not f:
        return []
    roots = _local_roots(src, course_name, f)
    if not isinstance((src.get("map") or {}).get(course_name), list) and str(src.get("sub") or "").strip():
        ex = find_sub([(p_, n, isdir, "") for p_, n, isdir, _ in _local_entries(Path(f[0]))], src["sub"])
        if not ex:
            return []
        roots = [(Path(ex[0]), False)]
    items: List[Item] = []
    for p_, name, mt in local_course_files(roots, src.get("only", ""), src.get("skip", "")):
        try:
            rel = os.path.relpath(p_, root)
        except ValueError:             # 윈도우: 다른 드라이브(D: 등)에서 고른 폴더
            rel = os.path.abspath(p_)
        uid = "local:" + hashlib.md5(rel.encode("utf-8")).hexdigest()[:16]
        items.append(Item(source=f"필야{label}", course=course_name, uid=uid, title=Path(name).stem, filename=name,
                          uploaded=datetime.fromtimestamp(mt).strftime("%Y-%m-%d %H:%M"), date_hint=None,
                          fetch={"kind": "local", "path": p_, "checked": True, "label": label}))
    return items


def old_extras(src: dict, semester: str, course_name: str, log) -> List[Item]:
    """src = {"label": "21", "folder": 링크/id, "path": "필야"} →
    <폴더>/<path>/<학기>/<과목>/ 아래 파일 전부 (하위 폴더 포함). 날짜는 해마다 달라서 date_hint 없음."""
    if src.get("local") and not src.get("folder"):       # 드라이브 대신 내 컴퓨터 폴더
        return old_extras_local(src, semester, course_name, log)
    from .matching import same_course
    fid, label = folder_id_of(src.get("folder", "")), str(src.get("label", "")).strip()
    k = (fid, src.get("path", ""), semester)
    if k not in _old_courses:
        cur = fid
        for part in old_parts(src, semester):   # "." = 링크가 곧 학기 폴더
            e = _find(list_folder(cur), lambda e, part=part: e[2] and e[1].strip() == part.strip())
            if not e:
                log(f"선배 추가자료({label}): '{part}' 폴더를 못 찾음")
                cur = None
                break
            cur = e[0]
        _old_courses[k] = [(e[0], e[1]) for e in list_folder(cur) if e[2]] if cur else []
    ents = [(i, n, True, "") for i, n in _old_courses[k]]
    f, how = match_course_folder(course_name, ents, src.get("map") or {})   # 선배 드라이브마다 직접 고른 과목 폴더
    if not f:
        f = next(((c[0], c[1]) for c in _old_courses[k] if same_course(c[1], course_name)), None)
    cf = (f[0], f[1]) if f else None
    if not cf:
        return []
    if str(src.get("sub") or "").strip():          # 과목 폴더 안의 추가자료 폴더만 (학기 › 과목 › 추가자료 구조)
        ex = find_sub(list_folder(cf[0]), src["sub"])
        if not ex:
            return []
        cf = (ex[0], ex[1])
    items: List[Item] = []

    only, skip = src.get("only", ""), src.get("skip", "")

    def walk(fid, depth, rel):
        for eid, name, isdir, mod in list_folder(fid):
            if isdir:
                if depth < 3 and name_filter_ok(rel + [name], "", skip):     # 뺄 이름의 폴더는 안으로 안 들어감
                    walk(eid, depth + 1, rel + [name])
                continue
            if not name_filter_ok(rel, only, skip):                          # 「이 이름의 폴더만」: 그 폴더 안 파일만
                continue
            items.append(Item(source=f"필야{label}", course=course_name, uid=eid, title=Path(name).stem, filename=name,
                              uploaded=_mod_sortable(mod), date_hint=None,
                              fetch={"kind": "drive", "id": eid, "checked": True, "label": label}))
    walk(cf[0], 0, [])
    return items


# ---------------------------------------------------------------- 폴더 구조 자동 추천
_PRIO = re.compile(r"학기|semester|추가|필야|필기|자료|본과|학년|\d{2}\s*학번", re.I)


def suggest_layouts(root: str, semester: str, courses: List[str], want: str = "extras", limit: int = 45) -> List[dict]:
    """드라이브 링크 안을 3단계까지 둘러보고, 과목 폴더들이 든 폴더와 추가자료 위치를 추천해요.
    → [{parts:[경로 이름들], container: id, sub: 과목 안 폴더 이름("" = 과목 폴더 전체), found, total, score, label}] (좋은 순)
    want="extras": 추가자료 위치 · "manual": 매뉴얼(학기 폴더) 위치"""
    from collections import deque
    sem = str(semester or "").strip()
    rid = folder_id_of(root)
    q, seen, cands = deque([(rid, [])]), 0, []
    while q and seen < limit:
        fid, parts = q.popleft()
        try:
            ents = list_folder(fid)
        except Exception:
            continue
        seen += 1
        hits = [(c, match_course_folder(c, ents, {}, courses)[0]) for c in courses]
        hits = [(c, f) for c, f in hits if f]
        if len(hits) >= max(1, min(2, len(courses))):
            cands.append({"container": fid, "parts": parts, "hits": hits, "found": len(hits)})
            continue                                   # 과목 폴더 안으로는 더 안 들어감
        if len(parts) < 3:
            dirs = [e for e in ents if e[2]]
            dirs.sort(key=lambda e: (0 if (sem and e[1].strip() == sem) else 1 if _PRIO.search(e[1]) else 2, e[1]))
            for e in dirs[:20]:
                q.append((e[0], parts + [e[1].strip()]))
    out = []
    for c in cands:
        # 과목 폴더 몇 개를 열어 안쪽 구조 보기: 추가자료 폴더가 있는지, 매뉴얼(날짜) 폴더가 있는지
        n_x = n_m = 0
        subs: dict = {}
        for _c, f in c["hits"][:5]:
            try:
                es = list_folder(f[0])
            except Exception:
                continue
            x = find_sub(es, "")
            if x:
                n_x += 1
                subs[x[1].strip()] = subs.get(x[1].strip(), 0) + 1
            if find_manual(es) or any(e[2] and re.fullmatch(r"\d{4}", e[1].strip()) for e in es):
                n_m += 1
        k = max(1, min(5, len(c["hits"])))
        x_path = any(EXTRA_RE.search(p) for p in c["parts"])            # 경로에 추가자료·필야가 있음 → 그 아래 과목 폴더가 곧 추가자료
        sem_in = [i for i, p in enumerate(c["parts"]) if sem and p == sem]
        sem_like = [p for p in c["parts"] if re.search(r"\d\s*학기", p)]
        if want == "manual":
            score = c["found"] * 2 + (3 if n_m * 2 >= k else 0) - (4 if x_path else 0) + (1 if sem_in else 0)
            sub = ""
        else:
            sub = max(subs, key=subs.get) if (n_x * 2 >= k and not x_path) else ""
            score = c["found"] * 2 + (4 if x_path else 0) + (3 if sub else 0) + (1 if sem_in else 0) - (2 if (not x_path and not sub) else 0)
        tmpl = [SEM_TOKEN if (sem and p == sem) else p for p in c["parts"]]
        label = " › ".join(c["parts"] + ["[과목]"] + ([sub] if sub else []))
        out.append({"container": c["container"], "parts": c["parts"], "path": "/".join(tmpl), "sub": sub,
                    "found": c["found"], "total": len(courses), "score": score, "label": label,
                    "sem_found": bool(sem_in), "sem_other": "" if sem_in else (sem_like[-1] if sem_like else ""),
                    "extras_ok": bool(x_path or sub), "manual_ok": n_m * 2 >= k})
    out.sort(key=lambda d: -d["score"])
    return out


def maps_apply(cfg: dict, root: str = "", sid=None) -> bool:
    """직접 고른 과목·매뉴얼·추가자료 폴더(드라이브 고르기에서 저장)를 지금 드라이브·학기 폴더에 써도 되는지
    · 다른 드라이브나 다른 학기 폴더를 골랐으면 안 써요 (예전 설정은 고른 학기 폴더 기록이 없어서 지금 학기 폴더로 봐요)"""
    root = root or cfg.get("drive_root") or ""
    mr = cfg.get("drive_course_map_root") or ""
    if mr and root and mr != root:
        return False
    ms = cfg.get("drive_maps_sem") or cfg.get("drive_sem_id") or ""
    sid = (cfg.get("drive_sem_id") or "") if sid is None else sid
    return not ms or not sid or ms == sid

