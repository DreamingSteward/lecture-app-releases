"""내 파일 정리하기: 내가 고른 파일 · 폴더의 강의록을 시간표 강의에 맞춰 「직접 넣은 자료」로 복사
(원본은 옮기거나 지우지 않음 · 만드는 건 평소 받기가 직접 넣은 자료로 함)

흐름: pick() 로 고르기 → suggest() 로 강의 맞추기(미리 보기) → place() 로 복사 → 그 강의들만 받기"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
import sys
import unicodedata
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

from .matching import Item, Memory, match, title_score, same_course, date_hints, period_hints
from .timetable import norm_course

EXT = (".pdf", ".ppt", ".pptx", ".doc", ".docx", ".hwp", ".hwpx", ".odp")     # .key(키노트)는 폴더 묶음이라 못 넣음
MAX_FILES = 400
SKIP_DIRS = {"node_modules", "__pycache__", "$RECYCLE.BIN", "System Volume Information", "Library", "AppData", "Applications", "Program Files", "Program Files (x86)", "Windows"}
MAX_ENTRIES = 30000          # 폴더를 너무 넓게 골랐을 때(홈 · 드라이브 전체) 끝없이 돌지 않게
SKIP_ROOTS: List[Path] = []  # 앱이 만든 결과 · 직접 넣은 자료 폴더 (다시 넣지 않게) · gui 가 채움


# ---------------------------------------------------------------- 고르기 (Finder · 탐색기 창)
def pick(kind: str, start: Optional[str] = None) -> dict:
    """kind = files | folder → {"ok", "paths": [...]} · 취소면 cancel"""
    st = Path(str(start or "~")).expanduser()
    st = st if st.is_dir() else Path.home()
    many = kind != "folder"
    try:
        if sys.platform == "darwin":
            q = lambda t: t.replace("\\", "\\\\").replace('"', '\\"')
            if many:
                script = (f'set fs to choose file with prompt "정리할 강의록 파일을 고르세요" '
                          f'default location (POSIX file "{q(str(st))}") with multiple selections allowed\n'
                          'set out to ""\nrepeat with f in fs\nset out to out & POSIX path of f & linefeed\nend repeat\nreturn out')
            else:
                script = (f'set f to choose folder with prompt "강의록이 든 폴더를 고르세요" '
                          f'default location (POSIX file "{q(str(st))}")\nreturn POSIX path of f')
            r = subprocess.run(["osascript", "-e", "activate", "-e", script], capture_output=True, text=True, timeout=900)
            out = r.stdout or ""
        elif os.name == "nt":
            if many:
                ps = ("Add-Type -AssemblyName System.Windows.Forms;"
                      "$d=New-Object System.Windows.Forms.OpenFileDialog;$d.Multiselect=$true;"
                      "$d.Title='정리할 강의록 파일을 고르세요';$d.InitialDirectory=$env:START;"
                      "$d.Filter='강의록|*.pdf;*.ppt;*.pptx;*.doc;*.docx;*.hwp;*.hwpx;*.odp|모든 파일|*.*';"
                      "$w=New-Object System.Windows.Forms.Form;$w.TopMost=$true;"
                      "if($d.ShowDialog($w) -eq 'OK'){[Console]::OutputEncoding=[Text.Encoding]::UTF8;$d.FileNames|%{Write-Output $_}}")
            else:
                ps = ("Add-Type -AssemblyName System.Windows.Forms;"
                      "$d=New-Object System.Windows.Forms.FolderBrowserDialog;"
                      "$d.Description='강의록이 든 폴더를 고르세요';$d.SelectedPath=$env:START;"
                      "$w=New-Object System.Windows.Forms.Form;$w.TopMost=$true;"
                      "if($d.ShowDialog($w) -eq 'OK'){[Console]::OutputEncoding=[Text.Encoding]::UTF8;Write-Output $d.SelectedPath}")
            r = subprocess.run(["powershell", "-NoProfile", "-STA", "-Command", ps], capture_output=True, timeout=900,
                               env={**os.environ, "START": str(st)})
            out = (r.stdout or b"").decode("utf-8-sig", "ignore")     # 앞에 BOM 이 붙는 환경도
        else:
            args = ["zenity", "--file-selection", f"--filename={st}/"] + (["--multiple", "--separator=\n"] if many else ["--directory"])
            out = subprocess.run(args, capture_output=True, text=True, timeout=900).stdout or ""
    except Exception as e:
        return {"ok": False, "msg": f"고르기 창을 못 열었어요 ({type(e).__name__})"}
    paths = [p.strip() for p in out.splitlines() if p.strip()]
    if not paths:
        return {"ok": False, "cancel": True}
    return {"ok": True, "paths": paths}


# ---------------------------------------------------------------- 파일 모으기
def _skipped(p: Path) -> bool:
    try:
        rp = p.resolve()
    except Exception:
        return False
    return any(rp == s or s in rp.parents for s in SKIP_ROOTS)


def scan(paths: List[str], info: Optional[dict] = None) -> List[Path]:
    """고른 파일 + 폴더(하위 폴더까지) 안의 강의록 파일 · 숨김 · 임시 파일(~$) · 앱이 만든 폴더 빼고
    많으면 MAX_FILES 개 · 폴더 항목 MAX_ENTRIES 개까지 (info["more"] = 잘림)"""
    out: List[Path] = []
    seen = set()
    info = info if info is not None else {}
    seen_n = [0]

    def add(f: Path):
        if len(out) >= MAX_FILES:
            return
        n = f.name
        if n.startswith(".") or n.startswith("~$") or f.suffix.lower() not in EXT:
            return
        k = str(f.resolve())
        if k not in seen and f.is_file():
            seen.add(k)
            out.append(f)

    for p in paths:
        p = Path(p).expanduser()
        if _skipped(p):
            info["skipped"] = True
            continue
        if p.is_file():
            add(p)
        elif p.is_dir():
            def _err(e, _i=info):
                if isinstance(e, PermissionError):
                    _i["denied"] = True
            for root, dirs, files in os.walk(p, onerror=_err):
                keep = []
                for d in sorted(dirs):
                    if d.startswith(".") or d in SKIP_DIRS:
                        continue
                    if _skipped(Path(root) / d):
                        info["skipped"] = True
                        continue
                    keep.append(d)
                dirs[:] = keep
                seen_n[0] += len(files) + len(dirs)
                for n in sorted(files):
                    if len(out) >= MAX_FILES:
                        break
                    add(Path(root) / n)
                if len(out) >= MAX_FILES or seen_n[0] > MAX_ENTRIES:
                    info["more"] = True
                    break
        if len(out) >= MAX_FILES:
            info["more"] = True
            break
    return out


# ---------------------------------------------------------------- 강의 맞추기
def _nfc(s: str) -> str:
    return unicodedata.normalize("NFC", s or "")


def _guess_courses(f: Path, courses: List[str], base: Optional[Path]) -> List[str]:
    """폴더 이름 · 파일 이름에 과목 이름이 들어 있으면 그 과목 (안쪽 폴더일수록 먼저)"""
    parts = [_nfc(f.stem)] + [_nfc(x) for x in reversed(f.parent.parts[-2:])]     # 파일만 골랐으면 가까운 폴더 2개까지만 (Users · Desktop 같은 위 폴더는 안 봄)
    if base:
        try:
            parts = [_nfc(f.stem)] + [_nfc(x) for x in reversed(f.parent.relative_to(base.parent).parts)]
        except ValueError:
            pass
    for part in parts:
        np = norm_course(part)
        hit = [c for c in courses if norm_course(c) and (norm_course(c) in np or (len(np) >= 2 and np in norm_course(c)) or same_course(c, part))]
        if hit:
            return hit
    return []


def _item(f: Path, course: str, rel: str) -> Item:
    st = f.stat()
    title = " ".join(_nfc(x) for x in Path(rel).parent.parts[-2:] + (f.stem,))    # 폴더 이름(날짜 · 교시가 적힌 경우)도 힌트로
    return Item(source="직접", course=course, uid=f"내파일:{rel}", title=title, filename=f.name,
                uploaded=datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%dT%H:%M:%S"), size=st.st_size,
                fetch={"kind": "local", "path": str(f)})


def suggest(paths: List[str], lectures, mem_path: Optional[Path] = None) -> dict:
    """{"rows": [{path, name, size, how(확실|추정|애매|없음), key, cands:[key…]}], "more": 400개 넘음}"""
    info: dict = {}
    files = scan(paths, info)
    courses = sorted({L.course for L in lectures})
    by_key = {L.key: L for L in lectures}
    if mem_path:
        mem = Memory(mem_path)
    else:                                       # 기억은 안 씀 (빈 기억 · 파일을 읽거나 쓰지 않음)
        mem = Memory.__new__(Memory)
        mem.path, mem.data = None, {}
    bases = [Path(p).expanduser() for p in paths if Path(p).expanduser().is_dir()]
    rows = []
    for f in files:
        base = next((b for b in bases if str(f).startswith(str(b))), None)
        rel = str(f.relative_to(base.parent)) if base else f.name
        guess = _guess_courses(f, courses, base)
        weak = False

        def run(cs):
            h: Dict[str, str] = {}             # key → how
            for c in cs:
                for d in match([_item(f, c, rel)], lectures, mem):
                    if d.lecture is not None:
                        h.setdefault(d.lecture.key, d.how)
                    for L in (d.candidates or []):
                        h.setdefault(L.key, "애매")
            return h
        hits = run(guess) if guess else {}
        if not hits:                            # 과목을 못 정했거나 그 과목에서 못 찾음 → 모든 과목에서
            hits = run([c for c in courses if c not in guess])
        strong = [k for k, h in hits.items() if h in ("기억", "확실")]
        dates = set(date_hints(f"{rel} {f.stem}"))
        if strong:                              # 파일 이름의 날짜가 그 강의 날짜와 같을 때만 날짜로 믿음 · 아니면 제목이 꽤 맞아야 확실
            dated = [k for k in strong if by_key[k].mmdd in dates]
            if dated:
                strong = dated
            else:
                ts = max(title_score(_nfc(f.stem), by_key[k]) for k in strong)
                if ts < 0.5:
                    hits = {k: "애매" for k in hits} if ts == 0 else hits
                    strong = [] if ts == 0 else strong
                    weak = ts > 0
        if not guess and len({by_key[k].course for k in strong}) > 1:    # 과목을 모르는데 여러 과목의 같은 제목(OT · 종합평가 등) → 고르게
            hits = {k: "애매" for k in hits}
            strong = []
        # 날짜 + 교시가 딱 맞는 강의 (제목이 줄임말이라 못 맞춘 경우: 「1116_4교시_UTI」 → 11/16 4교시)
        txt = f"{rel} {f.stem}"
        ps = set(period_hints(txt))
        dp = [L.key for L in lectures if L.mmdd in dates and (not ps or set(L.periods()) & ps)] if dates else []
        if not strong and dp and (len(dp) == 1 or len({(by_key[k].course, by_key[k].title) for k in dp}) == 1) and ps:
            strong, weak = dp, True
            for k in dp:
                hits.setdefault(k, "애매")
        if len(strong) == 1 or (strong and len({(by_key[k].course, by_key[k].title) for k in strong}) == 1):
            how, key, cands = ("추정" if weak else "확실"), strong[0], strong
        elif len(hits) == 1:
            how, key, cands = "추정", next(iter(hits)), list(hits)
        elif hits:
            for k in dp:
                hits.setdefault(k, "애매")
            ranked = sorted(hits, key=lambda k: (k not in dp, by_key[k].mmdd not in dates, -title_score(_nfc(f.stem), by_key[k])))   # 날짜 · 교시가 맞는 강의 먼저
            how, key, cands = "애매", ranked[0], ranked[:8]
        else:
            how, key, cands = "없음", "", []
        rows.append({"path": str(f), "name": f.name, "rel": rel, "size": f.stat().st_size, "how": how, "key": key,
                     "keys": strong if how in ("확실", "추정") and len(strong) > 1 else ([key] if key else []),
                     "cands": [{"key": k, "label": _label(by_key[k])} for k in cands if k in by_key]})
    return {"ok": True, "rows": rows, "more": bool(info.get("more")), "skipped": bool(info.get("skipped")), "denied": bool(info.get("denied"))}


def _label(L) -> str:
    return f"{L.course} · {L.mmdd[:2]}/{L.mmdd[2:]} · {L.title}"


# ---------------------------------------------------------------- 넣기
def _same(a: Path, b: Path) -> bool:
    """크기가 같을 때 내용도 같은지 (앞뒤 1MB 비교)"""
    try:
        with open(a, "rb") as x, open(b, "rb") as y:
            if x.read(1 << 20) != y.read(1 << 20):
                return False
            n = a.stat().st_size
            if n > 2 << 20:
                x.seek(-(1 << 20), 2); y.seek(-(1 << 20), 2)
                return x.read() == y.read()
            return True
    except Exception:
        return False


def place(rows: List[dict], lectures, manual_dir) -> dict:
    """rows: [{path, keys:[강의 key…]}] → 그 강의의 직접 넣은 자료 폴더로 복사 (같은 이름 · 같은 크기면 건너뜀)"""
    by_key = {L.key: L for L in lectures}
    done, same, bad, keys = 0, 0, [], []
    for r in rows:
        src = Path(str(r.get("path") or ""))
        ks = [k for k in (r.get("keys") or ([r["key"]] if r.get("key") else [])) if k in by_key]
        if not src.is_file() or src.suffix.lower() not in EXT or not ks:
            bad.append(src.name)
            continue
        for k in ks:
            d = manual_dir(by_key[k])
            d.mkdir(parents=True, exist_ok=True)
            dst = d / _nfc(src.name)
            sib = [x for x in d.iterdir() if x.is_file() and x.suffix.lower() == dst.suffix.lower()
                   and (x.stem == dst.stem or re.fullmatch(re.escape(dst.stem) + r"_\d+", x.stem))]
            if any(x.stat().st_size == src.stat().st_size and _same(x, src) for x in sib):   # 같은 내용이 이미 있음
                same += 1
                keys.append(k)
                continue
            if dst.exists():                    # 같은 이름 · 다른 내용 = 고친 판 → 옛 판은 「_이전」 폴더로 (강의록에 둘 다 들어가지 않게)
                old = d / "_이전"
                old.mkdir(exist_ok=True)
                n, tgt = 1, old / dst.name
                while tgt.exists():
                    n += 1
                    tgt = old / f"{dst.stem}_{n}{dst.suffix}"
                try:
                    shutil.move(str(dst), str(tgt))
                except Exception:
                    bad.append(src.name)
                    continue
            try:
                shutil.copyfile(src, dst)           # 넣은 시각이 파일 시각 (더 새것으로 보이게)
                done += 1
                keys.append(k)
            except Exception:
                bad.append(src.name)
    return {"ok": True, "copied": done, "same": same, "bad": bad, "keys": sorted(set(keys))}
