#!/bin/bash
# 강의록앱 화면(백그라운드 서버)을 새로 켜요 — 업데이트가 안 보이거나 화면이 이상할 때 더블클릭
APP="$(cd "$(dirname "$0")" && pwd)"
LBL="kr.knu.lectureapp-gui"
if /bin/launchctl print "gui/$(id -u)/$LBL" >/dev/null 2>&1; then
  /bin/launchctl kickstart -k "gui/$(id -u)/$LBL"
else
  /usr/bin/pkill -f "lecture_app 화면" ; sleep 1
  PRE=""; /usr/sbin/sysctl -n hw.optional.arm64 2>/dev/null | grep -q 1 && /usr/bin/arch -arm64 "$APP/.venv/bin/python" -c "" 2>/dev/null && PRE="/usr/bin/arch -arm64"
  cd "$APP" && nohup $PRE "$APP/.venv/bin/python" -m lecture_app 화면 --상주 --창없이 >> "$APP/logs/화면.log" 2>&1 &
fi
sleep 2
echo "강의록앱을 다시 켰어요. 앱 창에서 새로고침을 눌러 주세요."
sleep 2
/usr/bin/osascript -e 'tell application "Terminal" to close (every window whose name contains "앱 다시 켜기")' >/dev/null 2>&1 &
exit 0
