﻿# 강의록앱 삭제 (Windows). 앱·앱 전용 파이썬·설정·기록·저장한 비밀번호를 지워요.
# 받아 둔 강의록(정리 폴더의 PDF)은 지우지 않아요.
[Console]::OutputEncoding = [Text.Encoding]::UTF8
$App = Join-Path $env:USERPROFILE '강의록앱'
Write-Host '강의록앱 삭제' -ForegroundColor White
Write-Host ''
$Save = ''
try { $Save = [Environment]::ExpandEnvironmentVariables(((Get-Content (Join-Path $App 'config.json') -Raw -Encoding UTF8) | ConvertFrom-Json).save_root) } catch {}
if ($Save -like '~*') { $Save = Join-Path $env:USERPROFILE $Save.Substring(1).TrimStart('\','/') }
Write-Host '지우는 것'
Write-Host '  · 앱 폴더 %USERPROFILE%\강의록앱 (앱 전용 파이썬 환경·설정·시간표·고른 자료 기억·기록)'
Write-Host '  · 바탕 화면·시작 메뉴 바로가기 · 자동 받기 예약 · 작업 표시줄 아이콘 · 저장한 학교 비밀번호·노션 시크릿'
Write-Host '  · 자동 로그인용 브라우저 (%LOCALAPPDATA%\ms-playwright)'
if ($Save) { Write-Host "  · 받기 기록 폴더 ($Save\_실행기록)" }
Write-Host ''
Write-Host '남기는 것' -ForegroundColor Green
Write-Host "  · 받아 둔 강의록·추가자료·표지 PDF $(if ($Save) { "($Save)" })"
Write-Host '  · LibreOffice · 파이썬 (다른 프로그램도 쓸 수 있어서)'
Write-Host ''
$a = Read-Host '정말 지울까요? 지우려면 y 를 입력하고 엔터'
if ($a -ne 'y' -and $a -ne 'Y') { Write-Host '취소했어요.'; Start-Sleep 1; exit 0 }

Write-Host ''; Write-Host '▶ 앱 끄기'
Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -and ($_.CommandLine -like "*$App*") -and $_.ProcessId -ne $PID } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
Start-Sleep 1

Write-Host '▶ 자동 받기 예약 지우기'
(schtasks /Query /FO CSV /NH 2>$null) | ForEach-Object { $n = ($_ -split ',')[0].Trim('"').TrimStart('\'); if ($n -like '강의록앱_예약*') { schtasks /Delete /F /TN $n | Out-Null } }

Write-Host '▶ 저장한 비밀번호 지우기'
$py = Join-Path $App '.venv\Scripts\python.exe'
if (Test-Path $py) {   # 앱이 저장한 방식(keyring) 그대로 지움 (cmdkey 출력 글자가 깨져도 확실히)
  & $py -c "import keyring`nfor s in ('\uac15\uc758\ub85d\uc571-KNU','\uac15\uc758\ub85d\uc571-Notion'):`n  for u in ('__account__','__secret__'):`n    try: keyring.delete_password(s,u)`n    except Exception: pass" 2>$null
}
(cmdkey /list) | ForEach-Object { if ($_ -match '(?:대상|Target):\s*(.+)$') { $t = $Matches[1].Trim(); if ($t -like '*강의록앱*') { cmdkey "/delete:$t" | Out-Null } } }

Write-Host '▶ 바로가기·파일 지우기'
$progs = [Environment]::GetFolderPath('Programs')
@((Join-Path ([Environment]::GetFolderPath('Desktop')) '강의록앱.lnk'), (Join-Path $progs '강의록앱.lnk'), (Join-Path $progs '강의록앱 다시 켜기.lnk'),
  (Join-Path $progs '강의록앱 삭제.lnk'), (Join-Path ([Environment]::GetFolderPath('Startup')) '강의록앱 (백그라운드).lnk'),
  (Join-Path $progs 'Chrome Apps\강의록앱.lnk'), (Join-Path $progs '강의록앱 (Chrome).lnk'), (Join-Path $progs 'Edge Apps\강의록앱.lnk')) |
  ForEach-Object { Remove-Item $_ -Force -ErrorAction SilentlyContinue }
if ($Save -and (Test-Path (Join-Path $Save '_실행기록'))) { Remove-Item (Join-Path $Save '_실행기록') -Recurse -Force -ErrorAction SilentlyContinue }
Remove-Item (Join-Path $env:LOCALAPPDATA 'ms-playwright') -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\LectureApp' -Recurse -Force -ErrorAction SilentlyContinue   # 설치 프로그램(exe)이 만든 「앱 목록」 항목
Set-Location $env:USERPROFILE
Remove-Item $App -Recurse -Force -ErrorAction SilentlyContinue

Write-Host ''
if (Test-Path $App) { Write-Host "일부를 지우지 못했어요. 컴퓨터를 다시 켠 뒤 $App 폴더를 직접 지워 주세요." -ForegroundColor Red }
else { Write-Host '삭제 끝!' -ForegroundColor Green }
Write-Host '  · 크롬·엣지에 앱으로 설치했다면: chrome://apps (엣지: edge://apps) → 강의록앱 → 삭제'
Write-Host ''
Read-Host '엔터를 누르면 닫혀요'
