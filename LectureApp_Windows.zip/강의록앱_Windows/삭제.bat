@echo off
chcp 65001 >nul
title Lecture App uninstall
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0uninstall.ps1"
