﻿# 강의록앱 설치·업데이트 (Windows) — 설치.bat 이 실행해요. 받아 둔 강의록·설정·시간표·매칭 기억은 건드리지 않아요.
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
$Src = Split-Path -Parent $MyInvocation.MyCommand.Path
$Pay = Join-Path $Src 'app'
$App = Join-Path $env:USERPROFILE '강의록앱'
function Say($t) { Write-Host ''; Write-Host "▶ $t" -ForegroundColor Cyan }
function Fail($t) { Write-Host ''; Write-Host $t -ForegroundColor Red; Read-Host '엔터를 누르면 닫혀요'; exit 1 }

Write-Host "강의록앱 설치·업데이트 (버전 $(Get-Content (Join-Path $Pay 'VERSION')))" -ForegroundColor White
Write-Host '몇 분 걸릴 수 있어요. 끝나면 앱 화면이 저절로 열려요.'

# 더 새 버전이 이미 깔려 있으면 덮어쓰지 않음 (예전 설치 파일을 다시 실행한 경우)
$NewV = (Get-Content (Join-Path $Pay 'VERSION') -ErrorAction SilentlyContinue | Select-Object -First 1)
$OldV = (Get-Content (Join-Path $App 'VERSION') -ErrorAction SilentlyContinue | Select-Object -First 1)
if ($OldV -and $NewV -and ([string]::CompareOrdinal($OldV.Trim(), $NewV.Trim()) -gt 0) -and (Test-Path (Join-Path $App '.venv\Scripts\python.exe'))) {
  Write-Host "이미 더 새 버전($OldV)이 설치돼 있어요. 이 설치 파일($NewV)은 쓰지 않을게요." -ForegroundColor Yellow
  Read-Host '엔터를 누르면 닫혀요'; exit 0
}
# 받는 중이면 먼저 물어봄 (끄면 이번 받기가 중간에 멈춰요)
$Busy = $false
foreach ($lk in @((Join-Path $App 'logs\받기중.json'), (Join-Path $App 'logs\업데이트중\pid'))) {
  try {
    if (Test-Path $lk) {
      $t = Get-Content $lk -Raw -ErrorAction Stop
      $m = [regex]::Match($t, '\d+')
      if ($m.Success) {
        $pr = Get-CimInstance Win32_Process -Filter ("ProcessId=" + [int]$m.Value) -ErrorAction SilentlyContinue   # 같은 번호를 다른 프로그램이 다시 쓰는 경우는 빼고
        if ($pr -and $pr.Name -match '^pythonw?\.exe$' -and $pr.CommandLine -like '*lecture_app*') { $Busy = $true }
      }
    }
  } catch {}
}
if ($Busy) {
  Write-Host ''
  Write-Host '지금 강의록을 받는 중(또는 앱이 업데이트하는 중)이에요. 설치하면 그 작업이 멈춰요.' -ForegroundColor Yellow
  $a = Read-Host '그래도 설치할까요? (y = 설치 / 엔터 = 취소)'
  if ($a -notmatch '^[yYㅛ]') { Write-Host '취소했어요. 받기가 끝난 뒤 다시 실행해 주세요.'; Read-Host '엔터를 누르면 닫혀요'; exit 0 }
}
# 켜져 있는 앱(화면 서버)을 먼저 끔: 켜진 채로는 파일이 잠겨서 복사·설치가 실패할 수 있어요
Get-CimInstance Win32_Process -Filter "Name='pythonw.exe' OR Name='python.exe'" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -like '*lecture_app*' } | ForEach-Object { & taskkill /T /F /PID $_.ProcessId 2>$null | Out-Null }   # /T = 받기용 브라우저(node·chrome)까지 같이 끔
Start-Sleep 1

Say ('1/6 앱 파일 복사 → ' + $App)
New-Item -ItemType Directory -Force -Path $App | Out-Null
# /R:3 /W:1 = 잠긴 파일(백신·OneDrive)은 3번만 다시 시도 (기본값이면 며칠을 기다려요) · 8 이상 = 복사 실패
robocopy (Join-Path $Pay 'lecture_app') (Join-Path $App 'lecture_app') /MIR /XD __pycache__ /R:3 /W:1 /NFL /NDL /NJH /NJS /NP | Out-Null
if ($LASTEXITCODE -ge 8) { Fail '앱 파일을 복사하지 못했어요. 백신·OneDrive가 강의록앱 폴더를 쓰고 있을 수 있어요. 잠시 뒤 설치.bat 을 다시 실행해 주세요.' }
robocopy (Join-Path $Pay 'fonts') (Join-Path $App 'fonts') /E /XD user /R:3 /W:1 /NFL /NDL /NJH /NJS /NP | Out-Null
if ($LASTEXITCODE -ge 8) { Fail '글꼴 파일을 복사하지 못했어요. 잠시 뒤 설치.bat 을 다시 실행해 주세요.' }
foreach ($f in 'requirements.txt', 'lecture_app_run.pyw', 'icon.ico', 'restart.ps1') { Copy-Item (Join-Path $Pay $f) $App -Force }
foreach ($f in 'config.json', '시간표.json') { if (-not (Test-Path (Join-Path $App $f))) { Copy-Item (Join-Path $Pay $f) $App } }
# BOM 없는 UTF-8 로 (Set-Content -Encoding UTF8 은 BOM 을 붙여서 앱이 못 읽음)
if (-not (Test-Path (Join-Path $App '매칭기억.json'))) { [IO.File]::WriteAllText((Join-Path $App '매칭기억.json'), '{}') }

Say '2/6 파이썬 확인'
function Test-Py($exe) {
  try { $o = & $exe -c "import sys;print(sys.version_info >= (3,9))" 2>$null; return ($o -match 'True') } catch { return $false }
}
function Find-Py {
  $c = @()
  $ver = { $m = [regex]::Match($_.Directory.Name, 'Python3(\d+)'); if ($m.Success) { [int]$m.Groups[1].Value } else { 0 } }   # Python313 > Python39
  $c += Get-ChildItem "$env:LOCALAPPDATA\Programs\Python\Python3*\python.exe" -ErrorAction SilentlyContinue | Sort-Object -Property @{Expression=$ver} -Descending | ForEach-Object FullName
  $c += Get-ChildItem "$env:ProgramFiles\Python3*\python.exe" -ErrorAction SilentlyContinue | Sort-Object -Property @{Expression=$ver} -Descending | ForEach-Object FullName
  $py = Get-Command py -ErrorAction SilentlyContinue
  if ($py) { try { $p = & py -3 -c "import sys;print(sys.executable)" 2>$null; if ($p) { $c += $p.Trim() } } catch {} }
  $pc = Get-Command python -ErrorAction SilentlyContinue
  if ($pc -and $pc.Source -notmatch 'WindowsApps') { $c += $pc.Source }     # Microsoft Store 바로가기(가짜 python)는 빼고
  foreach ($e in $c) { if ($e -and (Test-Path $e) -and (Test-Py $e)) { return $e } }
  return $null
}
$Py = Find-Py
if (-not $Py) {
  Write-Host '파이썬이 없어서 설치할게요 (winget).'
  try { winget install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements } catch {}
  $Py = Find-Py
  if (-not $Py) { Fail '파이썬을 설치하지 못했어요. https://www.python.org 에서 Python 3.12 를 설치한 뒤 설치.bat 을 다시 실행해 주세요.' }
}
Write-Host "사용할 파이썬: $Py"
$VPy = Join-Path $App '.venv\Scripts\python.exe'
$VPyw = Join-Path $App '.venv\Scripts\pythonw.exe'
# 예전에 만든 환경이 망가졌으면(기본 파이썬을 지웠거나 바꿈) 새로 만듦
if (Test-Path $VPy) {
  $bad = $false
  try { & $VPy -c "import sys" 2>$null; $bad = ($LASTEXITCODE -ne 0) } catch { $bad = $true }
  if ($bad) { Remove-Item -Recurse -Force (Join-Path $App '.venv') }
}
if (-not (Test-Path $VPy)) { & $Py -m venv (Join-Path $App '.venv'); if ($LASTEXITCODE) { Fail '앱 전용 파이썬 환경을 만들지 못했어요.' } }

Say '3/6 필요한 프로그램 설치 (처음엔 몇 분 걸려요)'
& $VPy -m pip install -q --upgrade pip
& $VPy -m pip install -q -r (Join-Path $App 'requirements.txt'); if ($LASTEXITCODE) { Fail '프로그램 설치에 실패했어요. 인터넷 연결을 확인하고 다시 실행해 주세요.' }
& $VPy -m playwright install chromium; if ($LASTEXITCODE) { Fail '자동 로그인용 브라우저를 받지 못했어요. 인터넷 연결을 확인하고 다시 실행해 주세요.' }

Say '4/6 LibreOffice (PPT → PDF 변환) 확인'
function Find-LO { @("$env:ProgramFiles\LibreOffice\program\soffice.exe", "${env:ProgramFiles(x86)}\LibreOffice\program\soffice.exe", "$env:LOCALAPPDATA\LibreOffice\program\soffice.exe") | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1 }
if (Find-LO) { Write-Host '있어요.' -ForegroundColor Green }
else {
  Write-Host 'LibreOffice(무료)를 설치할게요. 관리자 확인 창이 뜨면 [예]를 눌러 주세요. (몇 분 걸려요)'
  try { if (Get-Command winget -ErrorAction SilentlyContinue) { winget install -e --id TheDocumentFoundation.LibreOffice --accept-package-agreements --accept-source-agreements } } catch {}
  if (-not (Find-LO)) {      # winget 이 없거나 실패하면 공식 사이트에서 설치 파일을 직접 받아 설치
    try {
      [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
      $LB = 'https://download.documentfoundation.org/libreoffice/stable'
      $html = (Invoke-WebRequest -UseBasicParsing "$LB/").Content
      $LV = [regex]::Matches($html, 'href="(\d+\.\d+\.\d+)/"') | ForEach-Object { $_.Groups[1].Value } | Sort-Object { [version]$_ } | Select-Object -Last 1
      if ($LV) {
        if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64') { $LF = 'aarch64'; $LA = 'aarch64' } else { $LF = 'x86_64'; $LA = 'x86-64' }
        $msi = Join-Path $env:TEMP "LibreOffice_$LV.msi"
        Write-Host "LibreOffice $LV 받는 중 (약 350MB)…"
        $pp = $ProgressPreference; $ProgressPreference = 'SilentlyContinue'
        Invoke-WebRequest -UseBasicParsing "$LB/$LV/win/$LF/LibreOffice_${LV}_Win_$LA.msi" -OutFile $msi
        $ProgressPreference = $pp
        Write-Host '설치 중… (관리자 확인 창이 뜨면 [예])'
        Start-Process msiexec.exe -ArgumentList @('/i', "`"$msi`"", '/passive', '/norestart') -Verb RunAs -Wait
        Remove-Item $msi -ErrorAction SilentlyContinue
      }
    } catch { Write-Host "($($_.Exception.Message))" }
  }
  if (Find-LO) { Write-Host 'LibreOffice 설치 완료.' -ForegroundColor Green }
  else {
    Write-Host ''
    Write-Host 'LibreOffice를 자동으로 설치하지 못했어요. 꼭 직접 설치해 주세요!' -ForegroundColor Red
    Write-Host '  · 없으면 PPT로 올라온 강의록이 「실패」로 떠요 (PDF 강의록은 받아져요).'
    Write-Host '  · 곧 열리는 페이지에서 Windows용을 받아 설치 프로그램을 실행하세요.'
    Write-Host '  · 설치한 뒤 앱에서 받기를 다시 돌리면 실패한 강의록이 만들어져요.'
    Start-Process 'https://www.libreoffice.org/download/download-libreoffice/'
    Read-Host '확인했으면 엔터를 누르세요'
  }
}

Say '5/6 바로가기 만들기 (바탕 화면 · 시작 메뉴)'
$sh = New-Object -ComObject WScript.Shell
foreach ($dir in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
  $lnk = $sh.CreateShortcut((Join-Path $dir '강의록앱.lnk'))
  $lnk.TargetPath = $VPyw
  $lnk.Arguments = '"' + (Join-Path $App 'lecture_app_run.pyw') + '" 화면'
  $lnk.WorkingDirectory = $App
  $lnk.IconLocation = (Join-Path $App 'icon.ico')
  $lnk.Description = '강의록앱'
  $lnk.Save()
}

# 시작 메뉴: 강의록앱 다시 켜기 (업데이트가 안 보이거나 화면이 이상할 때)
$rl = $sh.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Programs')) '강의록앱 다시 켜기.lnk'))
$rl.TargetPath = 'powershell.exe'
$rl.Arguments = '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + (Join-Path $App 'restart.ps1') + '"'
$rl.WorkingDirectory = $App
$rl.IconLocation = (Join-Path $App 'icon.ico')
$rl.Save()

# 로그인할 때 화면 서버를 창 없이 켜 둠 → 작업 표시줄에 고정한 강의록앱 아이콘이 언제 눌러도 바로 열림
Copy-Item (Join-Path $Src 'uninstall.ps1') (Join-Path $App 'uninstall.ps1') -Force -ErrorAction SilentlyContinue
$un = $sh.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Programs')) '강의록앱 삭제.lnk'))
$un.TargetPath = 'powershell.exe'
$un.Arguments = '-NoProfile -ExecutionPolicy Bypass -File "' + (Join-Path $App 'uninstall.ps1') + '"'
$un.WorkingDirectory = $env:USERPROFILE
$un.Description = '강의록앱 삭제 (받아 둔 강의록은 남겨요)'
Copy-Item (Join-Path $Src 'uninstall.ico') (Join-Path $App 'uninstall.ico') -Force -ErrorAction SilentlyContinue
$un.IconLocation = (Join-Path $App 'uninstall.ico')
$un.Save()
$st = $sh.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Startup')) '강의록앱 (백그라운드).lnk'))
$st.TargetPath = $VPyw
$st.Arguments = '"' + (Join-Path $App 'lecture_app_run.pyw') + '" 화면 --상주 --창없이'
$st.WorkingDirectory = $App
$st.IconLocation = (Join-Path $App 'icon.ico')
$st.Save()

Say '6/6 마무리'
Copy-Item (Join-Path $Pay 'VERSION') $App -Force
# 예전 화면 서버가 켜져 있으면 끄고(업데이트 반영) 새로 켬
Get-CimInstance Win32_Process -Filter "Name='pythonw.exe'" | Where-Object { $_.CommandLine -like '*lecture_app_run.pyw*화면*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
Start-Process -FilePath $VPyw -ArgumentList @('"' + (Join-Path $App 'lecture_app_run.pyw') + '"', '화면', '--상주', '--창없이') -WorkingDirectory $App
Start-Sleep 2
Start-Process -FilePath $VPyw -ArgumentList @('"' + (Join-Path $App 'lecture_app_run.pyw') + '"', '창') -WorkingDirectory $App
Write-Host ''
Write-Host '설치 끝! 앱 화면이 열려요. 다음부터는 바탕 화면의 「강의록앱」을 누르면 돼요.' -ForegroundColor Green
Start-Sleep 3
