@echo off
chcp 65001 >nul
title Lecture App setup
if not exist "%~dp0app\lecture_app\" (
  echo.
  echo  Please extract the zip first: right-click the zip - Extract All, then run the bat in the extracted folder.
  echo.
  pause
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
if errorlevel 1 pause
