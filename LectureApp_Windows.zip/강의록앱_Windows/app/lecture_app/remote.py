"""휴대폰·아이패드에서 열기: 같은 와이파이(또는 핫스팟)의 다른 기기에서 강의록앱 화면을 보고 받기를 시작.

- 기본은 꺼져 있음. 설정에서 켜면 RPORT(8766)로 따로 문을 엶 (원래 화면 8765 는 이 컴퓨터만 그대로).
- 처음 접속한 기기는 이 컴퓨터 화면에 뜬 6자리 코드를 입력해야 함 → 기기마다 열쇠(쿠키)를 줌.
- 다른 기기에서 되는 것: 현황·받기 진행·기록 보기, 받기 시작·중지, PDF 보기. 설정·계정·파일 바꾸기는 안 됨.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import secrets
import socket
import subprocess
import sys
import threading
import time
from http.server import ThreadingHTTPServer
from pathlib import Path
from typing import List, Optional
from urllib.parse import parse_qs, quote, urlparse

from . import main as M

RPORT = 8766
COOKIE = "la_rt"
_SRV: List[Optional[ThreadingHTTPServer]] = [None]
# 연결 코드·QR 열쇠는 방법마다 따로 (같은 와이파이 / 밖에서)
_CODES = {"lan": {"code": "", "at": 0.0, "key": ""}, "tunnel": {"code": "", "at": 0.0, "key": ""}}
_FAILS: dict = {}
_GFAILS: list = []           # 모든 기기 합친 틀린 시각 (코드를 바꿔도 안 지움 → 밖에서 계속 맞혀 보기 막기)
G_WIN = 600
_TFAILS: list = []           # 터널(밖)에서 온 코드 실패 (1시간)
TUNNEL_FAIL_MAX = 10
_NEXT: dict = {}             # 홈 화면 앱용 한 번 쓰는 열쇠 → (만료 시각, 방법)
_LOCK = threading.Lock()

# 다른 기기용 서비스 워커: 컴퓨터가 꺼져도(터널이 끊겨도) 마지막으로 본 현황·열어 본 PDF를 보여 줌
# (https 주소 = 밖에서 열기 터널에서만 동작. 같은 와이파이 http 주소에선 브라우저가 서비스 워커를 안 씀)
REMOTE_SW = r"""
const C='la-r2', P='la-r1-pdf', MAXPDF=40;
const API=/^\/api\/(state|job|runs|run|remote\/me|remote|pending|decided|profs|settings|covers|tt|sched_runs|update|cloud|acct\/state|prefs|ttlib|deps)$/, LIVE=/^\/api\/(events|log|progress)$/;
const LIB=/^https:\/\/cdn\.jsdelivr\.net\/npm\/pdfjs-dist@3\.11\.174\//;
// 설치할 때 앱 화면(/)도 받아 둠 → 처음 연 뒤 바로 컴퓨터가 꺼져도 앱이 열리고(마지막 내용 · 받아 둔 PDF), 앱이 10초마다 다시 이어 봄
self.addEventListener('install',e=>{ self.skipWaiting(); e.waitUntil((async()=>{ const c=await caches.open(C);
  try{ await c.addAll(['/manifest.webmanifest','/icon-192.png','/icon-64.png']); }catch(x){}
  try{ const r=await within(fetch('/',{cache:'no-store'}),8000); if(r.ok&&!down(r)&&/text\/html/.test(r.headers.get('content-type')||'')) await c.put('/',await stamp(r)); }catch(x){}
})()); });
// 앱 화면도 받아 둔 게 없을 때: 몇 초마다 스스로 다시 확인 + 이 기기에 받아 둔 PDF 열기
function offPage(){
  const css=':root{--bg:#EEF1F0;--card:#FFFFFF;--line:#E0E6E4;--ink:#16242A;--ink2:#4E6066;--ink3:#5F6F75;--accent:#0E6B63}'
   +'@media (prefers-color-scheme:dark){:root{--bg:#0F1618;--card:#172124;--line:#28373A;--ink:#E3ECEC;--ink2:#A7B7B9;--ink3:#8899A0;--accent:#3FB2A6}}'
   +'body{margin:0;background:var(--bg);color:var(--ink);font-family:-apple-system,system-ui,sans-serif;line-height:1.6}'
   +'.w{max-width:560px;margin:0 auto;padding:24px 16px}.c{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:16px;margin-top:12px}'
   +'h1{font-size:19px;margin:0 0 6px}p{margin:0;color:var(--ink2);font-size:14px}small{color:var(--ink3)}a{color:var(--accent);font-weight:700;text-decoration:none}'
   +'ul{list-style:none;margin:8px 0 0;padding:0}li{padding:7px 0;border-top:1px solid var(--line)}li:first-child{border-top:0}button{font:inherit;font-weight:700;color:var(--accent);background:none;border:1px solid var(--line);border-radius:10px;padding:6px 12px;margin-top:10px}';
  const js='(function(){var t=document.getElementById("t"),p=document.getElementById("p"),n=0,h=0,busy=0;'
   +'function chk(){if(busy)return;busy=1;clearTimeout(h);fetch("/api/remote/me",{cache:"no-store"}).then(function(r){busy=0;if(r.headers.get("x-la-app")&&!r.headers.get("x-la-offline"))location.reload();else again();}).catch(function(){busy=0;again();});}'
   +'function again(){n++;var s=Math.min(30,4+n*2);t.textContent=s+"초 뒤에 다시 확인해요";h=setTimeout(chk,s*1000);}'
   +'h=setTimeout(chk,4000);document.getElementById("r").onclick=function(){t.textContent="확인하는 중…";n=0;chk();};'
   +'document.addEventListener("visibilitychange",function(){if(!document.hidden)chk();});'
   +'var esc=function(s){return String(s).replace(/[&<>"]/g,function(c){return{"&":"&amp;","<":"&lt;",">":"&gt;","\\"":"&quot;"}[c];});};'
   +'if(self.caches)caches.open("la-r1-pdf").then(function(c){return c.keys();}).then(function(ks){var a=[];ks.forEach(function(k){var u=new URL(k.url);if(u.pathname==="/remote/file"){var rel=u.searchParams.get("rel")||"";if(rel)a.push(rel);}});'
   +'if(!a.length){p.innerHTML="<p>이 기기에 받아 둔 PDF가 없어요. 다음부터는 컴퓨터가 켜져 있을 때 한 번 열어 본 PDF가 여기 남아요.</p>";return;}'
   +'a.reverse();p.innerHTML="<p><b>이 기기에 받아 둔 PDF</b> · 컴퓨터가 꺼져 있어도 열려요</p><ul>"+a.map(function(rel){var s=rel.split("/"),nm=s.pop();return "<li><a href=\\"/remote/file?rel="+encodeURIComponent(rel)+"\\">"+esc(nm)+"</a>"+(s.length?"<br><small>"+esc(s.join(" › "))+"</small>":"")+"</li>";}).join("")+"</ul>";}).catch(function(){});})();';
  const html='<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>강의록앱</title><style>'+css+'</style>'
   +'<div class="w"><h1>컴퓨터에 연결할 수 없어요</h1><p>컴퓨터가 켜져 있고 강의록앱이 실행 중인지 확인해 주세요. 이어지면 저절로 열려요 · <span id="t">잠시 뒤에 다시 확인해요</span></p>'
   +'<button id="r" type="button">지금 다시 확인</button><div class="c" id="p"><p>받아 둔 PDF를 찾는 중…</p></div></div><script>'+js+'</script></html>';
  return new Response(html,{status:503,headers:{'content-type':'text/html; charset=utf-8','x-la-offline':'0'}});
}
self.addEventListener('activate',e=>e.waitUntil((async()=>{ for(const k of await caches.keys()) if(k!==C&&k!==P) await caches.delete(k); await self.clients.claim(); })()));
// 강의록앱이 보낸 응답에는 x-la-app 이 붙음 → 없으면(Cloudflare 오류 페이지 등) 번호와 상관없이 컴퓨터 꺼짐으로 봄
const down=r=>!r||r.type==='opaqueredirect'||!r.headers.get('x-la-app')||[502,503,504,520,521,522,523,524,530].includes(r.status);
function within(p,ms){ return new Promise((ok,no)=>{ const t=setTimeout(()=>no(new Error('timeout')),ms); p.then(v=>{clearTimeout(t);ok(v);},e=>{clearTimeout(t);no(e);}); }); }
async function stamp(r){ const h=new Headers(r.headers); h.set('x-la-at',String(Date.now())); h.delete('set-cookie'); const b=await r.clone().blob();
  const n=+(r.headers.get('content-length')||0); if(n&&b.size!==n) throw new Error('short');      // 중간에 끊긴 파일은 저장 안 함
  return new Response(b,{status:200,headers:h}); }
async function fromCache(cache,key){ const hit=await cache.match(key); if(!hit) return null; const h=new Headers(hit.headers); h.set('x-la-offline',hit.headers.get('x-la-at')||'1'); return new Response(await hit.blob(),{status:200,headers:h}); }
function offlineJson(){ return new Response(JSON.stringify({ok:false,offline:true,msg:'컴퓨터에 연결할 수 없어요'}),{status:503,headers:{'content-type':'application/json; charset=utf-8','x-la-offline':'0'}}); }
async function netFirst(req,key,ms,cacheName,keep){
  const cache=await caches.open(cacheName);
  try{
    const r=await within(fetch(req,{cache:'no-store'}),ms);
    if(down(r)) throw new Error('down');
    if(r.ok && (!keep||await keep(r.clone()))){ try{ await cache.put(key,await stamp(r)); if(cacheName===P) trim(cache); }catch(e){} }
    return r;
  }catch(e){
    return (await fromCache(cache,key)) || null;
  }
}
async function trim(cache){ const ks=await cache.keys(); for(let i=0;i<ks.length-MAXPDF;i++) await cache.delete(ks[i]); }
self.addEventListener('fetch',e=>{
  const req=e.request; if(req.method!=='GET') return;
  const u=new URL(req.url);
  if(LIB.test(req.url)){ e.respondWith(caches.open(C).then(async c=>{ const hit=await c.match(req.url); if(hit) return hit; const r=await fetch(req); if(r.ok) c.put(req.url,r.clone()); return r; })); return; }
  if(u.origin!==location.origin) return;
  if(u.pathname==='/remote/file'||u.pathname.startsWith('/remote/file/')){
    const rel=u.searchParams.get('rel')||''; const key='/remote/file?rel='+encodeURIComponent(rel);
    e.respondWith(netFirst(req,key,15000,P,async r=>/pdf/.test(r.headers.get('content-type')||'')).then(r=>r||offlineJson())); return; }
  if(u.pathname==='/remote/pfile'||u.pathname.startsWith('/remote/pfile/')){
    e.respondWith(netFirst(req,'/remote/pfile'+u.search,15000,P,async r=>/pdf/.test(r.headers.get('content-type')||'')).then(r=>r||offlineJson())); return; }
  if(u.pathname==='/'){
    e.respondWith(netFirst(req,'/',8000,C,async r=>/text\/html/.test(r.headers.get('content-type')||'')).then(r=>r||offPage())); return; }
  if(LIVE.test(u.pathname)){              // 받기 중 실시간 기록: 저장 안 함 (꺼져 있으면 빈 내용)
    e.respondWith(within(fetch(req,{cache:'no-store'}),7000).then(r=>{ if(down(r)) throw 0; return r; }).catch(()=>new Response(JSON.stringify({text:'',offset:+(u.searchParams.get('offset')||0),offline:true}),{status:200,headers:{'content-type':'application/json; charset=utf-8','x-la-offline':'-1'}}))); return; }
  if(API.test(u.pathname)){
    const key=u.pathname+u.search;
    const keep=u.pathname==='/api/remote/me'?(async r=>{ let a=false; try{ a=!!(await r.json()).auth; }catch(x){}
      if(!a){ await caches.delete(C); await caches.delete(P); }      // 연결이 끊긴 기기: 저장해 둔 현황·PDF도 지움
      return a; }):null;
    e.respondWith(netFirst(req,key,7000,C,keep).then(r=>r||offlineJson())); return; }
  if(/^\/(icon-\d+\.png|manifest\.webmanifest|help-img\/)/.test(u.pathname)){
    e.respondWith(netFirst(req,u.pathname,6000,C).then(r=>r||fetch(req))); return; }
});
"""

GET_OK = {"/api/rev", "/api/state", "/api/verq", "/api/merge", "/api/name", "/api/progress", "/api/job", "/api/log", "/api/events", "/api/runs", "/api/run",
          # 휴대폰에서 보기: 애매한 자료·강좌별 교수 (고르기·고치기도 됨) / 설정·예약·시간표·표지 (보기만)
          "/api/pending", "/api/decided", "/api/profs", "/api/settings", "/api/covers", "/api/cover/preview",
          "/api/font/file", "/api/tt", "/api/sched_runs", "/api/update", "/api/cloud",
          "/api/prefs", "/api/acct/state", "/api/sync/state", "/api/acct/devices", "/api/ttlib", "/api/deps"}                      # 컴퓨터의 화면 설정(과목 카드 핀·순서·시험 시간 등)을 휴대폰에서도 보기만
POST_OK = {"/api/start", "/api/stop", "/api/xskip", "/api/view"}          # 휴대폰에서 바로 받는 것: 받기 시작·중지 · 시험에 안 나옴 표시 · 보기 설정
# 폰만 쓰는 웹앱에서 고칠 수 있는 것은 컴퓨터에 연결한 폰에서도 고칠 수 있게 (같은 화면 · 같은 기능)
POST_EDIT = {"/api/pending", "/api/decided", "/api/schedule", "/api/grade", "/api/prefs", "/api/merge", "/api/verq",
             "/api/tt/preview", "/api/tt/pick", "/api/tt/apply", "/api/tt/move", "/api/tt/revert", "/api/tt/past_preview", "/api/tt/past_apply", "/api/profs/set",
             "/api/drive_list", "/api/drive_check", "/api/drive_check_old", "/api/old_status", "/api/drive_suggest",
             "/api/settings"}
PC_ONLY = "이 설정은 컴퓨터의 강의록앱에서 바꿔 주세요"      # 연결 기기에서 막힌 것 — 화면(gui.html RM_PC_MSG)과 같은 문구
CFG_LOCKED = {"/api/settings", "/api/schedule", "/api/grade", "/api/tt/apply", "/api/tt/move", "/api/tt/revert", "/api/tt/past_apply", "/api/profs/set"}
# 설정은 이 값만 휴대폰에서 받음 (저장 위치 · LMS · 표지 · 파일 이름 · 휴대폰 연결 등은 컴퓨터에서만)
SET_OK = {"extras_old", "extras_old_clear", "extras_order", "extras_label", "extras",
          "drive_root", "drive_sem_id", "drive_semester", "drive_sem_label", "drive_maps_sem",
          "drive_course_map", "drive_course_map_root", "drive_manual_map", "drive_extras_map", "drive_extras"}


def _phone_settings(body: dict) -> dict:
    """휴대폰이 보낸 설정에서 허용한 값만 남김.
    선배 추가자료의 '내 컴퓨터 폴더' 줄은 휴대폰이 보낸 값을 쓰지 않고 컴퓨터에 저장된 줄을 통째로 그대로 둠
    (폰에서 새로 만들거나 · 경로 · 구조 · 과목 맞추기를 바꾸거나 · 지울 수 없음)"""
    b = {k: v for k, v in (body or {}).items() if k in SET_OK}
    b.pop("extras_old_clear", None)                     # 전부 지우기는 컴퓨터에서만
    if "extras_old" in b:
        if not isinstance(b["extras_old"], list):
            b.pop("extras_old")
        else:
            from . import gui
            mine = [dict(o) for o in (gui._read_cfg().get("extras_old") or []) if isinstance(o, dict) and o.get("local")]
            rows, seen = [], set()
            for o in b["extras_old"]:
                if not isinstance(o, dict):
                    continue
                if o.get("local"):                       # 컴퓨터 폴더 줄: 같은 폴더의 저장된 줄로 바꿔 넣음 (없는 폴더면 버림)
                    keep = next((m for m in mine if str(m.get("local")) == str(o.get("local"))), None)
                    if keep is not None and id(keep) not in seen:
                        seen.add(id(keep)); rows.append(keep)
                    continue
                o = {k: v for k, v in o.items() if k not in ("local",)}
                if isinstance(o.get("map"), dict):
                    o["map"] = {k: v for k, v in o["map"].items() if isinstance(v, str)}
                p = str(o.get("path") or "")
                if ".." in p.replace("\\", "/").split("/"):
                    o["path"] = ""
                rows.append(o)
            rows += [m for m in mine if id(m) not in seen]   # 폰 목록에 빠졌어도 컴퓨터 폴더 줄은 남김
            b["extras_old"] = rows
    return b


def _phone_body(path: str, body: dict) -> dict:
    """휴대폰 요청 본문 정리: 컴퓨터 폴더를 들여다보는 값은 컴퓨터에 저장된 선배 폴더만"""
    if path in ("/api/old_status", "/api/drive_check_old"):
        o = body.get("row") if isinstance(body.get("row"), dict) else None
        tgt = o if o is not None else body
        if tgt.get("local"):
            from . import gui
            have = {str(x.get("local")) for x in (gui._read_cfg().get("extras_old") or []) if isinstance(x, dict) and x.get("local")}
            if str(tgt.get("local")) not in have:
                return {}
        p = str(tgt.get("path") or "")
        if (_bad_rel(p) if tgt.get("local") else ".." in [x.strip() for x in p.replace("\\", "/").split("/")]):
            tgt["path"] = ""                           # 내 폴더: .. · 절대 경로 · 드라이브(C:\ · D:) · 네트워크 경로(\\서버) → 비움 / 드라이브 줄: ..
        for o2 in {id(tgt): tgt, id(body): body}.values():   # 학기 이름도 폴더 한 칸으로만 (/etc · ..\\.. · C: 막기)
            if "semester" in o2 and _bad_name(o2.get("semester")):
                o2.pop("semester", None)
    return body


def _bad_rel(p) -> bool:
    """폰이 보낸 「폴더 안 경로」가 저장된 폴더 밖을 가리키는지 (윈도우 · 맥 둘 다 기준으로 봄)"""
    from pathlib import PurePosixPath, PureWindowsPath
    s = str(p or "")
    if not s:
        return False
    if "\x00" in s or ":" in s or s.startswith(("/", "\\", "~")):
        return True
    if PureWindowsPath(s).drive or PureWindowsPath(s).anchor or PurePosixPath(s).is_absolute():
        return True
    return ".." in [x.strip() for x in s.replace("\\", "/").split("/")]


def _bad_name(v) -> bool:
    """폴더 이름 한 칸이어야 하는 값(학기)"""
    s = str(v or "").strip()
    return bool(s) and (s == ".." or any(c in s for c in "/\\:\x00") or s.startswith("~"))     # "." = 학기 폴더 없음 (그대로 둠)


# ---------------------------------------------------------------- 설정
def _cfg() -> dict:
    try:
        return dict(M.read_cfg().get("remote") or {})
    except Exception:
        return {}


def enabled() -> bool:
    """같은 와이파이에서 열기 (와이파이의 다른 기기에 문을 엶)"""
    return bool(_cfg().get("enabled"))


def tunnel_on() -> bool:
    return bool(_cfg().get("tunnel"))


def serving() -> bool:
    """다른 기기용 문(RPORT)이 필요한지: 와이파이 또는 밖에서 열기 중 하나라도 켜져 있으면"""
    r = _cfg()
    return bool(r.get("enabled")) or bool(r.get("tunnel"))


def mb_view() -> str:
    """메뉴 막대에 보일 QR: 둘 다 켜져 있으면 고른 쪽, 하나만 켜져 있으면 그쪽"""
    r = _cfg()
    lan, tn = bool(r.get("enabled")), bool(r.get("tunnel"))
    if lan and tn:
        return "tunnel" if r.get("mb_view") == "tunnel" else "lan"
    return "tunnel" if tn else ("lan" if lan else "")


ACCT_KEY_DAYS = 30


def acct_key() -> str:
    """계정 열쇠: 내 구글 드라이브 「_상태」에만 올라가는 긴 열쇠 (같은 구글 계정의 웹앱이 터널 주소가 바뀌어도 코드 없이 연결)
    30일마다 새로 · 밖에서 열기(터널)가 꺼져 있으면 없음"""
    if not tunnel_on():
        return ""
    r = _cfg()
    k, at = str(r.get("acct_key") or ""), float(r.get("acct_key_at") or 0)
    if k and time.time() - at < ACCT_KEY_DAYS * 86400:
        return k
    k = secrets.token_urlsafe(32)
    with M.CFG_LOCK:
        cfg = M.read_cfg()
        rr = dict(cfg.get("remote") or {})
        rr["acct_key"], rr["acct_key_at"] = k, time.time()
        cfg["remote"] = rr
        M.write_cfg(cfg)
    return k


def _hash(tok: str) -> str:
    return hashlib.sha256(tok.encode("utf-8")).hexdigest()


def _m(via: str) -> str:
    return "tunnel" if via == "tunnel" else "lan"


def new_code(via: str = "lan") -> str:
    with _LOCK:
        C = _CODES[_m(via)]
        C["code"] = f"{secrets.randbelow(1000000):06d}"
        C["key"] = secrets.token_urlsafe(18)          # QR 안에 들어가는 열쇠 (찍으면 코드 없이 연결)
        C["at"] = time.time()
        return C["code"]


CODE_TTL = 30 * 60          # 연결 코드는 30분이 지나면 새로 (화면에는 늘 지금 코드가 보여요)
FAIL_MAX = 20               # 모든 기기 합쳐서 이만큼 틀리면 코드를 새로 (주소를 바꿔 가며 맞혀 보는 것 막기)


def code(via: str = "lan") -> str:
    with _LOCK:
        C = _CODES[_m(via)]
        c = C["code"]
        old = c and time.time() - C["at"] > CODE_TTL
    return new_code(via) if (not c or old) else c


WEB_APP = "https://lecture-app-knu.pages.dev"


def _acct_hint() -> str:
    """QR 에 넣는 계정 힌트: 가린 이메일만 (kcm***@gmail.com) · 로그인 안 했으면 ''"""
    try:
        e = str(json.loads((M.APP / "account.json").read_text("utf-8")).get("email") or "")
    except Exception:
        return ""
    i = e.find("@")
    return (e[:3] + "***" + e[i:]) if i > 3 else ("***" + e[i:] if i > 0 else "")


def qr_url(base: str, via: str = "lan") -> str:
    """QR 에 넣는 주소: 찍으면 코드 입력 없이 바로 연결 (# 뒤라 서버 기록에도 안 남음)
    밖에서(터널) QR = 웹앱 주소 + 터널 주소 · QR 열쇠(k, 원래 있던 것) · 가린 계정 · 기기 종류
      → 웹앱이 처음이면 「쓰던 기기 찾았어요 · kcm*** 계정」 이어받기(캔버스 P12), 이미 쓰는 웹앱이면 바로 컴퓨터 화면(base/#k=…)으로
    같은 와이파이(http) QR 은 그대로 컴퓨터 화면"""
    code(via)
    k = _CODES[_m(via)]['key']
    if _m(via) == "tunnel" and base.startswith("https://"):
        d = "mac" if sys.platform == "darwin" else "win" if sys.platform.startswith("win") else "pc"
        return f"{WEB_APP}/#c={quote(base, safe='')}&k={quote(k, safe='')}&a={quote(_acct_hint(), safe='')}&d={d}"
    return f"{base}/#k={k}"


def _fail_key(ip: str) -> str:
    """틀린 횟수를 세는 단위: IPv4는 주소, IPv6는 앞 64비트(한 기기가 주소를 바꿔 가며 시도해도 같이 셈)"""
    try:
        import ipaddress
        a = ipaddress.ip_address(ip.split("%")[0])
        if a.version == 6 and not a.ipv4_mapped:
            return str(ipaddress.ip_network(f"{a}/64", strict=False))
    except Exception:
        pass
    return ip


def devices() -> list:
    """via: lan(같은 와이파이로 연결) / tunnel(밖에서 연결) / old(예전에 연결해 방법 기록이 없음)"""
    return [{"id": d.get("id"), "name": d.get("name", ""), "added": d.get("added", ""), "seen": d.get("seen", ""),
             "via": d.get("via") or "old"} for d in _cfg().get("devices") or []]


def _device_of(tok: str) -> Optional[dict]:
    if not tok:
        return None
    h = _hash(tok)
    for d in _cfg().get("devices") or []:
        if secrets.compare_digest(str(d.get("hash", "")), h):
            return d
    return None


def _add_device(name: str, via: str = "lan", replace: bool = False) -> str:
    tok = secrets.token_urlsafe(32)
    with M.CFG_LOCK:
        cfg = M.read_cfg()
        r = dict(cfg.get("remote") or {})
        devs = list(r.get("devices") or [])
        if replace:                                   # 계정 열쇠로 다시 연결(터널 주소가 바뀜) → 같은 이름 기기는 한 줄로
            devs = [d for d in devs if not (d.get("name") == name[:40] and (d.get("via") or "old") == _m(via))]
        devs.append({"id": secrets.token_hex(4), "name": name[:40], "hash": _hash(tok), "via": _m(via),
                     "added": time.strftime("%Y-%m-%d %H:%M")})
        same = [d for d in devs if (d.get("via") or "old") == _m(via)]
        if len(same) > 10:                            # 방법마다 기기는 10개까지 (오래된 것부터 빼기)
            drop = {id(d) for d in same[:-10]}
            devs = [d for d in devs if id(d) not in drop]
        r["devices"] = devs[-30:]
        cfg["remote"] = r
        M.write_cfg(cfg)
    return tok


def forget(dev_id) -> int:
    """기기 연결 끊기 · dev_id: 하나 또는 여러 개(list) · 끊은 수"""
    ids = {str(x) for x in (dev_id if isinstance(dev_id, (list, tuple, set)) else [dev_id]) if x}
    with M.CFG_LOCK:
        cfg = M.read_cfg()
        r = dict(cfg.get("remote") or {})
        old = r.get("devices") or []
        devs = [d for d in old if d.get("id") not in ids]
        if len(devs) == len(old):
            return 0
        r["devices"] = devs
        cfg["remote"] = r
        M.write_cfg(cfg)
    return len(old) - len(devs)


def _dev_name(ua: str) -> str:
    ua = ua or ""
    for k, v in (("iPad", "아이패드"), ("iPhone", "아이폰"), ("Android", "안드로이드"), ("Macintosh", "맥"), ("Windows", "윈도우")):
        if k in ua:
            return v
    return "기기"


# ---------------------------------------------------------------- 주소·QR
def addresses() -> List[str]:
    """다른 기기에서 쳐 넣을 주소 (이름 주소 먼저, 그다음 숫자 주소)"""
    out = []
    name = ""
    try:
        if sys.platform == "darwin":
            name = subprocess.run(["scutil", "--get", "LocalHostName"], capture_output=True, text=True, timeout=3).stdout.strip()
        else:
            name = socket.gethostname().split(".")[0]
    except Exception:
        pass
    if name and re.fullmatch(r"[A-Za-z0-9-]+", name):
        out.append(f"http://{name}.local:{RPORT}")
    ips = []
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))           # 실제로 보내지는 않음 (밖으로 나가는 주소 확인용)
        ips.append(s.getsockname()[0])
        s.close()
    except Exception:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ips.append(info[4][0])
    except Exception:
        pass
    import ipaddress
    clat = ipaddress.ip_network("192.0.0.0/29")     # 아이폰 핫스팟(IPv6 통신사)에서 맥이 받는 가짜 IPv4 → 폰에서 못 들어옴
    good = []
    for ip in dict.fromkeys(ips):
        try:
            a = ipaddress.ip_address(ip)
        except ValueError:
            continue
        if a.is_loopback or a.is_link_local or a in clat:
            continue
        good.append((0 if a.is_private else 1, ip))
    if any(k == 0 for k, _ in good):            # 집·핫스팟 같은 내부 주소만 (밖에서 보이는 주소는 같은 와이파이에선 안 쓰임)
        good = [g for g in good if g[0] == 0]
    v4 = [f"http://{ip}:{RPORT}" for _, ip in good]
    v6 = [f"http://[{ip}]:{RPORT}" for ip in _ipv6_addrs()]
    # 이름(.local) 주소를 먼저 (QR에 씀): 와이파이·핫스팟이 바뀌어도 그대로라 홈 화면 바로가기도 계속 쓸 수 있음
    # 안 열릴 때 쓰는 숫자 주소(IPv4 → IPv6)는 그 아래에
    return out + v4 + v6


def _ipv6_addrs() -> List[str]:
    """이 컴퓨터의 IPv6 주소 (link-local 빼고, 영구 주소 먼저)"""
    import ipaddress
    found = []
    try:
        s = socket.socket(socket.AF_INET6, socket.SOCK_DGRAM)
        s.connect(("2001:4860:4860::8888", 1))       # 실제로 보내지는 않음
        found.append(s.getsockname()[0].split("%")[0])
        s.close()
    except Exception:
        pass
    if sys.platform == "darwin":
        try:
            out = subprocess.run(["ifconfig"], capture_output=True, text=True, timeout=3).stdout
            for m in re.finditer(r"inet6 ([0-9a-f:]+)[^\n]*?(temporary)?\n", out):
                if not m.group(2):
                    found.insert(0, m.group(1))
                else:
                    found.append(m.group(1))
        except Exception:
            pass
    good = []
    for ip in dict.fromkeys(found):
        try:
            a = ipaddress.ip_address(ip)
        except ValueError:
            continue
        if a.version == 6 and not (a.is_loopback or a.is_link_local or a.is_multicast or a.is_unspecified):
            good.append(ip)
    return good[:2]


def qr_svg(text: str) -> str:
    try:
        import qrcode
        import qrcode.image.svg
    except ImportError:
        threading.Thread(target=_install_qr, daemon=True).start()
        return ""
    try:
        img = qrcode.make(text, image_factory=qrcode.image.svg.SvgPathImage, box_size=8, border=2)
        s = img.to_string()
        return s.decode("utf-8") if isinstance(s, bytes) else str(s)
    except Exception:
        return ""


_QR_TRY = [0.0]


def _install_qr():
    if time.time() - _QR_TRY[0] < 3600:
        return
    _QR_TRY[0] = time.time()
    kw = {"creationflags": 0x08000000} if os.name == "nt" else {}
    try:
        subprocess.run([sys.executable, "-m", "pip", "install", "-q", "--disable-pip-version-check", "qrcode"],
                       capture_output=True, timeout=300, **kw)
    except Exception:
        pass


_ADDR = {"t": 0.0, "v": []}


def state(lite: bool = False, public: bool = False) -> dict:
    """설정 화면·메뉴 막대용. lite: QR 그림 없이 / public: 휴대폰에서 보는 설정 화면용 (코드·QR 빼고)"""
    lan, on = enabled(), serving()
    if lan and (not lite or time.time() - _ADDR["t"] > 30):
        _ADDR["v"], _ADDR["t"] = addresses(), time.time()
    adds = _ADDR["v"] if lan else []
    from . import tunnel
    tn = tunnel.state()
    ready = tn["status"] == "ready" and bool(tn["url"])
    tnon = tunnel_on()
    if tnon and ready and not lite and not public:
        tn["qr"] = qr_svg(qr_url(tn["url"], "tunnel"))
    cl = code("lan") if lan else ""
    ct = code("tunnel") if tnon else ""
    cfg = _cfg()
    view = mb_view()
    ck = hashlib.sha256((cl + ct + _CODES["lan"]["key"] + _CODES["tunnel"]["key"]).encode()).hexdigest()[:8] if on else ""
    out = {"enabled": lan, "serving": on, "running": _SRV[0] is not None,
           "codes": {"lan": cl, "tunnel": ct}, "code": ct if view == "tunnel" else cl,     # code: 메뉴 막대에 보일 쪽
           "ck": ck, "urls": adds, "qr": "" if (lite or public) else (qr_svg(qr_url(adds[0], "lan")) if adds else ""),
           "devices": devices(), "port": RPORT, "tunnel": tn,
           "mb_view": view, "mb_show": cfg.get("mb_show", True) is not False,
           # 메뉴 막대가 QR을 직접 그릴 때 쓰는 주소 (# 뒤 열쇠 포함)
           "lan_qr": qr_url(adds[0], "lan") if adds else "", "tunnel_qr": qr_url(tn["url"], "tunnel") if (tnon and ready) else ""}
    if public:
        for k in ("code", "ck", "lan_qr", "tunnel_qr"):
            out[k] = ""
        out["codes"] = {"lan": "", "tunnel": ""}
    return out

def set_enabled(on: bool) -> dict:
    """같은 와이파이에서 열기 켜기·끄기 (밖에서 열기와는 따로)"""
    with M.CFG_LOCK:
        cfg = M.read_cfg()
        r = dict(cfg.get("remote") or {})
        r["enabled"] = bool(on)
        cfg["remote"] = r
        M.write_cfg(cfg)
    err = ensure()
    if err:
        return {"ok": False, "msg": err}
    if on:
        return {"ok": True, "msg": "켰어요. 같은 와이파이의 휴대폰·아이패드에서 QR을 찍어 주세요."}
    return {"ok": True, "msg": "같은 와이파이에서 열기를 껐어요." + (" 밖에서 열기는 그대로 켜져 있어요." if tunnel_on() else "")}


def set_menubar(body: dict) -> dict:
    with M.CFG_LOCK:
        cfg = M.read_cfg()
        r = dict(cfg.get("remote") or {})
        if body.get("view") in ("lan", "tunnel"):
            r["mb_view"] = body["view"]
        if "show" in body:
            r["mb_show"] = bool(body["show"])
        cfg["remote"] = r
        M.write_cfg(cfg)
    return {"ok": True}


_SVLOCK = threading.RLock()          # 문 열기·닫기를 동시에 하지 않게 (메뉴 막대와 설정 화면이 같이 눌러도)


def ensure() -> Optional[str]:
    """설정에 맞게 문 열기·닫기: 와이파이 켬 → 모든 주소 / 밖에서만 → 이 컴퓨터 안(127.0.0.1)만 / 둘 다 끔 → 닫음"""
    from . import tunnel
    with _SVLOCK:
        lan, tn = enabled(), tunnel_on()
        with _LOCK:                       # 끈 쪽의 연결 코드·QR 열쇠는 바로 못 쓰게
            for via, on in (("lan", lan), ("tunnel", tn)):
                if not on:
                    _CODES[via].update(code="", key="", at=0.0)
                    for k in [k for k, v in _NEXT.items() if v[1] == via]:
                        _NEXT.pop(k, None)
        if not (lan or tn):
            stop()
            tunnel.stop()
            return None
        want = "all" if lan else "local"
        if _SRV[0] is not None and _BIND[0] != want:
            stop()
        err = start()
        if tn:
            tunnel.start()
        else:
            tunnel.stop()
        return err

# ---------------------------------------------------------------- 서버
class _Srv(ThreadingHTTPServer):
    allow_reuse_address = os.name != "nt"      # 윈도우는 같은 문을 두 번 열 수 있게 되어 버려서 끔


class _DualServer(_Srv):
    address_family = socket.AF_INET6

    def server_bind(self):
        try:
            self.socket.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 0)
        except (OSError, AttributeError):
            pass
        super().server_bind()


_BIND = [""]


def start() -> Optional[str]:
    with _SVLOCK:
        return _start()


def _start() -> Optional[str]:
    if _SRV[0] is not None or not serving():
        return None
    from . import gui
    want = "all" if enabled() else "local"
    last = None
    for _ in range(20):                    # 다시 켜는 중이면 앞 서버가 문을 닫을 때까지 잠깐 기다림
        try:
            if want == "local":            # 밖에서 열기만: 터널(cloudflared)만 들어오게 이 컴퓨터 안으로만
                srv = _Srv(("127.0.0.1", RPORT), _handler(gui))
                break
            try:
                srv = _DualServer(("::", RPORT), _handler(gui))      # IPv4·IPv6 둘 다 (아이폰 핫스팟은 IPv6로 들어옴)
            except OSError:
                srv = _Srv(("0.0.0.0", RPORT), _handler(gui))
            break
        except OSError as e:
            last = e
            time.sleep(0.5)
    else:
        return f"다른 기기용 문({RPORT})을 열지 못했어요: {last}"
    srv.daemon_threads = True
    _SRV[0] = srv
    _BIND[0] = want
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    if tunnel_on():
        try:
            from . import tunnel
            tunnel.start()
        except Exception as e:
            sys.stderr.write(f"터널 켜기 실패: {e}\n")
    return None


def stop():
    with _SVLOCK:
        srv = _SRV[0]
        _SRV[0] = None
        if srv:
            try:
                srv.shutdown()
                srv.server_close()
            except Exception:
                pass


def _handler(gui):
    H = gui.H

    class RH(H):
        """다른 기기용: 열쇠(쿠키)가 있어야 하고, 보기·받기 시작만"""
        FROM_PHONE = True          # gui.H 가 이 요청을 「컴퓨터 창이 열려 있음」으로 세지 않게 (공용 PC 정리)

        def end_headers(self):
            # 모든 응답에 「강의록앱이 보냄」 표시: 이게 없으면 휴대폰은 컴퓨터가 꺼진 걸로 봄
            # (컴퓨터를 끄면 터널 주소가 사라져 Cloudflare가 404 같은 자기 오류 페이지를 보냄)
            self.send_header("X-LA-App", "1")
            super().end_headers()

        def _host_ok(self) -> bool:
            """다른 사이트가 이름을 바꿔치기해(DNS 리바인딩) 이 문으로 들어오는 것 막기: 숫자 주소·이 컴퓨터 이름·터널 주소만"""
            h = (self.headers.get("Host") or "").strip().lower()
            if not h:
                return True
            host = h[1:h.index("]")] if h.startswith("[") and "]" in h else h.rsplit(":", 1)[0] if h.count(":") == 1 else h
            import ipaddress
            try:
                ipaddress.ip_address(host)
                return True
            except ValueError:
                pass
            if host in ("localhost",):
                return True
            from . import tunnel
            tu = (tunnel.state().get("url") or "").lower()
            if tu and host == re.sub(r"^https?://", "", tu).split("/")[0]:
                return True
            th = ((tunnel._rcfg() or {}).get("tunnel_host") or "").lower()
            if th and host == th:
                return True
            for a in (_ADDR["v"] or []):
                if host == re.sub(r"^https?://", "", a).rsplit(":", 1)[0].lower():
                    return True
            return host.endswith(".local") and enabled()

        def _ip(self) -> str:
            """터널(cloudflared)로 들어오면 이 컴퓨터 안에서 온 것처럼 보이니 Cloudflare가 붙여 준 실제 주소로"""
            ip = self.client_address[0]
            if ip in ("127.0.0.1", "::1", "::ffff:127.0.0.1"):
                ip = (self.headers.get("CF-Connecting-IP") or ip).strip()
            return ip

        def _https(self) -> bool:
            return (self.headers.get("X-Forwarded-Proto") or "").lower() == "https"

        def _token(self) -> str:
            m = re.search(rf"(?:^|;\s*){COOKIE}=([A-Za-z0-9_\-]+)", self.headers.get("Cookie") or "")
            return m.group(1) if m else ""

        def _local(self) -> bool:
            return self.client_address[0] in ("127.0.0.1", "::1", "::ffff:127.0.0.1")

        def _open(self) -> bool:
            """문이 열려 있는지: 와이파이 켬 → 누구나(코드 필요) / 밖에서만 → 터널(이 컴퓨터 안)로 온 것만"""
            return enabled() or (tunnel_on() and self._local())

        def _authed(self) -> bool:
            if not self._open():
                return False
            d = _device_of(self._token())
            return d is not None

        def _deny(self, code=401):
            return self._send(code, {"ok": False, "auth": False, "msg": "연결 코드를 입력해 주세요."})

        def do_GET(self):
            if not self._host_ok():
                return self._send(403, {"ok": False, "msg": "forbidden"})
            if not self._open():
                return self._send(403, {"ok": False, "msg": "다른 기기에서 열기가 꺼져 있어요."})
            u = urlparse(self.path)
            q = parse_qs(u.query)
            if u.path == "/":
                html = gui.HTML.read_text("utf-8")
                html = html.replace("<script>", "<script>window.REMOTE=true;</script><script>", 1)
                return self._send(200, html.encode("utf-8"), "text/html; charset=utf-8")
            if u.path == "/sw.js":
                return self._send(200, REMOTE_SW.encode("utf-8"), "text/javascript; charset=utf-8")
            if u.path == "/manifest.webmanifest":      # 시작 주소를 비워 둠 → 홈 화면에 추가할 때 지금 주소(#k= 한 번 쓰는 열쇠 포함)로
                man = {k: v for k, v in gui.MANIFEST.items() if k not in ("start_url", "id")}
                return self._send(200, json.dumps(man, ensure_ascii=False).encode("utf-8"), "application/manifest+json")
            if u.path in ("/api/ping",) or re.fullmatch(r"/icon-(32|64|192|512)\.png", u.path) \
                    or re.fullmatch(r"/help-img/[a-z0-9_]+\.webp", u.path):
                return H.do_GET(self)
            if u.path == "/api/remote/me":
                try:
                    M.read_cfg()
                except Exception:              # 설정 파일을 잠깐 못 읽음 → 「연결 끊김」으로 (폰이 저장해 둔 걸 지우지 않게)
                    return self._send(503, {"ok": False, "msg": "잠시 뒤 다시 해 주세요."})
                me = {"ok": True, "auth": self._authed()}
                if me["auth"]:                 # 연결한 기기의 「이 기기」 카드: 어느 컴퓨터 · 연결 방법 · 처음/마지막 연결
                    try:
                        d = _device_of(self._token()) or {}
                        pc = re.sub(r"\.(local|lan|home)$", "", socket.gethostname() or "")[:40]
                        me.update({"via": d.get("via") or "old", "added": d.get("added", ""), "seen": d.get("seen", ""),
                                   "pc": pc, "os": {"darwin": "mac", "win32": "win"}.get(sys.platform, "")})
                    except Exception:
                        pass
                return self._send(200, me)
            if not self._authed():
                return self._deny()
            if u.path == "/remote/file" or u.path.startswith("/remote/file/"):     # 뒤에 파일 이름을 붙여도 됨 (아이폰이 그 이름으로 저장)
                return self._file((q.get("rel") or [""])[0], bool(q.get("dl")))
            if u.path == "/remote/ls":                  # 폴더 안 목록 (정리 폴더 · 바꾼 저장 위치 안만)
                return self._send(200, _ls((q.get("rel") or [""])[0]))
            if u.path == "/remote/pfile" or u.path.startswith("/remote/pfile/"):              # 애매한 자료 미리보기 (받아 둔 PDF)
                got = gui.preview_file({k: (v or [""])[0] for k, v in q.items()})
                if not got:
                    return self._send(404, {"ok": False, "msg": "미리 받아 둔 파일이 없어요."})
                f, name = got
                if f.suffix.lower() != ".pdf" and not str(name).lower().endswith(".pdf"):
                    return self._send(415, {"ok": False, "msg": f"PDF가 아닌 파일({Path(name).suffix or f.suffix})이라 휴대폰에서는 미리 볼 수 없어요. 컴퓨터에서 열어 주세요."})
                return self._pdf(f, name, False)
            if u.path == "/remote/linked" or u.path.startswith("/remote/linked/"):        # 선배 추가자료 「연결」(내 컴퓨터 폴더 원본) — 경로는 안 받고 키 · 학번 · 순번으로 컴퓨터가 찾음
                p, name = gui.linked_file({k: (v or [""])[0] for k, v in q.items()})
                if p is None:
                    return self._send(404, {"ok": False, "msg": name})
                if p.suffix.lower() == ".pdf":
                    return self._pdf(p, name, bool(q.get("dl")))
                if not q.get("dl"):
                    return self._send(415, {"ok": False, "msg": "PDF가 아니라 휴대폰에서 바로 볼 수 없어요 · 받아서 열어 주세요."})
                return self._pdf(p, name, True, "application/octet-stream")
            if u.path == "/api/remote":                 # 휴대폰의 설정 화면 (보기만 · 코드·QR 빼고)
                return self._send(200, state(True, public=True))
            if u.path in GET_OK:
                return H.do_GET(self)
            return self._send(403, {"ok": False, "msg": PC_ONLY})

        def _file(self, rel: str, dl: bool = False):
            from pathlib import PureWindowsPath, PurePosixPath
            if not rel or "\x00" in rel or PureWindowsPath(rel).anchor or PurePosixPath(rel).is_absolute() \
                    or rel.startswith(("\\", "//")):          # 절대 경로·드라이브·네트워크 경로(\\서버)는 아예 안 받음
                return self._send(404, {"ok": False, "msg": "파일이 없어요."})
            p = M.path_of_rel(rel)          # 정리 폴더 · 저장 위치를 바꾼 과목 폴더 안만
            if p is None or p.suffix.lower() != ".pdf" or not p.is_file():
                return self._send(404, {"ok": False, "msg": "파일이 없어요."})
            return self._pdf(p, p.name, dl)

        def _pdf(self, p: Path, name: str, dl: bool, ctype: str = "application/pdf"):
            try:
                data = p.read_bytes()
            except OSError:
                return self._send(403, {"ok": False, "msg": "이 컴퓨터에서 파일을 읽을 수 없어요 (폴더 권한)."})
            self.send_response(200)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            ascii_name = re.sub(r"[^A-Za-z0-9._-]+", "_", name).strip("_") or "lecture.pdf"
            self.send_header("Content-Disposition", ("attachment" if dl else "inline")
                             + f'; filename="{ascii_name}"; filename*=UTF-8\'\'' + quote(name))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(data)

        def do_POST(self):
            if not self._host_ok():
                return self._send(403, {"ok": False, "msg": "forbidden"})
            if not self._open():
                return self._send(403, {"ok": False, "msg": "다른 기기에서 열기가 꺼져 있어요."})
            if self.headers.get("X-Lecture-App") != "1":
                return self._send(403, {"ok": False})
            u = urlparse(self.path)
            cap = 1024 * 1024                            # 시간표 JSON 은 수십 KB (시간표 사진 읽기는 뺐음)
            try:
                n = max(0, int(self.headers.get("Content-Length") or 0))
            except ValueError:
                n = 0
            if n > cap:                                  # 잘린 채 저장한 척하지 않게: 읽지 않고 거절
                self.close_connection = True
                return self._send(413, {"ok": False, "msg": "보낸 내용이 너무 커요 (최대 1MB). 컴퓨터의 강의록앱에서 해 주세요."})
            if u.path != "/api/remote/pair" and not self._authed():   # 열쇠 없는 연결은 본문을 기다리지 않고 바로 거절 (본문을 안 보내 붙잡아 두지 못하게)
                self.close_connection = True
                return self._deny()
            try:
                self.connection.settimeout(15)           # 본문을 천천히(또는 안) 보내는 연결이 스레드를 오래 붙잡지 않게
            except Exception:
                pass
            try:
                body = json.loads(self.rfile.read(n) or b"{}")
            except Exception:
                body = {}
            if not isinstance(body, dict):               # JSON 목록 · 숫자 등: 파이썬 오류 문장 대신 쉬운 한 줄
                return self._send(400, {"ok": False, "msg": "보낸 내용을 읽지 못했어요. 화면을 새로고침한 뒤 다시 해 주세요."})
            if u.path == "/api/remote/pair":
                return self._pair(body)
            if u.path == "/api/remote/forget_me":      # 휴대폰 설정: 이 기기 연결 끊기
                d = _device_of(self._token())
                ok = bool(d) and forget(d.get("id"))
                data = json.dumps({"ok": ok, "msg": "이 기기 연결을 끊었어요." if ok else "이미 끊긴 기기예요."}).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Content-Length", str(len(data)))
                self.send_header("Set-Cookie", f"{COOKIE}=; Max-Age=0; Path=/; HttpOnly; SameSite=Strict" + ("; Secure" if self._https() else ""))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(data)
                return
            if u.path in POST_OK:
                gui._last_hit = time.time()
                fn = {"/api/start": gui.start_job, "/api/stop": lambda b: gui.stop_job(), "/api/xskip": gui.xskip_set, "/api/view": gui.view_set}[u.path]
                try:
                    return self._send(200, fn(body))
                except Exception as e:
                    return self._fail(e)
            if u.path in POST_EDIT:
                gui._last_hit = time.time()
                fn = gui._post_fns().get(u.path)
                if not fn:
                    return self._send(404, {"ok": False})
                body = _phone_body(u.path, body if isinstance(body, dict) else {})
                try:
                    if u.path in CFG_LOCKED:
                        with M.CFG_LOCK:                 # 저장된 설정 읽기(_phone_settings) ~ 저장까지 한 번에 (그 사이 컴퓨터가 저장한 줄이 안 빠지게)
                            if u.path == "/api/settings":
                                asked = bool(body)
                                body = _phone_settings(body)
                                if not body:
                                    return self._send(200, {"ok": True} if not asked else {"ok": False, "msg": PC_ONLY})
                            return self._send(200, fn(body))
                    return self._send(200, fn(body))
                except Exception as e:
                    return self._fail(e)
            return self._send(403, {"ok": False, "msg": PC_ONLY})

        def _via_tunnel(self) -> bool:
            return self.client_address[0] in ("127.0.0.1", "::1", "::ffff:127.0.0.1") and bool(self.headers.get("CF-Connecting-IP"))

        def _pair(self, body):
            ip = _fail_key(self._ip())
            now = time.time()
            c = re.sub(r"\D", "", str(body.get("code") or ""))[:6]
            k = str(body.get("key") or "")[:100]
            tunnel = self._via_tunnel()
            via = "tunnel" if tunnel else "lan"
            if not (tunnel_on() if via == "tunnel" else enabled()):
                return self._send(403, {"ok": False, "msg": "이 방법(같은 와이파이/밖에서)은 컴퓨터에서 꺼져 있어요."})
            C = _CODES[via]
            nxt = ""
            with _LOCK:
                for kk in [kk for kk, t in _NEXT.items() if now > t[0]]:
                    _NEXT.pop(kk, None)
                key, kat = C["key"], C["at"]
            # 1) QR 열쇠: 맞히기가 불가능할 만큼 길어서 틀린 횟수 제한보다 먼저 확인 (남이 일부러 막아도 QR 연결은 됨)
            if k:
                ok = False
                ak = acct_key() if via == "tunnel" else ""
                with _LOCK:
                    if key and now - kat <= CODE_TTL and secrets.compare_digest(k.encode(), key.encode()):
                        ok = True
                    elif ak and secrets.compare_digest(k.encode(), ak.encode()):
                        ok = True                            # 같은 구글 계정 웹앱 (계정 열쇠는 바꾸지 않음)
                        body = {**body, "_acct": True}
                    elif k in _NEXT and _NEXT[k][1] == via:
                        _NEXT.pop(k, None)                  # 홈 화면에 추가한 앱이 처음 열 때 한 번만 쓰는 열쇠
                        ok = True
                if not ok:
                    return self._send(200, {"ok": False, "msg": "QR이 오래됐어요. 컴퓨터의 강의록앱 › 설정 › 휴대폰·아이패드에 뜬 새 QR을 찍거나 6자리 코드를 넣어 주세요."})
                if secrets.compare_digest(k.encode(), key.encode()):
                    new_code(via)
            else:
                # 2) 6자리 코드: 틀린 횟수를 먼저 적어 두고 비교 (동시에 여러 번 보내 제한을 넘는 것 막기)
                with _LOCK:
                    expired = bool(C["code"]) and now - C["at"] > CODE_TTL
                if expired:
                    new_code(via)
                    return self._send(200, {"ok": False, "msg": "연결 코드가 바뀌었어요. 컴퓨터의 강의록앱 › 설정 › 휴대폰·아이패드에 뜬 새 6자리를 넣어 주세요."})
                with _LOCK:
                    fails = [t for t in _FAILS.get(ip, []) if now - t < 600]
                    _FAILS[ip] = fails
                    _GFAILS[:] = [t for t in _GFAILS if now - t < G_WIN]
                    _TFAILS[:] = [t for t in _TFAILS if now - t < 3600]
                    if len(fails) >= 5:
                        return self._send(429, {"ok": False, "msg": "코드를 너무 많이 틀렸어요. 10분 뒤에 다시 해 주세요."})
                    if len(_GFAILS) >= FAIL_MAX * 2:
                        return self._send(429, {"ok": False, "msg": "여러 곳에서 코드를 너무 많이 틀려서 잠깐 막아 뒀어요. 10분 뒤에 다시 하거나 QR로 연결해 주세요."})
                    if tunnel and len(_TFAILS) >= TUNNEL_FAIL_MAX:
                        return self._send(429, {"ok": False, "msg": "밖에서 코드를 너무 많이 틀려서 1시간 동안 코드 연결을 막아 뒀어요. 컴퓨터의 강의록앱 › 설정 › 휴대폰·아이패드의 QR을 찍어 연결해 주세요."})
                    fails.append(now)
                    _GFAILS.append(now)
                    if tunnel:
                        _TFAILS.append(now)
                    cur = C["code"]
                good = bool(cur) and len(c) == 6 and secrets.compare_digest(c, cur)
                if not good:
                    with _LOCK:
                        total = sum(len(v) for v in _FAILS.values())
                    if total >= FAIL_MAX:
                        new_code(via)       # 여러 곳에서 계속 틀리면 코드 자체를 바꿈
                        with _LOCK:
                            _FAILS.clear()
                    return self._send(200, {"ok": False, "msg": "코드가 맞지 않아요. 컴퓨터의 강의록앱 › 설정 › 휴대폰·아이패드에 뜬 6자리를 넣어 주세요."})
                with _LOCK:                                   # 맞혔으면 방금 적어 둔 실패 기록은 지움
                    for lst in (fails, _GFAILS, _TFAILS):
                        if now in lst:
                            lst.remove(now)
                new_code(via)                               # 한 번 쓴 코드는 바꿈
            if body.get("next"):                            # 사파리에서 연결 → 홈 화면에 추가할 앱이 쓸 열쇠 (30분 · 한 번)
                nxt = secrets.token_urlsafe(18)
                with _LOCK:
                    _NEXT[nxt] = (now + CODE_TTL, via)
                    while len(_NEXT) > 10:
                        _NEXT.pop(next(iter(_NEXT)))
            nm = _dev_name(self.headers.get("User-Agent", ""))
            tok = _add_device(("웹앱 · " + nm) if body.get("_acct") else nm, via, replace=bool(body.get("_acct")))
            data = json.dumps({"ok": True, "next": nxt}).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Set-Cookie", f"{COOKIE}={tok}; Max-Age=31536000; Path=/; HttpOnly; SameSite=Strict"
                             + ("; Secure" if self._https() else ""))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(data)

    return RH


def _ls(rel: str) -> dict:
    """휴대폰에서 폴더 보기: rel 이 파일이면 그 파일이 있는 폴더 · 파일 이름·크기만 (내용 X)"""
    from pathlib import PureWindowsPath, PurePosixPath
    rel = str(rel or "").replace("\\", "/").strip("/")
    if not rel or "\x00" in rel or PureWindowsPath(rel).anchor or PurePosixPath(rel).is_absolute():
        return {"ok": False, "msg": "폴더를 찾을 수 없어요."}
    p = M.path_of_rel(rel)
    sel = ""
    if p is not None and p.is_file():
        sel, rel = p.name, "/".join(rel.split("/")[:-1])
        p = M.path_of_rel(rel) if rel else None
    if p is None or not p.is_dir():
        return {"ok": False, "msg": "폴더를 찾을 수 없어요."}
    items = []
    try:
        for c in sorted(p.iterdir(), key=lambda c: (not c.is_dir(), c.name.lower())):
            if c.name.startswith((".", "~$")) or c.name in ("desktop.ini", "Thumbs.db"):
                continue
            d = c.is_dir()
            items.append({"n": c.name, "d": d, "pdf": (not d) and c.suffix.lower() == ".pdf",
                          "sz": 0 if d else c.stat().st_size})
            if len(items) >= 400:
                break
    except Exception:
        return {"ok": False, "msg": "폴더를 읽지 못했어요."}
    parts = rel.split("/")
    up = "/".join(parts[:-1]) if len(parts) > 1 and M.path_of_rel("/".join(parts[:-1])) is not None else ""
    return {"ok": True, "rel": rel, "name": parts[-1], "up": up, "sel": sel, "items": items}

