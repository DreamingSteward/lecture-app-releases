"""시간표 고치기·가져오기.

시간표.json(과목 → rows) 을 '수업 한 번 = 한 항목'으로 펼쳐서 다루고,
새 시간표(직접 수정 / AI가 만든 결과 / 사진)와 비교해 바뀐 점을 보여 주고, 고른 것만 적용한다.
적용하면 이미 만든 강의록·매칭 기억도 새 시간표에 맞게 정리한다.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import time
from datetime import date, datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from .timetable import YEAR_KEY, _parse_period, _profs, folder_course, norm_course, year_num, cal_year, period_label

WEEK = "월화수목금토일"
SKIP = re.compile(r"(중간|기말)고사|휴강|공강")   # 시험 일정은 AI 프롬프트에서 뺌 (「임상시험」 같은 강의가 빠지지 않게) · 자율학습 · 오리엔테이션은 수업으로 넣음 (2026-11-04)
YEAR_RE = re.compile(r"(20\d\d)\s*(계절)?")


def year_norm(y) -> Optional[str]:
    """'2025' · '2025 계절' · '2025계절학기' → '2025' / '2025 계절' (계절학기는 같은 학년도의 따로 칸)"""
    m = YEAR_RE.search(str(y or ""))
    return (m.group(1) + (" 계절" if m.group(2) else "")) if m else None


# ---------------------------------------------------------------- 붙여넣은 JSON 읽기
TOP_KEYS = {"courses", "lectures", "events", "1교시"}


def load_raw(raw):
    """붙여넣은 AI 답 → dict/list. 설명 글 · 코드 블록이 섞여 있어도 JSON 부분만,
    답이 길어 「"more": true」 → 「이어서」로 여러 번 받은 JSON 을 한 칸에 이어 붙였으면 하나로 합침
    (같은 과목은 lectures · exams 를 이어 붙이고, events 도 이어 붙임 · 「1교시」 · year 는 처음 것)"""
    if not isinstance(raw, str):
        return raw
    txt = raw.strip()
    dec, objs, i = json.JSONDecoder(), [], 0
    while True:
        j = min([k for k in (txt.find("{", i), txt.find("[", i)) if k >= 0], default=-1)
        if j < 0:
            break
        try:
            v, end = dec.raw_decode(txt, j)
        except ValueError:
            if re.match(r'[{\[]\s*["{\[]', txt[j:]):      # JSON 이 시작됐는데 끝까지 못 읽음 = 답이 끊김 → 안쪽 조각을 줍지 않고 멈춤
                raise ValueError("붙여 넣은 JSON이 중간에 끊겼어요. AI에게 「이어서」라고 해서 받은 답까지 함께 붙여 넣거나, 과목을 나눠 다시 받아 주세요.")
            i = j + 1                       # 「{학번}」 같은 글
            continue
        if (isinstance(v, dict) and TOP_KEYS & set(v)) or (isinstance(v, list) and v and all(isinstance(x, dict) for x in v)):
            objs.append(v)
            i = end
        else:
            i = j + 1                       # 다른 모양(예: 강의 하나)이면 그 안을 계속 찾음
    if not objs:
        return json.loads(txt)              # 원래 오류 메시지 그대로
    if len(objs) == 1:
        return objs[0]
    if not all(isinstance(o, dict) for o in objs):
        return max(objs, key=lambda o: len(json.dumps(o, ensure_ascii=False)))   # 예전 모양(목록)이 섞이면 가장 큰 것
    out: dict = {}
    for o in objs:
        for k, v in o.items():
            if k == "courses" and isinstance(v, list):
                cs = out.setdefault("courses", [])
                for c in v:
                    if not isinstance(c, dict):
                        continue
                    hit = next((x for x in cs if str(x.get("name") or "").strip() and str(x.get("name") or "").strip() == str(c.get("name") or "").strip()), None)
                    if hit is None:
                        cs.append({**c, "lectures": list(c.get("lectures") or []), **({"exams": list(c["exams"])} if isinstance(c.get("exams"), list) else {})})
                    else:
                        hit["lectures"] = list(hit.get("lectures") or []) + list(c.get("lectures") or [])
                        if isinstance(c.get("exams"), list):
                            hit["exams"] = list(hit.get("exams") or []) + c["exams"]
            elif k in ("lectures", "events") and isinstance(v, list):
                out[k] = list(out.get(k) or []) + v
            elif k == "more":
                continue
            elif k not in out:
                out[k] = v
    def uniq(xs):                          # 「이어서」가 앞 답의 끝부분을 다시 쓴 경우 같은 항목은 한 번만
        seen, res = set(), []
        for x in xs:
            key = json.dumps(x, ensure_ascii=False, sort_keys=True)
            if key not in seen:
                seen.add(key)
                res.append(x)
        return res
    for c in out.get("courses") or []:
        c["lectures"] = uniq(c.get("lectures") or [])
        if isinstance(c.get("exams"), list):
            c["exams"] = uniq(c["exams"])
    for k in ("lectures", "events"):
        if isinstance(out.get(k), list):
            out[k] = uniq(out[k])
    return out


def events_of(raw) -> List[dict]:
    """붙여넣은 시간표의 학교 행사 · 시험 기간 ("events") → [{"l","d","e"?,"g"?,"t"?}] (d · e = "M/D")"""
    raw = load_raw(raw)
    if not isinstance(raw, dict) or not isinstance(raw.get("events"), list):
        return []
    out, seen = [], set()
    for x in raw["events"][:150]:
        if not isinstance(x, dict):
            continue
        l = re.sub(r"\s+", " ", str(x.get("label") or x.get("l") or "")).strip()[:60]
        dd = parse_date(x.get("date") or x.get("d"))
        if not l or not dd or exam_like(l):
            continue                         # 시험인 것(전국 기초의학종합평가 등)은 시험 일정으로 (exams_of)
        e = {"l": l, "d": f"{int(dd[:2])}/{int(dd[2:])}"}
        ee = parse_date(x.get("end") or x.get("e"))
        if ee and ee != dd:
            e["e"] = f"{int(ee[:2])}/{int(ee[2:])}"
        g = str(x.get("period") or x.get("g") or "").replace("교시", "").strip()
        if re.fullmatch(r"\d{1,2}(\s*[-~]\s*\d{1,2})?", g):
            e["g"] = re.sub(r"\s*[-~]\s*", "-", g)
        t = re.findall(r"(\d{1,2}):(\d{2})", str(x.get("time") or x.get("t") or ""))
        if t:
            e["t"] = "-".join(f"{int(h):02d}:{mi}" for h, mi in t[:2])
        k = (e["l"], e["d"])
        if k not in seen:
            seen.add(k)
            out.append(e)
    return out


def elect_title(title: str, rows: list) -> str:
    """선택교과목 제목이 괄호 목록뿐일 때: 붙여 넣은 시간표에 나온 목록 순서대로 「선택교과목1 · 2 …」를 붙임"""
    key = lambda t: re.sub(r"\s+", "", t).strip("()（）")
    order = []
    for l in rows:
        t = str(l.get("title") or l.get("t") or "")
        if re.fullmatch(r"\s*[(（][^)）]+[/·,][^)）]+[)）]\s*", t) and key(t) not in order:
            order.append(key(t))
    n = order.index(key(title)) + 1 if key(title) in order else 1
    inner = re.sub(r"^\s*[(（]\s*|\s*[)）]\s*$", "", title)
    return f"선택교과목{n} ({inner})"


def section_of(v) -> Optional[int]:
    """분반: 2 · "2" · "2분반" · "(2분반)" → 2 (1–20만)"""
    m = re.search(r"\d+", str(v if v is not None else ""))
    n = int(m.group(0)) if m else 0
    return n if 1 <= n <= 20 else None


# ---------------------------------------------------------------- 기본 도구
def nt(t: str) -> str:
    """제목 비교용: 띄어쓰기·기호 무시, 로마숫자 통일 ('신생아 질환 III' == '신생아질환 III')"""
    t = (t or "").replace("Ⅰ", "I").replace("Ⅱ", "II").replace("Ⅲ", "III").replace("Ⅳ", "IV")
    return re.sub(r"[\s\-·ㆍ・_/(),.]+", "", t).lower()


def year_for(mm: int) -> int:
    return cal_year(mm)


def wd(mmdd: str) -> str:
    try:
        return WEEK[date(year_for(int(mmdd[:2])), int(mmdd[:2]), int(mmdd[2:])).weekday()]
    except ValueError:
        return ""


def parse_date(s) -> Optional[str]:
    s = str(s or "")
    m = re.search(r"(?:20\d{2}[-./\s]*)?(\d{1,2})\s*[-./월]\s*(\d{1,2})", s) or re.fullmatch(r"\s*(\d{2})(\d{2})\s*", s)
    if not m:
        return None
    mo, d = int(m.group(1)), int(m.group(2))
    return f"{mo:02d}{d:02d}" if 1 <= mo <= 12 and 1 <= d <= 31 else None


def parse_period(s) -> Optional[Tuple[int, int]]:
    if isinstance(s, (int, float)):
        return int(s), 1
    return _parse_period(str(s or "").replace("교시", ""))


def prof_str(p) -> str:
    if isinstance(p, list):
        p = "·".join(p)
    return "·".join(_profs(str(p or "")))


# ---------------------------------------------------------------- 펼치기 / 접기
def expand(data: list) -> List[dict]:
    """rows → 수업 한 번씩: {course, mmdd, start, hours, title, prof, term, row}"""
    out = []
    for ci, c in enumerate(data):
        for ri, r in enumerate(c.get("rows") or []):
            dates = [parse_date(x) for x in re.split(r"[·,]", r.get("d") or "")]
            gs = re.split(r"·", r.get("g") or "")
            ss = re.split(r"·", r.get("s") or "")
            prof = prof_str((r.get("y") or {}).get(YEAR_KEY, ""))
            for i, dd in enumerate(d for d in dates if d):
                p = parse_period(gs[i] if i < len(gs) else (gs[-1] if gs else ""))
                if not p:
                    continue
                out.append({"course": c["name"], "mmdd": dd, "start": p[0], "hours": p[1],
                            "g": period_label((gs[i] if i < len(gs) else (gs[-1] if gs else "")).replace("교시", "")),
                            "title": (r.get("t") or "").strip(), "prof": prof,
                            "term": int(r.get("term") or 0), "row": [ci, ri],
                            **({"sep": ss[i].strip()} if i < len(ss) and ss[i].strip() else {}),
                            **({"sec": int(r["sec"])} if section_of(r.get("sec")) else {})})
    out.sort(key=lambda x: (x["course"], x["mmdd"], x["start"]))
    return out


def _gtxt(start: int, hours: int, g: str = "") -> str:
    return g or (f"{start}" if hours <= 1 else f"{start}-{start + hours - 1}")


def _row_yields(r) -> bool:
    """이 행에서 수업이 하나라도 나오는지 (expand 와 같은 기준)"""
    dates = [parse_date(x) for x in re.split(r"[·,]", r.get("d") or "")]
    gs = re.split(r"·", r.get("g") or "")
    return any(parse_period(gs[i] if i < len(gs) else (gs[-1] if gs else "")) for i, d in enumerate(x for x in dates if x))


def collapse(items: List[dict], old: list) -> list:
    """수업 목록 → 시간표.json 형식. 역대 교수 기록은 같은 제목의 예전 행에서 이어받는다."""
    new = []
    for c in old:
        hist_rows = {nt(r.get("t")): r for r in c.get("rows") or []}      # 분반이 달라도 같은 제목이면 역대 교수는 같은 줄에서
        mine = [x for x in items if x["course"] == c["name"]]
        groups: Dict[tuple, List[dict]] = {}
        for x in sorted(mine, key=lambda x: (x["mmdd"], x["start"])):
            groups.setdefault((x["title"], x["prof"], x["term"], x.get("sec") or 0), []).append(x)
        rows, used = [], set()
        order = {nt(r.get("t")): i for i, r in enumerate(c.get("rows") or [])}
        for (title, prof, term, sec), xs in sorted(groups.items(), key=lambda kv: (order.get(nt(kv[0][0]), 10 ** 6), kv[1][0]["mmdd"], kv[1][0]["start"])):
            base = hist_rows.get(nt(title)) or {}
            used.add(nt(title))
            y = dict(base.get("y") or {})
            y[YEAR_KEY] = prof or "—"
            tm = dict(base.get("tm") or {})
            if term:
                tm[YEAR_KEY] = term
            rows.append({"t": title,
                         "d": "·".join(f"{int(x['mmdd'][:2])}/{int(x['mmdd'][2:])}({wd(x['mmdd'])})" for x in xs),
                         "g": "·".join(_gtxt(x["start"], x["hours"], x.get("g") or "") for x in xs),
                         **({"s": "·".join(x.get("sep") or "" for x in xs)} if any(x.get("sep") for x in xs) else {}),
                         "y": y, "term": term, "tm": tm, **({"sec": sec} if sec else {})})   # sec: 분반 (분반마다 따로 줄)
        # 올해 수업은 없지만 예전 기록만 있는 행(비교용)은 그대로 둔다
        for r in c.get("rows") or []:
            if nt(r.get("t")) not in used and (not (r.get("d") or "").strip() or not _row_yields(r)):
                rows.append(r)            # 날짜는 있어도 교시를 못 읽는 행(점심 특강 등)도 지우지 않음
        ys = sorted({str(y) for y in (c.get("years") or [])} | {YEAR_KEY}, reverse=True)   # 올해 칸이 꼭 있게
        new.append({**c, "years": ys, "rows": rows, "cur": YEAR_KEY})       # cur: 이번 학기 칸 이름 (날짜 대신 이걸로 정함)
    # 새 과목
    known = {c["name"] for c in old}
    for cname in sorted({x["course"] for x in items} - known):
        new.append({"name": cname, "years": [YEAR_KEY], "rows": [], "hasTerm": False, "cur": YEAR_KEY})
        new[-1] = collapse([x for x in items if x["course"] == cname], [new[-1]])[0]
    return new


# ---------------------------------------------------------------- 가져오기(정리)
def guess_course(title: str, mmdd: str, cur: List[dict], names: List[str]) -> Optional[str]:
    t = nt(title)
    hit = [x["course"] for x in cur if nt(x["title"]) == t]
    if hit:
        return max(set(hit), key=hit.count)
    # 비슷한 제목 (포함 관계)
    hit = [x["course"] for x in cur if t and (t in nt(x["title"]) or nt(x["title"]) in t) and len(t) >= 3]
    if hit:
        return max(set(hit), key=hit.count)
    # 같은 날 다른 수업이 가장 많은 과목
    same = [x["course"] for x in cur if x["mmdd"] == mmdd]
    if same:
        return max(set(same), key=same.count)
    return names[0] if len(names) == 1 else None


def _overlap(a: str, b: str) -> float:
    """두 제목의 글자 2개 묶음 겹침 비율 (짧은 쪽 기준)"""
    A = {a[i:i + 2] for i in range(len(a) - 1)}
    B = {b[i:i + 2] for i in range(len(b) - 1)}
    return len(A & B) / max(1, min(len(A), len(B)))


COMMON = "공통"                           # 과목 없이 학년 전체가 보는 시험 (전국 기초의학종합평가 등) · 시험일정.json 의 과목 이름
EXAM_EV = re.compile(r"(평가|시험|고사)\s*(\(?\s*\d+\s*차\s*\)?)?\s*$")   # 행사로 왔어도 시험인 것 (「…기간」은 행사)


def exam_like(label: str) -> bool:
    return bool(EXAM_EV.search(str(label or ""))) and "기간" not in str(label or "")


def exams_of(raw) -> Dict[str, list]:
    """붙여넣은 시간표의 과목별 시험 일정 → {과목: [{"l","d","g"?,"t"?}]} (이번 학기 것만 · 강의 목록에는 안 섞음)"""
    try:
        raw = load_raw(raw)
    except ValueError:
        return {}
    if not isinstance(raw, dict):
        return {}
    lab = cur_label(raw)
    out: Dict[str, list] = {}
    for c in raw.get("courses") or []:
        if not isinstance(c, dict) or not isinstance(c.get("exams"), list):
            continue
        name = str(c.get("name") or "").strip()
        xs = []
        for x in c["exams"]:
            if not isinstance(x, dict):
                continue
            y = str(x.get("year") or "").strip()
            yn = year_norm(y) or ""            # 이번 학기 칸 이름(cur_label)과 같은 방식으로 읽음
            if yn and lab and yn != re.sub(r"\s*\(.*\)$", "", lab):
                continue
            dd = parse_date(x.get("date") or x.get("d"))
            if not dd:
                continue
            e = {"l": str(x.get("label") or x.get("l") or "시험").strip()[:40] or "시험", "d": f"{int(dd[:2])}/{int(dd[2:])}"}
            g = str(x.get("period") or x.get("g") or "").replace("교시", "").strip()
            if re.fullmatch(r"\d{1,2}(\s*[-~]\s*\d{1,2})?", g):
                e["g"] = re.sub(r"\s*[-~]\s*", "-", g)
            t = re.findall(r"(\d{1,2}):(\d{2})", str(x.get("time") or x.get("t") or ""))
            if t:
                e["t"] = "-".join(f"{int(h):02d}:{mi}" for h, mi in t[:2])
            if "g" in e or "t" in e:
                xs.append(e)
        if name and (xs or not c["exams"]):       # 「exams: []」 = 그 과목 시험 일정을 비움 (취소된 시험 지우기)
            out[name] = xs
    # 과목 없는 시험: 맨 위 "exams" + 행사로 왔지만 시험인 것 (전국 기초의학종합평가 등) → 「공통」
    com, seen = [], set()
    for x in list(raw.get("exams") or []) if isinstance(raw.get("exams"), list) else []:
        if isinstance(x, dict):
            com.append(x)
    for x in raw.get("events") or [] if isinstance(raw.get("events"), list) else []:
        if isinstance(x, dict) and exam_like(x.get("label") or x.get("l")):
            dd, ee = parse_date(x.get("date") or x.get("d")), parse_date(x.get("end") or x.get("e"))
            days = [dd]
            if dd and ee and ee > dd and int(ee[:2]) == int(dd[:2]) and int(ee[2:]) - int(dd[2:]) <= 6:
                days = [f"{dd[:2]}{d:02d}" for d in range(int(dd[2:]), int(ee[2:]) + 1)]   # 이틀 이상이면 날마다 (같은 달 · 일주일까지)
            for d in days:
                if d:
                    com.append({**x, "date": f"{int(d[:2])}/{int(d[2:])}", "period": x.get("period") or ("" if x.get("time") else "1-9")})
    if com:
        xs = []
        for x in com:
            dd = parse_date(x.get("date") or x.get("d"))
            if not dd:
                continue
            e = {"l": str(x.get("label") or x.get("l") or "시험").strip()[:40] or "시험", "d": f"{int(dd[:2])}/{int(dd[2:])}"}
            g = str(x.get("period") or x.get("g") or "").replace("교시", "").strip()
            if re.fullmatch(r"\d{1,2}(\s*[-~]\s*\d{1,2})?", g):
                e["g"] = re.sub(r"\s*[-~]\s*", "-", g)
            t = re.findall(r"(\d{1,2}):(\d{2})", str(x.get("time") or x.get("t") or ""))
            if t:
                e["t"] = "-".join(f"{int(h):02d}:{mi}" for h, mi in t[:2])
            if ("g" in e or "t" in e) and (e["l"], e["d"]) not in seen:
                seen.add((e["l"], e["d"]))
                xs.append(e)
        if xs:
            out[COMMON] = xs
    return out


def normalize(raw, cur: List[dict], course_names: List[str]) -> Tuple[List[dict], List[str]]:
    """AI 결과·직접 수정·사진 결과 → 수업 목록. (목록, 경고)"""
    raw = load_raw(raw)                                  # 설명 글이 섞여 있어도 JSON 부분만 · 여러 번 나눠 받은 답은 합침
    rows = []
    if isinstance(raw, dict) and "courses" in raw:
        for c in raw["courses"] or []:
            for l in c.get("lectures") or []:
                rows.append({**l, "course": l.get("course") or c.get("name")})
    elif isinstance(raw, dict) and "lectures" in raw:
        rows = list(raw["lectures"])
    elif isinstance(raw, list):
        rows = raw
    warn, out, nocourse = [], [], []
    for i, l in enumerate(rows):
        title = str(l.get("title") or l.get("t") or "").strip()
        if not title or SKIP.search(title):
            continue
        dd = parse_date(l.get("date") or l.get("d") or l.get("mmdd"))
        p = parse_period(l.get("period") or l.get("g") or (f"{l.get('start')}-{int(l.get('start')) + int(l.get('hours', 1)) - 1}" if l.get("start") else ""))
        if not dd or not p:
            warn.append(f"{i + 1}번째 항목 「{title}」: 날짜나 교시를 못 읽었어요 → 빼고 진행")
            continue
        course = str(l.get("course") or "").strip()
        from .matching import same_course
        cn = next((n for n in course_names if norm_course(n) == norm_course(course) or same_course(n, course)), None) if course else None
        if not cn and course:
            cn = course                  # 지금 시간표에 없는 과목 → 새 과목으로 (처음 넣는 시간표·새 학기)
        if not cn:
            cn = guess_course(title, dd, cur, course_names)
        if not cn:
            nocourse.append(f"「{title}」({dd[:2]}/{dd[2:]})")
            continue
        # 띄어쓰기만 다른 제목, 또는 같은 날·같은 교시에 이름 일부만 다른 제목('유전대사' ↔ '유전-대사 질환')은 기존 이름 유지
        same = next((x["title"] for x in cur if x["course"] == cn and nt(x["title"]) == nt(title)), None)
        if not same:
            t2 = nt(title)
            same = next((x["title"] for x in cur if x["course"] == cn and x["mmdd"] == dd and x["start"] == p[0]
                         and len(t2) >= 2 and (t2 in nt(x["title"]) or nt(x["title"]) in t2 or _overlap(t2, nt(x["title"])) >= 0.6)), None)
        term = l.get("term")
        try:
            term = int(re.sub(r"\D", "", str(term))) if term not in (None, "") else None
        except ValueError:
            term = None
        if re.fullmatch(r"\s*[(（][^)）]+[/·,][^)）]+[)）]\s*", title) and re.search(r"선택\s*교과목", cn):
            title = elect_title(title, rows)      # 「(의공학/…)」만 있으면 「선택교과목1 (의공학/…)」
        sec = section_of(l.get("section") or l.get("sec"))
        out.append({"course": cn, "mmdd": dd, "start": p[0], "hours": p[1], "title": same or title,
                    "g": period_label(str(l.get("period") or l.get("g") or "").replace("교시", "")),
                    "prof": prof_str(l.get("prof") or l.get("profs") or l.get("professor") or ""), "term": term,
                    **({"sec": sec} if sec else {})})
    if len(nocourse) > 3:
        warn.insert(0, f"과목명이 없어서 수업 {len(nocourse)}개를 뺐어요 (예: {', '.join(nocourse[:2])} …). "
                       "AI에게 「과목 이름과 기간을 알려 줄게」 하고 과목명을 알려 준 뒤 다시 받아 주세요.")
    else:
        warn += [f"{x}: 어느 과목인지 몰라서 뺐어요" for x in nocourse]
    # 차수가 없으면: 같은 제목의 기존 차수 → 날짜가 가장 가까운 기존 수업의 차수
    for x in out:
        if x["term"] is None:
            same = [c["term"] for c in cur if c["course"] == x["course"] and nt(c["title"]) == nt(x["title"]) and c["term"]]
            if same:
                x["term"] = same[0]
            else:
                near = sorted((c for c in cur if c["course"] == x["course"] and c["term"]),
                              key=lambda c: abs(int(c["mmdd"]) - int(x["mmdd"])))
                x["term"] = near[0]["term"] if near else 0
    return out, warn


# ---------------------------------------------------------------- 비교
def _same(a, b) -> bool:
    return (a["mmdd"], a["start"], a["hours"], a.get("g") or "", nt(a["title"]), a["prof"], a["term"], a.get("sep") or "", a.get("sec") or 0) == \
           (b["mmdd"], b["start"], b["hours"], b.get("g") or "", nt(b["title"]), b["prof"], b["term"], b.get("sep") or "", b.get("sec") or 0)


def diff(cur: List[dict], new: List[dict], mode: str, courses: Optional[List[str]] = None, days: Optional[set] = None) -> List[dict]:
    """mode: all(시간표 전체를 새 것으로) / full(새 목록에 있는 과목 전체 교체) / partial(새 목록에 있는 날짜만) / course(지정 과목 전체)
    → [{id, type: add|remove|change, before, after, fields}]"""
    if mode == "all":                    # 처음 설정: 새 시간표가 전부 (새 목록에 없는 과목·수업은 모두 뺌)
        scope = list(cur)
    elif mode == "partial":
        days = set(days or ()) | {x["mmdd"] for x in new}     # 옮기기: 떠나는 날도 범위에 (안 그러면 그날 하나뿐인 강의가 복제됨)
        scope = [x for x in cur if x["mmdd"] in days]
    elif mode == "course":
        cs = set(courses or {x["course"] for x in new})
        scope = [x for x in cur if x["course"] in cs]
    else:
        cs = {x["course"] for x in new}
        scope = [x for x in cur if x["course"] in cs]        # 새 목록에 없는 과목은 건드리지 않음
    olds, news = list(scope), list(new)
    pairs = []
    def take(pred):
        for n in list(news):
            o = next((o for o in olds if o["course"] == n["course"] and pred(o, n)), None)
            if o:
                pairs.append((o, n))
                olds.remove(o)
                news.remove(n)
    take(_same)
    if days:                         # 홈에서 옮기기: 같은 강의(제목·교수)부터 짝지음 (두 강의 자리 바꾸기가 '제목 바뀜'으로 보이지 않게)
        take(lambda o, n: nt(o["title"]) == nt(n["title"]) and o["prof"] == n["prof"])
    take(lambda o, n: o["mmdd"] == n["mmdd"] and o["start"] == n["start"] and (o.get("sec") or 0) == (n.get("sec") or 0))   # 같은 시간(같은 분반) → 제목/교수 바뀜
    take(lambda o, n: nt(o["title"]) == nt(n["title"]) and o["prof"] == n["prof"])        # 같은 강의 → 날짜/교시 이동
    take(lambda o, n: nt(o["title"]) == nt(n["title"]))
    out = []
    for o, n in pairs:
        if _same(o, n):
            continue
        f = [k for k, a, b in (("날짜", o["mmdd"], n["mmdd"]), ("교시", (o["start"], o["hours"], o.get("g") or ""), (n["start"], n["hours"], n.get("g") or "")),
                               ("제목", nt(o["title"]), nt(n["title"])), ("교수", o["prof"], n["prof"]), ("차수", o["term"], n["term"]),
                               ("분반", o.get("sec") or 0, n.get("sec") or 0)) if a != b]
        out.append({"type": "change", "before": o, "after": n, "fields": f})
    out += [{"type": "add", "before": None, "after": n, "fields": []} for n in news]
    out += [{"type": "remove", "before": o, "after": None, "fields": []} for o in olds]
    out.sort(key=lambda c: ((c["after"] or c["before"])["course"], (c["after"] or c["before"])["mmdd"], (c["after"] or c["before"])["start"]))
    for i, c in enumerate(out):
        c["id"] = i
    return out


def apply_changes(cur: List[dict], changes: List[dict], accept: Optional[List[int]] = None) -> List[dict]:
    acc = set(accept) if accept is not None else {c["id"] for c in changes}
    res = [dict(x) for x in cur]
    def find(x):            # 똑같은 수업(시간·반 교시·교수·차수까지) 먼저 → 없으면 같은 날·교시·제목
        i = next((i for i, y in enumerate(res) if y["course"] == x["course"] and _same(y, x)), None)
        if i is not None:
            return i
        return next((i for i, y in enumerate(res) if y["course"] == x["course"] and y["mmdd"] == x["mmdd"]
                     and y["start"] == x["start"] and nt(y["title"]) == nt(x["title"])), None)
    for c in changes:
        if c["id"] not in acc:
            continue
        if c["type"] in ("remove", "change"):
            i = find(c["before"])
            if i is not None:
                res.pop(i)
        if c["type"] in ("add", "change"):
            a = {k: c["after"].get(k) for k in ("course", "mmdd", "start", "hours", "g", "title", "prof", "term")}
            if c["after"].get("sep"):
                a["sep"] = c["after"]["sep"]          # 같은 칸에 따로 둔 강의
            if c["after"].get("sec"):
                a["sec"] = c["after"]["sec"]          # 분반
            res.append(a)
    res.sort(key=lambda x: (x["course"], x["mmdd"], x["start"]))
    return res


# ---------------------------------------------------------------- 강의록 정리
def _key(x: dict, group: List[dict]) -> str:
    """timetable.load 와 같은 방식의 강의 key (같은 날·교시·교수 묶음은 제목을 · 로 이음)"""
    title = "·".join(g["title"] for g in group)
    return f"{folder_course(x['course'])}|{x['mmdd']}-{x['start']}|{title}"


def _ex(p: Path, isdir: bool = False) -> bool:
    """있는지 · 이름이 너무 길거나(합친 긴 제목) 경로 오류면 없는 것으로 (정리 도중에 멈추지 않게)"""
    try:
        return p.is_dir() if isdir else p.exists()
    except (OSError, ValueError):
        return False


def _ren(x: Path, y: Path, log=print) -> bool:
    """같은 폴더 안 이름 바꾸기 · 실패하면 그 하나만 건너뜀 (윈도우에서 PDF 가 열려 있으면 복사만 되고 원본이 남는 shutil.move 대신)"""
    try:
        os.rename(x, y)
        return True
    except OSError as e:
        log(f"옮기기 실패 (파일이 열려 있나요?): {x.name} — {e}")
        return False


def tidy_outputs(app: Path, old_lectures, new_lectures, out_dir, out_name, read_records, write_records, log=print, hint: Optional[dict] = None) -> dict:
    """시간표가 바뀌어 이름·표지가 달라진 강의록은 _이전버전 으로 옮기고 기록을 지운다 (다음 받기 때 새로 만듦).
    매칭 기억의 강의 key 도 새 key 로 바꾼다."""
    new_by = {L.key: L for L in new_lectures}
    moved, remap = [], {}
    stamp = f"{datetime.now():%m%d}"
    for L in old_lectures:
        same = new_by.get(L.key)
        if same and out_name(same) == out_name(L) and out_dir(same) == out_dir(L) and same.hours == L.hours \
                and same.profs == L.profs and same.period_label == L.period_label:     # 3A→3B 처럼 반 교시만 바뀌어도 표지가 다름
            continue
        # 홈에서 옮기며 key·파일 이름만 바뀐 강의(날짜·교시·교수·제목 그대로) → 버리지 않고 이름만 바꿈
        N = new_by.get((hint or {}).get(L.key, ""))
        if N is not None and N.key != L.key and (N.mmdd, N.start, N.hours, N.period_label, N.profs, N.titles) == \
                (L.mmdd, L.start, L.hours, L.period_label, L.profs, L.titles) and out_dir(N) == out_dir(L):
            remap[L.key] = N.key
            d, a_, b_ = out_dir(L), out_name(L), out_name(N)
            if a_ != b_:
                pdf_ok = True
                for x, y in ((d / a_, d / b_), (d / a_[:-4], d / b_[:-4]), (d / (a_[:-4] + "_원본"), d / (b_[:-4] + "_원본")),
                             (d / (a_[:-4] + "_참고자료"), d / (b_[:-4] + "_참고자료"))):
                    if _ex(x) and not _ex(y) and not _ren(x, y, log) and x.name == a_:
                        pdf_ok = False             # 파일이 열려 있어 못 바꿈 (윈도우) → 기록도 그대로 둠 (다음 받기 때 새로 만듦)
                if pdf_ok:
                    try:
                        recs = read_records(d)
                        if a_ in recs and b_ not in recs:
                            r_ = recs.pop(a_)
                            recs[b_] = {**r_, "합본파일명": b_} if isinstance(r_, dict) and "합본파일명" in r_ else r_   # 파일에는 이 칸으로 저장됨
                            write_records(d, recs)
                    except Exception as e:
                        log(f"기록 이름 바꾸기 실패: {e}")
            continue
        # 짝 찾기: 같은 과목·같은 제목 → 같은 과목·같은 날짜·교시
        cand = [N for N in new_lectures if N.course == L.course and nt(N.title) == nt(L.title)]
        cand = cand or [N for N in new_lectures if N.course == L.course and N.mmdd == L.mmdd and N.start == L.start]
        if hint and L.key in hint:                 # 홈에서 옮긴 강의: 어디로 갔는지 정확히 앎 (같은 제목 다른 주 강의로 잘못 잇지 않게)
            remap[L.key] = hint[L.key]
        elif cand:
            remap[L.key] = sorted(cand, key=lambda N: abs(int(N.mmdd) - int(L.mmdd)))[0].key
        d, name = out_dir(L), out_name(L)
        fd = d / name[:-4]                       # 강의록 여러 개를 따로 만든 폴더
        if _ex(d / name) or _ex(fd, True) or _ex(d / (name[:-4] + "_원본"), True):
            prev = d / "_이전버전"
            try:
                prev.mkdir(exist_ok=True)
            except OSError as e:
                log(f"_이전버전 폴더를 못 만듦: {e}")
                continue

            def _free(base: str, ext: str = "") -> Path:
                dst, k = prev / f"{base}_시간표변경{stamp}{ext}", 2
                while _ex(dst):
                    dst, k = prev / f"{base}_시간표변경{stamp}_{k}{ext}", k + 1
                return dst
            ok = True
            if _ex(d / name):
                ok = _ren(d / name, _free(name[:-4], ".pdf"), log)
            for fd_ in (fd, d / (name[:-4] + "_원본"), d / (name[:-4] + "_참고자료")):
                if _ex(fd_):
                    _ren(fd_, _free(fd_.name), log)
            if not ok:                              # 강의록 PDF 가 열려 있어 못 옮김 → 기록은 그대로 (지우면 다음 받기 때 덮어쓰다 또 실패)
                continue
            try:
                recs = read_records(d)
                recs.pop(name, None)
                write_records(d, recs)
            except Exception as e:
                log(f"기록 정리 실패: {e}")
            moved.append(name)
    # 확실한 연결만 기록에 씀: 홈에서 옮긴 강의·붙여넣기 짝(hint) · 새로 생긴 key 로 간 것 (이미 있던 다른 강의로 덮어 잇지 않게)
    old_keys = {L.key for L in old_lectures}
    remap = {k: v for k, v in remap.items() if (hint and k in hint) or v not in old_keys}
    from .matching import safe_replace

    def _save(path: Path, obj):          # 임시 파일에 쓰고 바꿔치기 (쓰는 도중 다른 쪽이 읽어도 깨진 파일을 안 보게)
        tmp = path.with_name(path.stem + ".tt.tmp")
        tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=1), "utf-8")
        safe_replace(tmp, path)
    # 매칭 기억 key 바꾸기 (내가 정한 자료 + 앱이 정한 자료)
    mp = app / "매칭기억.json"
    if mp.exists() and remap:
        try:
            mem = json.loads(mp.read_text("utf-8-sig"))
            for k, v in list(mem.items()):
                if v not in ("제외", "범위밖", "보류"):
                    mem[k] = "||".join(remap.get(x, x) for x in v.split("||"))
            _save(mp, mem)
        except Exception:
            pass
    for fn in ("강의록합치기.json", "재업로드확인.json"):      # 강의록 합치기 선택 · 재업로드 질문도 새 key 로
        fp = app / fn
        if fp.exists() and remap:
            try:
                v = json.loads(fp.read_text("utf-8-sig"))
                if fn.startswith("강의록"):
                    v = {remap.get(k, k): e for k, e in v.items()}
                else:
                    for q in v.get("q") or []:
                        q["key"] = remap.get(q.get("key"), q.get("key"))
                _save(fp, v)
            except Exception:
                pass
    ap = app / "자동분류.json"
    if ap.exists() and remap:
        try:
            auto = json.loads(ap.read_text("utf-8-sig"))
            for e in auto.values():
                e["keys"] = [remap.get(x, x) for x in e.get("keys") or []]
            _save(ap, auto)
        except Exception:
            pass
    # 현황 기록에서 바뀐 강의는 지움 (다음 받기 때 다시 채움)
    sp = app / "현황.json"
    if sp.exists():
        try:
            st = json.loads(sp.read_text("utf-8-sig"))
            for k in list(st):
                if k not in new_by:
                    st.pop(k)
            _save(sp, st)
        except Exception:
            pass
    return {"moved": moved, "remap": remap}


def backup(path: Path) -> Path:
    d = path.parent / "시간표_백업"
    d.mkdir(exist_ok=True)
    dst = d / f"시간표_{datetime.now():%Y%m%d_%H%M%S}.json"
    k = 2
    while dst.exists():                  # 같은 초에 두 번 (옮기고 바로 되돌리기) 저장해도 덮어쓰지 않게
        dst = d / f"시간표_{datetime.now():%Y%m%d_%H%M%S}_{k}.json"
        k += 1
    shutil.copy(path, dst)
    try:                                 # 백업은 60개가 넘을 때, 30일 지난 것만 지움 (옮기기를 많이 해도 최근 백업은 남게)
        olds = sorted(d.glob("시간표_*.json"), key=lambda f: f.stat().st_mtime)
        cut = time.time() - 30 * 86400
        for f in olds[:-60]:
            if f.stat().st_mtime < cut:
                f.unlink()
    except OSError:
        pass
    return dst


PROMPT = """첨부한 시간표(강의계획서/시간표 PDF 또는 사진)를 읽어서, 아래 형식의 JSON만 출력해 주세요. 설명 문장은 쓰지 마세요.
이번 학기 시간표 하나만 있어도 되고, 지난 연도 시간표를 같이 첨부했으면 한꺼번에 적어요.
{학번_줄}
{
  "1교시": "08:30",
  "courses": [
    {
      "name": "과목명 (예: 생식성장발달 II)",
      "lectures": [
        {"year": "2026", "date": "10/27", "period": "1-2", "title": "신생아질환 III", "prof": "김성래", "term": 2},
        {"year": "2026", "date": "3/3", "period": "1-3", "title": "인간의 삶과 사회복지", "prof": "이연주", "section": 2},
        {"year": "2025", "title": "신생아질환 III", "prof": "김성래", "term": 1}
      ],
      "exams": [
        {"label": "1차", "date": "10/1", "period": "3-4"},
        {"label": "2차", "date": "10/15", "time": "09:30-11:20"}
      ]
    }
  ],
  "exams": [
    {"label": "전국 기초의학종합평가 2차", "date": "12/18", "period": "1-9"}
  ],
  "events": [
    {"label": "체육대회", "date": "5/8"},
    {"label": "중간고사 기간", "date": "4/16", "end": "4/22"}
  ]
}

어디를 읽나
- 이번 학기 수업(date·period가 있는 것)은 「○월 ○주 ( 날짜 ~ 날짜 )」 머리글이 있는 **주간 시간표 표**에서만 적어요.
  · 강의계획서의 주차별 강의 목록 · 교육목표 · 평가 방법 · 학사력 · 교수 연락처 쪽에 나온 날짜로 이번 학기 수업을 만들지 마세요.
  · 지난 연도 교수 비교용(date 없는 항목)은 강의계획서 목록에서 적어도 돼요.
- 표 머리에 <24학번> · <25학번>처럼 학번이 적힌 시간표가 여러 벌이면 위에 적어 둔 학번 표만 읽어요.
  · 학번이 적혀 있지 않은데 시간표가 학번별로 여러 벌이면, JSON을 쓰기 전에 먼저 "어느 학번 시간표를 읽을까요? (예: 24학번 · 25학번)"라고 물어봐요.
- 날짜 줄 나누기: 한 날짜 줄은 왼쪽 날짜 칸(「9/ 월 21」처럼 적힌 칸)의 위아래 선 안에 있는 칸만이에요.
  · 날짜 글자는 줄 가운데쯤에 있고, 교수 이름 줄이 그 날짜의 맨 아래 줄이에요. 바로 위 · 아래 날짜 줄의 칸을 이 날짜로 옮겨 적지 마세요.
  · 주(週)가 바뀌는 곳(「○월 ○주」 머리글)에서는 날짜를 새 머리글 기준으로 다시 세요.

규칙
- 1교시: 이번 학기 시간표의 1교시 시작 시각 "시:분". 시간표 머리줄·교시표(1교시 08:30~09:20처럼)에서 찾아요.
  · 경북대 의대는 예과 1학년 09:00, 예과 2학년·본과 08:30이에요. 시간표에 적힌 시각이 다르면 시간표를 따라요.
  · 시간표에서 확인할 수 없고 학년도 모르면 이 줄은 빼요.
- year: 그 시간표의 학년도 (예: 2026). 2학기 시간표의 1·2월 수업도 같은 학년도예요. 여러 해를 첨부했으면 해마다 따로 적어요.
  · 계절학기 시간표는 학년도 뒤에 「계절」을 붙여요 (예: "2025 계절"). 같은 해의 정규 학기와 따로 적어요.
- 수업 한 번(한 칸) = lectures 항목 하나. 같은 강의가 여러 날이면 날마다 따로 적어요.
  · 같은 날 같은 강의(같은 제목 · 같은 교수 · 같은 분반)가 바로 이어진 칸에 나뉘어 있으면 한 항목으로 합쳐요 (예: 3교시 「CP-혈뇨」 + 4교시 「CP-혈뇨」 → "3-4").
  · 같은 날 같은 제목이라도 칸이 떨어져 있으면(사이에 빈 칸이나 다른 강의) 합치지도 빼지도 말고 칸마다 따로 적어요 (예: 4교시 「CP-단백뇨」 + 6교시 「CP-단백뇨」 → 항목 두 개).
- date: "월/일" (예: "10/27"). period: 시작-끝 교시 (예: 1교시만이면 "1", 6~9교시면 "6-9"). 여러 교시를 합친 칸은 합친 범위로.
  · 예과처럼 한 교시를 30분씩 나눈 시간표(머리줄에 2A·2B, 5A·5B처럼 A·B가 있음)는 A·B까지 그대로 적어요. A = 그 교시 앞 30분, B = 뒤 30분.
    예: 09:00~10:30 칸(1·2A) → "1-2A", 10:30~12:00(2B·3) → "2B-3", 칸 안에 「(6A~6B)」처럼 적혀 있으면 그 표기대로 "6A-6B".
    칸 안에 교시 표기(빨간 글씨 등)가 있으면 칸이 그려진 위치보다 그 표기를 먼저 따라요.
  · 가장 최근 해(이번 학기) 시간표는 date·period가 꼭 있어야 해요. 지난 연도는 몰라도 돼요 (교수님 비교용).
  · 앱은 date가 적힌 가장 최근 해를 '이번 학기'로 봐요. 지난 연도 수업에는 date를 적지 않아도 돼요.
- title: 칸에 적힌 강의 제목 그대로. 줄바꿈은 띄어쓰기로 이어 붙이고, 앞뒤를 감싼 「-」는 빼요. 제목 끝 번호는 지우지 않아요 (예: 「-삶의 질1-」 → "삶의 질1").
  · 색 칸 맨 위 굵은 글씨가 과목 이름이고 그 아래가 강의 제목이면, 아래 줄을 title 로 적어요. 제목이 따로 없으면 과목 이름을 그대로 적어요.
  · 한 칸 안에 강의 제목이 두 개 이상(예: 「-법의학의 이해, 검시제도-」 「-부검과 검안, 시체현상-」) 적혀 있으면 강의를 제목마다 따로 적어요. 교시 · 교수는 그 칸 그대로 둘 다 같게 적어요.
  · 시간표에서 **파란 글씨**인 칸은 CP(증례) 강의예요. 제목에 CP가 안 써 있어도 앞에 "CP "를 붙여요. 단, 제목에 「실습」이 들어간 칸은 파란 글씨여도 CP를 붙이지 않아요.
  · TBL 수업이면 끝에 " -TBL"을 붙여요. 예: 파란 글씨 「신생아 황달 (TBL)」 → "CP 신생아 황달 -TBL"
  · 자율학습 · 「(자율)」 · 오리엔테이션 · 실습도 다른 수업과 똑같이 적어요.
- prof: 담당 교수 이름. 여러 명이면 "·"로 이어요 (예: "백정현·김민수"). 「지도교수」·「담당교수」처럼 적혀 있으면 그대로. 없으면 "".
- section: 「(2분반)」처럼 분반이 적혀 있으면 숫자로 (예: 2). 분반이 다른 같은 수업은 항목을 따로 적어요. 분반이 없으면 빼요.
- term: 차수(1차/2차 시험 범위)가 표시돼 있으면 숫자로, 모르면 빼요.
- 「선택교과목1」처럼 학생이 골라 듣는 칸은 name 을 "선택교과목", title 은 칸 이름과 괄호 안 목록을 함께 적어요.
  예: {"date": "12/22", "period": "6-7", "title": "선택교과목1 (의공학/임상의학영양학/의학교육학개요)", "prof": "담당교수"}
- 시험 일정(중간고사·기말고사·1차/2차 시험·「기말시험 예정」·OSCE·종합평가 등)은 lectures 에 넣지 말고, 그 과목의 exams 에 따로 적어요.
  · 이번 학기 시험만 적어요 (지난 연도 시험은 빼요). label = 시험 이름 그대로 (예: "1차", "2차(기말)", "기말시험 예정").
  · date: "월/일". period: 시험 교시 (예: "3-4"). 교시 대신 시각만 적혀 있으면 time: "09:30-11:20" (둘 다 알면 둘 다).
  · 재시험·날짜 미정인 시험은 빼요. 여러 과목 공동 시험이면 해당 과목마다 적어요.
  · 어느 과목 시험도 아닌 학년 전체 시험(전국 기초의학종합평가 · 임상의학종합평가 · 국가시험 모의평가 등)은 맨 아래 "exams" 에 적어요 (events 가 아니에요). 하루 종일이면 period "1-9".
  · 「임상시험」처럼 강의 제목에 '시험'이 들어간 수업은 강의라서 lectures 에 그대로 적어요.
- events: 과목에 속하지 않는 학교 행사 · 시험 기간이에요 (시험 자체는 exams) (체육대회 · 행운제 · 진입식 · 「중간고사(4.16~4.22)」처럼 머리글에 적힌 기간 등).
  · label = 적힌 그대로, date: "월/일". 여러 날이면 end: "월/일". 시간이 정해져 있으면 period 나 time 도 적어요.
- 휴강 · 공휴일 · 명절 · 대체 공휴일 · 「○○ 보강」 안내 문구 · 빈 칸은 빼요. 공휴일은 앱이 따로 넣어요.
- name(과목명): 시간표 맨 위·옆 제목, 과목별 기간 표, 범례, 색·블록 구분, 강의계획서 표지에서 찾아요. LMS에 나오는 과목 이름과 같게 적어야 해요 (예: "생식성장발달 II").
  · 칸에 과목 이름이 없으면 그 주 「개설교과목」 중 강의 내용에 맞는 과목에 넣어요.
  · 시간표 어디에도 과목명이 없으면 지어내거나 비워 두지 말고, JSON을 쓰기 전에 먼저 나에게 물어봐요.
    "이 시간표에는 과목명이 안 보여요. 과목 이름과 기간(예: 생식성장발달 II 10/20~11/14)을 알려 주세요"처럼 묻고, 답을 받은 뒤 날짜로 나눠 적어요.
  · 예외: 이미 앱에 시간표가 있고 주간 수정본 사진처럼 몇 칸만 고치는 경우에는 "name"을 "" 로 두면 앱이 기존 시간표에서 찾아 넣어요.
- 날짜·교시가 확실하지 않은 이번 학기 칸은 빼고, 그냥 생략해요.

다 쓰기 전에
- 모든 과목을 **한 번의 답에 끝까지** 써요. 과목을 나눠 쓰거나 「이어서」를 기다리며 중간에 멈추지 마세요.
- 다 쓴 뒤 날짜마다 PDF와 칸 수 · 교시를 다시 맞춰 보고, 다른 날짜로 옮겨 적은 칸이나 빠진 과목(예: 한 주에 한두 번만 있는 과목)이 없는지 확인해요."""


def prompt_for(cohort=None) -> str:
    """프롬프트의 {학번_줄} 채우기: 학번(입학 연도 두 자리, 예 '25')을 고르면 그 학번 표만 읽게, 아니면 그 줄을 뺌"""
    c = re.sub(r"\D", "", str(cohort or ""))[-2:]
    line = f"읽을 학번: {c}학번 — 표 머리에 <{c}학번> 처럼 학번이 적힌 시간표가 여러 벌이면 이 표만 읽어요." if len(c) == 2 else ""
    return PROMPT.replace("{학번_줄}\n", line + "\n" if line else "")


# ---------------------------------------------------------------- 지난 연도 시간표 (역대 담당 교수 채우기)
PROMPT_PAST = PROMPT          # 예전 이름 (같은 프롬프트로 올해·지난 연도를 함께 읽음)


def _past_items(raw) -> Tuple[Optional[str], List[dict]]:
    raw = load_raw(raw)
    year = None
    rows = []
    if isinstance(raw, dict):
        year = str(raw.get("year") or "").strip() or None
        for c in raw.get("courses") or []:
            for l in c.get("lectures") or []:
                rows.append({**l, "course": l.get("course") or c.get("name") or ""})
        for l in raw.get("lectures") or []:
            rows.append(l)
    elif isinstance(raw, list):
        rows = raw
    return year, rows


def cur_label(raw) -> Optional[str]:
    """붙여넣은 시간표에서 '이번 학기' 칸 이름 = 날짜가 적힌 수업들의 가장 최근 year (없으면 None)"""
    y0, items = _past_items(raw)
    labs = {year_norm(l.get("year") or y0) for l in items if parse_date(l.get("date") or l.get("mmdd"))}
    labs.discard(None)
    return max(labs) if labs else None


def cur_months(raw) -> set:
    """붙여넣은 시간표의 이번 학기 수업이 있는 달 (요일·달력 연도 계산용)"""
    y0, items = _past_items(raw)
    lab = cur_label(raw)
    out = set()
    for l in items:
        dd = parse_date(l.get("date") or l.get("mmdd"))
        if dd and (year_norm(l.get("year") or y0) or lab) == lab:
            out.add(int(dd[:2]))
    return out


def split_years(raw) -> Tuple[List[dict], Dict[str, List[dict]], List[str]]:
    """AI 결과 → (이번 학기 수업, {지난 기록 칸: 수업들}, []).
    이번 학기 = 날짜가 적힌 수업의 가장 최근 year (오늘 날짜와 상관없음). year 가 없는 항목도 이번 학기로."""
    y0, items = _past_items(raw)
    cur_y = cur_label(raw) or YEAR_KEY
    cur, past = [], {}
    for l in items:
        y = year_norm(l.get("year") or y0) or cur_y
        if y == cur_y:
            cur.append(l)
        else:
            past.setdefault(y, []).append(l)
    return cur, past, []


def plan_past(data: list, raw, year: Optional[str] = None) -> Tuple[str, List[dict], List[str]]:
    """지난 연도 시간표 → 역대 교수 칸 변경 목록. 과목·강의는 제목으로 지금 시간표에 맞추고,
    지금 시간표에 없는 강의는 '올해 없는 강의(비교용)' 줄로 추가."""
    y0, items = _past_items(raw)
    year = year_norm(year or y0)
    if not year:
        raise ValueError("몇 년도 시간표인지 알 수 없어요. 연도를 적어 주세요.")
    if year == YEAR_KEY:
        raise ValueError(f"「{year}」는 이번 학기 시간표예요. 이번 학기 시간표는 위의 「시간표 가져오기」로 넣어 주세요.")
    names = [c["name"] for c in data]
    warn, agg = [], {}
    for l in items:
        title = str(l.get("title") or l.get("t") or "").strip()
        if not title or SKIP.search(title):
            continue
        praw = str(l.get("prof") or l.get("profs") or l.get("professor") or "")
        prof = prof_str(praw)
        cname = str(l.get("course") or "")
        ci = next((i for i, n in enumerate(names) if cname and norm_course(n) == norm_course(cname)), None)
        t = nt(title)
        if ci is None:                   # 과목명이 없거나 다르면 제목으로 찾기
            hits = [(i, r) for i, c in enumerate(data) for r in c.get("rows") or [] if nt(r.get("t")) == t]
            if not hits:
                best = max(((i, _overlap(t, nt(r.get("t")))) for i, c in enumerate(data) for r in c.get("rows") or []),
                           key=lambda x: x[1], default=(None, 0))
                hits = [(best[0], None)] if best[1] >= 0.7 else []
            ci = hits[0][0] if hits else None
        if ci is None:
            warn.append(f"「{title}」: 지금 시간표의 어느 과목인지 몰라서 뺐어요")
            continue
        rows = data[ci].get("rows") or []
        ri = next((i for i, r in enumerate(rows) if nt(r.get("t")) == t), None)
        if ri is None and len(t) >= 2:
            sc = sorted(((i, _overlap(t, nt(r.get("t")))) for i, r in enumerate(rows)), key=lambda x: -x[1])
            if sc and sc[0][1] >= 0.75 and (len(sc) == 1 or sc[0][1] - sc[1][1] >= 0.1):
                ri = sc[0][0]
        term = l.get("term")
        try:
            term = int(re.sub(r"\D", "", str(term))) if term not in (None, "") else None
        except ValueError:
            term = None
        k = (ci, ri if ri is not None else "new:" + t)
        a = agg.setdefault(k, {"ci": ci, "ri": ri, "title": rows[ri]["t"] if ri is not None else title,
                               "from": title, "profs": [], "term": term, "star": praw.strip().startswith("*")})
        for p in _profs(prof):
            if p not in a["profs"]:
                a["profs"].append(p)
        if a["term"] is None:
            a["term"] = term
    changes = []
    for a in agg.values():
        c = data[a["ci"]]
        r = c["rows"][a["ri"]] if a["ri"] is not None else None
        before = str((r.get("y") or {}).get(year, "")) if r else ""
        after = ("*" if a.get("star") and a["profs"] else "") + ("·".join(a["profs"]) or "—")   # * = 시간표 대신 기출 출제자 기준
        tm_b = (r.get("tm") or {}).get(year) if r else None
        if r is not None and (before == after or before.lstrip("*") == after) and (a["term"] is None or tm_b == a["term"]):
            continue
        changes.append({"course": c["name"], "title": a["title"], "from": a["from"], "ri": a["ri"], "new": r is None,
                        "before": before, "after": after, "term": a["term"]})
    changes.sort(key=lambda x: (names.index(x["course"]), x["new"], x["ri"] if x["ri"] is not None else 0))
    for i, x in enumerate(changes):
        x["id"] = i
        x["key"] = f"{year}|{x['course']}|{x['title']}"
    return year, changes, warn


def apply_past(data: list, year: str, changes: List[dict], accept: Optional[List[int]] = None) -> list:
    acc = set(accept) if accept is not None else {c["id"] for c in changes}
    out = json.loads(json.dumps(data))
    idx = {c["name"]: c for c in out}
    for x in changes:
        if x["id"] not in acc:
            continue
        c = idx[x["course"]]
        if x["new"]:
            r = {"t": x["title"], "d": "", "g": "", "y": {YEAR_KEY: "—"}, "term": 0, "tm": {}}
            c.setdefault("rows", []).append(r)
        else:
            r = c["rows"][x["ri"]]
        r.setdefault("y", {})[year] = x["after"]
        if x.get("term"):
            r.setdefault("tm", {})[year] = x["term"]
        c["years"] = sorted({str(y) for y in (c.get("years") or [])} | {year, YEAR_KEY}, reverse=True)
    return out


def set_prof(data: list, course: str, ri: int, year: str, value: str) -> list:
    """강좌별 교수 표에서 한 칸 고치기 (지난 연도만)"""
    out = json.loads(json.dumps(data))
    c = next(c for c in out if c["name"] == course)
    r = c["rows"][ri]
    v = prof_str(value)
    r.setdefault("y", {})[year] = v or "—"
    c["years"] = sorted({str(y) for y in (c.get("years") or [])} | {year, YEAR_KEY}, reverse=True)
    return out
