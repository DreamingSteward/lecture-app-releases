"""경북대 LMS(canvas.knu.ac.kr + LearningX) 접속과 자료 목록·다운로드.

로그인 (혼합 방식)
  1) ~/강의록앱/.browser 에 저장된 브라우저 세션으로 canvas 접속 → 바로 되면 끝
  2) 로그인 화면으로 튕기면 → macOS 키체인에 저장한 학번·비밀번호로 자동 로그인
  3) 그래도 안 되면(직접 실행일 때) 브라우저 창을 띄워 직접 로그인하도록 기다림
비밀번호는 파일·코드·로그 어디에도 남기지 않고, 실행할 때마다 키체인에서 꺼내 바로 입력만 한다.
"""
from __future__ import annotations

import os
import re
import subprocess
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

from .matching import Item
from .timetable import norm_course

CANVAS = "https://canvas.knu.ac.kr"
LOGIN_START = "https://lms1.knu.ac.kr/"
SSO_START = "https://lms1.knu.ac.kr/sso/business.php"   # 통합 로그인 버튼이 가는 곳
KEYCHAIN_SERVICE = "강의록앱-KNU"


class LoginNeeded(Exception):
    pass


class SlowServer(Exception):
    pass


class ClosedOnLMS(Exception):
    """학습 기간이 끝나 LMS에서 받을 수 없음 (다시 시도해도 소용없음)"""


class RetryLater(Exception):
    """지금은 안 받아짐 → 다른 강의 먼저 하고 나중에 다시"""


def _short(e) -> str:
    """오류 메시지에서 핵심만 (주소·토큰은 빼고)"""
    t = re.sub(r"https?://\S+", "<주소>", str(e))
    m = re.search(r"Caused by (\w+)\((?:[^']*')?([^'\)]*)", t)
    if m:
        return f"{m.group(1)} {m.group(2)}"[:120]
    return t[:120]


MAX_WAIT = 15 * 60      # 한 파일에 남은 예상 시간이 15분을 넘으면 미룸


# ---------------------------------------------------------------- 키체인
SESSION_CRED: Optional[tuple] = None     # 여러 사람이 쓰는 컴퓨터: 이번에 켠 동안만 (키체인에 안 둠)


def keychain_get() -> Optional[tuple]:
    """저장된 (아이디, 비밀번호): macOS 키체인 / Windows 자격 증명 관리자
    여러 사람이 쓰는 컴퓨터 모드면 저장하지 않고 화면 프로세스의 메모리 → 받기 프로세스는 표준 입력으로 한 번 받음"""
    global SESSION_CRED
    if SESSION_CRED:
        return SESSION_CRED
    if os.environ.pop("LA_LMS_STDIN", None) == "1":
        try:
            import sys
            uid, pw = sys.stdin.readline().rstrip("\n"), sys.stdin.readline().rstrip("\n")
            if uid and pw:
                SESSION_CRED = (uid, pw)
                return SESSION_CRED
        except Exception:
            pass
    from . import secrets_store
    r = secrets_store.get(KEYCHAIN_SERVICE)
    return r if r and r[0] and r[1] else None


# ---------------------------------------------------------------- 세션
class LMS:
    def __init__(self, app_dir: Path, log, interactive: bool):
        self.app_dir = app_dir
        self.log = log
        self.interactive = interactive
        self._pw = None
        self.ctx = None
        self.page = None
        self.token = None
        self.last_status = None
        try:                     # 설정한 정리 폴더의 _실행기록 (바탕 화면 고정이 아니게)
            from . import main as _m
            self.shot_dir = _m.SAVE_ROOT / "_실행기록"
        except Exception:
            self.shot_dir = Path.home() / "Desktop" / "매뉴얼 정리" / "_실행기록"

    # -- 브라우저
    def _open(self, headless: bool):
        from playwright.sync_api import sync_playwright
        if self._pw is None:
            self._pw = sync_playwright().start()
        if self.ctx is not None:
            try:
                self.ctx.close()
            except Exception:
                pass
            self.ctx = None
        prof = getattr(self, "profile_dir", None) or (self.app_dir / ".browser")      # 학교 인증 전용은 빈 임시 프로필
        last = None
        for attempt in range(4):
            if attempt:
                self._free_profile(prof)
            try:
                self.ctx = self._pw.chromium.launch_persistent_context(
                    str(prof), headless=headless, accept_downloads=True,
                    locale="ko-KR", viewport={"width": 1280, "height": 860})
                break
            except Exception as e:      # 이전 브라우저가 프로필을 아직 잡고 있음
                last = e
                time.sleep(1.5)
        else:
            raise last
        self.page = self.ctx.pages[0] if self.ctx.pages else self.ctx.new_page()
        # 로그인 중 뜨는 알림창(예: '이미 로그인된 곳이 있습니다. 계속할까요?')은 기본값이 '취소'라
        # 로그인이 조용히 취소된다 → 확인을 누르고 내용을 기록
        for pg in self.ctx.pages:
            pg.on("dialog", self._on_dialog)
        self.ctx.on("page", lambda pg: pg.on("dialog", self._on_dialog))

    def _on_dialog(self, d):
        try:
            self.log(f"   · 알림창: {d.message.strip()[:100]} → 확인")
            d.accept()
        except Exception:
            pass

    @staticmethod
    def _free_profile(prof: Path):
        """남아 있는 앱 전용 브라우저를 끄고 프로필 잠금 파일을 지운다 (평소 쓰는 Chrome은 건드리지 않음)."""
        try:
            if os.name == "nt":
                # Windows: 이 프로필을 쓰는 크롬만 골라 끔 (평소 쓰는 크롬은 그대로)
                subprocess.run(["powershell", "-NoProfile", "-Command",
                                "Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like '*" + str(prof).replace("'", "''") +
                                "*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }"], capture_output=True, timeout=30)
            else:
                subprocess.run(["pkill", "-f", f"user-data-dir={prof}"], capture_output=True)
        except Exception:
            pass
        time.sleep(1)
        for name in ("SingletonLock", "SingletonSocket", "SingletonCookie"):
            try:
                (prof / name).unlink()
            except FileNotFoundError:
                pass
            except Exception:
                pass

    def close(self):
        try:
            if self.ctx:
                self.ctx.close()
        finally:
            if self._pw:
                self._pw.stop()

    def _on_canvas(self) -> bool:
        u = self.page.url
        return u.startswith(CANVAS) and "/login" not in u

    def _try_session(self) -> bool:
        try:
            self.page.goto(CANVAS + "/", wait_until="domcontentloaded", timeout=45000)
            self.page.wait_for_load_state("networkidle", timeout=20000)
        except Exception:
            pass
        return self._logged_in()

    def _api_ok(self) -> bool:
        r = self.ctx.request.get(CANVAS + "/api/v1/users/self", headers={"Accept": "application/json"})
        return r.ok

    def _auto_login(self) -> bool:
        """자동 로그인 · 학교가 「User has not active status」를 주면(프로필에 남은 통합인증 쿠키가 꼬인 경우)
        학교 로그인 쿠키만 지우고 같은 실행에서 딱 1번 다시"""
        ok = self._auto_login1()
        if not ok and self.auto_why == "inactive" and not getattr(self, "_inactive_retried", False):
            self._inactive_retried = True
            try:
                self.ctx.clear_cookies(domain=re.compile(r"(^|\.)knu\.ac\.kr$"))
                self.log("   · 학교 로그인 기록(쿠키)이 꼬여 보여서 지우고 한 번 더 로그인해요")
            except Exception as e:
                self.log(f"   · 학교 로그인 쿠키를 지우지 못했어요: {type(e).__name__}")
                return False
            self._auto_fail_t = 0
            ok = self._auto_login1()
        return ok

    def _auto_login1(self) -> bool:
        """경북대 통합로그인(appfn.knu.ac.kr) 아이디 로그인 → LMS → canvas."""
        cred = getattr(self, "cred_override", None) or keychain_get()   # cred_override: 설정에서 저장 전에 맞는지 확인할 때 (저장 안 된 값)
        self.auto_why = ""                    # 실패 이유: "server" 학교 서버가 안 열림 · "cred" 아이디·비밀번호가 안 맞아 보임
        if not cred:
            self.log("키체인에 로그인 정보가 없어요 (설치 때 저장 안 함)")
            return False
        # 방금(5분 안) 자동 로그인이 실패했으면 또 시도하지 않음 (실행 중 몇 분마다 반복되는 것 방지)
        if time.time() - getattr(self, "_auto_fail_t", 0) < 300:
            return False
        filled = inactive = False
        uid, pw = cred
        p = self.page
        trail: List[str] = []           # 어느 주소들을 거쳤는지 (주소 뒤의 ?… 는 빼고) → 실패 원인 찾기용
        def _nav(fr):
            try:
                if fr == p.main_frame:
                    u = fr.url.split("?")[0]
                    if not trail or trail[-1] != u:
                        trail.append(u)
            except Exception:
                pass
        p.on("framenavigated", _nav)
        try:
            # LMS 로그인 화면(xn-sso) → '통합 로그인' → 학교 통합인증 화면.
            # 통합인증 서버가 잠깐 응답이 없으면 버튼을 눌러도 그대로 → 쉬었다가 최대 3번
            for attempt in range(3):
                if attempt:
                    self.log(f"   · 통합로그인 화면이 안 열림 (학교 로그인 서버 응답 없음) → 20초 뒤 다시 ({attempt + 1}/3)")
                    p.wait_for_timeout(20000)
                p.goto(LOGIN_START + "login", wait_until="domcontentloaded", timeout=60000)
                try:
                    p.locator("a[href*='sso/business.php']").locator("visible=true").first.click(timeout=15000)
                except Exception:
                    p.goto(SSO_START, wait_until="domcontentloaded", timeout=60000)
                # 통합인증에 이미 로그인돼 있으면 아이디 칸 없이 바로 LMS로 돌아온다
                for _ in range(45):
                    p.wait_for_timeout(1000)
                    if p.locator("#idpw_id").count() or "appfn.knu.ac.kr" not in p.url and "/login" not in p.url:
                        break
                if p.locator("#idpw_id").count() or "/login" not in p.url:
                    break
            if not p.locator("#idpw_id").count():
                self._go_canvas()
                if self._logged_in():
                    return True
                raise TimeoutError(f"아이디 칸이 안 나옴 ({p.url.split('?')[0]})")
            p.fill("#idpw_id", uid)
            p.fill("#idpw_pw", pw)
            del pw
            p.click("#btn-login")
            filled = True
            trail.append("(아이디 입력 후 로그인 누름)")
            p.wait_for_timeout(2500)
            self._shot(p, "로그인직후")             # 학교 쪽 안내/오류 문구 확인용 (비밀번호 칸은 비움)
            try:                                    # 「사용자 인증에 실패하였습니다. (failed. User has not active status)」
                inactive = "not active status" in (p.locator("body").inner_text(timeout=3000) or "")
            except Exception:
                inactive = False
            for _ in range(30):                     # 통합로그인 → LMS 로 돌아올 때까지
                p.wait_for_timeout(1000)
                if "appfn.knu.ac.kr" not in p.url:
                    break
            p.wait_for_load_state("domcontentloaded", timeout=30000)
            self._go_canvas()
        except Exception as e:
            self.log(f"자동 로그인 중 문제: {type(e).__name__} {str(e)[:80]}")
        ok = self._logged_in()
        try:
            p.remove_listener("framenavigated", _nav)
        except Exception:
            pass
        if not ok:
            try:
                self.auto_why = "inactive" if filled and inactive else \
                    "cred" if filled and ("appfn.knu.ac.kr" in p.url or p.locator("#idpw_id").count()) else ("server" if not filled else "cred")
            except Exception:
                self.auto_why = "server" if not filled else "cred"
            self._auto_fail_t = time.time()
            self.log("   · 자동 로그인 경로: " + " → ".join(trail[-12:]))
            self._shot(p, "자동로그인실패")
            self.log(f"자동 로그인 실패 화면 저장: {p.url.split('?')[0]}")
        return ok

    def _shot(self, p, tag: str):
        """화면 저장 (비밀번호 칸은 비우고) · 여러 사람이 쓰는 컴퓨터에선 남기지 않음 (학번이 보이는 화면)"""
        if SESSION_CRED:
            return
        try:
            p.evaluate("document.querySelectorAll('input[type=password]').forEach(e=>e.value='')")
            d = self.shot_dir
            d.mkdir(parents=True, exist_ok=True)
            p.screenshot(path=str(d / f"{datetime.now():%Y-%m-%d_%H%M%S}_{tag}.png"))
        except Exception:
            pass

    def _go_canvas(self):
        """LMS(lms1) 로그인 상태에서 canvas 로 넘어가기: '나의 과목 바로가기'(보이는 것) → 안 되면 직접 이동."""
        p = self.page
        for _ in range(3):
            if self._logged_in():
                break
            try:
                if p.url.startswith(LOGIN_START):
                    link = p.locator("a:visible", has_text="나의 과목 바로가기").first
                    if link.count():
                        link.click(timeout=10000)
                        p.wait_for_timeout(4000)
                        continue
                p.goto(CANVAS + "/", wait_until="domcontentloaded", timeout=60000)
                p.wait_for_timeout(3000)
            except Exception:
                p.wait_for_timeout(2000)
        cp = self._canvas_page()
        if cp:
            self.page = cp

    def _canvas_page(self):
        """열린 탭 중 canvas에 들어가 있는 탭 (새 탭으로 열려도 찾는다)."""
        for pg in reversed(self.ctx.pages):
            try:
                if pg.url.startswith(CANVAS) and "/login" not in pg.url:
                    return pg
            except Exception:
                pass
        return None

    def _logged_in(self) -> bool:
        """주소와 상관없이 canvas API가 열리면 로그인된 것."""
        try:
            return self._api_ok()
        except Exception:
            return False

    def _manual_login(self) -> bool:
        self._open(headless=False)
        self.page.goto(LOGIN_START)
        print("\n  ▶ 열린 브라우저 창에서 경북대 통합 로그인을 해 주세요. (최대 5분 기다려요)")
        print("    로그인 후 「나의 과목 바로가기」까지 눌러 주면 더 빨라요.\n")
        clicked = 0
        for i in range(150):
            try:
                self.page.wait_for_timeout(2000)      # time.sleep 대신: 브라우저 소식을 계속 받음
                if self._logged_in():
                    cp = self._canvas_page()
                    if cp:
                        self.page = cp
                    else:
                        self.page.goto(CANVAS + "/", wait_until="domcontentloaded", timeout=60000)
                    print("    로그인 확인! 진행할게요.\n", flush=True)
                    return True
                # LMS 메인으로 돌아와 있으면 '나의 과목 바로가기'를 대신 눌러 canvas 로그인까지 이어감
                for pg in list(self.ctx.pages):
                    if clicked < 3 and pg.url.startswith(LOGIN_START) and "/login" not in pg.url \
                            and pg.locator("a:visible", has_text="나의 과목 바로가기").count():
                        pg.locator("a:visible", has_text="나의 과목 바로가기").first.click(timeout=10000)
                        clicked += 1
                        break
                if i and i % 15 == 0:
                    print(f"    기다리는 중… ({i * 2}초)", flush=True)
            except Exception:
                pass
        return False

    def login(self):
        self._open(headless=True)
        if self._try_session():
            self.log("로그인: 저장된 세션 사용")
        elif self._auto_login():
            self.log("로그인: 키체인으로 자동 로그인")
        elif self.interactive and self._manual_login():
            self.log("로그인: 직접 로그인 (이번 실행은 열린 창으로 계속 진행해요)")
        else:
            raise LoginNeeded()
        self.token = self._xn_token()

    def _xn_token(self, force: bool = False) -> str:
        """LearningX API 토큰(xn_api_token 쿠키). 강의실 화면을 열면 새로 발급된다.
        한 시간쯤 지나면 만료되므로, 401이 나면 force=True 로 다시 받는다."""
        def get():
            for c in self.ctx.cookies(CANVAS):
                if c["name"] == "xn_api_token":
                    return c["value"]
        old = get()
        t = None if force else old
        if not t:
            if force and not self._logged_in():     # canvas 로그인 자체가 풀렸으면 다시 로그인
                if not self._auto_login():
                    raise LoginNeeded()
            cs = self.courses()
            if cs:
                pg = self.ctx.new_page()
                try:
                    pg.goto(f"{CANVAS}/courses/{cs[0]['id']}/external_tools/46", wait_until="networkidle", timeout=60000)
                    pg.wait_for_timeout(1500)
                finally:
                    pg.close()
                t = get()
        if not t:
            raise RuntimeError("LearningX 토큰을 얻지 못했어요")
        if force and t != old:
            self.log("   · LMS 접속 토큰 새로 받음")
        return t

    # -- API
    def _get(self, path: str, xn: bool = False, need: bool = False):
        """need=True: 목록 요청 — 서버 오류(5xx) · 로그인 풀림(401) · 너무 많음(429)이면 「없음」이 아니라 오류로
        (예전엔 None → 「자료 0개」로 조용히 넘어가 강의록이 빠졌음). 404 · 403 · 400 은 그대로 「없음」"""
        h = {"Accept": "application/json"}
        if xn:
            h["Authorization"] = "Bearer " + self.token
        r = self.ctx.request.get(CANVAS + path, headers=h, timeout=60000)
        # 토큰 만료 → 새로 받아서 한 번 더 (자료 정보 주소는 만료 때 401 대신 400/403을 주기도 함)
        if xn and (r.status == 401 or (r.status in (400, 403) and time.time() - getattr(self, "_tok_t", 0) > 120)):
            self._tok_t = time.time()                # 400/403은 진짜 오류일 수도 있어 2분에 한 번만 새로 받음
            self.token = self._xn_token(force=True)
            h["Authorization"] = "Bearer " + self.token
            r = self.ctx.request.get(CANVAS + path, headers=h, timeout=60000)
        if r.status == 401 and not xn and self._auto_login():
            r = self.ctx.request.get(CANVAS + path, headers=h, timeout=60000)
        self.last_status = r.status
        if not r.ok:
            if need and (r.status >= 500 or r.status in (401, 429)):
                raise RuntimeError(f"LMS 목록 요청 실패 (HTTP {r.status})")
            return None
        t = r.text()
        if t.startswith("while(1);"):
            t = t[9:]
        import json
        return json.loads(t)

    def courses(self) -> List[dict]:
        cs = self._get("/api/v1/courses?per_page=100&enrollment_state=active", need=True) or []
        return [c for c in cs if c.get("name")]

    def tab_ids(self, course_id: int) -> Dict[str, int]:
        """과목 메뉴의 '강의실'·'게시판' 외부도구 번호 (과목마다 같지만 혹시 몰라 확인)."""
        out = {}
        for t in self._get(f"/api/v1/courses/{course_id}/tabs", need=True) or []:
            m = re.search(r"external_tools/(\d+)", t.get("html_url", ""))
            if m and t.get("label") in ("강의실", "게시판"):
                out[t["label"]] = int(m.group(1))
        return out

    # -- 강의실
    def classroom_items(self, course: dict) -> List[Item]:
        mods = self._get(f"/learningx/api/v1/courses/{course['id']}/modules?include_detail=true", xn=True, need=True) or []
        items, seen = [], set()
        for m in mods:
            mdate = _module_date(m.get("title", ""))
            for mi in m.get("module_items") or []:
                cd = mi.get("content_data") or {}
                if cd.get("item_content_type") != "commons":
                    continue
                icd = cd.get("item_content_data") or {}
                cid = icd.get("content_id")
                fn = icd.get("file_name") or ""
                # 학습 기간이 끝난 항목: LMS가 자료 번호를 'not_open'으로 숨기고 사이트에서도 못 받는다
                closed = cid in (None, "", "not_open") or cd.get("lecture_period_status") == "closed"
                # 아직 공개 전(GRAT·퀴즈처럼 수업 시간에 여는 자료)도 LMS가 'not_open'으로 숨김 → 날짜로 구분
                notyet = (closed and cd.get("lecture_period_status") != "closed" and bool(mdate)
                          and _mdate_day(mdate) >= datetime.now().date())   # 해를 넘기는 학기도 맞게 (예전: 월일 글자 비교)
                mkey = f"m{mi.get('module_item_id')}"
                key = mkey if closed else cid
                if not fn or not key or (key, mdate) in seen:
                    continue
                seen.add((key, mdate))
                items.append(Item(
                    source="강의실", course=course["name"], uid=f"{key}@{mdate or ''}",
                    title=mi.get("title") or icd.get("title") or fn, filename=fn,
                    uploaded=icd.get("last_updated_date") or icd.get("registered_date") or "",
                    date_hint=mdate, size=int(icd.get("total_file_size") or 0),
                    fetch=({"kind": "closed", "why": "notyet" if notyet else "closed"} if closed
                           else {"kind": "commons", "content_id": cid, "mkey": f"{mkey}@{mdate or ''}"})))
        return items

    # -- 게시판 (강의자료실만)
    def board_items(self, course: dict, include=("강의자료", "자료실")) -> List[Item]:
        cid = course["id"]
        boards = self._get(f"/learningx/api/v1/learningx_board/courses/{cid}/boards", xn=True, need=True) or []
        items = []
        for b in boards:
            if not any(k in (b.get("title") or "") for k in include):
                continue
            page = 1
            while True:
                d = self._get(f"/learningx/api/v1/learningx_board/courses/{cid}/boards/{b['id']}/posts?page={page}&per_page=50", xn=True, need=True) or {}
                for p in d.get("items") or []:
                    if not p.get("attachment_count"):
                        continue
                    det = self._get(f"/learningx/api/v1/learningx_board/courses/{cid}/boards/{b['id']}/posts/{p['id']}", xn=True, need=True) or {}
                    for a in det.get("attachments") or []:
                        items.append(Item(
                            source="게시판", course=course["name"], uid=str(a.get("canvas_file_id") or a.get("id")),
                            title=p.get("title") or "", filename=a.get("filename") or "",
                            uploaded=p.get("updated_at") or p.get("created_at") or "", size=int(a.get("filesize") or 0),
                            fetch={"kind": "canvas_file", "url": a.get("url")}))
                pg = d.get("pagination") or {}
                if not pg or pg.get("current_page", 1) >= pg.get("last_page", 1):
                    break
                page += 1
        return items

    # -- 다운로드
    def download(self, it: Item, dest: Path, quick: bool = False) -> Path:
        """quick=True: 첫 바퀴용. 짧게 한 번만 해 보고 안 되면 바로 뒤로 미룬다."""
        dest.parent.mkdir(parents=True, exist_ok=True)
        referer = CANVAS + "/"
        if it.fetch["kind"] == "closed":
            if it.fetch.get("why") == "notyet":
                raise ClosedOnLMS("LMS에 아직 공개 전 (교수님이 정한 시간에 열려요)")
            raise ClosedOnLMS("LMS 학습 기간 종료 (사이트에서도 못 받음)")
        if it.fetch["kind"] == "commons":
            try:
                info = self._get(f"/learningx/api/v1/commons/contents?content_id={it.fetch['content_id']}", xn=True) or {}
            except LoginNeeded:
                raise
            except Exception as e:                      # 연결 끊김(ECONNRESET 등) → 나중에 다시
                raise RetryLater(f"LMS 자료 정보 요청 끊김 ({type(e).__name__})")
            res = info.get("result") or {}
            url = res.get("download_url")
            size = int(res.get("original_file_length") or 0)
            if not url:
                raise RetryLater(f"LMS 자료 정보를 못 받음 (HTTP {self.last_status})")
            # 자료 저장소(lcms)는 자료 보기 화면을 한 번 거쳐야 받기를 허락함 → 그 화면을 먼저 연다
            share = res.get("share_url") or f"https://lcms.knu.ac.kr/em/{it.fetch['content_id']}"
            referer = share
            self._visit(share, 8000 if quick else 20000)
        else:
            url = it.fetch["url"]
            size = it.size
        # 한 번씩만 시도하고, 안 되면 RetryLater → 다른 강의를 다 한 뒤 다시 돌아온다
        status = None
        try:
            status = self._stream(url, referer, dest, it.filename, quick)
            if status == 200:
                return dest
        except SlowServer:
            raise
        except Exception as e:
            status = f"{type(e).__name__}: {_short(e)}"
            if not self.wait_online():
                raise RuntimeError("인터넷이 20분 넘게 끊겨 있었어요 → 다음 실행 때 다시")
        if isinstance(status, int):
            status = f"학교 자료 서버 응답 HTTP {status}" + (" (서버 과부하/점검)" if status in (502, 503, 504) else "")
        if quick:                                     # 첫 바퀴는 여기서 바로 미룸 (느린 대기 없이)
            raise RetryLater(status)
        # 서버가 아예 응답을 안 하는 경우(시간 초과)는 브라우저로 받아도 똑같이 막힌다 → 바로 미룸
        if "Timeout" in str(status) or "timed out" in str(status):
            raise RetryLater(status)
        # 파이썬 쪽 연결이 막히면 앱 브라우저의 연결로 같은 주소를 받아 본다 (최대 5분)
        try:
            limit = int(min(5 * 60, 120 + size / (30 * 1024)) * 1000)
            r = self.ctx.request.get(url, headers={"Referer": referer}, timeout=limit)
            body = r.body() if r.ok and not r.headers.get("content-type", "").startswith("text/html") else b""
            if body:                     # 빈 응답은 실패로 (빈 파일이 남으면 다음부터 '받아 둔 파일'로 착각함)
                part = dest.with_name(dest.name + ".part")
                part.write_bytes(body)
                part.replace(dest)
                return dest
            status = f"{status} / 브라우저 연결 HTTP {r.status}"
        except Exception as e:
            status = f"{status} / 브라우저 연결 {type(e).__name__}"
        raise RetryLater(status)

    def wait_online(self, max_wait: int = 20 * 60) -> bool:
        """와이파이가 끊겼으면 다시 연결될 때까지 기다린다 (최대 20분)."""
        import requests
        t0, told = time.time(), False
        while True:
            try:
                requests.head(CANVAS + "/", timeout=5)
                if told:
                    self.log("   · 인터넷 다시 연결됨 → 이어서 진행")
                return True
            except Exception:
                if not told:
                    self.log("   · 인터넷 연결이 끊겼어요 → 다시 연결될 때까지 기다릴게요 (최대 20분)")
                    told = True
                if time.time() - t0 > max_wait:
                    return False
                time.sleep(10)

    def _stream(self, url: str, referer: str, dest: Path, label: str, quick: bool = False) -> int:
        """큰 파일(수십 MB)도 끊기지 않게 조금씩 받아 바로 파일에 쓴다.
        전체 시간 제한 없이, 2분 동안 한 조각도 안 오면 그때 실패로 본다."""
        import requests
        jar = {c["name"]: c["value"] for c in self.ctx.cookies(url)}
        tmp = dest.with_suffix(dest.suffix + ".part")
        with requests.get(url, headers={"Referer": referer, "User-Agent": self.page.evaluate("navigator.userAgent")},
                          cookies=jar, stream=True, timeout=(10, 20) if quick else (30, 120), allow_redirects=True) as r:
            if r.status_code != 200 or r.headers.get("content-type", "").startswith("text/html"):
                return r.status_code if r.status_code != 200 else 415
            total = int(r.headers.get("content-length") or 0)
            got, last, t0 = 0, 0.0, time.time()
            with open(tmp, "wb") as f:
                for chunk in r.iter_content(1 << 16):
                    f.write(chunk)
                    got += len(chunk)
                    el = time.time() - t0
                    cb = getattr(self, "on_progress", None)
                    if cb and time.time() - getattr(self, "_cb_t", 0) > 2:            # 앱 화면용 진행 (2초마다)
                        self._cb_t = time.time()
                        try:
                            cb(got, total, got / max(el, 0.1))
                        except Exception:
                            pass
                    if total > 20 << 20 and time.time() - last > 15:     # 20MB 넘으면 진행 표시
                        last = time.time()
                        print(f"     받는 중 {label[:30]} {got >> 20}/{total >> 20}MB ({got / 1024 / max(el, 1):.0f}KB/s)", flush=True)
                    # 학교 서버가 심하게 느릴 때: 이 파일은 다음 실행으로 미루고 다른 강의부터 처리
                    if quick and el > 30 and total and (total - got) / max(got / el, 1) > 300:
                        f.close()
                        tmp.unlink(missing_ok=True)
                        raise RetryLater(f"느림 ({got / 1024 / el:.0f}KB/s, {total >> 20}MB)")
                    if el > 90 and total:
                        rate = got / el
                        if (total - got) / max(rate, 1) > MAX_WAIT:
                            f.close()
                            tmp.unlink(missing_ok=True)
                            raise SlowServer(f"학교 서버가 너무 느림 ({rate / 1024:.0f}KB/s, {total >> 20}MB) → 다음 실행 때 다시")
            if total and got < total:
                tmp.unlink(missing_ok=True)
                return 206
        tmp.replace(dest)
        return 200

    def _visit(self, url: str, timeout: int = 20000):
        pg = self.ctx.new_page()
        try:
            pg.goto(url, wait_until="domcontentloaded", timeout=timeout)
            pg.wait_for_timeout(1500)
        except Exception:
            pass
        finally:
            pg.close()

    def _browser_download(self, url: str, referer: str, dest: Path) -> Path:
        pg = self.ctx.new_page()
        try:
            try:
                pg.goto(referer, wait_until="domcontentloaded", timeout=60000)
            except Exception:
                pass
            with pg.expect_download(timeout=45000) as dl:
                pg.evaluate("u => { const a = document.createElement('a'); a.href = u; a.download = ''; "
                            "document.body.appendChild(a); a.click(); }", url)
            dl.value.save_as(str(dest))
            if dest.stat().st_size == 0:
                raise RuntimeError("빈 파일")
            return dest
        finally:
            pg.close()


def _mdate_day(mmdd: str):
    """'1201' → 이번 학기 기준 실제 날짜 (2학기의 1 · 2월은 다음 해). 날짜가 이상하면 아주 먼 미래(= 공개 전으로 봄)"""
    from datetime import date
    from .timetable import cal_year
    try:
        mo, dd = int(mmdd[:2]), int(mmdd[2:])
        return date(cal_year(mo), mo, dd)
    except Exception:
        return date.max


def _module_date(title: str) -> Optional[str]:
    """'10월 19일(월)_출석부 표기 주차: 1주차' → '1019', '2주차(10/8)' → '1008'."""
    m = re.search(r"(\d{1,2})\s*월\s*(\d{1,2})\s*일", title) or re.search(r"(?<!\d)(\d{1,2})/(\d{1,2})(?!\d)", title)
    if m:
        return f"{int(m.group(1)):02d}{int(m.group(2)):02d}"
    return None


def course_map(courses: List[dict], timetable_courses: List[str]) -> Dict[str, dict]:
    """시간표 과목명 → canvas 과목."""
    by = {norm_course(c["name"]): c for c in courses}
    return {t: by[norm_course(t)] for t in timetable_courses if norm_course(t) in by}
