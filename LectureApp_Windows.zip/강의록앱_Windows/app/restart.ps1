﻿# 강의록앱 화면(백그라운드 서버)을 새로 켜요 — 업데이트가 안 보이거나 화면이 이상할 때
$App = Split-Path -Parent $MyInvocation.MyCommand.Path
$VPyw = Join-Path $App '.venv\Scripts\pythonw.exe'
Get-CimInstance Win32_Process -Filter "Name='pythonw.exe'" | Where-Object { $_.CommandLine -like '*lecture_app_run.pyw*화면*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
Start-Sleep 1
Start-Process -FilePath $VPyw -ArgumentList @('"' + (Join-Path $App 'lecture_app_run.pyw') + '"', '화면', '--상주', '--창없이') -WorkingDirectory $App
